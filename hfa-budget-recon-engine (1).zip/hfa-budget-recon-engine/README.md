# hfa-budget-recon-engine

Deterministic resolution of **label variances** between a borrower's latest draw file and the bank's
existing budget lines, which LOB users typed as free-form text.

For every borrower line the engine reports:

- **Which system line(s) it is.** Resolved, resolved-confirm-once, ambiguous, or new.
- **How it was decided.** The rule that fired and a plain-English reason.
- **How the free-form system label was read.** Notes removed, abbreviations expanded, typos fixed.
- **Whether the amounts agree,** checked separately for budget and paid-to-date, and whether the category agrees.

No machine learning and no randomness: the same inputs and configuration always give the same answer, in any
input order. Every result carries a fingerprint that proves it.

## The problem

```
System (typed by LOB)          Borrower's latest file
---------------------          ----------------------
Elecrtical                     Electrical
Drs & Windows                  Doors & Windows
Site Work - per CO #2          Sitework
A&E + Survey                   Architect / Engineering / Survey
3rd party reports              Appraisal / Environmental /
Title & studies                Market Study / Title & Recording
Misc 1                         Developer Fee
Permits & Impact   42,850      Permits & Impact Fees   48,250
```

## How it works (six deterministic steps)

| Step | What happens | Example |
|---|---|---|
| **A. Read** | Find the table in Excel by column names on any sheet; read section headings as categories; check every line, subtotal and grand total adds up. CSV is read as-is | "HARD COSTS" heading → category HARD |
| **B. Clean each label** | 1. Remove notes (CO numbers, dates, "rev.", line numbers). 2. Expand phrases and abbreviations from `config/abbreviations.json`. 3. Fix a typo only if **exactly one** known word is one edit away. 4. Drop filler words. 5. Map to a standard cost code (`config/cost_codes.json`), or infer the category | "Site Work - per CO #2" → `site work` → HC-0100 |
| **C. Align detail** | If only one side lists contractor trades, add them up to the summary line | 9 trades → "Construction contract" |
| **D. Match by rules** | Rules M01–M06 run in order. Each only sees lines that earlier rules left unresolved. Strictest first | see table below |
| **E. Regroup** | Inside one category, lines left over on both sides that total the same budget **and** paid-to-date were simply grouped differently | 2 system lines ↔ 4 borrower lines |
| **F. Classify** | Status, amount checks (budget, paid-to-date), category check, and a sentence saying why | "Labels are the same after cleanup ('electrical')" |

### Matching rules (`config/match_rules.json`)

| Rule | Matches when | Confidence |
|---|---|---|
| M01 | A mapping a person confirmed earlier | 1.00 |
| M02 | Cleaned labels are the same, or both map to the same unique cost code, **and** budget and paid-to-date are equal | 1.00 |
| M03 | Budget and paid-to-date are identical and unique, but the words differ | 0.75–1.00: below 0.95 means confirm |
| M04 | One borrower line = the sum of 2–6 system lines on **every** amount | 0.82 + up to 0.15 for shared words |
| M05 | One system line = the sum of 2–6 borrower lines on every amount | same |
| M06 | Labels are similar enough (≥ 0.80, or the same cost code) but amounts differ | the similarity score |
| S01 | Regrouped within a category (step E) | 0.90: confirm |

**Why the matching can be trusted:**

- **Amounts must agree on every column for any amount-based match.** Round numbers ($25k + $50k = $75k) can't create a false summation, because paid-to-date has to add up too.
- **Two possible groupings means no guess.** If two different groups explain a line equally well, the line is marked AMBIGUOUS.
- **The optimal pairing is computed, not chosen first-come.** When several lines share the same amounts, they are paired by label similarity using an optimal assignment (Hungarian algorithm). The result doesn't depend on which line came first.
- **Generic labels need a person.** "Misc 1" never resolves automatically; at most it's resolved-confirm.

### Result statuses

| Status | Meaning | Action |
|---|---|---|
| RESOLVED | Matched with confidence ≥ 0.95 | None |
| RESOLVED_CONFIRM | Matched, but on weaker evidence (amounts only, a regroup, a generic label) | A person confirms once; feed it back as a confirmed mapping (M01) |
| AMBIGUOUS | More than one valid explanation | A person picks one |
| NEW | No system line has this meaning or these amounts | A new line, or a decision |

**Amount checks** (the borrower file is the reference):

| Check | Meaning |
|---|---|
| AGREE | Amounts match |
| ROUNDING | Under $1 apart |
| SYSTEM_TYPO (pattern) | Transposed digits, a dropped or extra digit, or a decimal shift in the system value |
| DIFFERENT | Anything else: a budget change or a system error to investigate |

## Run

```bash
pip install -e ".[test]"
python -m pytest -q                      # 66 tests
```

### JSON in, JSON out (the integration path)

Two input records, one result:

```bash
python -m recon_engine resolve-json \
       --system   samples/minimal/system_record.json \
       --borrower samples/minimal/borrower_record.json \
       --out      samples/minimal/result.json
```

From Python (an ADK tool, a FastAPI route, a batch job):

```python
from recon_engine.json_io import resolve_records
result = resolve_records(system_record, borrower_record)   # dict, dict -> dict
```

**`system_record.json`** holds the bank's current lines, exactly as LOB keyed them:

```json
{"schema": "hfa.system_record.v1", "loan_id": "HFA-DEMO", "as_of_draw": 18,
 "lines": [{"key": "S3", "label": "Elecrtical", "category": "HARD", "budget": 610000.00, "paid_to_date": 305000.00}]}
```

**`borrower_record.json`** holds the borrower's latest draw. `totals` is optional; if given, the lines must add up to it:

```json
{"schema": "hfa.borrower_record.v1", "loan_id": "HFA-DEMO", "draw_no": 19,
 "lines": [{"key": "3", "label": "Electrical", "category": "HARD", "budget": 610000.00,
            "paid_to_date": 305000.00, "this_draw": 61000.00}],
 "totals": {"budget": 610000.00, "paid_to_date": 305000.00, "this_draw": 61000.00}}
```

Required fields per line: `key`, `label` and `budget`. Amounts can be numbers or strings (`"$610,000.00"`).

**`result.json`** has `status` set to `COMPLETE`, `NEEDS_REVIEW` or `REJECTED`. It also carries `summary`, `input_checks`,
`unresolved_system_lines`, `category_tieout`, `fingerprint`, and `decisions`. There is one decision per matched group, so
a 3-into-1 summation is a single decision:

```json
{"decision_id": "G005", "status": "RESOLVED", "rule_id": "M05", "confidence": 0.97,
 "action": "None. Matched automatically.",
 "explanation": "'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): ...",
 "borrower_lines": [{"key": "5", "label": "Architect", "budget": 180000.0, "...": "..."}, "... Engineering, Survey"],
 "system_lines":   [{"key": "S5", "label": "A&E + Survey", "reads_as": "architecture engineering survey", "...": "..."}],
 "label_cleanup": ["'a&e' -> 'architecture engineering'"],
 "checks": {"budget":       {"result": "AGREE", "borrower": 287500.0, "system": 287500.0, "difference": 0.0},
            "paid_to_date": {"result": "AGREE", "borrower": 201000.0, "system": 201000.0, "difference": 0.0},
            "category": "AGREE"}}
```

The JSON Schemas for all three files are in `schemas/`. Bad input is never guessed at; it returns `REJECTED`, with
`input_checks` saying why. Possible reasons: a missing budget, a non-numeric amount, lines that don't add up to `totals`,
a line whose math is wrong, mismatched loan ids, or no lines.

To turn today's Excel/CSV files into the two records:

```bash
python -m recon_engine to-json --borrower samples/HFA-2001_borrower_draw19.xlsx \
       --system samples/HFA-2001_system_lines.csv --out samples --loan-id HFA-2001
```

### Excel / CSV in, reports out (for reviewers)

```bash
python -m recon_engine resolve --borrower samples/HFA-2001_borrower_draw19.xlsx \
       --system samples/HFA-2001_system_lines.csv --out results/HFA-2001
```

Outputs: `resolution.xlsx` (one row per borrower line, colour-coded), `resolution.md`, `resolution.json`.
Both paths give the same decisions and the same fingerprint.

Exit codes (both commands):

- **0:** every borrower line resolved automatically
- **1:** some lines need a person
- **2:** the input is rejected or doesn't add up

## Results on the samples (all figures invented)

| Sample | Borrower lines | Resolved | Confirm once | Ambiguous | New | System lines left over |
|---|---|---|---|---|---|---|
| HFA-1001: 29 free-form system lines vs draw 7 | 33 | 30 | 2 | 0 | 1 | 0 |
| HFA-2001: SOR after 18 hand-keyed draws vs draw 19 | 33 | 27 | 5 | 0 | 1 | 0 |

**What the HFA-2001 sample covers:**

- **Resolved automatically:** typos, abbreviations, notes in labels, a 3-into-1 merge, and a contractor-trade line matched on its cost code ("HVAC/Mech" → HVAC).
- **Sent to confirm:** the 2-into-4 regrouping and "Misc 1".
- **New:** the Solar PV line.
- **Amount checks:** flagged a transposed-digit typo, 4 budget differences (2 of them SOR keying errors, which the larger package tells apart from real changes using the previous draw file), 3 paid-to-date differences, a dropped-digit typo, and 1 line filed under the wrong category.

## Determinism, tested

`tests/test_engine.py` resolves each sample, then resolves it again 20 times with both input files shuffled into
random order. The fingerprint is identical every time. Also covered:

- every kind of label variance
- summation in both directions, and the round-number trap
- regrouping and trade roll-up
- duplicate amounts and generic labels
- every amount-check pattern and the category check
- the CLI

That's 38 tests. `tests/test_json_io.py` adds 28 more:

- the JSON path gives the same fingerprint as the Excel/CSV path
- all three files validate against their schemas
- shuffled JSON gives identical decisions
- amounts as strings and old field names are accepted
- each kind of bad input is rejected
- the `resolve-json` and `to-json` commands

## Configure, don't code

- **New abbreviation:** `config/abbreviations.json`
- **New line type or synonym:** `config/cost_codes.json`
- **Rule order, or switching a rule off:** `config/match_rules.json`
- **Thresholds and tolerances:** `config/settings.json`

The configuration hash is printed on every result.

## Package layout

```
recon_engine/
  extract.py     read Excel / CSV, footing checks
  normalize.py   label cleanup, cost codes, categories, explain()
  similarity.py  string similarity (stdlib only)
  hierarchy.py   trade roll-up
  grouping.py    multi-column subset-sum for summations
  matcher.py     the ordered rules M01-M06
  typos.py       amount typo patterns
  resolver.py    steps A-F, statuses, explanations, fingerprint
  report.py      Excel / Markdown / JSON reports
  json_io.py     JSON contract: two records in, result out; resolve_records()
config/          abbreviations, cost codes, match rules, settings
schemas/         JSON Schemas: system_record, borrower_record, resolution_result
samples/         minimal/ demo JSON pair; two loans as Excel+CSV and as JSON records
results/         the reports produced from the samples
tests/           66 tests
```

This package is the label-resolution core of the larger `hfa-budget-recon` reference implementation, which
adds budget restructuring, posting, the review queue and the SOR update.
