# Label resolution - HFA-2001_borrower_draw19.xlsx vs HFA-2001_system_lines.csv

33 borrower lines: **27 resolved**, **5 resolved (confirm once)**, **0 ambiguous**, **1 new**. System lines left unresolved: 0.

Rules used: {'-': 1, 'M02': 15, 'M03': 1, 'M05': 3, 'M06': 9, 'S01': 4}  
Budget check: {'AGREE': 25, 'DIFFERENT': 4, 'SYSTEM_TYPO': 1}  
Paid-to-date check: {'AGREE': 26, 'DIFFERENT': 3, 'SYSTEM_TYPO': 1}  
Category check: {'AGREE': 29, 'DIFFERS': 1}  
Fingerprint a9594a49d00c54ec (engine 1.0.0, config 5c1518d6827e)

| Status | Borrower line | System line(s) | Rule | Conf. | Budget | Paid-to-date | Why |
|---|---|---|---|---|---|---|---|
| NEW | Solar PV System | - | - | 0.00 | n/a | n/a | No system line has this meaning or these amounts: a new line, or a system line too different to match safely. |
| RESOLVED_CONFIRM | Appraisal | 3rd party reports + Title & studies | S01 | 0.90 | AGREE (as a group) | AGREE (as a group) | SOFT: system lines '3rd party reports', 'Title & studies' and borrower lines 'Appraisal', 'Environmental (Phase I)', 'Market Study', 'Title & Recording' both total $200,000.00 budget and $120,000.00 paid-to-date; the lines were grouped differently when keyed. |
| RESOLVED_CONFIRM | Environmental (Phase I) | 3rd party reports + Title & studies | S01 | 0.90 | AGREE (as a group) | AGREE (as a group) | SOFT: system lines '3rd party reports', 'Title & studies' and borrower lines 'Appraisal', 'Environmental (Phase I)', 'Market Study', 'Title & Recording' both total $200,000.00 budget and $120,000.00 paid-to-date; the lines were grouped differently when keyed. |
| RESOLVED_CONFIRM | Market Study | 3rd party reports + Title & studies | S01 | 0.90 | AGREE (as a group) | AGREE (as a group) | SOFT: system lines '3rd party reports', 'Title & studies' and borrower lines 'Appraisal', 'Environmental (Phase I)', 'Market Study', 'Title & Recording' both total $200,000.00 budget and $120,000.00 paid-to-date; the lines were grouped differently when keyed. |
| RESOLVED_CONFIRM | Title & Recording | 3rd party reports + Title & studies | S01 | 0.90 | AGREE (as a group) | AGREE (as a group) | SOFT: system lines '3rd party reports', 'Title & studies' and borrower lines 'Appraisal', 'Environmental (Phase I)', 'Market Study', 'Title & Recording' both total $200,000.00 budget and $120,000.00 paid-to-date; the lines were grouped differently when keyed. |
| RESOLVED_CONFIRM | Developer Fee | Misc 1 | M03 | 0.75 | AGREE | AGREE | Budget $1,650,000.00 and paid-to-date $495,000.00 are identical and unique; the wording differs ('Misc 1' vs 'Developer Fee'). |
| RESOLVED | Land Acquisition | Land Acq. | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('land acquisition'); budget and paid-to-date agree. |
| RESOLVED | Acquisition Closing Costs | Acq Closing | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('acquisition closing'); budget and paid-to-date agree. |
| RESOLVED | Sitework | Site Work - per CO #2 | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code HC-0100; budget and paid-to-date agree. |
| RESOLVED | Concrete | CONCRETE | M02 | 1.00 | AGREE | AGREE | Labels are identical; budget and paid-to-date agree. |
| RESOLVED | Masonry | Masonary | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('masonry'); budget and paid-to-date agree. |
| RESOLVED | Rough Carpentry / Framing | Rough Carp/Framing | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('rough carpentry framing'); budget and paid-to-date agree. |
| RESOLVED | Roofing | Roofng | M06 | 1.00 | AGREE | DIFFERENT | Labels match (same cost code T-07); amounts differ, see the amount check. |
| RESOLVED | Doors & Windows | Drs & Windows | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('doors windows'); budget and paid-to-date agree. |
| RESOLVED | Finishes | Finishes (rev 9/14) | M06 | 1.00 | DIFFERENT | AGREE | Labels match (same cost code T-09); amounts differ, see the amount check. |
| RESOLVED | Plumbing | Plumbng | M06 | 1.00 | DIFFERENT | AGREE | Labels match (same cost code T-22); amounts differ, see the amount check. |
| RESOLVED | HVAC | HVAC/Mech | M06 | 0.97 | DIFFERENT | AGREE | Labels match (same cost code T-23); amounts differ, see the amount check. |
| RESOLVED | Electrical | Elecrtical | M06 | 1.00 | AGREE | DIFFERENT | Labels match (same cost code T-26); amounts differ, see the amount check. |
| RESOLVED | General Contractor Overhead & Profit | GC OH&P / Gen Req | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code HC-0800; budget and paid-to-date agree. |
| RESOLVED | Hard Cost Contingency | Constuction Contg 5% | M06 | 0.97 | DIFFERENT | AGREE | Labels match (same cost code HC-0900); amounts differ, see the amount check. |
| RESOLVED | Architect | A&E + Survey | M05 | 0.97 | AGREE | AGREE | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Engineering | A&E + Survey | M05 | 0.97 | see B15 (same group) | see B15 (same group) | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Survey | A&E + Survey | M05 | 0.97 | see B15 (same group) | see B15 (same group) | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Permits & Impact Fees | Permits & Impact | M06 | 1.00 | SYSTEM_TYPO (TRANSPOSED_DIGITS) | AGREE | Labels match (same cost code SC-0200); amounts differ, see the amount check. |
| RESOLVED | Legal | Legal (outside counsel) | M06 | 0.97 | AGREE | SYSTEM_TYPO (DROPPED_DIGIT) | Labels match (same cost code SC-0300); amounts differ, see the amount check. |
| RESOLVED | Builder's Risk Insurance | Bldrs Risk Ins | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('builders risk insurance'); budget and paid-to-date agree. |
| RESOLVED | Construction Interest Reserve | Constr. Int. Reserve | M06 | 1.00 | AGREE | DIFFERENT | Labels match (same cost code SC-0700); amounts differ, see the amount check. |
| RESOLVED | Financing Fees / Cost of Issuance | Fin Fees / COI | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('financing issuance'); budget and paid-to-date agree. |
| RESOLVED | HFA / Tax Credit Fees | HFA Fees | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code SC-0800; budget and paid-to-date agree. |
| RESOLVED | Marketing / Lease-Up | Mktg/Lease Up | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('marketing lease up'); budget and paid-to-date agree. |
| RESOLVED | Soft Cost Contingency | Soft Contg | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('soft contingency'); budget and paid-to-date agree. |
| RESOLVED | Operating Reserve | Op Reserve | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('operating reserve'); budget and paid-to-date agree. |
| RESOLVED | Replacement Reserve | Repl Reserve | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('replacement reserve'); budget and paid-to-date agree. |