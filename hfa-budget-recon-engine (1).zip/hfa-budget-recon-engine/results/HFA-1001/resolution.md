# Label resolution - HFA-1001_borrower_draw07.xlsx vs HFA-1001_system_lines.csv

33 borrower lines: **30 resolved**, **2 resolved (confirm once)**, **0 ambiguous**, **1 new**. System lines left unresolved: 0.

Rules used: {'-': 1, 'M02': 23, 'M05': 5, 'M06': 4}  
Budget check: {'AGREE': 26, 'DIFFERENT': 2, 'SYSTEM_TYPO': 1}  
Paid-to-date check: {'AGREE': 28, 'SYSTEM_TYPO': 1}  
Category check: {'AGREE': 28, 'n/a': 1}  
Fingerprint f99b1d6ba7c29d54 (engine 1.0.0, config 5c1518d6827e)

| Status | Borrower line | System line(s) | Rule | Conf. | Budget | Paid-to-date | Why |
|---|---|---|---|---|---|---|---|
| NEW | Solar PV System | - | - | 0.00 | n/a | n/a | No system line has this meaning or these amounts: a new line, or a system line too different to match safely. |
| RESOLVED_CONFIRM | Appraisal | 3rd Pty Rpts | M05 | 0.82 | AGREE | AGREE | '3rd Pty Rpts' equals the sum of 2 borrower lines (Environmental (Phase I) + Appraisal): budget $75,000.00, paid-to-date $55,000.00 on both sides. |
| RESOLVED_CONFIRM | Environmental (Phase I) | 3rd Pty Rpts | M05 | 0.82 | see B20 (same group) | see B20 (same group) | '3rd Pty Rpts' equals the sum of 2 borrower lines (Environmental (Phase I) + Appraisal): budget $75,000.00, paid-to-date $55,000.00 on both sides. |
| RESOLVED | Land Acquisition | Land Acq. | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('land acquisition'); budget and paid-to-date agree. |
| RESOLVED | Acquisition Closing Costs | Acq Closing | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('acquisition closing'); budget and paid-to-date agree. |
| RESOLVED | Sitework | Site Work - per CO #2 | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code HC-0100; budget and paid-to-date agree. |
| RESOLVED | Concrete | CONCRETE | M02 | 1.00 | AGREE | AGREE | Labels are identical; budget and paid-to-date agree. |
| RESOLVED | Masonry | Masonary | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('masonry'); budget and paid-to-date agree. |
| RESOLVED | Rough Carpentry / Framing | Rough Carp/Framing | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('rough carpentry framing'); budget and paid-to-date agree. |
| RESOLVED | Roofing | Roofng | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('roofing'); budget and paid-to-date agree. |
| RESOLVED | Doors & Windows | Drs & Windows | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('doors windows'); budget and paid-to-date agree. |
| RESOLVED | Finishes | Finishes (rev 9/14) | M06 | 1.00 | DIFFERENT | AGREE | Labels match (same cost code T-09); amounts differ, see the amount check. |
| RESOLVED | Plumbing | Plumbng | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('plumbing'); budget and paid-to-date agree. |
| RESOLVED | HVAC | HVAC/Mech | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code T-23; budget and paid-to-date agree. |
| RESOLVED | Electrical | Elecrtical | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('electrical'); budget and paid-to-date agree. |
| RESOLVED | General Contractor Overhead & Profit | GC OH&P / Gen Req | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code HC-0800; budget and paid-to-date agree. |
| RESOLVED | Hard Cost Contingency | Constuction Contg 5% | M06 | 0.97 | DIFFERENT | AGREE | Labels match (same cost code HC-0900); amounts differ, see the amount check. |
| RESOLVED | Architect | A&E + Survey | M05 | 0.97 | AGREE | AGREE | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Engineering | A&E + Survey | M05 | 0.97 | see B15 (same group) | see B15 (same group) | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Survey | A&E + Survey | M05 | 0.97 | see B15 (same group) | see B15 (same group) | 'A&E + Survey' equals the sum of 3 borrower lines (Architect + Engineering + Survey): budget $287,500.00, paid-to-date $201,000.00 on both sides. |
| RESOLVED | Permits & Impact Fees | Permits & Impact | M06 | 1.00 | SYSTEM_TYPO (TRANSPOSED_DIGITS) | AGREE | Labels match (same cost code SC-0200); amounts differ, see the amount check. |
| RESOLVED | Legal | Legal (outside counsel) | M06 | 0.97 | AGREE | SYSTEM_TYPO (DROPPED_DIGIT) | Labels match (same cost code SC-0300); amounts differ, see the amount check. |
| RESOLVED | Market Study | Mkt Study | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('market study'); budget and paid-to-date agree. |
| RESOLVED | Title & Recording | Title/Rec. | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('title recording'); budget and paid-to-date agree. |
| RESOLVED | Builder's Risk Insurance | Bldrs Risk Ins | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('builders risk insurance'); budget and paid-to-date agree. |
| RESOLVED | Construction Interest Reserve | Constr. Int. Reserve | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('construction interest reserve'); budget and paid-to-date agree. |
| RESOLVED | Financing Fees / Cost of Issuance | Fin Fees / COI | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('financing issuance'); budget and paid-to-date agree. |
| RESOLVED | HFA / Tax Credit Fees | HFA Fees | M02 | 1.00 | AGREE | AGREE | Both labels map to cost code SC-0800; budget and paid-to-date agree. |
| RESOLVED | Marketing / Lease-Up | Mktg/Lease Up | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('marketing lease up'); budget and paid-to-date agree. |
| RESOLVED | Developer Fee | Dev Fee | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('developer'); budget and paid-to-date agree. |
| RESOLVED | Soft Cost Contingency | Soft Contg | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('soft contingency'); budget and paid-to-date agree. |
| RESOLVED | Operating Reserve | Op Reserve | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('operating reserve'); budget and paid-to-date agree. |
| RESOLVED | Replacement Reserve | Repl Reserve | M02 | 1.00 | AGREE | AGREE | Labels are the same after cleanup ('replacement reserve'); budget and paid-to-date agree. |