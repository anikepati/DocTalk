"""JSON contract: two records in, one result out.

    system_record.json    the bank's existing budget lines for the loan (free-form labels keyed by LOB)
    borrower_record.json  the borrower's latest draw (the budget lines exactly as the borrower sent them)
    -> result.json        one decision per matched group, plus checks, summary and a fingerprint

Amounts may be JSON numbers (2400000.00) or strings ("2,400,000.00"); internally they are integer cents.
Every amount in the result is a number in dollars with two decimals.

Use from Python (e.g. inside an ADK tool or a FastAPI route):

    from recon_engine.json_io import resolve_records
    result = resolve_records(system_record, borrower_record)       # dicts in, dict out
"""
from __future__ import annotations

import json
from pathlib import Path

from .config import load_config
from .extract import validate
from .models import Line
from .money import to_cents
from .resolver import Resolver

SYSTEM_SCHEMA = "hfa.system_record.v1"
BORROWER_SCHEMA = "hfa.borrower_record.v1"
RESULT_SCHEMA = "hfa.resolution_result.v1"
CATEGORIES = {"ACQUISITION", "HARD", "SOFT", "OTHER"}

ACTIONS = {
    "RESOLVED": "None. Matched automatically.",
    "RESOLVED_CONFIRM": "Confirm once. The confirmed mapping is then applied automatically on later draws (rule M01).",
    "AMBIGUOUS": "Pick the correct system line(s); the engine found more than one valid explanation.",
    "NEW": "Decide: a genuinely new budget line, or a system line too different to match safely.",
}


def _usd(cents):
    return None if cents is None else round(cents / 100, 2)


def _check(rows, code, line, detail, severity="BLOCKING"):
    rows.append({"code": code, "severity": severity, "line": line, "detail": detail})


def _amount(raw, field, key, side, checks, default=0):
    if raw is None:
        return default
    try:
        return to_cents(raw)
    except ValueError:
        _check(checks, "BAD_AMOUNT", key, f"{side} {field}: not an amount: {raw!r}")
        return default


def _first(d, *names):
    for n in names:
        if n in d and d[n] is not None:
            return d[n]
    return None


def parse_record(obj: dict, side: str):
    """-> (lines, header, checks). side = 'system' | 'borrower'. Never raises on bad content; reports it."""
    checks = []
    expected = SYSTEM_SCHEMA if side == "system" else BORROWER_SCHEMA
    if not isinstance(obj, dict):
        _check(checks, "NOT_AN_OBJECT", "", f"{side} record must be a JSON object")
        return [], {}, checks
    if obj.get("schema") not in (None, expected):
        _check(checks, "WRONG_SCHEMA", "", f"{side} record schema is {obj.get('schema')!r}, expected {expected!r}")
    header = {k: obj.get(k) for k in ("loan_id", "draw_no", "as_of_draw", "period_to", "source") if k in obj}
    raw_lines = obj.get("lines")
    if not isinstance(raw_lines, list) or not raw_lines:
        _check(checks, "NO_LINES", "", f"{side} record has no 'lines' array")
        return [], header, checks
    lines = []
    for i, r in enumerate(raw_lines, start=1):
        if not isinstance(r, dict):
            _check(checks, "BAD_LINE", f"#{i}", f"{side} line {i} is not an object")
            continue
        key = str(r.get("key") or f"{side[0].upper()}{i:02d}")
        label = str(r.get("label") or "").strip()
        if not label:
            _check(checks, "MISSING_LABEL", key, f"{side} line {key} has no label")
            continue
        cat = (r.get("category") or "").upper() or None
        if cat and cat not in CATEGORIES:
            _check(checks, "UNKNOWN_CATEGORY", key, f"{cat!r} is not one of {sorted(CATEGORIES)}; ignored", "WARNING")
            cat = None
        if _first(r, "budget") is None:
            _check(checks, "MISSING_BUDGET", key, f"{side} line {key} ({label}) has no budget")
        budget = _amount(_first(r, "budget"), "budget", key, side, checks)
        prior = _amount(_first(r, "paid_to_date", "prior"), "paid_to_date", key, side, checks)
        current = _amount(_first(r, "this_draw", "current"), "this_draw", key, side, checks)
        bal_raw = _first(r, "balance_to_finish", "balance")
        balance = _amount(bal_raw, "balance_to_finish", key, side, checks, None) if bal_raw is not None else None
        lines.append(Line(key=key, label=label, budget=budget, prior=prior, current=current,
                          reported_balance=balance, cost_code=r.get("cost_code") or None, category=cat,
                          source_ref=f"{side}_record:lines[{i - 1}]"))
    totals = {}
    for name, col in (("budget", "budget"), ("paid_to_date", "prior"), ("this_draw", "current")):
        v = (obj.get("totals") or {}).get(name)
        if v is not None:
            totals[col] = _amount(v, f"totals.{name}", "TOTAL", side, checks)
    checks += validate(lines, totals)
    if side == "system":  # a system line has no draw in progress; its own math is not the borrower's footing
        checks = [c for c in checks if c["code"] != "LINE_MATH"]
    return lines, header, checks


def _rule_id(rule):
    return rule.split(" ")[0] if rule and rule != "-" else None


def _decisions(result, bor_by_key, sys_by_key):
    """Group the per-borrower-line rows into one decision per matched group (NEW lines stand alone)."""
    groups, order = {}, []
    for r in result.resolutions:
        gid = r.group_id or f"N-{r.borrower_key}"
        if gid not in groups:
            groups[gid] = []
            order.append(gid)
        groups[gid].append(r)
    out = []
    for gid in order:
        rows = groups[gid]
        head = rows[0]
        sys_lines = [sys_by_key[k] for k in head.system_keys if k in sys_by_key]
        bor_lines = [bor_by_key[r.borrower_key] for r in rows]
        sb = sum(l.budget for l in sys_lines) if sys_lines else None
        sp = sum(l.prior for l in sys_lines) if sys_lines else None
        bb, bp = sum(l.budget for l in bor_lines), sum(l.prior for l in bor_lines)
        has_sys = head.status != "NEW"
        out.append({
            "decision_id": gid if head.group_id else f"NEW-{head.borrower_key}",
            "status": head.status,
            "action": ACTIONS[head.status],
            "rule_id": _rule_id(head.rule),
            "rule": None if head.rule == "-" else head.rule,
            "relation": head.relation or None,
            "confidence": head.confidence,
            "explanation": head.explanation,
            "borrower_lines": [{"key": l.key, "label": l.label, "category": l.category, "budget": _usd(l.budget),
                                "paid_to_date": _usd(l.prior), "this_draw": _usd(l.current),
                                "reads_as": r.borrower_reads_as}
                               for l, r in zip(bor_lines, rows)],
            "system_lines": [{"key": l.key, "label": l.label, "category": l.category, "budget": _usd(l.budget),
                              "paid_to_date": _usd(l.prior), "reads_as": ra}
                             for l, ra in zip(sys_lines, head.system_reads_as or [None] * len(sys_lines))],
            "label_cleanup": head.label_cleanup,
            "checks": {
                "budget": {"result": head.budget_check, "borrower": _usd(bb), "system": _usd(sb),
                           "difference": _usd(bb - sb) if has_sys and sb is not None else None},
                "paid_to_date": {"result": head.prior_check, "borrower": _usd(bp), "system": _usd(sp),
                                 "difference": _usd(bp - sp) if has_sys and sp is not None else None},
                "category": head.category_check or "n/a",
            },
        })
    return out


def _rejected(header, input_checks, cfg, version):
    return {"schema": RESULT_SCHEMA, **header, "engine_version": version, "config_version": cfg.version,
            "status": "REJECTED", "reason": "Input records failed validation; nothing was resolved.",
            "input_checks": input_checks, "summary": None, "decisions": [], "unresolved_system_lines": [],
            "category_tieout": [], "fingerprint": None}


def resolve_records(system_record: dict, borrower_record: dict, cfg=None) -> dict:
    """The whole engine behind one call: two JSON objects in, the result JSON object out."""
    from . import __version__
    cfg = cfg or load_config()
    s_lines, s_head, s_checks = parse_record(system_record, "system")
    b_lines, b_head, b_checks = parse_record(borrower_record, "borrower")
    input_checks = [{"record": "system", **c} for c in s_checks] + [{"record": "borrower", **c} for c in b_checks]
    header = {"loan_id": b_head.get("loan_id") or s_head.get("loan_id"), "draw_no": b_head.get("draw_no"),
              "system_as_of_draw": s_head.get("as_of_draw")}
    if s_head.get("loan_id") and b_head.get("loan_id") and s_head["loan_id"] != b_head["loan_id"]:
        input_checks.append({"record": "both", "code": "LOAN_MISMATCH", "severity": "BLOCKING", "line": "",
                             "detail": f"system loan {s_head['loan_id']} vs borrower loan {b_head['loan_id']}"})
    if any(c["severity"] == "BLOCKING" for c in input_checks):
        return _rejected(header, input_checks, cfg, __version__)

    result = Resolver(cfg).resolve(s_lines, b_lines)
    sm = result.summary()
    decisions = _decisions(result, {l.key: l for l in b_lines}, {l.key: l for l in s_lines})
    status = "COMPLETE" if sm["resolved"] == sm["borrower_lines"] and not sm["system_lines_unresolved"] \
        else "NEEDS_REVIEW"
    return {
        "schema": RESULT_SCHEMA,
        **header,
        "engine_version": __version__,
        "config_version": cfg.version,
        "status": status,
        "input_checks": input_checks,
        "summary": {**sm, "decisions": len(decisions),
                    "needs_review": sum(1 for d in decisions if d["status"] != "RESOLVED")},
        "decisions": decisions,
        "unresolved_system_lines": [{"key": u["key"], "label": u["label"], "category": u["category"],
                                     "budget": _usd(u["budget"]), "paid_to_date": _usd(u["prior"]),
                                     "reads_as": u["reads_as"],
                                     "action": "No borrower line matches it: removed, renamed beyond "
                                               "recognition, or merged into a NEW line."}
                                    for u in result.unresolved_system_lines],
        "category_tieout": [{"category": t["category"],
                             "budget": {"system": _usd(t["system_budget"]), "borrower": _usd(t["borrower_budget"]),
                                        "difference": _usd(t["budget_gap"])},
                             "paid_to_date": {"system": _usd(t["system_prior"]),
                                              "borrower": _usd(t["borrower_prior"]),
                                              "difference": _usd(t["prior_gap"])}}
                            for t in result.category_tieout],
        "fingerprint": result.fingerprint(),
    }


def resolve_files(system_path, borrower_path, out_path=None, config_dir=None) -> dict:
    sys_obj = json.loads(Path(system_path).read_text())
    bor_obj = json.loads(Path(borrower_path).read_text())
    res = resolve_records(sys_obj, bor_obj, load_config(config_dir))
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        Path(out_path).write_text(json.dumps(res, indent=2) + "\n")
    return res


def lines_to_record(lines, side, **header) -> dict:
    """Convert extracted lines (from Excel/CSV) into a record, e.g. to produce sample JSON or feed an API."""
    rows = []
    for l in lines:
        r = {"key": l.key, "label": l.label, "category": l.category, "budget": _usd(l.budget),
             "paid_to_date": _usd(l.prior)}
        if side == "borrower":
            r["this_draw"] = _usd(l.current)
            if l.reported_balance is not None:
                r["balance_to_finish"] = _usd(l.reported_balance)
        if l.cost_code:
            r["cost_code"] = l.cost_code
        rows.append(r)
    rec = {"schema": SYSTEM_SCHEMA if side == "system" else BORROWER_SCHEMA, **header, "lines": rows}
    if side == "borrower":
        rec["totals"] = {"budget": _usd(sum(l.budget for l in lines)),
                         "paid_to_date": _usd(sum(l.prior for l in lines)),
                         "this_draw": _usd(sum(l.current for l in lines))}
    return rec
