"""CLI

    python -m recon_engine resolve --borrower <latest draw .xlsx|.csv> --system <system lines .csv> [--out DIR]
    python -m recon_engine resolve-json --system system_record.json --borrower borrower_record.json --out result.json
    python -m recon_engine to-json --borrower <file> --system <file> --out DIR   (Excel/CSV -> the two JSON records)

Writes DIR/resolution.xlsx, DIR/resolution.md, DIR/resolution.json and prints the Markdown summary.
Exit code 0 = every borrower line resolved automatically; 1 = some lines need a person (confirm / ambiguous / new);
2 = the borrower file does not foot (fix the file first).
"""
import argparse
import sys
from pathlib import Path

from .config import load_config
from .extract import read_any
from .report import to_excel, to_json, to_markdown
from .resolver import Resolver


def main(argv=None):
    ap = argparse.ArgumentParser(prog="recon_engine")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("resolve", help="resolve borrower lines against free-form system lines")
    p.add_argument("--borrower", required=True)
    p.add_argument("--system", required=True)
    p.add_argument("--out", default="out")
    p.add_argument("--config")
    j = sub.add_parser("resolve-json", help="system_record.json + borrower_record.json -> result.json")
    j.add_argument("--system", required=True)
    j.add_argument("--borrower", required=True)
    j.add_argument("--out", default="result.json")
    j.add_argument("--config")
    t = sub.add_parser("to-json", help="convert Excel/CSV inputs into the two JSON records")
    t.add_argument("--borrower", required=True)
    t.add_argument("--system", required=True)
    t.add_argument("--out", default=".")
    t.add_argument("--loan-id")
    a = ap.parse_args(argv)
    if a.cmd == "resolve-json":
        return _resolve_json(a)
    if a.cmd == "to-json":
        return _to_json(a)
    cfg = load_config(a.config)
    b, s = read_any(a.borrower), read_any(a.system)
    for name, ext in (("borrower", b), ("system", s)):
        for c in ext.checks:
            print(f"{name} file {c['severity']}: {c['code']} {c['detail']}")
    if b.blocking:
        print("The borrower file does not foot. Fix or confirm it before resolving.")
        return 2
    result = Resolver(cfg).resolve(s.lines, b.lines)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    md = to_markdown(result, f"Label resolution - {Path(a.borrower).name} vs {Path(a.system).name}")
    (out / "resolution.md").write_text(md)
    to_json(result, out / "resolution.json")
    to_excel(result, out / "resolution.xlsx", cfg.s("match_rules"))
    print(md)
    sm = result.summary()
    return 0 if sm["resolved"] == sm["borrower_lines"] else 1


def _resolve_json(a):
    from .json_io import resolve_files
    res = resolve_files(a.system, a.borrower, a.out, a.config)
    print(f"{res['loan_id']} draw {res['draw_no']}: {res['status']}")
    for c in res["input_checks"]:
        print(f"  {c['record']} {c['severity']}: {c['code']} {c['detail']}")
    if res["summary"]:
        sm = res["summary"]
        print(f"  {sm['borrower_lines']} borrower lines: {sm['resolved']} resolved, {sm['resolved_confirm']} confirm, "
              f"{sm['ambiguous']} ambiguous, {sm['new']} new; {sm['system_lines_unresolved']} system lines unresolved")
        print(f"  fingerprint {res['fingerprint']}")
    print(f"  wrote {a.out}")
    return {"COMPLETE": 0, "NEEDS_REVIEW": 1, "REJECTED": 2}[res["status"]]


def _to_json(a):
    import json
    from .json_io import lines_to_record
    b, s = read_any(a.borrower), read_any(a.system)
    loan = a.loan_id or b.meta.get("loan_id")
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    stem = loan or "loan"
    sys_rec = lines_to_record(s.lines, "system", loan_id=loan,
                              as_of_draw=(b.meta.get("draw_no") - 1) if b.meta.get("draw_no") else None)
    bor_rec = lines_to_record(b.lines, "borrower", loan_id=loan, draw_no=b.meta.get("draw_no"),
                              period_to=b.meta.get("period_to"))
    for name, rec in (("system_record", sys_rec), ("borrower_record", bor_rec)):
        path = out / f"{stem}_{name}.json"
        path.write_text(json.dumps(rec, indent=2) + "\n")
        print(f"wrote {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
