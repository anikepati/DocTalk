"""Data structures. Amounts are integer cents everywhere; never floats."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Line:
    key: str
    label: str
    budget: int = 0
    prior: int = 0  # paid / work completed to date before this draw
    current: int = 0  # this draw's request
    retainage: int = 0
    reported_balance: Optional[int] = None
    cost_code: Optional[str] = None
    category: Optional[str] = None
    source_ref: str = ""
    norm_label: str = ""
    tokens: tuple = ()
    children: tuple = ()
    aliases: tuple = ()
    group_aliases: tuple = ()

    @property
    def balance(self) -> int:
        return self.budget - self.prior - self.current

    def col(self, name: str) -> int:
        return getattr(self, name)

    def vector(self, cols) -> tuple:
        return tuple(self.col(c) for c in cols)


@dataclass
class MatchGroup:
    comparison: str
    relation: str  # "1:1", "N:1" (several system lines -> one borrower line), "1:N" (one system line -> several)
    left: list  # system lines
    right: list  # borrower lines
    pass_name: str
    confidence: float
    notes: list = field(default_factory=list)
    rule_id: str = ""
    rule_name: str = ""

    def total(self, side: str, col: str) -> int:
        return sum(l.col(col) for l in getattr(self, side))


@dataclass
class ReconException:
    """A finding raised while preparing lines (e.g. trade detail that does not add up to its summary line)."""
    reason_code: str
    severity: str
    comparison: str
    message: str
    impact_cents: int = 0
    line_keys: list = field(default_factory=list)
