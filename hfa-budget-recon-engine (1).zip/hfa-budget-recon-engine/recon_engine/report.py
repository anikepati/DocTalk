"""Reports: Excel workbook for reviewers, Markdown summary, JSON for systems."""
from __future__ import annotations

import json

from .money import usd

STATUS_FILL = {"RESOLVED": "D1E7DD", "RESOLVED_CONFIRM": "FFF3CD", "AMBIGUOUS": "F8D7DA", "NEW": "F8D7DA"}
CHECK_FILL = {"AGREE": "D1E7DD", "ROUNDING": "D1E7DD", "SYSTEM_TYPO": "FFF3CD", "DIFFERENT": "F8D7DA",
              "DIFFERS": "F8D7DA"}


def _m(c):
    return None if c is None else c / 100


def to_markdown(result, title="Label resolution") -> str:
    s = result.summary()
    out = [f"# {title}", "",
           f"{s['borrower_lines']} borrower lines: **{s['resolved']} resolved**, **{s['resolved_confirm']} resolved "
           f"(confirm once)**, **{s['ambiguous']} ambiguous**, **{s['new']} new**. System lines left unresolved: "
           f"{s['system_lines_unresolved']}.", "",
           f"Rules used: {s['by_rule']}  ", f"Budget check: {s['budget_check']}  ",
           f"Paid-to-date check: {s['paid_to_date_check']}  ", f"Category check: {s['category_check']}  ",
           f"Fingerprint {result.fingerprint()} (engine {result.engine_version}, config {result.config_version})", "",
           "| Status | Borrower line | System line(s) | Rule | Conf. | Budget | Paid-to-date | Why |",
           "|---|---|---|---|---|---|---|---|"]
    order = {"AMBIGUOUS": 0, "NEW": 1, "RESOLVED_CONFIRM": 2, "RESOLVED": 3}
    for r in sorted(result.resolutions, key=lambda x: (order[x.status], x.borrower_key)):
        out.append(f"| {r.status} | {r.borrower_label} | {' + '.join(r.system_labels) or '-'} | {r.rule.split(' ')[0]} | "
                   f"{r.confidence:.2f} | {r.budget_check} | {r.prior_check} | {r.explanation} |")
    if result.unresolved_system_lines:
        out += ["", "## System lines not resolved", ""]
        out += [f"- {x['label']} ({usd(x['budget'])})" for x in result.unresolved_system_lines]
    return "\n".join(out)


def to_json(result, path):
    with open(path, "w") as f:
        json.dump(result.to_dict(), f, indent=2, default=str)


def to_excel(result, path, match_rules=()):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Resolution"
    ws.append(["Group", "Status", "Borrower item", "Borrower line", "Category", "Resolved to system line(s)", "Rule",
               "Relation", "Confidence", "Why (plain English)", "How the system label was read",
               "Budget - borrower", "Budget - system", "Budget check", "Paid-to-date - borrower",
               "Paid-to-date - system", "Paid-to-date check", "Category check"])
    for r in result.resolutions:
        ws.append([r.group_id, r.status, r.borrower_key, r.borrower_label, r.borrower_category,
                   " + ".join(r.system_labels), r.rule, r.relation, r.confidence, r.explanation,
                   "; ".join(r.label_cleanup), _m(r.budget), _m(r.system_budget), r.budget_check, _m(r.prior),
                   _m(r.system_prior), r.prior_check, r.category_check])
        row = ws.max_row
        ws.cell(row, 2).fill = PatternFill("solid", fgColor=STATUS_FILL[r.status])
        for col, val in ((14, r.budget_check), (17, r.prior_check), (18, r.category_check)):
            key = (val or "").split(" ")[0]
            if key in CHECK_FILL:
                ws.cell(row, col).fill = PatternFill("solid", fgColor=CHECK_FILL[key])
        for col in (12, 13, 15, 16):
            ws.cell(row, col).number_format = '#,##0.00'
        for col in (10, 11):
            ws.cell(row, col).alignment = Alignment(wrap_text=True, vertical="top")

    s2 = wb.create_sheet("Summary")
    s = result.summary()
    for k, v in (("Borrower lines", s["borrower_lines"]), ("Resolved automatically", s["resolved"]),
                 ("Resolved - confirm once", s["resolved_confirm"]), ("Ambiguous (not guessed)", s["ambiguous"]),
                 ("New borrower lines", s["new"]), ("System lines not resolved", s["system_lines_unresolved"]),
                 ("Budget check", json.dumps(s["budget_check"])), ("Paid-to-date check", json.dumps(s["paid_to_date_check"])),
                 ("Category check", json.dumps(s["category_check"])), ("Fingerprint", result.fingerprint()),
                 ("Engine version", result.engine_version), ("Config version", result.config_version)):
        s2.append([k, v])
    s2.append([])
    s2.append(["Rule", "Name", "Borrower lines resolved by it"])
    for rule in list(match_rules) + [{"id": "S01", "name": "Regrouped within category (M:N)"}]:
        s2.append([rule["id"], rule["name"], s["by_rule"].get(rule["id"], 0)])

    s3 = wb.create_sheet("System lines not resolved")
    s3.append(["System item", "System line", "Reads as", "Category", "Budget", "Paid-to-date"])
    for x in result.unresolved_system_lines:
        s3.append([x["key"], x["label"], x["reads_as"], x["category"], _m(x["budget"]), _m(x["prior"])])

    s4 = wb.create_sheet("Category tie-out")
    s4.append(["Category", "System budget", "Borrower budget", "Gap", "System paid-to-date", "Borrower paid-to-date", "Gap"])
    for t in result.category_tieout:
        s4.append([t["category"], _m(t["system_budget"]), _m(t["borrower_budget"]), _m(t["budget_gap"]),
                   _m(t["system_prior"]), _m(t["borrower_prior"]), _m(t["prior_gap"])])

    for sheet in wb.worksheets:
        for c in sheet[1]:
            c.font = Font(bold=True)
        for col in sheet.columns:
            sheet.column_dimensions[col[0].column_letter].width = min(55, max(len(str(c.value or "")) for c in col) + 2)
        sheet.freeze_panes = "A2"
    ws.column_dimensions["J"].width = 70
    ws.column_dimensions["K"].width = 45
    wb.save(path)
