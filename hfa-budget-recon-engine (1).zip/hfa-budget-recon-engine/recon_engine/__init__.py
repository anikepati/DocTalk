"""hfa-budget-recon-engine: deterministic label-variance resolution for HFA construction-loan draw budgets."""
__version__ = "1.0.0"
