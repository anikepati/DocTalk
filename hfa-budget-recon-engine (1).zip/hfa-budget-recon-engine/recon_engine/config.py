"""Configuration: every vocabulary list, rule and threshold is a JSON file in config/. Changing behaviour never
needs a code change, and the config hash is stamped on every result so any output can be reproduced."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

DEFAULT_CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


@dataclass
class Config:
    settings: dict
    abbreviations: dict
    cost_codes: list
    version: str

    def s(self, key, default=None):
        return self.settings.get(key, default)

    def override(self, **kwargs) -> "Config":
        return Config({**self.settings, **kwargs}, self.abbreviations, self.cost_codes, self.version + "+override")


def load_config(config_dir=None) -> Config:
    d = Path(config_dir) if config_dir else DEFAULT_CONFIG_DIR
    settings = json.loads((d / "settings.json").read_text())
    abbreviations = json.loads((d / "abbreviations.json").read_text())
    cost_codes = json.loads((d / "cost_codes.json").read_text())["codes"]
    settings["match_rules"] = json.loads((d / "match_rules.json").read_text())["rules"]
    digest = hashlib.sha256(json.dumps([settings, abbreviations, cost_codes], sort_keys=True).encode()).hexdigest()[:12]
    return Config(settings, abbreviations, cost_codes, digest)
