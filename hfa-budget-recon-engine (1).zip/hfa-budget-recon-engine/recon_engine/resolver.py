"""Label-variance resolution: which system line(s) does each borrower line correspond to, and why.

The engine answers two separate questions for every borrower line, and never mixes them:

  1. LABEL RESOLUTION   Is this the same budget line as something already in the system, despite the system
                        label being typed free-form (abbreviations, notes, typos, merged lines)?
                        -> RESOLVED / RESOLVED_CONFIRM (plausible, a person confirms once) / AMBIGUOUS / NEW
  2. AMOUNT CHECK       Once resolved, do budget and paid-to-date agree?
                        -> AGREE / ROUNDING / SYSTEM_TYPO (transposed, dropped, extra digit, decimal shift) / DIFFERENT

The method is fully deterministic: the same inputs and config always produce the same output, regardless of
input order (tested). Nothing is learned at run time and nothing is random.

Steps (each one only sees what earlier steps left unresolved):
  A. read files            Excel or CSV, footing checks
  B. clean labels          remove notes, expand abbreviations, fix one-edit typos, assign cost code / category
  C. align detail level    roll contractor trade lines up to the summary line when only one side has trade detail
  D. match by rules        M01-M06 from config/match_rules.json, strictest first
  E. regroup               lines left over inside one category that add up on both sides (M:N regrouping)
  F. classify              resolution status + amount check + a plain-English explanation per line
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Optional

from .hierarchy import rollup
from .matcher import Matcher
from .models import Line
from .money import usd
from .normalize import Normalizer
from .typos import classify_amount_diff

TYPO_PATTERNS = {"TRANSPOSED_DIGITS", "DROPPED_DIGIT", "EXTRA_DIGIT", "DECIMAL_SHIFT"}
RELATION = {"1:1": "one to one", "1:N": "one system line = several borrower lines",
            "N:1": "several system lines = one borrower line", "M:N": "lines regrouped within a category"}


@dataclass
class Resolution:
    borrower_key: str
    borrower_label: str
    borrower_category: Optional[str]
    budget: int
    prior: int
    current: int
    status: str  # RESOLVED | RESOLVED_CONFIRM | AMBIGUOUS | NEW
    rule: str  # e.g. "M02 Same label or cost code, same amounts"
    relation: str
    confidence: float
    system_keys: list
    system_labels: list
    system_budget: Optional[int]
    system_prior: Optional[int]
    explanation: str
    label_cleanup: list = field(default_factory=list)  # how the system label(s) were read
    borrower_reads_as: str = ""
    system_reads_as: list = field(default_factory=list)
    budget_check: str = ""  # AGREE | ROUNDING | SYSTEM_TYPO (pattern) | DIFFERENT
    prior_check: str = ""
    budget_diff: int = 0
    prior_diff: int = 0
    category_check: str = ""  # AGREE | DIFFERS (system X, borrower Y) | n/a
    group_id: str = ""


@dataclass
class Result:
    resolutions: list
    unresolved_system_lines: list
    category_tieout: list
    preparation_findings: list
    config_version: str
    engine_version: str

    def summary(self) -> dict:
        from collections import Counter
        st = Counter(r.status for r in self.resolutions)
        firsts = [r for r in self.resolutions if r.status not in ("NEW", "AMBIGUOUS") and not r.budget_check.startswith("see ")]
        bud = Counter(r.budget_check.split(" ")[0] for r in firsts)
        pri = Counter(r.prior_check.split(" ")[0] for r in firsts)
        cat = Counter(r.category_check.split(" ")[0] for r in firsts)
        return {
            "borrower_lines": len(self.resolutions),
            "resolved": st.get("RESOLVED", 0), "resolved_confirm": st.get("RESOLVED_CONFIRM", 0),
            "ambiguous": st.get("AMBIGUOUS", 0), "new": st.get("NEW", 0),
            "system_lines_unresolved": len(self.unresolved_system_lines),
            "by_rule": dict(sorted(Counter(r.rule.split(" ")[0] for r in self.resolutions).items())),
            "budget_check": dict(sorted(bud.items())), "paid_to_date_check": dict(sorted(pri.items())),
            "category_check": dict(sorted(cat.items())),
        }

    def to_dict(self) -> dict:
        return {"engine_version": self.engine_version, "config_version": self.config_version,
                "summary": self.summary(), "resolutions": [asdict(r) for r in self.resolutions],
                "unresolved_system_lines": self.unresolved_system_lines, "category_tieout": self.category_tieout,
                "preparation_findings": self.preparation_findings}

    def fingerprint(self) -> str:
        """Hash of the decisions (not timestamps): identical inputs + config must give an identical fingerprint."""
        return hashlib.sha256(json.dumps(self.to_dict(), sort_keys=True, default=str).encode()).hexdigest()[:16]


class Resolver:
    def __init__(self, cfg):
        from . import __version__
        self.cfg, self.version = cfg, __version__
        self.norm = Normalizer(cfg)
        self.auto = cfg.s("auto_accept_confidence", 0.95)

    # ------------------------------------------------------------------ main
    def resolve(self, system_lines, borrower_lines) -> Result:
        sys_n = [self.norm.normalize(l) for l in system_lines]
        bor_n = [self.norm.normalize(l) for l in borrower_lines]
        findings = []
        # C. align detail level: compare trade by trade only if both sides have trades
        if not (self._has_trades(sys_n) and self._has_trades(bor_n)):
            sys_n, f1 = rollup(sys_n, self.norm, "system")
            bor_n, f2 = rollup(bor_n, self.norm, "borrower")
            findings += [{"code": f.reason_code, "message": f.message} for f in f1 + f2]
        # D. match by rules
        res = Matcher(self.cfg, self.cfg.s("match_columns", ["budget", "prior"]), "resolution", "-").run(sys_n, bor_n)
        # E. regroup leftovers inside a category
        regroups = self._regroups(res)

        out = []
        for gi, g in enumerate(res.groups):
            out += self._from_group(g, f"G{gi + 1:03d}")
        for ri, rg in enumerate(regroups):
            out += self._from_regroup(rg, f"R{ri + 1:03d}")
        amb = {}
        for a in res.ambiguities:
            for ms in a["candidates"]:
                for m in ms:
                    amb.setdefault(m.key, (a["target"], a["candidates"]))
        done = {r.borrower_key for r in out}
        for r in sorted(res.unmatched_right, key=lambda x: x.key):
            out.append(self._new(r))
        for k, (target, cands) in sorted(amb.items()):
            r = next((x for x in bor_n if x.key == k), None)
            if r is not None and k not in done:
                out.append(self._ambiguous(r, target, cands))
        unresolved = [{"key": l.key, "label": l.label, "budget": l.budget, "prior": l.prior,
                       "reads_as": l.norm_label, "category": l.category}
                      for l in sorted(res.unmatched_left, key=lambda x: x.key)
                      if l.key not in amb and not any(l.key in r.system_keys for r in out)]
        out.sort(key=lambda r: r.borrower_key)
        return Result(out, unresolved, self._tieout(sys_n, bor_n), findings, self.cfg.version, self.version)

    # ------------------------------------------------------------------ helpers
    def _has_trades(self, lines):
        return any(self.norm.codes.get(l.cost_code or "", {}).get("rollup_to") for l in lines)

    def _regroups(self, res):
        by_l, by_r = {}, {}
        for l in res.unmatched_left:
            by_l.setdefault(l.category or "UNK", []).append(l)
        for r in res.unmatched_right:
            by_r.setdefault(r.category or "UNK", []).append(r)
        from .grouping import tolerance
        out = []
        for cat in sorted(set(by_l) & set(by_r)):
            ls, rs = by_l[cat], by_r[cat]
            if len(ls) + len(rs) < 3:
                continue
            if all(abs(sum(x.col(c) for x in ls) - sum(x.col(c) for x in rs)) <= tolerance(sum(x.col(c) for x in rs), self.cfg)
                   for c in ("budget", "prior")):
                out.append({"category": cat, "left": sorted(ls, key=lambda x: x.key), "right": sorted(rs, key=lambda x: x.key)})
        gone = {x.key for rg in out for x in rg["left"] + rg["right"]}
        res.unmatched_left = [l for l in res.unmatched_left if l.key not in gone]
        res.unmatched_right = [r for r in res.unmatched_right if r.key not in gone]
        return out

    def _check(self, b, s):
        if b == s:
            return "AGREE"
        cls = classify_amount_diff(b, s)["pattern"]
        if cls == "ROUNDING":
            return "ROUNDING"
        if cls in TYPO_PATTERNS:
            return f"SYSTEM_TYPO ({cls})"
        return "DIFFERENT"

    @staticmethod
    def _cat_check(left, right):
        lc = {l.category for l in left} - {None, "UNK"}
        rc = {r.category for r in right} - {None, "UNK"}
        if not lc or not rc:
            return "n/a (category unknown on one side)"
        if lc == rc:
            return "AGREE"
        return f"DIFFERS (system {'/'.join(sorted(lc))}, borrower {'/'.join(sorted(rc))})"

    def _cleanup(self, lines):
        steps = []
        for l in lines:
            for s in self.norm.explain(l.label):
                if s not in steps:
                    steps.append(s)
        return steps

    def _explain(self, g):
        l0, r0 = g.left[0], g.right[0]
        lb, rb = g.total("left", "budget"), g.total("right", "budget")
        lp, rp = g.total("left", "prior"), g.total("right", "prior")
        if g.relation in ("1:N", "N:1"):
            many, one = (g.right, g.left[0]) if g.relation == "1:N" else (g.left, g.right[0])
            side = "borrower" if g.relation == "1:N" else "system"
            return (f"'{one.label}' equals the sum of {len(many)} {side} lines ("
                    + " + ".join(m.label for m in many) + f"): budget {usd(sum(m.budget for m in many))}, "
                    f"paid-to-date {usd(sum(m.prior for m in many))} on both sides.")
        if g.pass_name == "exact_norm_label":
            how = "identical" if l0.label.strip().lower() == r0.label.strip().lower() else \
                f"the same after cleanup ('{l0.norm_label}')"
            return f"Labels are {how}; budget and paid-to-date agree."
        if g.pass_name == "exact_cost_code":
            return f"Both labels map to cost code {l0.cost_code}; budget and paid-to-date agree."
        if g.pass_name == "identical_numbers":
            return (f"Budget {usd(rb)} and paid-to-date {usd(rp)} are identical and unique; the wording differs "
                    f"('{l0.label}' vs '{r0.label}').")
        if g.pass_name == "label":
            why = f"same cost code {l0.cost_code}" if l0.cost_code and l0.cost_code == r0.cost_code else \
                f"label similarity {g.confidence:.2f}"
            return f"Labels match ({why}); amounts differ, see the amount check."
        if g.pass_name == "learned":
            return "Matched by a mapping confirmed earlier."
        return g.notes[0] if g.notes else ""

    def _from_group(self, g, gid):
        lb, rb = g.total("left", "budget"), g.total("right", "budget")
        lp, rp = g.total("left", "prior"), g.total("right", "prior")
        status = "RESOLVED" if g.confidence >= self.auto else "RESOLVED_CONFIRM"
        out = []
        for i, r in enumerate(sorted(g.right, key=lambda x: x.key)):
            res = Resolution(
                r.key, r.label, r.category, r.budget, r.prior, r.current, status,
                f"{g.rule_id} {g.rule_name}".strip(), RELATION.get(g.relation, g.relation), round(g.confidence, 3),
                [l.key for l in g.left], [l.label for l in g.left], lb, lp, self._explain(g),
                label_cleanup=self._cleanup(g.left), borrower_reads_as=r.norm_label,
                system_reads_as=[l.norm_label for l in g.left], group_id=gid)
            if r.children:
                res.label_cleanup = res.label_cleanup + [f"borrower trade lines rolled up: {len(r.children)}"]
            if i == 0:
                res.budget_check, res.prior_check = self._check(rb, lb), self._check(rp, lp)
                res.budget_diff, res.prior_diff = rb - lb, rp - lp
                res.category_check = self._cat_check(g.left, g.right)
            else:
                res.budget_check = res.prior_check = res.category_check = \
                    f"see {sorted(g.right, key=lambda x: x.key)[0].key} (same group)"
            out.append(res)
        return out

    def _from_regroup(self, rg, gid):
        ls, rs = rg["left"], rg["right"]
        lb, lp = sum(x.budget for x in ls), sum(x.prior for x in ls)
        expl = (f"{rg['category']}: system lines " + ", ".join(f"'{x.label}'" for x in ls) + " and borrower lines "
                + ", ".join(f"'{x.label}'" for x in rs) + f" both total {usd(lb)} budget and {usd(lp)} paid-to-date; "
                "the lines were grouped differently when keyed.")
        return [Resolution(r.key, r.label, r.category, r.budget, r.prior, r.current, "RESOLVED_CONFIRM",
                           "S01 Regrouped within category", RELATION["M:N"], 0.9, [x.key for x in ls],
                           [x.label for x in ls], lb, lp, expl, label_cleanup=self._cleanup(ls),
                           borrower_reads_as=r.norm_label, system_reads_as=[x.norm_label for x in ls],
                           budget_check="AGREE (as a group)", prior_check="AGREE (as a group)",
                           category_check="AGREE", group_id=gid)
                for r in rs]

    def _new(self, r):
        return Resolution(r.key, r.label, r.category, r.budget, r.prior, r.current, "NEW", "-", "", 0.0, [], [],
                          None, None, "No system line has this meaning or these amounts: a new line, or a system line "
                          "too different to match safely.", borrower_reads_as=r.norm_label,
                          budget_check="n/a", prior_check="n/a")

    def _ambiguous(self, r, target, cands):
        opts = " | ".join(" + ".join(m.label for m in ms) for ms in cands)
        return Resolution(r.key, r.label, r.category, r.budget, r.prior, r.current, "AMBIGUOUS", "-",
                          "", 0.0, [target.key], [target.label], target.budget, target.prior,
                          f"'{target.label}' can be explained by more than one group of lines ({opts}); "
                          "the engine does not guess.", borrower_reads_as=r.norm_label,
                          budget_check="n/a", prior_check="n/a")

    def _tieout(self, sys_n, bor_n):
        cats = {}
        for side, lines in (("system", sys_n), ("borrower", bor_n)):
            for l in lines:
                t = cats.setdefault(l.category or "UNK", {"system_budget": 0, "borrower_budget": 0,
                                                          "system_prior": 0, "borrower_prior": 0})
                t[f"{side}_budget"] += l.budget
                t[f"{side}_prior"] += l.prior
        order = ["ACQUISITION", "HARD", "SOFT", "OTHER", "UNK"]
        return [{"category": c, **v, "budget_gap": v["borrower_budget"] - v["system_budget"],
                 "prior_gap": v["borrower_prior"] - v["system_prior"]}
                for c, v in sorted(cats.items(), key=lambda kv: order.index(kv[0]) if kv[0] in order else 9)]
