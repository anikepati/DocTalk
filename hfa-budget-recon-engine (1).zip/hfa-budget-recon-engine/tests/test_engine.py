"""hfa-budget-recon-engine: every kind of label variance, the amount checks, and proof of determinism."""
import random
from pathlib import Path

import pytest

from recon_engine.__main__ import main
from recon_engine.config import load_config
from recon_engine.extract import read_any
from recon_engine.models import Line
from recon_engine.money import to_cents as c
from recon_engine.resolver import Resolver

ROOT = Path(__file__).resolve().parent.parent
CFG = load_config()


def S(key, label, budget, prior=0, category=None):
    return Line(key, label, c(budget), c(prior), category=category)


def B(key, label, budget, prior=0, current=0, category=None):
    return Line(key, label, c(budget), c(prior), c(current), category=category)


def resolve(system, borrower, cfg=CFG):
    return Resolver(cfg).resolve(system, borrower)


def one(result, label):
    return [r for r in result.resolutions if r.borrower_label == label][0]


# ------------------------------------------------------------------ label variances
@pytest.mark.parametrize("kind,system_label,borrower_label", [
    ("identical", "Legal", "Legal"),
    ("case", "CONCRETE", "Concrete"),
    ("punctuation", "Doors/Windows", "Doors & Windows"),
    ("abbreviation", "Drs & Windows", "Doors & Windows"),
    ("abbreviation", "GC OH&P / Gen Req", "General Contractor Overhead & Profit"),
    ("abbreviation", "Constr. Int. Reserve", "Construction Interest Reserve"),
    ("abbreviation", "Bldrs Risk Ins", "Builder's Risk Insurance"),
    ("note in label", "Site Work - per CO #2", "Sitework"),
    ("note in label", "Finishes (rev 9/14)", "Finishes"),
    ("line number", "3. Legal", "Legal"),
    ("typo: transposed letters", "Elecrtical", "Electrical"),
    ("typo: missing letter", "Plumbng", "Plumbing"),
    ("typo: extra letter", "Masonary", "Masonry"),
    ("typo + abbreviation", "Constuction Contg 5%", "Hard Cost Contingency"),
    ("synonym via cost code", "HVAC/Mech", "HVAC"),
])
def test_label_variance_resolves_automatically(kind, system_label, borrower_label):
    r = resolve([S("S1", system_label, 500000, 100000)], [B("B1", borrower_label, 500000, 100000)])
    x = r.resolutions[0]
    assert x.status == "RESOLVED" and x.system_labels == [system_label], kind
    assert x.budget_check == "AGREE" and x.prior_check == "AGREE"


def test_every_cleanup_step_is_explained():
    x = resolve([S("S1", "Elecrtical - per CO #4", 1000)], [B("B1", "Electrical", 1000)]).resolutions[0]
    assert "removed note 'per co #4'" in x.label_cleanup
    assert "spelling 'elecrtical' -> 'electrical'" in x.label_cleanup
    assert x.borrower_reads_as == x.system_reads_as[0] == "electrical"


def test_label_variant_with_different_amounts_is_resolved_and_the_difference_reported():
    x = resolve([S("S1", "Finishes (rev 9/14)", 1864000, 190000)], [B("B1", "Finishes", 1900000, 190000)]).resolutions[0]
    assert x.status == "RESOLVED" and x.rule.startswith("M06")
    assert x.budget_check == "DIFFERENT" and x.budget_diff == c(36000) and x.prior_check == "AGREE"


# ------------------------------------------------------------------ summation and regrouping
def test_system_line_is_the_sum_of_several_borrower_lines():
    r = resolve([S("S1", "A&E + Survey", 287500, 201000)],
                [B("B1", "Architect", 180000, 150000), B("B2", "Engineering", 95000, 38500), B("B3", "Survey", 12500, 12500)])
    assert {x.rule.split()[0] for x in r.resolutions} == {"M05"} and {x.status for x in r.resolutions} == {"RESOLVED"}
    assert "equals the sum of 3 borrower lines" in r.resolutions[0].explanation


def test_borrower_line_is_the_sum_of_several_system_lines():
    r = resolve([S("S1", "Architect", 180000, 150000), S("S2", "Engineering", 95000, 38500)],
                [B("B1", "Architecture & Engineering", 275000, 188500)])
    assert r.resolutions[0].rule.startswith("M04") and r.resolutions[0].system_labels == ["Architect", "Engineering"]


def test_summation_needs_every_amount_to_tie_so_round_numbers_cannot_fake_it():
    system = [S("S1", "3rd Pty Rpts", 75000, 55000)]
    borrower = [B("B1", "Appraisal", 25000, 25000), B("B2", "Environmental", 50000, 30000), B("B3", "Market Study", 50000, 50000)]
    r = resolve(system, borrower)
    assert one(r, "Appraisal").system_labels == ["3rd Pty Rpts"] and one(r, "Market Study").status == "NEW"
    budget_only = resolve(system, borrower, CFG.override(match_columns=["budget"]))
    assert {x.status for x in budget_only.resolutions} == {"AMBIGUOUS"}  # two groups fit: no guess


def test_lines_regrouped_within_a_category():
    system = [S("S1", "3rd party reports", 110000, 70000, "SOFT"), S("S2", "Title & studies", 90000, 50000, "SOFT")]
    borrower = [B("B1", "Appraisal", 25000, 25000, 0, "SOFT"), B("B2", "Environmental", 50000, 30000, 0, "SOFT"),
                B("B3", "Market Study", 50000, 50000, 0, "SOFT"), B("B4", "Title & Recording", 75000, 15000, 0, "SOFT")]
    r = resolve(system, borrower)
    assert {x.rule.split()[0] for x in r.resolutions} == {"S01"} and not r.unresolved_system_lines


def test_trade_detail_rolls_up_to_a_summary_line():
    r = resolve([S("S1", "Bldg Construction", 3000000, 1000000)],
                [B("T1", "Concrete", 1000000, 600000), B("T2", "Framing", 1200000, 300000), B("T3", "Electrical", 800000, 100000)])
    assert r.resolutions[0].status == "RESOLVED" and "rolled up: 3" in r.resolutions[0].label_cleanup[-1]


# ------------------------------------------------------------------ when the engine will not decide alone
def test_same_amounts_but_unrelated_wording_needs_confirmation():
    r = resolve([S("S1", "Owner's rep", 72000, 18000), S("S2", "Legal", 5000)],
                [B("B1", "Development consultant", 72000, 18000), B("B2", "Legal", 5000)])
    assert one(r, "Development consultant").status == "RESOLVED_CONFIRM"


def test_generic_system_label_is_never_resolved_automatically():
    r = resolve([S("S1", "Misc 1", 1650000, 495000)], [B("B1", "Developer Fee", 1650000, 495000)])
    assert r.resolutions[0].status == "RESOLVED_CONFIRM" and r.resolutions[0].confidence < 0.95


def test_duplicate_amounts_are_paired_by_label_not_by_position():
    r = resolve([S("S1", "Appraisal", 25000, 25000), S("S2", "Survey", 25000, 25000)],
                [B("B1", "Survey", 25000, 25000), B("B2", "Appraisal", 25000, 25000)])
    assert one(r, "Survey").system_labels == ["Survey"] and one(r, "Appraisal").system_labels == ["Appraisal"]


def test_new_line_and_unresolved_system_line():
    r = resolve([S("S1", "Legal", 5000), S("S2", "Marketing", 90000)],
                [B("B1", "Legal", 5000), B("B2", "Solar PV System", 60000, 0, 15000)])
    assert one(r, "Solar PV System").status == "NEW"
    assert [x["label"] for x in r.unresolved_system_lines] == ["Marketing"]


# ------------------------------------------------------------------ amount checks
@pytest.mark.parametrize("system,borrower,expected", [
    (42850, 48250, "SYSTEM_TYPO (TRANSPOSED_DIGITS)"),
    (16500, 165000, "SYSTEM_TYPO (DROPPED_DIGIT)"),
    (412, 41200, "SYSTEM_TYPO (DECIMAL_SHIFT)"),
    ("8,333.33", "8,333.00", "ROUNDING"),
    (640000, 650000, "DIFFERENT"),
])
def test_amount_check(system, borrower, expected):
    x = resolve([S("S1", "Permits", system)], [B("B1", "Permits", borrower)]).resolutions[0]
    assert x.status == "RESOLVED" and x.budget_check == expected


def test_category_check_flags_a_misfiled_line():
    x = resolve([S("S1", "Soft Contg", 150000, 22000, "HARD")],
                [B("B1", "Soft Cost Contingency", 150000, 22000, 0, "SOFT")]).resolutions[0]
    assert x.status == "RESOLVED" and x.category_check == "DIFFERS (system HARD, borrower SOFT)"


# ------------------------------------------------------------------ determinism
def _samples(name):
    b = read_any(ROOT / f"samples/{name}_borrower_draw{'07' if name == 'HFA-1001' else '19'}.xlsx").lines
    s = read_any(ROOT / f"samples/{name}_system_lines.csv").lines
    return s, b


@pytest.mark.parametrize("name", ["HFA-1001", "HFA-2001"])
def test_same_input_same_output_in_any_order(name):
    s, b = _samples(name)
    base = resolve(s, b).fingerprint()
    assert resolve(s, b).fingerprint() == base
    rng = random.Random(42)
    for _ in range(20):
        s2, b2 = s[:], b[:]
        rng.shuffle(s2)
        rng.shuffle(b2)
        assert resolve(s2, b2).fingerprint() == base


def test_behaviour_is_configuration_not_code():
    rules = [r for r in CFG.s("match_rules") if r["id"] != "M05"]
    r = resolve([S("S1", "A&E + Survey", 287500, 201000)],
                [B("B1", "Architect", 180000, 150000), B("B2", "Engineering", 95000, 38500), B("B3", "Survey", 12500, 12500)],
                CFG.override(match_rules=rules))
    assert "M05" not in {x.rule.split()[0] for x in r.resolutions}


# ------------------------------------------------------------------ samples end to end
def test_sample_HFA_1001_free_form_system_lines():
    s = resolve(*_samples("HFA-1001")).summary()
    assert (s["resolved"], s["resolved_confirm"], s["ambiguous"], s["new"], s["system_lines_unresolved"]) == (30, 2, 0, 1, 0)
    assert s["budget_check"] == {"AGREE": 26, "DIFFERENT": 2, "SYSTEM_TYPO": 1}


def test_sample_HFA_2001_eighteen_months_of_hand_keying():
    s = resolve(*_samples("HFA-2001")).summary()
    assert (s["resolved"], s["resolved_confirm"], s["ambiguous"], s["new"], s["system_lines_unresolved"]) == (27, 5, 0, 1, 0)
    assert s["by_rule"]["S01"] == 4 and s["category_check"]["DIFFERS"] == 1


def test_cli_writes_reports_and_returns_exit_codes(tmp_path):
    rc = main(["resolve", "--borrower", str(ROOT / "samples/HFA-1001_borrower_draw07.xlsx"),
               "--system", str(ROOT / "samples/HFA-1001_system_lines.csv"), "--out", str(tmp_path)])
    assert rc == 1 and {p.name for p in tmp_path.iterdir()} == {"resolution.xlsx", "resolution.md", "resolution.json"}
