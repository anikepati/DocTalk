"""JSON contract: system_record.json + borrower_record.json -> result.json."""
import copy
import json
import random
from pathlib import Path

import pytest

from recon_engine.__main__ import main
from recon_engine.config import load_config
from recon_engine.extract import read_any
from recon_engine.json_io import resolve_records
from recon_engine.resolver import Resolver

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "samples"
SCHEMAS = ROOT / "schemas"


def load(p):
    return json.loads(Path(p).read_text())


@pytest.fixture(scope="module")
def cfg():
    return load_config()


@pytest.fixture(scope="module")
def demo(cfg):
    return resolve_records(load(SAMPLES / "minimal/system_record.json"),
                           load(SAMPLES / "minimal/borrower_record.json"), cfg)


def by_borrower(res, label):
    return next(d for d in res["decisions"] if any(l["label"] == label for l in d["borrower_lines"]))


# ---------------------------------------------------------------- the demo shows each variance
@pytest.mark.parametrize("borrower,system,rule,cleanup", [
    ("Land Acquisition", ["Land Acq."], "M02", "'acq' -> 'acquisition'"),
    ("Sitework", ["Site Work - per CO #2"], "M02", "removed note 'per co #2'"),
    ("Electrical", ["Elecrtical"], "M02", "spelling 'elecrtical' -> 'electrical'"),
    ("Doors & Windows", ["Drs & Windows"], "M02", "'drs' -> 'doors'"),
    ("Architect", ["A&E + Survey"], "M05", "'a&e' -> 'architecture engineering'"),
])
def test_demo_label_variances(demo, borrower, system, rule, cleanup):
    d = by_borrower(demo, borrower)
    assert d["status"] == "RESOLVED" and d["rule_id"] == rule
    assert [l["label"] for l in d["system_lines"]] == system
    assert cleanup in d["label_cleanup"]


def test_demo_summation_lists_all_borrower_lines(demo):
    d = by_borrower(demo, "Architect")
    assert [l["label"] for l in d["borrower_lines"]] == ["Architect", "Engineering", "Survey"]
    assert d["checks"]["budget"] == {"result": "AGREE", "borrower": 287500.0, "system": 287500.0, "difference": 0.0}


def test_demo_amount_typo_and_new(demo):
    d = by_borrower(demo, "Permits & Impact Fees")
    assert d["checks"]["budget"]["result"] == "SYSTEM_TYPO (TRANSPOSED_DIGITS)"
    assert d["checks"]["budget"]["difference"] == 5400.0
    n = by_borrower(demo, "Solar PV System")
    assert n["status"] == "NEW" and n["system_lines"] == [] and n["decision_id"] == "NEW-9"
    assert demo["status"] == "NEEDS_REVIEW" and demo["summary"]["needs_review"] == 1


# ---------------------------------------------------------------- JSON path == Excel/CSV path
@pytest.mark.parametrize("loan,draw", [("HFA-1001", "draw07"), ("HFA-2001", "draw19")])
def test_json_path_matches_file_path(cfg, loan, draw):
    res = resolve_records(load(SAMPLES / f"{loan}_system_record.json"),
                          load(SAMPLES / f"{loan}_borrower_record.json"), cfg)
    direct = Resolver(cfg).resolve(read_any(SAMPLES / f"{loan}_system_lines.csv").lines,
                                   read_any(SAMPLES / f"{loan}_borrower_{draw}.xlsx").lines)
    assert res["fingerprint"] == direct.fingerprint()
    assert res["summary"]["borrower_lines"] == direct.summary()["borrower_lines"]
    # every borrower line appears in exactly one decision
    keys = [l["key"] for d in res["decisions"] for l in d["borrower_lines"]]
    assert sorted(keys) == sorted(r.borrower_key for r in direct.resolutions)
    assert len(keys) == len(set(keys))


# ---------------------------------------------------------------- schemas
@pytest.mark.parametrize("loan", ["HFA-1001", "HFA-2001", "minimal"])
def test_inputs_and_result_match_schemas(cfg, loan):
    jsonschema = pytest.importorskip("jsonschema")
    if loan == "minimal":
        s, b = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    else:
        s, b = load(SAMPLES / f"{loan}_system_record.json"), load(SAMPLES / f"{loan}_borrower_record.json")
    jsonschema.validate(s, load(SCHEMAS / "system_record.schema.json"))
    jsonschema.validate(b, load(SCHEMAS / "borrower_record.schema.json"))
    jsonschema.validate(resolve_records(s, b, cfg), load(SCHEMAS / "resolution_result.schema.json"))


def test_rejected_result_matches_schema(cfg):
    jsonschema = pytest.importorskip("jsonschema")
    res = resolve_records({"lines": []}, {"lines": []}, cfg)
    jsonschema.validate(res, load(SCHEMAS / "resolution_result.schema.json"))


# ---------------------------------------------------------------- determinism
def test_shuffled_json_gives_identical_result(cfg, demo):
    s0, b0 = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    for seed in range(20):
        s, b = copy.deepcopy(s0), copy.deepcopy(b0)
        random.Random(seed).shuffle(s["lines"])
        random.Random(seed + 100).shuffle(b["lines"])
        res = resolve_records(s, b, cfg)
        assert res["fingerprint"] == demo["fingerprint"]
        assert res["decisions"] == demo["decisions"]


# ---------------------------------------------------------------- input handling
def test_amounts_as_strings_are_accepted(cfg, demo):
    s, b = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    for rec in (s, b):
        for l in rec["lines"]:
            for k in ("budget", "paid_to_date", "this_draw"):
                if k in l:
                    l[k] = f"${l[k]:,.2f}"
    assert resolve_records(s, b, cfg)["fingerprint"] == demo["fingerprint"]


def test_old_field_names_prior_current_accepted(cfg, demo):
    b = load(SAMPLES / "minimal/borrower_record.json")
    for l in b["lines"]:
        l["prior"], l["current"] = l.pop("paid_to_date"), l.pop("this_draw")
    res = resolve_records(load(SAMPLES / "minimal/system_record.json"), b, cfg)
    assert res["fingerprint"] == demo["fingerprint"]


@pytest.mark.parametrize("mutate,code", [
    (lambda s, b: b["totals"].update(budget=1.0), "GRAND_TOTAL_MISMATCH"),
    (lambda s, b: b["lines"][0].pop("budget"), "MISSING_BUDGET"),
    (lambda s, b: b["lines"][1].update(budget="abc"), "BAD_AMOUNT"),
    (lambda s, b: b["lines"][1].update(balance_to_finish=1.0), "LINE_MATH"),
    (lambda s, b: s.update(loan_id="HFA-OTHER"), "LOAN_MISMATCH"),
    (lambda s, b: s.update(lines=[]), "NO_LINES"),
    (lambda s, b: b.update(schema="something.else"), "WRONG_SCHEMA"),
])
def test_bad_input_is_rejected_not_guessed(cfg, mutate, code):
    s, b = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    mutate(s, b)
    res = resolve_records(s, b, cfg)
    assert res["status"] == "REJECTED" and res["decisions"] == []
    assert code in [c["code"] for c in res["input_checks"]]


def test_complete_when_everything_resolves(cfg):
    s, b = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    s["lines"] = [l for l in s["lines"] if l["key"] in ("S1", "S2", "S3")]
    b["lines"] = [l for l in b["lines"] if l["key"] in ("1", "2", "3")]
    b.pop("totals")
    res = resolve_records(s, b, cfg)
    assert res["status"] == "COMPLETE" and res["summary"]["needs_review"] == 0


def test_unresolved_system_line_reported(cfg):
    s, b = load(SAMPLES / "minimal/system_record.json"), load(SAMPLES / "minimal/borrower_record.json")
    s["lines"].append({"key": "S9", "label": "Bond Issuance", "category": "SOFT", "budget": 99999.0,
                       "paid_to_date": 0})
    res = resolve_records(s, b, cfg)
    assert [u["key"] for u in res["unresolved_system_lines"]] == ["S9"]
    assert res["status"] == "NEEDS_REVIEW"


# ---------------------------------------------------------------- CLI
def test_cli_resolve_json(tmp_path):
    out = tmp_path / "result.json"
    code = main(["resolve-json", "--system", str(SAMPLES / "minimal/system_record.json"),
                 "--borrower", str(SAMPLES / "minimal/borrower_record.json"), "--out", str(out)])
    assert code == 1 and load(out)["schema"] == "hfa.resolution_result.v1"


def test_cli_rejected_exit_2(tmp_path):
    (tmp_path / "s.json").write_text(json.dumps({"lines": []}))
    (tmp_path / "b.json").write_text(json.dumps({"lines": []}))
    assert main(["resolve-json", "--system", str(tmp_path / "s.json"), "--borrower", str(tmp_path / "b.json"),
                 "--out", str(tmp_path / "r.json")]) == 2


def test_cli_to_json_roundtrip(tmp_path, cfg):
    main(["to-json", "--borrower", str(SAMPLES / "HFA-2001_borrower_draw19.xlsx"),
          "--system", str(SAMPLES / "HFA-2001_system_lines.csv"), "--out", str(tmp_path), "--loan-id", "HFA-2001"])
    for name in ("system_record", "borrower_record"):
        assert load(tmp_path / f"HFA-2001_{name}.json") == load(SAMPLES / f"HFA-2001_{name}.json")
