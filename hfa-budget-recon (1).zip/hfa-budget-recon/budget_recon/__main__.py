"""CLI.

Draw validation (the rule engine):
  python -m budget_recon validate <borrower_latest.xlsx|.csv> --system <system_lines.csv>
         [--previous <borrower_previous.xlsx>] [--loan ID] [--draw N] [--approvals a.csv] [--sources s.csv]
         [--xlsx out.xlsx] [--json out.json]

Operating model (system processes, LOB reviews):
  python -m budget_recon onboard <loan_id> <approved_budget.csv> --store DIR --feeds DIR
  python -m budget_recon process <borrower_file.xlsx|.csv|.pdf> --store DIR --feeds DIR [--loan ID --draw N]
  python -m budget_recon tasks   --store DIR [--queue Q] [--loan ID]
  python -m budget_recon decide  <loan_id> <task_id> <ACTION> --user U [--ref APPROVAL_REF] [--note TEXT] [--amount 32000]
  python -m budget_recon status  <loan_id> --store DIR

Lower-level commands (engine, restructuring, posting) remain available:

  python -m budget_recon recon  <draw_folder> [--out r.json] [--xlsx r.xlsx]      identify only (no ledger)
  python -m budget_recon plan   <draw_folder> --store DIR [--out cs.json]         identify + restructuring plan
  python -m budget_recon commit <cs.json> --store DIR --maker A --checker B [--approval I=REF ...] [--override I=REASON ...]
  python -m budget_recon resolve <draw_folder> --store DIR --exception EX-.. --action CORRECTED --user U [--adjust KEY=AMOUNT]
  python -m budget_recon post   <draw_folder> --store DIR
  python -m budget_recon ledger <loan_id> --store DIR                             print the current ledger version
"""
import argparse
import json
import sys

from .config import load_config
from .engine import ReconEngine
from .io import load_loan, to_excel, to_markdown
from .ledger import JsonFileRepository
from .money import to_cents, usd
from .restructure import ChangeSet
from .service import ReconService


def _kv(items):
    out = {}
    for it in items or []:
        k, v = it.split("=", 1)
        out[int(k)] = v
    return out


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    cmds = {"validate", "recon", "plan", "commit", "resolve", "post", "ledger", "onboard", "process", "tasks", "decide", "status"}
    if argv and argv[0] not in cmds and not argv[0].startswith("-"):
        argv = ["recon"] + argv  # backward compatible: python -m budget_recon <folder>
    ap = argparse.ArgumentParser(prog="budget_recon")
    ap.add_argument("--config")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("validate"); p.add_argument("borrower_file"); p.add_argument("--system", required=True)
    p.add_argument("--loan"); p.add_argument("--draw", type=int); p.add_argument("--approvals")
    p.add_argument("--sources"); p.add_argument("--xlsx"); p.add_argument("--json")
    p.add_argument("--previous", help="the borrower's previous draw file (third reference)")
    p = sub.add_parser("recon"); p.add_argument("folder"); p.add_argument("--out"); p.add_argument("--xlsx")
    p = sub.add_parser("plan"); p.add_argument("folder"); p.add_argument("--store", required=True)
    p.add_argument("--out"); p.add_argument("--xlsx")
    p = sub.add_parser("commit"); p.add_argument("change_set"); p.add_argument("--store", required=True)
    p.add_argument("--maker", required=True); p.add_argument("--checker", required=True)
    p.add_argument("--approval", action="append"); p.add_argument("--override", action="append")
    p = sub.add_parser("resolve"); p.add_argument("folder"); p.add_argument("--store", required=True)
    p.add_argument("--exception", required=True); p.add_argument("--action", required=True)
    p.add_argument("--user", required=True); p.add_argument("--note", default=""); p.add_argument("--adjust")
    p = sub.add_parser("post"); p.add_argument("folder"); p.add_argument("--store", required=True)
    p = sub.add_parser("ledger"); p.add_argument("loan_id"); p.add_argument("--store", required=True)
    p = sub.add_parser("onboard"); p.add_argument("loan_id"); p.add_argument("approved")
    p.add_argument("--store", required=True); p.add_argument("--feeds", required=True)
    p.add_argument("--last-draw", type=int); p.add_argument("--previous"); p.add_argument("--sor")
    p = sub.add_parser("process"); p.add_argument("file"); p.add_argument("--store", required=True)
    p.add_argument("--sor", help="folder of the file-backed SOR stand-in; updates are written and read back")
    p.add_argument("--feeds", required=True); p.add_argument("--loan"); p.add_argument("--draw", type=int)
    p.add_argument("--lob", help="LOB entry for shadow comparison during transition")
    p = sub.add_parser("tasks"); p.add_argument("--store", required=True); p.add_argument("--feeds", default=".")
    p.add_argument("--queue"); p.add_argument("--loan"); p.add_argument("--all", action="store_true")
    p = sub.add_parser("decide"); p.add_argument("loan_id"); p.add_argument("task_id"); p.add_argument("action")
    p.add_argument("--user", required=True); p.add_argument("--ref"); p.add_argument("--note")
    p.add_argument("--amount"); p.add_argument("--key"); p.add_argument("--store", required=True)
    p.add_argument("--feeds", required=True); p.add_argument("--sor")
    p = sub.add_parser("status"); p.add_argument("loan_id"); p.add_argument("--store", required=True)
    p.add_argument("--feeds", default=".")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)

    if a.cmd == "validate":
        return _validate_cmd(a, cfg)
    if a.cmd == "recon":
        rep = ReconEngine(cfg).reconcile(load_loan(a.folder))
        print(to_markdown(rep, cfg))
        if a.out:
            json.dump(rep.to_dict(), open(a.out, "w"), indent=2, default=str)
        if a.xlsx:
            to_excel(rep, a.xlsx)
        return 0 if rep.can_post else 2

    if a.cmd in ("onboard", "process", "tasks", "decide", "status"):
        return _pipeline_cmd(a, cfg)
    svc = ReconService(cfg, JsonFileRepository(a.store))
    if a.cmd == "plan":
        loan = load_loan(a.folder)
        rep = svc.identify(loan)
        cs = svc.plan(loan, rep)
        print(to_markdown(rep, cfg))
        print(f"\n## Restructuring change set {cs.change_set_id} ({cs.status}), based on ledger v{cs.base_version}\n")
        for i, o in enumerate(cs.ops):
            flag = "  [needs approval]" if o.requires_approval and not o.approval_ref else ""
            print(f"{i:>3}. {o.kind:<15} {o.describe()}{flag}")
        for x in cs.open_issues:
            print(f"OPEN ISSUE: {x['code']} {x.get('line', '')} {x.get('detail', '')}")
        if a.out:
            json.dump(cs.to_dict(), open(a.out, "w"), indent=2, default=str)
        if a.xlsx:
            to_excel(rep, a.xlsx)
        return 0
    if a.cmd == "commit":
        cs = ChangeSet.from_dict(json.load(open(a.change_set)))
        if cs.status == "NOT_NEEDED":
            print("Nothing to commit.")
            return 0
        svc.submit(cs, a.maker)
        svc.approve(cs, a.checker, _kv(a.approval), _kv(a.override))
        v = svc.commit(cs)
        print(f"Committed {cs.change_set_id} -> ledger v{v.version_no}: budget {usd(v.total_budget())}, "
              f"drawn {usd(v.total_drawn())}, {len(v.active())} active lines")
        return 0
    if a.cmd == "resolve":
        loan = load_loan(a.folder)
        key, amt = (a.adjust.split("=", 1) if a.adjust else (None, None))
        svc.resolve(loan.loan_id, _draw_no(a.folder), a.exception, a.action, a.user, a.note,
                    to_cents(amt) if amt else None, key)
        print(f"Resolved {a.exception}: {a.action}")
        return 0
    if a.cmd == "post":
        loan = load_loan(a.folder)
        v, rec = svc.post(loan, _draw_no(a.folder))
        print(f"Posted draw {rec.draw_no}: {usd(rec.total)} across {len(rec.lines)} ledger lines -> ledger v{v.version_no}")
        return 0
    if a.cmd == "ledger":
        v = svc.repo.current(a.loan_id)
        print(f"{a.loan_id} ledger v{v.version_no} ({v.source}, {v.change_ref}), last draw {v.draw_no}")
        for l in sorted(v.lines.values(), key=lambda x: x.line_id):
            print(f"{l.line_id}  {l.status:<7} {l.category:<11} {l.label:<45} {usd(l.budget):>16} {usd(l.drawn):>16}")
        return 0


def _validate_cmd(a, cfg):
    import csv
    from pathlib import Path
    from .extract import CsvExtractor, ExcelExtractor, extract_file
    from .io import read_lines
    from .validate import DrawValidator
    ext = extract_file(a.borrower_file, [ExcelExtractor(), CsvExtractor()])
    blocking = [c for c in ext.checks if c["severity"] == "BLOCKING"]
    for c in ext.checks:
        print(f"EXTRACTION {c['severity']}: {c['code']} {c['detail']}")
    if blocking:
        print("The borrower file does not foot; fix or confirm it before validating.")
        return 2
    approvals = []
    if a.approvals:
        approvals = [{"approval_ref": r["approval_ref"], "cost_code": r.get("cost_code") or None,
                      "label": r.get("label") or None, "delta": to_cents(r["delta"])}
                     for r in csv.DictReader(open(a.approvals))]
    sources = [{"source": r["source"], "amount": to_cents(r["amount"])} for r in csv.DictReader(open(a.sources))] \
        if a.sources else None
    loan = a.loan or ext.meta.get("loan_id") or "LOAN"
    prev = extract_file(a.previous, [ExcelExtractor(), CsvExtractor()]).lines if a.previous else None
    res = DrawValidator(cfg).validate(read_lines(Path(a.system)), ext.lines, loan, a.draw or ext.meta.get("draw_no"),
                                      approvals, sources, previous_borrower=prev)
    print(res.to_markdown())
    if a.xlsx:
        res.to_excel(a.xlsx)
    if a.json:
        json.dump(res.to_dict(), open(a.json, "w"), indent=2, default=str)
    return 0 if not res.summary["blocking_exceptions"] else 2


def _print_sub(sub):
    print(f"{sub['submission_id']}  draw {sub['draw_no']}  state {sub['state']}"
          + (f"  (waiting at {sub['stage']})" if sub["state"] == "AWAITING_REVIEW" else ""))
    for h in sub["history"]:
        print(f"   {h['at']}  {h['state']:<21} {h['note']}")
    for r in sub.get("returned_reasons", []):
        print(f"   returned: {r['task']} - {r['note']} ({r['by']})")
    if sub.get("reject_reason"):
        print(f"   rejected: {sub['reject_reason']}")


def _print_tasks(tasks):
    if not tasks:
        print("No open tasks.")
    for t in tasks:
        need = f" [{len([d for d in t.decisions if d['action'] == 'APPROVE'])}/{t.approvals_needed} approvals]" \
            if t.approvals_needed > 1 else ""
        print(f"{t.task_id}  {t.loan_id}  {t.queue:<20} due {t.due_at}  {t.kind}{need}")
        print(f"   {t.title}")
        print(f"   {t.detail[:200]}")
        print(f"   actions: {', '.join(t.allowed_actions)}")


def _pipeline_cmd(a, cfg):
    from .pipeline import FolderFeeds, Pipeline
    from .sor import FileSorAdapter
    sor = FileSorAdapter(a.sor) if getattr(a, "sor", None) else None
    p = Pipeline(cfg, JsonFileRepository(a.store), FolderFeeds(a.feeds), sor=sor)
    if a.cmd == "onboard":
        v = p.onboard(a.loan_id, a.approved, a.last_draw, a.previous)
        print(f"{a.loan_id} onboarded: ledger v{v.version_no}, {len(v.lines)} lines, budget {usd(v.total_budget())}")
    elif a.cmd == "process":
        sub = p.receive(a.file, a.loan, a.draw, a.lob)
        _print_sub(sub)
        _print_tasks(p.tasks.list("OPEN", sub["loan_id"], submission_id=sub["submission_id"]))
    elif a.cmd == "tasks":
        _print_tasks(p.tasks.list(None if a.all else "OPEN", a.loan, a.queue))
    elif a.cmd == "decide":
        payload = {k: v for k, v in (("approval_ref", a.ref), ("note", a.note), ("borrower_key", a.key)) if v}
        if a.amount:
            payload["amount_cents"] = to_cents(a.amount)
        sub = p.decide(a.loan_id, a.task_id, a.action.upper(), a.user, payload)
        _print_sub(sub)
        _print_tasks(p.tasks.list("OPEN", a.loan_id, submission_id=sub["submission_id"]))
    elif a.cmd == "status":
        for sub in p.repo.list_records("submissions", a.loan_id):
            _print_sub(sub)
    return 0


def _draw_no(folder):
    from pathlib import Path
    meta = Path(folder) / "loan.json"
    return json.loads(meta.read_text())["draw_no"]


def _safe_main():
    from .posting import PostingError
    from .restructure import ChangeSetError
    from .hitl import TaskError
    from .service import WorkflowError
    try:
        return main()
    except (WorkflowError, PostingError, ChangeSetError, TaskError) as exc:
        print(f"REFUSED: {exc}", file=sys.stderr)
        return 3


if __name__ == "__main__":
    sys.exit(_safe_main())
