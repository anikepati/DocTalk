"""Draw posting against a (restructured) ledger version.

Posting only works when the borrower's structure is aligned with the ledger: every borrower line must
resolve to ledger line(s) by alias, and its prior draws must equal the ledger's drawn. That alignment
is exactly what a committed restructuring change set guarantees.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .ledger import BudgetVersion
from .money import usd
from .planner import _largest_remainder


class PostingError(ValueError):
    def __init__(self, errors):
        super().__init__("; ".join(errors))
        self.errors = errors


@dataclass
class DrawRecord:
    loan_id: str
    draw_no: int
    based_on_version: int
    posted_version: int
    lines: list = field(default_factory=list)  # {line_id, borrower_key, amount, retainage}
    total: int = 0


def resolve_lines(version: BudgetVersion, borrower_lines):
    """Map each borrower line to ledger line ids. Returns (mapping, unresolved)."""
    one, group = {}, {}
    for l in version.active():
        for a in l.aliases:
            one.setdefault(a, []).append(l.line_id)
        for a in l.group_aliases:
            group.setdefault(a, []).append(l.line_id)
    mapping, unresolved = {}, []
    for r in borrower_lines:
        hits = one.get(r.norm_label, [])
        if len(hits) == 1:
            mapping[r.key] = hits
        elif not hits and group.get(r.norm_label):
            mapping[r.key] = sorted(group[r.norm_label])
        else:
            unresolved.append(r)
    return mapping, unresolved


def post_draw(version: BudgetVersion, borrower_lines, draw_no: int, adjustments=None):
    """Returns (new_version, DrawRecord). adjustments: {borrower_key: approved current amount in cents}."""
    adjustments = adjustments or {}
    errors = []
    if version.draw_no is not None and draw_no <= version.draw_no:
        raise PostingError([f"draw {draw_no} already posted (ledger is at draw {version.draw_no})"])
    mapping, unresolved = resolve_lines(version, borrower_lines)
    for r in unresolved:
        errors.append(f"STRUCTURE_NOT_ALIGNED: borrower line '{r.label}' does not resolve to one ledger line; "
                      "commit a restructuring change set first")
    nv = version.successor("DRAW", f"draw-{draw_no}")
    nv.draw_no = draw_no
    rec = DrawRecord(version.loan_id, draw_no, version.version_no, nv.version_no)
    seen = set()
    for r in borrower_lines:
        ids = mapping.get(r.key)
        if not ids:
            continue
        if seen & set(ids):
            errors.append(f"two borrower lines resolve to the same ledger line(s) {ids}")
        seen |= set(ids)
        lines = [nv.lines[i] for i in ids]
        drawn = sum(l.drawn for l in lines)
        if drawn != r.prior:
            errors.append(f"PRIOR_NOT_ALIGNED: '{r.label}' borrower prior {usd(r.prior)} vs ledger drawn {usd(drawn)}")
            continue
        amount = adjustments.get(r.key, r.current)
        if amount < 0:
            errors.append(f"'{r.label}': negative draw")
            continue
        remaining = [l.budget - l.drawn for l in lines]
        if amount > sum(remaining):
            errors.append(f"OVERRUN: '{r.label}' draw {usd(amount)} exceeds remaining {usd(sum(remaining))}")
            continue
        parts = [amount] if len(lines) == 1 else _largest_remainder(amount, remaining)
        rets = [r.retainage] if len(lines) == 1 else _largest_remainder(r.retainage, parts)
        for l, part, ret in zip(lines, parts, rets):
            if part > l.budget - l.drawn:
                errors.append(f"OVERRUN after group allocation on {l.line_id}")
            l.drawn += part
            l.retainage += ret
            if part or ret:
                rec.lines.append({"line_id": l.line_id, "borrower_key": r.key, "amount": part, "retainage": ret})
        rec.total += amount
    if errors:
        raise PostingError(errors)
    return nv, rec
