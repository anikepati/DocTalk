"""Core data structures."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from .money import usd

CATEGORIES = ("ACQUISITION", "HARD", "SOFT", "OTHER", "UNK")


@dataclass
class Line:
    """One budget line on one side (approved baseline, borrower file, or LOB entry)."""

    key: str
    label: str
    budget: int = 0  # cents
    prior: int = 0  # drawn in previous draws, cents
    current: int = 0  # requested in this draw, cents
    retainage: int = 0
    reported_balance: Optional[int] = None  # balance column as extracted, for math checks
    cost_code: Optional[str] = None
    category: Optional[str] = None
    source_ref: str = ""
    # filled by the normalizer
    norm_label: str = ""
    tokens: tuple = ()
    children: tuple = ()  # keys of trade lines rolled up into this line
    aliases: tuple = ()  # ledger lines only: normalized borrower/LOB labels known to mean this line
    group_aliases: tuple = ()  # ledger lines only: borrower labels that mean a group of ledger lines

    @property
    def balance(self) -> int:
        return self.budget - self.prior - self.current

    def col(self, name: str) -> int:
        return getattr(self, name)

    def vector(self, cols) -> tuple:
        return tuple(self.col(c) for c in cols)

    def to_dict(self) -> dict:
        return {
            "key": self.key,
            "label": self.label,
            "norm_label": self.norm_label,
            "cost_code": self.cost_code,
            "category": self.category,
            "budget": usd(self.budget),
            "prior": usd(self.prior),
            "current": usd(self.current),
            "children": list(self.children),
            "source_ref": self.source_ref,
        }


@dataclass
class MatchGroup:
    comparison: str  # "keying" (borrower vs LOB) or "change" (approved vs borrower)
    relation: str  # "1:1", "N:1" (many left -> one right), "1:N", "1:0", "0:1"
    left: list
    right: list
    pass_name: str
    confidence: float
    notes: list = field(default_factory=list)
    rule_id: str = ""
    rule_name: str = ""

    def total(self, side: str, col: str) -> int:
        return sum(l.col(col) for l in getattr(self, side))

    def to_dict(self) -> dict:
        return {
            "comparison": self.comparison,
            "relation": self.relation,
            "rule": f"{self.rule_id} {self.rule_name}".strip(),
            "pass": self.pass_name,
            "confidence": round(self.confidence, 3),
            "left": [l.key + " | " + l.label for l in self.left],
            "right": [l.key + " | " + l.label for l in self.right],
            "notes": self.notes,
        }


SEVERITY_BLOCKS = {"BLOCKING": True, "REVIEW": True, "WARNING": False, "INFO": False}


@dataclass
class ReconException:
    reason_code: str
    severity: str  # BLOCKING | REVIEW | WARNING | INFO
    comparison: str  # keying | change | rules | extraction
    message: str
    impact_cents: int = 0
    line_keys: list = field(default_factory=list)
    evidence: dict = field(default_factory=dict)
    suggestion: Optional[dict] = None
    rule_id: Optional[str] = None

    @property
    def blocks_posting(self) -> bool:
        return SEVERITY_BLOCKS[self.severity]

    @property
    def exception_id(self) -> str:
        """Stable across re-runs of the same submission, so reviewer resolutions survive a re-run."""
        import hashlib
        raw = "|".join([self.reason_code, self.comparison, self.rule_id or "", *sorted(self.line_keys),
                        str(self.evidence.get("column", ""))])
        return "EX-" + hashlib.sha1(raw.encode()).hexdigest()[:10]

    def to_dict(self) -> dict:
        return {
            "exception_id": self.exception_id,
            "reason_code": self.reason_code,
            "severity": self.severity,
            "blocks_posting": self.blocks_posting,
            "comparison": self.comparison,
            "rule_id": self.rule_id,
            "message": self.message,
            "impact": usd(self.impact_cents),
            "line_keys": self.line_keys,
            "evidence": self.evidence,
            "suggestion": self.suggestion,
        }


@dataclass
class LoanInput:
    loan_id: str
    approved: list  # last approved budget version (system of record)
    borrower: list  # extracted borrower draw file (source document)
    lob: Optional[list] = None  # what the LOB keyed for this draw
    approvals: list = field(default_factory=list)  # approved reallocations / change orders
    sources: Optional[list] = None  # [{"source":..., "amount": cents}]
    mappings: list = field(default_factory=list)  # confirmed mappings from earlier draws
    previous_borrower: Optional[list] = None  # the borrower's previous draw file: the third reference
