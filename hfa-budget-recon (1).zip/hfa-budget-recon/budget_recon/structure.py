"""Structural analysis that runs after line matching, before differences are judged.

It answers the questions a reviewer would ask before looking at single lines:

  1. Category tie-out   Do Acquisition / Hard / Soft / Other totals agree (budget and paid-to-date)?
                        LOB users mostly checked these totals, so they are the most trustworthy anchor.
  2. Misfiled lines     Is a matched line sitting in a different category in the SOR than in the borrower
                        file (e.g. soft contingency keyed under Hard)? Explains equal-and-opposite category gaps.
  3. Regrouping (M:N)   Inside a category, do the lines left unmatched on both sides add up to each other?
                        Then the LOB simply grouped the lines differently: one structural fix, not N exceptions.
  4. Third reference    With the borrower's PREVIOUS draw file, every budget difference can be attributed:
                        borrower unchanged since last file  -> the SOR value is wrong (keying / allocation error)
                        SOR equals the borrower's last file -> a real change this period (needs approval)
                        neither                             -> both moved: escalate
                        and the borrower's own continuity is checked (last prior + last request = this prior).
  5. Paid-to-date moves Within a category whose paid-to-date ties, differences that net to zero are draws
                        booked to the wrong line: a reclass, not a cash problem.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from .grouping import tolerance

CATS = ("ACQUISITION", "HARD", "SOFT", "OTHER", "UNK")


@dataclass
class Findings:
    category_tieout: list = field(default_factory=list)
    misfiles: list = field(default_factory=list)  # {"group", "sor_category", "borrower_category", "budget", "prior"}
    regroups: list = field(default_factory=list)  # {"category", "left", "right", "includes_matched"}
    budget_attribution: dict = field(default_factory=dict)  # id(group) -> SOR_ERROR | REAL_CHANGE | BOTH_MOVED
    prior_misallocated: set = field(default_factory=set)  # id(group)
    continuity: list = field(default_factory=list)  # borrower lines whose prior != last prior + last request
    has_previous: bool = False


def _cat(line):
    return line.category or "UNK"


def effective_left_category(g):
    """SOR category of a group; an unknown SOR category takes the borrower's (no evidence of misfiling)."""
    cats = {_cat(l) for l in g.left} - {"UNK"}
    if len(cats) == 1:
        return next(iter(cats))
    rc = {_cat(r) for r in g.right} - {"UNK"}
    return next(iter(rc)) if len(rc) == 1 else "UNK"


def analyse(res, approved, borrower, previous, cfg) -> Findings:
    f = Findings(has_previous=previous is not None)
    prev = {}
    for p in previous or []:
        prev.setdefault(p.norm_label, p)

    # ---- 4. third reference: the borrower's previous file -------------------------
    for r in borrower:  # borrower's own continuity: last prior + last request must equal this prior
        p = prev.get(r.norm_label)
        if p is not None and p.prior + p.current != r.prior:
            f.continuity.append({"line": r, "previous_prior": p.prior, "previous_request": p.current})
    for g in res.groups:
        if g.relation != "1:1":
            continue
        l, r = g.left[0], g.right[0]
        p = prev.get(r.norm_label)
        if l.budget == r.budget or p is None:
            continue
        if p.budget == r.budget:
            f.budget_attribution[id(g)] = "SOR_ERROR"
        elif p.budget == l.budget:
            f.budget_attribution[id(g)] = "REAL_CHANGE"
        else:
            f.budget_attribution[id(g)] = "BOTH_MOVED"

    # ---- 2. misfiled lines --------------------------------------------------------
    for g in res.groups:
        lc = {_cat(l) for l in g.left} - {"UNK"}
        rc = {_cat(r) for r in g.right} - {"UNK"}
        if len(lc) == 1 and len(rc) == 1 and lc != rc:
            f.misfiles.append({"group": g, "sor_category": next(iter(lc)), "borrower_category": next(iter(rc)),
                               "budget": g.total("left", "budget"), "prior": g.total("left", "prior")})

    # ---- 3. regrouping inside a category (unmatched on both sides, sums tie) --------
    by_cat_l, by_cat_r = {}, {}
    for l in res.unmatched_left:
        by_cat_l.setdefault(_cat(l), []).append(l)
    for r in res.unmatched_right:
        by_cat_r.setdefault(_cat(r), []).append(r)
    for cat in sorted(set(by_cat_l) & set(by_cat_r)):
        ls, rs = by_cat_l[cat], by_cat_r[cat]
        if len(ls) + len(rs) < 3:
            continue  # 1 vs 1 is a rename or a replacement, not a regrouping
        ok = all(abs(sum(x.col(c) for x in ls) - sum(x.col(c) for x in rs)) <= tolerance(sum(x.col(c) for x in rs), cfg)
                 for c in ("budget", "prior"))
        if ok:
            f.regroups.append({"category": cat, "left": ls, "right": rs, "includes_matched": False})
    absorbed = {x.key for rg in f.regroups for x in rg["left"] + rg["right"]}
    res.unmatched_left = [l for l in res.unmatched_left if l.key not in absorbed]
    res.unmatched_right = [r for r in res.unmatched_right if r.key not in absorbed]
    res.regroups = f.regroups

    # ---- 5. paid-to-date booked to the wrong line, inside a category ---------------
    pd_by_cat = {}
    for g in res.groups:
        d = g.total("right", "prior") - g.total("left", "prior")
        if d and not any(m["group"] is g for m in f.misfiles):
            pd_by_cat.setdefault(effective_left_category(g), []).append((g, d))
    for cat, items in pd_by_cat.items():
        if len(items) >= 2 and sum(d for _, d in items) == 0:
            f.prior_misallocated |= {id(g) for g, _ in items}

    # ---- 1. category tie-out (after the explanations above) -------------------------
    sor, bor = {}, {}
    for g in res.groups:
        c = effective_left_category(g)
        for l in g.left:
            s = sor.setdefault(c, [0, 0])
            s[0] += l.budget
            s[1] += l.prior
    for l in res.unmatched_left + [x for rg in f.regroups for x in rg["left"]]:
        s = sor.setdefault(_cat(l), [0, 0])
        s[0] += l.budget
        s[1] += l.prior
    for r in borrower:
        b = bor.setdefault(_cat(r), [0, 0])
        b[0] += r.budget
        b[1] += r.prior
    mis = {}
    for m in f.misfiles:  # what the SOR totals would be once misfiled lines sit in the borrower's category
        mis.setdefault(m["sor_category"], [0, 0])
        mis.setdefault(m["borrower_category"], [0, 0])
        mis[m["sor_category"]][0] -= m["budget"]
        mis[m["sor_category"]][1] -= m["prior"]
        mis[m["borrower_category"]][0] += m["budget"]
        mis[m["borrower_category"]][1] += m["prior"]
    for c in [x for x in CATS if x in sor or x in bor]:
        s, b, adj = sor.get(c, [0, 0]), bor.get(c, [0, 0]), mis.get(c, [0, 0])
        f.category_tieout.append({
            "category": c, "sor_budget": s[0], "borrower_budget": b[0], "budget_gap": b[0] - s[0],
            "sor_prior": s[1], "borrower_prior": b[1], "prior_gap": b[1] - s[1],
            "budget_gap_after_misfiles": b[0] - (s[0] + adj[0]), "prior_gap_after_misfiles": b[1] - (s[1] + adj[1]),
        })
    return f
