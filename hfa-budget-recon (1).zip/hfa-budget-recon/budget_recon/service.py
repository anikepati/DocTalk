"""Application service: the end-to-end workflow for one draw, behind a storage-agnostic repository.

  identify   reconcile the submission against the CURRENT ledger version (bootstraps version 1 if new)
  plan       turn change-check findings into a balanced restructuring change set
  submit     maker submits the change set
  approve    checker approves; every money-moving op needs an approval_ref or a recorded override
  commit     apply with invariants -> new ledger version (idempotent; optimistic concurrency)
  resolve    reviewer resolves remaining exceptions by stable exception_id
  post_draw  re-identify against the restructured version, require all blocking items resolved, post

Every step emits an event (EventSink), so the same service runs behind a REST API, a Kafka consumer
or a batch job without change.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import asdict
from typing import Protocol

from .engine import ReconEngine
from .ledger import bootstrap_version
from .normalize import Normalizer
from .planner import Planner
from .posting import post_draw
from .restructure import ChangeSet, ChangeSetError, apply_change_set


class EventSink(Protocol):
    def emit(self, event_type: str, payload: dict) -> None: ...


class ListSink:
    def __init__(self):
        self.events = []

    def emit(self, event_type, payload):
        self.events.append({"type": event_type, "at": _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"),
                            **payload})


class WorkflowError(RuntimeError):
    pass


class ReconService:
    def __init__(self, cfg, repo, events: EventSink = None):
        self.cfg, self.repo = cfg, repo
        self.events = events or ListSink()
        self.engine = ReconEngine(cfg)
        self.norm = Normalizer(cfg)
        self.planner = Planner(cfg)

    # ---- identify + plan -------------------------------------------------
    def ledger(self, loan):
        v = self.repo.current(loan.loan_id)
        if v is None:
            total_sources = sum(s["amount"] for s in loan.sources) if loan.sources else None
            v = bootstrap_version(loan.loan_id, loan.approved, self.norm, total_sources)
            self.repo.save(v)
            self.events.emit("ledger.bootstrapped", {"loan_id": loan.loan_id, "version": 1, "lines": len(v.lines)})
        return v

    def identify(self, loan):
        v = self.ledger(loan)
        rep = self.engine.reconcile(loan, ledger=v)
        self.events.emit("recon.completed", {"loan_id": loan.loan_id, "ledger_version": v.version_no,
                                             "can_post": rep.can_post, "counts": rep.counts()})
        return rep

    def plan(self, loan, report) -> ChangeSet:
        v = self.repo.current(loan.loan_id)
        approvals = [{**a, "norm_label": " ".join(self.norm.tokens(a["label"])) if a.get("label") else None}
                     for a in loan.approvals]
        cs = self.planner.plan(v, report, approvals)
        if not cs.ops:
            cs.status = "NOT_NEEDED"
        self.repo.save_record(loan.loan_id, "change_sets", cs.change_set_id, cs.to_dict())
        self.events.emit("restructure.planned", {"loan_id": loan.loan_id, "change_set_id": cs.change_set_id,
                                                 "ops": len(cs.ops), "open_issues": len(cs.open_issues)})
        return cs

    # ---- maker-checker ---------------------------------------------------
    def submit(self, cs: ChangeSet, maker: str, manual_ops=()):
        if cs.status != "DRAFT":
            raise WorkflowError(f"cannot submit a {cs.status} change set")
        cs.ops += list(manual_ops)
        cs.maker, cs.status = maker, "SUBMITTED"
        self._save(cs)
        return cs

    def approve(self, cs: ChangeSet, checker: str, approval_refs=None, overrides=None, resolved_issues=()):
        """approval_refs / overrides: {op_index: ref or reason}. resolved_issues: open-issue codes cleared by checker."""
        if cs.status != "SUBMITTED":
            raise WorkflowError(f"cannot approve a {cs.status} change set")
        if checker == cs.maker:
            raise WorkflowError("maker and checker must be different people")
        for i, ref in (approval_refs or {}).items():
            cs.ops[int(i)].approval_ref = ref
        for i, reason in (overrides or {}).items():
            cs.overrides.append({"op": int(i), "by": checker, "reason": reason})
        overridden = {o["op"] for o in cs.overrides}
        missing = [i for i, o in enumerate(cs.ops) if o.requires_approval and not o.approval_ref and i not in overridden]
        if missing:
            raise WorkflowError("ops need an approval reference or a checker override: " +
                                ", ".join(f"#{i} {cs.ops[i].describe()}" for i in missing))
        blocking = [x for x in cs.open_issues if x.get("severity", "BLOCKING") == "BLOCKING"
                    and x["code"] not in resolved_issues]
        if blocking:
            raise WorkflowError(f"unresolved planning issues: {blocking}")
        cs.checker, cs.status = checker, "APPROVED"
        self._save(cs)
        self.events.emit("restructure.approved", {"loan_id": cs.loan_id, "change_set_id": cs.change_set_id,
                                                  "maker": cs.maker, "checker": checker})
        return cs

    def commit(self, cs: ChangeSet):
        stored = self.repo.load_record(cs.loan_id, "change_sets", cs.change_set_id)
        if stored and stored["status"] == "COMMITTED":  # idempotent replay
            return self.repo.get(cs.loan_id, stored["committed_version"])
        if cs.status != "APPROVED":
            raise WorkflowError(f"cannot commit a {cs.status} change set")
        cur = self.repo.current(cs.loan_id)
        try:
            nv, refs = apply_change_set(cur, cs)
        except ChangeSetError as exc:
            self.events.emit("restructure.rejected", {"loan_id": cs.loan_id, "errors": exc.errors})
            raise
        self.repo.save(nv)
        cs.status, cs.committed_version = "COMMITTED", nv.version_no
        cs.notes.append({"new_line_ids": refs})
        self._save(cs)
        self.events.emit("restructure.committed", {"loan_id": cs.loan_id, "change_set_id": cs.change_set_id,
                                                   "version": nv.version_no, "new_lines": refs})
        return nv

    # ---- exceptions + posting -------------------------------------------
    def resolve(self, loan_id, draw_no, exception_id, action, user, note="", adjust_current_cents=None,
                borrower_key=None):
        """action: CORRECTED | ACCEPTED | OVERRIDDEN | ADJUST_DRAW (with borrower_key + adjust_current_cents)."""
        rid = f"draw-{draw_no}"
        rec = self.repo.load_record(loan_id, "resolutions", rid) or {}
        rec[exception_id] = {"action": action, "by": user, "note": note, "borrower_key": borrower_key,
                             "adjust_current_cents": adjust_current_cents}
        self.repo.save_record(loan_id, "resolutions", rid, rec)
        self.events.emit("exception.resolved", {"loan_id": loan_id, "exception_id": exception_id, "action": action})

    def post(self, loan, draw_no: int):
        v = self.repo.current(loan.loan_id)
        rep = self.engine.reconcile(loan, ledger=v)
        res = self.repo.load_record(loan.loan_id, "resolutions", f"draw-{draw_no}") or {}
        open_items = [e for e in rep.exceptions if e.blocks_posting and e.exception_id not in res]
        if open_items:
            raise WorkflowError("unresolved exceptions: " + "; ".join(f"{e.exception_id} {e.reason_code}: {e.message}"
                                                                       for e in open_items))
        adjustments = {r["borrower_key"]: r["adjust_current_cents"] for r in res.values()
                       if r["action"] == "ADJUST_DRAW"}
        nv, record = post_draw(v, rep.borrower_lines, draw_no, adjustments)
        self.repo.save(nv)
        self.repo.save_record(loan.loan_id, "draws", f"draw-{draw_no}", asdict(record))
        self.events.emit("draw.posted", {"loan_id": loan.loan_id, "draw_no": draw_no, "version": nv.version_no,
                                         "total": record.total})
        return nv, record

    def _save(self, cs):
        self.repo.save_record(cs.loan_id, "change_sets", cs.change_set_id, cs.to_dict())
