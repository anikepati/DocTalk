"""Configuration loading. Everything tunable lives in JSON files (Postgres cfg_* tables in production)."""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

DEFAULT_CONFIG_DIR = Path(__file__).resolve().parent.parent / "config"


@dataclass
class Config:
    settings: dict
    abbreviations: dict
    cost_codes: list
    rules: list
    version: str

    def s(self, key, default=None):
        return self.settings.get(key, default)

    def override(self, **kwargs) -> "Config":
        merged = dict(self.settings)
        merged.update(kwargs)
        return Config(merged, self.abbreviations, self.cost_codes, self.rules, self.version + "+override")


def load_config(config_dir=None) -> Config:
    d = Path(config_dir) if config_dir else DEFAULT_CONFIG_DIR
    parts = {}
    for name in ("settings", "abbreviations", "cost_codes", "rules"):
        parts[name] = json.loads((d / f"{name}.json").read_text())
    mr = d / "match_rules.json"
    if mr.exists():
        parts["settings"] = {**parts["settings"], "match_rules": json.loads(mr.read_text())["rules"]}
    digest = hashlib.sha256(json.dumps(parts, sort_keys=True).encode()).hexdigest()[:12]
    return Config(
        settings=parts["settings"],
        abbreviations=parts["abbreviations"],
        cost_codes=parts["cost_codes"]["codes"],
        rules=parts["rules"]["rules"],
        version=digest,
    )
