"""Restructuring planner: turns what the change check IDENTIFIED into a concrete, balanced change set
with exact amounts, so that after it is committed the next draw matches the ledger 1:1.

Case -> operations (see the design doc's case catalog):
  label variant / abbreviation            -> ADD_ALIAS (+ RELABEL to the borrower's wording)
  baseline holds a merged line (1:N)      -> SPLIT with each child's budget AND prior draws from the borrower file
  borrower merged ledger lines (N:1)      -> MERGE (policy adopt_borrower_structure) or ADD_GROUP_ALIAS (keep_system_detail)
  brand-new borrower line                 -> CREATE + REALLOCATE from the lines it is funded by (or FUNDING_CHANGE)
  new line already carrying prior draws   -> CREATE + RECLASS_DRAWS from the line those draws were booked to
  line dropped by the borrower            -> REALLOCATE its budget away, then RETIRE (no draws) or CLOSE at drawn
  budget changed between existing lines   -> REALLOCATE (paired, contingency first) / FUNDING_CHANGE for the net
  prior draws disagree and do not net out -> CORRECT_DRAWN, which needs evidence (wire / funding record)
  category changed                        -> RECATEGORIZE (needs approval: affects eligible basis and source rules)
Anything it cannot decide (ambiguous groups, search limits) is listed in open_issues and blocks commit.
"""
from __future__ import annotations

from .restructure import ChangeSet, Op

_PHASE = {"SPLIT": 0, "MERGE": 0, "REGROUP": 0, "CORRECT_BUDGET": 1, "CREATE": 1, "ADD_ALIAS": 2, "ADD_GROUP_ALIAS": 2, "RELABEL": 2,
          "RECATEGORIZE": 2, "RECLASS_DRAWS": 3, "CORRECT_DRAWN": 3, "REALLOCATE": 4, "FUNDING_CHANGE": 4,
          "RETIRE": 5, "CLOSE": 5}


def _largest_remainder(total: int, weights: list) -> list:
    """Split integer total by weights; exact, deterministic."""
    if total == 0 or not weights:
        return [0] * len(weights)
    s = sum(weights)
    if s == 0:
        weights, s = [1] * len(weights), len(weights)
    raw = [total * w / s for w in weights]
    base = [int(x) for x in raw]
    rem = total - sum(base)
    order = sorted(range(len(weights)), key=lambda i: (-(raw[i] - base[i]), i))
    for i in order[:rem]:
        base[i] += 1
    return base


class Planner:
    def __init__(self, cfg):
        pol = cfg.s("restructure", {})
        self.merge_policy = pol.get("on_borrower_merge", "adopt_borrower_structure")
        self.adopt_labels = pol.get("adopt_borrower_labels", True)
        self.funding_pref = pol.get("funding_preference", ["HC-0900", "SC-0950"])

    def plan(self, version, report, approvals=()) -> ChangeSet:
        self.version = version
        self.ops, self.issues = [], []
        self.budget_delta, self.prior_delta = {}, {}
        self.meta = {}  # target ref -> {"label","category","cost_code","norms"}
        res = report.change
        self.corrected = {id(c["group"]): c for c in (getattr(report, "corrections", None) or [])}
        fnd = getattr(report, "findings", None)
        self.misalloc = {l.key for g in res.groups if fnd and id(g) in fnd.prior_misallocated for l in g.left}

        for rg in getattr(res, "regroups", []) or []:
            self._regroup(rg)
        for g in res.groups:
            self.cur = g
            self.ev = {"confidence": round(g.confidence, 3), "pass": g.pass_name}
            if g.relation == "1:1":
                self._one_to_one(g.left[0], g.right[0])
            elif g.relation == "1:N":
                self._split(g.left[0], g.right)
            elif g.relation == "N:1":
                self._merge(g.left, g.right[0])
        self.ev = {}
        for r in res.unmatched_right:
            self._create(r)
        removed = list(res.unmatched_left)
        self.removed_keys = {l.key for l in removed}
        for l in removed:
            self._target(l.key, l.label, l.category, l.cost_code, l.aliases)
            self._add(self.prior_delta, l.key, -l.prior)
        for a in res.ambiguities:
            self.issues.append({"code": "AMBIGUOUS_CONSOLIDATION", "line": a["target"].key,
                                "detail": "Pick the correct group, then re-run planning"})
        for s in res.search_limits:
            self.issues.append({"code": "SEARCH_LIMIT", "line": s["target"].key, "detail": s["reason"]})

        final_drawn = self._plan_prior_draws()
        for l in removed:
            keep = max(0, final_drawn.get(l.key, 0))
            self._add(self.budget_delta, l.key, -(l.budget - keep))
        self._plan_budget_moves()
        for l in removed:
            if final_drawn.get(l.key, 0) > 0:
                self.ops.append(Op("CLOSE", {"line": l.key}, "Borrower dropped a line that already has draws; "
                                   "kept at budget = drawn so history is preserved"))
                self.issues.append({"code": "DROPPED_LINE_HAS_DRAWS", "line": l.key, "severity": "REVIEW",
                                    "detail": f"{l.label} keeps its draw history; confirm with borrower"})
            else:
                self.ops.append(Op("RETIRE", {"line": l.key}, "Borrower no longer carries this line"))

        self._attach_approvals(approvals)
        self.ops.sort(key=lambda o: _PHASE[o.kind])  # stable: keeps planning order within a phase
        cs = ChangeSet(ChangeSet.make_id(version.loan_id, version.version_no, self.ops), version.loan_id,
                       version.version_no, self.ops, open_issues=self.issues)
        return cs

    # ---- structural cases ------------------------------------------------
    def _target(self, ref, label, category, code, norms=()):
        self.meta.setdefault(ref, {"label": label, "category": category, "cost_code": code, "norms": set(norms)})

    @staticmethod
    def _add(d, k, v):
        if v:
            d[k] = d.get(k, 0) + v

    def _spec(self, r):
        return {"ref": f"new:{r.key}", "label": r.label, "cost_code": r.cost_code, "category": r.category,
                "budget": r.budget, "drawn": r.prior, "retainage": r.retainage, "aliases": [r.norm_label]}

    def _one_to_one(self, l, r):
        self._target(l.key, l.label, l.category, l.cost_code, set(l.aliases) | {r.norm_label})
        if r.norm_label and r.norm_label not in l.aliases:
            self.ops.append(Op("ADD_ALIAS", {"line": l.key, "alias": r.norm_label},
                               f"Borrower calls '{l.label}' '{r.label}'", evidence=dict(self.ev)))
        if self.adopt_labels and r.label != l.label and not r.children and r.norm_label not in l.group_aliases:
            self.ops.append(Op("RELABEL", {"line": l.key, "label": r.label}, "Adopt the borrower's wording",
                               evidence=dict(self.ev)))
        if r.category not in (None, "UNK") and l.category not in (None, "UNK") and r.category != l.category:
            self.ops.append(Op("RECATEGORIZE", {"line": l.key, "category": r.category, "cost_code": r.cost_code},
                               f"{l.category} -> {r.category}: check eligible basis and source restrictions"))
        corr = self.corrected.get(id(self.cur))
        if corr:
            self.ops.append(Op("CORRECT_BUDGET", {"line": l.key, "amount": corr["amount"], "basis": corr["basis"]},
                               "The SOR value is wrong; this is a correction, not a budget change",
                               evidence={"system": l.budget, "borrower": r.budget, **self.ev}))
        else:
            self._add(self.budget_delta, l.key, r.budget - l.budget)
        self._add(self.prior_delta, l.key, r.prior - l.prior)

    def _regroup(self, rg):
        """M:N regrouping inside one category: retire the SOR lines, create the borrower's lines with the
        borrower's budget and paid-to-date, conserving the totals exactly."""
        ls, rs = rg["left"], sorted(rg["right"], key=lambda x: x.key)
        specs = [self._spec(r) for r in rs]
        big = max(range(len(specs)), key=lambda i: (specs[i]["budget"], -i))
        db = sum(l.budget for l in ls) - sum(s["budget"] for s in specs)
        dd = sum(l.prior for l in ls) - sum(s["drawn"] for s in specs)
        specs[big]["budget"] += db
        specs[big]["drawn"] += dd
        rets = _largest_remainder(sum(l.retainage for l in ls), [s["drawn"] for s in specs])
        for s_, ret in zip(specs, rets):
            s_["retainage"] = ret
        self.ops.append(Op("REGROUP", {"sources": [l.key for l in ls], "children": specs},
                           f"{rg['category']}: lines were grouped differently when keyed; totals tie",
                           evidence={"category": rg["category"]}))
        for s_ in specs:
            self._target(s_["ref"], s_["label"], s_["category"], s_["cost_code"], s_["aliases"])
        self._add(self.budget_delta, specs[big]["ref"], -db)
        self._add(self.prior_delta, specs[big]["ref"], -dd)

    def _split(self, l, rs):
        specs = [self._spec(r) for r in sorted(rs, key=lambda x: x.key)]
        big = max(range(len(specs)), key=lambda i: (specs[i]["budget"], -i))
        db = l.budget - sum(s["budget"] for s in specs)
        dd = l.prior - sum(s["drawn"] for s in specs)
        specs[big]["budget"] += db  # tolerance residue: keep the split exact, then reconcile to borrower figure
        specs[big]["drawn"] += dd
        rets = _largest_remainder(l.retainage, [s["drawn"] for s in specs])
        for s, ret in zip(specs, rets):
            s["retainage"] = ret
        self.ops.append(Op("SPLIT", {"source": l.key, "children": specs},
                           f"Approved line '{l.label}' holds {len(specs)} borrower lines; budget and prior draws "
                           "taken line by line from the borrower file", evidence={"lineage": l.key, **self.ev}))
        for s in specs:
            self._target(s["ref"], s["label"], s["category"], s["cost_code"], s["aliases"])
        self._add(self.budget_delta, specs[big]["ref"], -db)
        self._add(self.prior_delta, specs[big]["ref"], -dd)

    def _merge(self, ls, r):
        if self.merge_policy == "keep_system_detail":
            keys = [l.key for l in ls]
            self.ops.append(Op("ADD_GROUP_ALIAS", {"lines": keys, "alias": r.norm_label},
                               f"Borrower reports {len(keys)} ledger lines as '{r.label}'; detail kept, "
                               "draws allocated across the group by remaining balance", evidence=dict(self.ev)))
            big = max(ls, key=lambda x: (x.budget, x.key))
            for l in ls:
                self._target(l.key, l.label, l.category, l.cost_code, l.aliases)
            self._add(self.budget_delta, big.key, r.budget - sum(l.budget for l in ls))
            self._add(self.prior_delta, big.key, r.prior - sum(l.prior for l in ls))
            return
        spec = {k: v for k, v in self._spec(r).items() if k not in ("budget", "drawn", "retainage")}
        self.ops.append(Op("MERGE", {"sources": [l.key for l in ls], "into": spec},
                           f"Borrower carries {len(ls)} ledger lines as one line '{r.label}'", evidence=dict(self.ev)))
        self._target(spec["ref"], r.label, r.category, r.cost_code, [r.norm_label])
        self._add(self.budget_delta, spec["ref"], r.budget - sum(l.budget for l in ls))
        self._add(self.prior_delta, spec["ref"], r.prior - sum(l.prior for l in ls))

    def _create(self, r):
        spec = {k: v for k, v in self._spec(r).items() if k not in ("budget", "drawn", "retainage")}
        self.ops.append(Op("CREATE", {"spec": spec}, f"New borrower line '{r.label}'"))
        self._target(spec["ref"], r.label, r.category, r.cost_code, [r.norm_label])
        self._add(self.budget_delta, spec["ref"], r.budget)
        self._add(self.prior_delta, spec["ref"], r.prior)

    # ---- money -----------------------------------------------------------
    def _pair(self, deltas, prefer_contingency):
        """Pair decreases with increases deterministically. Returns (pairs, unfunded_increases, unused_decreases)."""
        inc = {k: v for k, v in deltas.items() if v > 0}
        dec = {k: -v for k, v in deltas.items() if v < 0}
        pairs = []

        def rank(src, dst):
            m_src, m_dst = self.meta.get(src, {}), self.meta.get(dst, {})
            pref = self.funding_pref.index(m_src.get("cost_code")) if (prefer_contingency and m_src.get("cost_code") in self.funding_pref) else len(self.funding_pref)
            return (m_src.get("category") != m_dst.get("category"), pref, -dec[src], src)

        for dst in sorted(inc, key=lambda k: (-inc[k], k)):
            for src in sorted([s for s in dec if dec[s] > 0], key=lambda s: rank(s, dst)):
                if inc[dst] == 0:
                    break
                amt = min(inc[dst], dec[src])
                pairs.append((src, dst, amt))
                inc[dst] -= amt
                dec[src] -= amt
        return pairs, {k: v for k, v in inc.items() if v}, {k: v for k, v in dec.items() if v}

    def _plan_prior_draws(self):
        drawn_after = {}
        # 1) draws booked to the wrong line inside a category (found by the structure analysis): reclass those first
        mis = {k: v for k, v in self.prior_delta.items() if k in self.misalloc}
        pairs, up1, down1 = self._pair(mis, prefer_contingency=False)
        # 2) everything else: new lines carrying history booked elsewhere, then genuine record gaps
        rest = {k: v for k, v in self.prior_delta.items() if k not in self.misalloc}
        rest.update(up1)
        rest.update({k: -v for k, v in down1.items()})
        p2, up, down = self._pair(rest, prefer_contingency=False)
        pairs += p2
        for src, dst, amt in pairs:
            self.ops.append(Op("RECLASS_DRAWS", {"from": src, "to": dst, "amount": amt},
                               "Borrower books these prior draws to a different line; total disbursed is unchanged"))
            drawn_after[src] = drawn_after.get(src, 0) - amt
            drawn_after[dst] = drawn_after.get(dst, 0) + amt
        for k, v in sorted(up.items()):
            self.ops.append(Op("CORRECT_DRAWN", {"line": k, "amount": v},
                               "Borrower shows more drawn than the ledger: likely a missed disbursement record",
                               evidence={"needs": "funding / wire record"}))
            drawn_after[k] = drawn_after.get(k, 0) + v
        for k, v in sorted(down.items()):
            if k in self.removed_keys:
                continue  # dropped line keeps its own history (closed at drawn); never erase disbursed cash
            self.ops.append(Op("CORRECT_DRAWN", {"line": k, "amount": -v},
                               "Ledger shows more drawn than the borrower acknowledges: dispute or duplicate record",
                               evidence={"needs": "funding / wire record"}))
            drawn_after[k] = drawn_after.get(k, 0) - v
        # absolute drawn after planning, for ledger lines
        out = {}
        for k, l in self.version.lines.items():
            out[k] = l.drawn + drawn_after.get(k, 0)
        return out

    def _plan_budget_moves(self):
        pairs, up, down = self._pair(self.budget_delta, prefer_contingency=True)
        for src, dst, amt in pairs:
            self.ops.append(Op("REALLOCATE", {"from": src, "to": dst, "amount": amt},
                               f"Fund {self.meta.get(dst, {}).get('label', dst)} from {self.meta.get(src, {}).get('label', src)}"))
        for k, v in sorted(up.items()):
            self.ops.append(Op("FUNDING_CHANGE", {"line": k, "amount": v},
                               "Net budget increase: needs a matching Sources increase"))
        for k, v in sorted(down.items()):
            self.ops.append(Op("FUNDING_CHANGE", {"line": k, "amount": -v},
                               "Net budget decrease: Sources exceed Uses unless reduced"))

    def _attach_approvals(self, approvals):
        """Attach a recorded approval to an op when both of its ends are covered by the same approval_ref."""
        def covers(a, ref, amount):
            m = self.meta.get(ref, {})
            same = (a.get("cost_code") and a["cost_code"] == m.get("cost_code")) or \
                   (a.get("norm_label") and a["norm_label"] in m.get("norms", set()))
            return same and a["delta"] == amount
        for op in self.ops:
            p = op.params
            if op.kind == "REALLOCATE":
                for a in approvals:
                    if covers(a, p["to"], p["amount"]) and any(
                            b["approval_ref"] == a["approval_ref"] and covers(b, p["from"], -p["amount"]) for b in approvals):
                        op.approval_ref = a["approval_ref"]
                        break
            elif op.kind in ("FUNDING_CHANGE", "CORRECT_DRAWN"):
                for a in approvals:
                    if covers(a, p["line"], p["amount"]):
                        op.approval_ref = a["approval_ref"]
                        break
