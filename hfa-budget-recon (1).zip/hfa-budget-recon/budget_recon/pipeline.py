"""Autonomous draw processing with human-in-the-loop review.

The system takes the borrower's latest file and does the whole job itself:

  RECEIVED -> extraction gate -> restructure gate -> post gate -> POSTED
                    |                  |                 |
                    +--------- AWAITING_REVIEW ----------+   (only for what policy cannot decide)
                    |                  |                 |
                    +------------ RETURNED_TO_BORROWER --+   (a reviewer sends it back)

Each gate either passes by policy or opens HITL tasks and stops. When the last task of a gate is decided,
processing resumes on its own. Every step is idempotent: re-running a submission never duplicates tasks,
change sets or postings, and the same file submitted twice is recognized by its hash.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import asdict, fields
from pathlib import Path

from .engine import ReconEngine
from .extract import CsvExtractor, ExcelExtractor, extract_file
from .hitl import TaskError, TaskQueue
from .io import read_lines
from .ledger import bootstrap_version
from .models import Line, LoanInput
from .money import to_cents, usd
from .normalize import Normalizer
from .planner import Planner
from .policy import StpPolicy
from .posting import PostingError, post_draw
from .restructure import ChangeSet, Op
from .service import ListSink, ReconService

_LINE_FIELDS = ("key", "label", "budget", "prior", "current", "retainage", "reported_balance", "cost_code",
                "category", "source_ref")


def _line_to_dict(l):
    return {k: getattr(l, k) for k in _LINE_FIELDS}


def _line_from_dict(d):
    return Line(**{k: d.get(k) for k in _LINE_FIELDS if k in {f.name for f in fields(Line)}})


class FolderFeeds:
    """Reference data the pipeline needs from other systems. Production: approvals from the change-order /
    reallocation workflow, sources from the loan servicing system. Here: feeds/<loan_id>/*.csv."""

    def __init__(self, root):
        self.root = Path(root)

    def approvals(self, loan_id):
        p = self.root / loan_id / "approvals.csv"
        if not p.exists():
            return []
        import csv
        return [{"approval_ref": r["approval_ref"], "cost_code": r.get("cost_code") or None,
                 "label": r.get("label") or None, "delta": to_cents(r["delta"])} for r in csv.DictReader(p.open())]

    def sources(self, loan_id):
        p = self.root / loan_id / "sources.csv"
        if not p.exists():
            return None
        import csv
        return [{"source": r["source"], "amount": to_cents(r["amount"])} for r in csv.DictReader(p.open())]


class Pipeline:
    def __init__(self, cfg, repo, feeds, extractors=None, events=None, clock=None, sor=None):
        self.cfg, self.repo, self.feeds = cfg, repo, feeds
        self.sor = sor  # SorAdapter: when set, every posted draw is pushed to the SOR and verified by read-back
        self.events = events or ListSink()
        self.clock = clock or (lambda: _dt.datetime.now(_dt.timezone.utc))
        self.extractors = extractors or [ExcelExtractor(), CsvExtractor()]
        self.policy = StpPolicy(cfg)
        self.tasks = TaskQueue(repo, self.clock)
        self.norm = Normalizer(cfg)
        self.engine = ReconEngine(cfg)
        self.planner = Planner(cfg)
        self.svc = ReconService(cfg, repo, self.events)

    # ------------------------------------------------------------------ onboarding
    def onboard(self, loan_id, approved_budget_file, last_draw_no=None, previous_borrower_file=None):
        """Bring a loan under automation, at closing or mid-project (e.g. after draw 18 of 36).

        approved_budget_file: the SOR export (key, label, [category], budget, prior = paid to date).
        last_draw_no:         the last draw already posted in the SOR, so the next file is checked for sequence.
        previous_borrower_file: the borrower's file for that last draw: the third reference for attribution.
        """
        if self.repo.current(loan_id):
            return self.repo.current(loan_id)
        src = self.feeds.sources(loan_id)
        sor_lines = read_lines(Path(approved_budget_file))
        v = bootstrap_version(loan_id, sor_lines, self.norm, sum(s["amount"] for s in src) if src else None)
        v.draw_no = last_draw_no
        self.repo.save(v)
        sor_map = {lid: l.lineage[0].split(":", 1)[1] for lid, l in v.lines.items()}
        self.repo.save_record(loan_id, "sor_map", "current", sor_map)
        if self.sor is not None and not self.sor.export(loan_id):
            self.sor.load_export(loan_id, approved_budget_file)
        if previous_borrower_file:
            prev = extract_file(previous_borrower_file, self.extractors)
            self.repo.save_record(loan_id, "baseline", "previous_borrower",
                                  {"draw_no": last_draw_no, "lines": [_line_to_dict(l) for l in prev.lines]})
        self.events.emit("ledger.bootstrapped", {"loan_id": loan_id, "version": 1, "lines": len(v.lines),
                                                 "last_draw_no": last_draw_no})
        return v

    # ------------------------------------------------------------------ intake
    def receive(self, path, loan_id=None, draw_no=None, lob_file=None) -> dict:
        ext = extract_file(path, self.extractors)
        loan_id = loan_id or ext.meta.get("loan_id")
        draw_no = int(draw_no or ext.meta.get("draw_no") or 0)
        if not loan_id or not draw_no:
            raise ValueError("cannot tell which loan and draw this file is for; pass loan_id and draw_no")
        sid = f"SUB-{loan_id}-D{draw_no:03d}-{ext.file_hash[:8]}"
        existing = self.repo.load_record(loan_id, "submissions", sid)
        if existing:
            self.events.emit("submission.duplicate", {"loan_id": loan_id, "submission_id": sid})
            return existing  # same file again: idempotent
        self._supersede(loan_id, draw_no, sid)
        sub = {"submission_id": sid, "loan_id": loan_id, "draw_no": draw_no, "file": str(path),
               "file_hash": ext.file_hash, "method": ext.meta.get("method"), "meta": ext.meta,
               "state": "RECEIVED", "stage": "extraction", "lines": [_line_to_dict(l) for l in ext.lines],
               "extraction": {"checks": ext.checks, "confidence": ext.confidence},
               "extraction_accepted": False, "change_set_id": None, "history": [], "returned_reasons": [],
               "previous_lines": self._previous_lines(loan_id, draw_no),
               "lob_lines": [_line_to_dict(l) for l in read_lines(Path(lob_file))] if lob_file else None}
        self._log(sub, "RECEIVED", f"{len(ext.lines)} lines via {ext.meta.get('method')}, "
                                   f"{len(ext.checks)} extraction checks"
                                   + ("" if sub["previous_lines"] else "; no previous borrower file on record"))
        self._save(sub)
        self.events.emit("submission.received", {"loan_id": loan_id, "submission_id": sid, "draw_no": draw_no})
        return self.run(loan_id, sid)

    def _previous_lines(self, loan_id, draw_no):
        """The borrower's last accepted file: the latest posted submission, or the onboarding baseline."""
        done = [x for x in self.repo.list_records("submissions", loan_id)
                if x["state"] in ("POSTED", "SOR_SYNCED") and x["draw_no"] < draw_no]
        if done:
            last = max(done, key=lambda x: x["draw_no"])
            return last.get("funded_lines") or last["lines"]
        base = self.repo.load_record(loan_id, "baseline", "previous_borrower")
        return base["lines"] if base and (base["draw_no"] or 0) < draw_no else None

    def _supersede(self, loan_id, draw_no, new_sid):
        """A corrected file for the same draw replaces any earlier one that has not been posted."""
        for old in self.repo.list_records("submissions", loan_id):
            if old["draw_no"] == draw_no and old["submission_id"] != new_sid and \
                    old["state"] not in ("POSTED", "SOR_SYNCED", "REJECTED", "SUPERSEDED"):
                old["state"] = "SUPERSEDED"
                self._log(old, "SUPERSEDED", f"replaced by {new_sid}")
                self.tasks.cancel_open(loan_id, old["submission_id"], f"superseded by {new_sid}")
                self._save(old)
                self.events.emit("submission.superseded", {"loan_id": loan_id, "submission_id": old["submission_id"],
                                                           "by": new_sid})

    # ------------------------------------------------------------------ the state machine
    def run(self, loan_id, sid) -> dict:
        sub = self._load(loan_id, sid)
        terminal = {"RETURNED_TO_BORROWER", "REJECTED", "SUPERSEDED", "SOR_SYNCED"} | \
            (set() if self.sor else {"POSTED"})
        for _ in range(5):  # extraction -> restructure -> post -> sync; bounded so a bug can never spin
            if sub["state"] in terminal:
                break
            if self._returned(sub):  # a return or rejection takes effect at once and cancels other tasks
                break
            if self._open_tasks(sub):
                sub["state"] = "AWAITING_REVIEW"
                break
            step = {"extraction": self._extraction_gate, "restructure": self._restructure_gate,
                    "post": self._post_gate, "sync": self._sync_gate}[sub["stage"]]
            if not step(sub):
                break
        if sub["state"] not in terminal | {"POSTED"} and self._open_tasks(sub):
            sub["state"] = "AWAITING_REVIEW"
        self._save(sub)
        return sub

    def decide(self, loan_id, task_id, action, user, payload=None) -> dict:
        t = self.tasks.get(loan_id, task_id)
        if t is None:
            raise TaskError(f"no task {task_id}")
        payload = dict(payload or {})
        if t.kind == "RESTRUCTURE_OP" and action == "APPROVE" and t.evidence.get("requires_approval_ref") \
                and not payload.get("approval_ref"):
            raise TaskError("this change moves money or disbursement history: give approval_ref "
                            "(change order, reallocation memo or wire reference)")
        if action == "ADJUST_DRAW":
            keys = t.evidence.get("borrower_keys", [])
            payload.setdefault("borrower_key", keys[0] if len(keys) == 1 else None)
            if not payload.get("borrower_key") or payload.get("amount_cents") is None:
                raise TaskError("ADJUST_DRAW needs borrower_key and amount_cents")
        self.tasks.decide(t, action, user, payload)
        self.events.emit("task.decided", {"loan_id": loan_id, "task_id": task_id, "action": action, "user": user})
        return self.run(loan_id, t.submission_id)

    # ------------------------------------------------------------------ gate 1: extraction
    def _extraction_gate(self, sub) -> bool:
        v = self.repo.current(sub["loan_id"])
        if v is None:
            return self._reject(sub, "ONBOARDING_REQUIRED", "loan has no ledger; onboard its approved budget first")
        if v.draw_no is not None and sub["draw_no"] <= v.draw_no:
            return self._reject(sub, "DRAW_ALREADY_POSTED", f"ledger already has draw {v.draw_no}")
        expected = (v.draw_no or 0) + 1
        if v.draw_no is not None and sub["draw_no"] != expected:
            self._task(sub, "DRAW_EXCEPTION", "extraction", "SEQUENCE", "Draw out of sequence",
                       f"Expected draw {expected}, file is draw {sub['draw_no']}", ["OVERRIDE", "RETURN_TO_BORROWER"])
        ext = sub["extraction"]
        if ext["checks"] and not sub["extraction_accepted"]:
            ok = not any(c["severity"] == "BLOCKING" for c in ext["checks"]) and \
                ext["confidence"] >= self.policy.p.get("extraction_min_confidence", 0.95)
            if not ok:
                self._task(sub, "EXTRACTION_REVIEW", "extraction", "EXTRACTION", "Check the extracted figures",
                           "; ".join(c["detail"] for c in ext["checks"])[:900], ["ACCEPT", "RETURN_TO_BORROWER"],
                           evidence={"checks": ext["checks"], "method": sub["method"]})
        if self._open_tasks(sub):
            return False
        if any(t.outcome == "ACCEPT" for t in self._stage_tasks(sub, "extraction")):
            sub["extraction_accepted"] = True
        sub["stage"] = "restructure"
        self._log(sub, "EXTRACTED", "extraction accepted" + (" by policy" if not ext["checks"] else ""))
        return True

    # ------------------------------------------------------------------ gate 2: restructure the ledger
    def _restructure_gate(self, sub) -> bool:
        loan_id = sub["loan_id"]
        cs = None
        if sub["change_set_id"]:
            cs = ChangeSet.from_dict(self.repo.load_record(loan_id, "change_sets", sub["change_set_id"]))
        if cs is None:
            v = self.repo.current(loan_id)
            rep = self.engine.reconcile(self._loan_input(sub), ledger=v)
            if sub["lob_lines"] is not None:
                sub["lob_shadow"] = {"keying_exceptions": sum(1 for e in rep.exceptions if e.comparison == "keying")}
            cs = self.planner.plan(v, rep, self._approvals(loan_id))
            sub["change_set_id"] = cs.change_set_id
            sub["base_version"] = v.version_no
            sub["findings"] = {"category_tieout": rep.findings.category_tieout if rep.findings else []}
            if not cs.ops and not cs.open_issues:
                cs.status = "NOT_NEEDED"
            routing = []
            for i, op in enumerate(cs.ops):
                route, why, n = self.policy.op_route(op)
                routing.append({"op": i, "kind": op.kind, "route": route, "why": why})
                if route == "HUMAN":
                    self._task(sub, "RESTRUCTURE_OP", "restructure", str(i), f"{op.kind}: {op.describe()}",
                               f"{op.reason}. Needs a person because: {why}.", ["APPROVE", "REJECT"],
                               approvals_needed=n, evidence={"op": {"kind": op.kind, "params": op.params},
                                                             "requires_approval_ref": op.requires_approval,
                                                             **op.evidence})
            for x in cs.open_issues:
                acts = ["ACKNOWLEDGE", "RETURN_TO_BORROWER"] if x.get("severity") == "REVIEW" \
                    else ["RESOLVE_WITH_OPS", "RETURN_TO_BORROWER"]
                self._task(sub, "PLAN_ISSUE", "restructure", f"{x['code']}:{x.get('line', '')}", x["code"],
                           x.get("detail", ""), acts, evidence=x)
            sub["routing"] = routing
            self.repo.save_record(loan_id, "change_sets", cs.change_set_id, cs.to_dict())
            auto = sum(1 for r in routing if r["route"] == "AUTO")
            self._log(sub, "PLANNED", f"{len(cs.ops)} ops ({auto} by policy, {len(cs.ops) - auto} for review), "
                                      f"{len(cs.open_issues)} planning issues")
        if self._open_tasks(sub) or self._returned(sub):
            return False
        if cs.status in ("DRAFT",):
            self._commit(sub, cs)
        sub["stage"] = "post"
        return True

    def _commit(self, sub, cs):
        done = self._stage_tasks(sub, "restructure")
        refs, users, manual, resolved = {}, set(), [], []
        for t in done:
            approvers = [d for d in t.decisions if d["action"] in ("APPROVE", "ACKNOWLEDGE", "RESOLVE_WITH_OPS")]
            users |= {d["user"] for d in approvers}
            if t.kind == "RESTRUCTURE_OP" and t.outcome == "APPROVE":
                ref = next((d["payload"].get("approval_ref") for d in approvers if d["payload"].get("approval_ref")), None)
                if ref:
                    refs[int(t.ref)] = ref
            if t.kind == "PLAN_ISSUE":
                resolved.append(t.evidence.get("code"))
                for d in approvers:
                    manual += [Op(o["kind"], o["params"], o.get("reason", "manual")) for o in d["payload"].get("ops", [])]
        human_ops = {int(t.ref) for t in done if t.kind == "RESTRUCTURE_OP"}
        overrides = {i: "approved in HITL task" for i in human_ops if i not in refs}
        checker = "+".join(sorted(users)) if users else self.policy.approver
        self.svc.submit(cs, "system", manual)
        self.svc.approve(cs, checker, refs, overrides, resolved)
        v = self.svc.commit(cs)
        sub["restructured_version"] = v.version_no
        self._log(sub, "RESTRUCTURED", f"change set {cs.change_set_id} committed as ledger v{v.version_no}; "
                                       f"checker {checker}")

    # ------------------------------------------------------------------ gate 3: post the draw
    def _post_gate(self, sub) -> bool:
        loan_id = sub["loan_id"]
        v = self.repo.current(loan_id)
        rep = self.engine.reconcile(self._loan_input(sub), ledger=v)
        keys = {l["key"] for l in sub["lines"]}
        for e in rep.exceptions:
            if not e.blocks_posting or e.comparison == "keying":
                continue  # LOB entry, if any, is only a shadow comparison during transition
            if e.comparison == "extraction" and sub["extraction_accepted"]:
                continue
            self._task(sub, "DRAW_EXCEPTION", "post", e.exception_id, e.reason_code, e.message,
                       self.policy.exception_actions(e.reason_code),
                       evidence={"borrower_keys": [k for k in e.line_keys if k in keys], "impact_cents": e.impact_cents,
                                 "suggestion": e.suggestion, "evidence": e.evidence})
        adjustments = {d["payload"]["borrower_key"]: int(d["payload"]["amount_cents"])
                       for t in self._stage_tasks(sub, "post") if t.outcome == "ADJUST_DRAW"
                       for d in t.decisions if d["action"] == "ADJUST_DRAW"}
        total = sum(adjustments.get(l["key"], l["current"]) for l in sub["lines"])
        if self.policy.needs_signoff(total):
            self._task(sub, "DRAW_SIGNOFF", "post", "SIGNOFF", f"Sign off draw {sub['draw_no']} for {usd(total)}",
                       "Above the straight-through posting limit", ["APPROVE", "RETURN_TO_BORROWER"])
        if self._open_tasks(sub) or self._returned(sub):
            return False
        try:
            nv, rec = post_draw(v, rep.borrower_lines, sub["draw_no"], adjustments)
        except PostingError as exc:
            self._task(sub, "DRAW_EXCEPTION", "post", "POSTING_REFUSED", "Posting refused", str(exc)[:900],
                       ["RETURN_TO_BORROWER"])
            return False
        self.repo.save(nv)
        self.repo.save_record(loan_id, "draws", f"draw-{sub['draw_no']}", asdict(rec))
        touched = len(self.tasks.list(loan_id=loan_id, submission_id=sub["submission_id"]))
        # what the bank actually funded per borrower line: next draw's continuity check uses these, not the request
        sub["funded_lines"] = [{**l, "current": adjustments.get(l["key"], l["current"])} for l in sub["lines"]]
        sub.update({"state": "POSTED", "stage": "sync" if self.sor else "done", "posted_version": nv.version_no,
                    "draw_total": rec.total, "human_tasks": touched})
        self._log(sub, "POSTED", f"{usd(rec.total)} posted as ledger v{nv.version_no}; "
                                 f"{'straight-through' if not touched else f'{touched} human task(s)'}")
        self.events.emit("draw.posted", {"loan_id": loan_id, "submission_id": sub["submission_id"],
                                         "draw_no": sub["draw_no"], "total": rec.total, "human_tasks": touched})
        return self.sor is not None

    # ------------------------------------------------------------------ gate 4: update the SOR and verify
    def _sync_gate(self, sub) -> bool:
        from .sor import build_instructions, verify
        loan_id = sub["loan_id"]
        if any(t.outcome == "ACKNOWLEDGE" for t in self._stage_tasks(sub, "sync")):
            sub["state"], sub["stage"] = "SOR_SYNCED", "done"
            self._log(sub, "SOR_SYNCED", "read-back differences acknowledged by a reviewer")
            return False
        sor_map = self.repo.load_record(loan_id, "sor_map", "current") or {}
        base = self.repo.get(loan_id, sub["base_version"])
        restructured = self.repo.get(loan_id, sub.get("restructured_version") or sub["base_version"])
        posted = self.repo.get(loan_id, sub["posted_version"])
        draw = self.repo.load_record(loan_id, "draws", f"draw-{sub['draw_no']}")
        ins = build_instructions(loan_id, base, restructured, posted, draw, sor_map)
        result = self.sor.apply(loan_id, ins)
        sor_map.update(result.get("created", {}))
        self.repo.save_record(loan_id, "sor_map", "current", sor_map)
        self.repo.save_record(loan_id, "sor_updates", f"draw-{sub['draw_no']}", {"instructions": ins})
        diffs = verify(loan_id, posted, self.sor.export(loan_id), sor_map)
        counts = {}
        for i in ins:
            counts[i["op"]] = counts.get(i["op"], 0) + 1
        if diffs:
            self._task(sub, "SOR_SYNC_MISMATCH", "sync", "READBACK", "SOR does not match the ledger after update",
                       "; ".join(diffs)[:900], ["ACKNOWLEDGE"], evidence={"differences": diffs})
            return False
        sub.update({"state": "SOR_SYNCED", "stage": "done", "sor_instructions": counts})
        self._log(sub, "SOR_SYNCED", f"{len(ins)} SOR updates applied ({counts}); read-back matches the ledger")
        self.events.emit("sor.synced", {"loan_id": loan_id, "submission_id": sub["submission_id"], "updates": counts})
        return False

    # ------------------------------------------------------------------ helpers
    def _loan_input(self, sub):
        loan_id = sub["loan_id"]
        lob = [_line_from_dict(d) for d in sub["lob_lines"]] if sub.get("lob_lines") is not None else None
        prev = sub.get("previous_lines")
        return LoanInput(loan_id, None, [_line_from_dict(d) for d in sub["lines"]], lob,
                         self._open_approvals(loan_id), self.feeds.sources(loan_id),
                         previous_borrower=[_line_from_dict(d) for d in prev] if prev else None)

    def _used_approval_refs(self, loan_id):
        used = set()
        for cs in self.repo.list_records("change_sets", loan_id):
            if cs.get("status") == "COMMITTED":
                used |= {o.get("approval_ref") for o in cs["ops"] if o.get("approval_ref")}
        return used

    def _open_approvals(self, loan_id):
        """Approvals already consumed by a committed change set are not offered again."""
        used = self._used_approval_refs(loan_id)
        return [a for a in self.feeds.approvals(loan_id) if a["approval_ref"] not in used]

    def _approvals(self, loan_id):
        return [{**a, "norm_label": " ".join(self.norm.tokens(a["label"])) if a.get("label") else None}
                for a in self._open_approvals(loan_id)]

    def _task(self, sub, kind, stage, ref, title, detail, actions, approvals_needed=1, evidence=None):
        t = self.tasks.open(sub["loan_id"], sub["submission_id"], kind, stage, ref, title, detail, actions,
                            self.policy.queue(kind), self.policy.sla_hours(kind), approvals_needed, evidence)
        if t.status == "OPEN" and not t.decisions:
            self.events.emit("task.opened", {"loan_id": sub["loan_id"], "task_id": t.task_id, "kind": kind,
                                             "queue": t.queue, "due_at": t.due_at})
        return t

    def _stage_tasks(self, sub, stage):
        return [t for t in self.tasks.list(loan_id=sub["loan_id"], submission_id=sub["submission_id"])
                if t.stage == stage]

    def _open_tasks(self, sub):
        return [t for t in self.tasks.list("OPEN", sub["loan_id"], submission_id=sub["submission_id"])]

    def _returned(self, sub) -> bool:
        ret = [t for t in self.tasks.list("DONE", sub["loan_id"], submission_id=sub["submission_id"])
               if t.outcome in ("RETURN_TO_BORROWER", "REJECT")]
        if not ret:
            return False
        sub["state"] = "RETURNED_TO_BORROWER"
        sub["returned_reasons"] = [{"task": t.title, "detail": t.detail, "note": t.decisions[-1]["payload"].get("note"),
                                    "by": t.decisions[-1]["user"]} for t in ret]
        self.tasks.cancel_open(sub["loan_id"], sub["submission_id"], "submission returned to borrower")
        self._log(sub, "RETURNED_TO_BORROWER", "; ".join(r["note"] or "" for r in sub["returned_reasons"]))
        self.events.emit("submission.returned", {"loan_id": sub["loan_id"], "submission_id": sub["submission_id"],
                                                 "reasons": sub["returned_reasons"]})
        return True

    def _reject(self, sub, code, detail) -> bool:
        sub["state"], sub["reject_reason"] = "REJECTED", {"code": code, "detail": detail}
        self._log(sub, "REJECTED", f"{code}: {detail}")
        self.events.emit("submission.rejected", {"loan_id": sub["loan_id"], "submission_id": sub["submission_id"],
                                                 "code": code})
        return False

    def _log(self, sub, state, note):
        sub["history"].append({"at": self.clock().isoformat(timespec="seconds"), "state": state, "note": note})

    def _save(self, sub):
        self.repo.save_record(sub["loan_id"], "submissions", sub["submission_id"], sub)

    def _load(self, loan_id, sid):
        sub = self.repo.load_record(loan_id, "submissions", sid)
        if sub is None:
            raise KeyError(sid)
        return sub
