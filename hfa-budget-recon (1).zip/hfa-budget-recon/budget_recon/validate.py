"""Draw validation: the rule engine that checks the borrower's LATEST draw against the bank's existing line
items, which LOB users keyed as free-form text.

For every borrower line it answers: which system line(s) is this, which rule decided that, how sure are we,
how was the free-form label understood, and do the amounts agree (and if not: typo, real change, or a
draw-history problem)? Output is one row per borrower line, built for a reviewer to scan.

    DrawValidator(cfg).validate(system_lines, borrower_lines, loan_id) -> ValidationResult
"""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Optional

from .engine import STRONG_TYPO_PATTERNS, ReconEngine
from .models import LoanInput
from .money import usd
from .normalize import Normalizer
from .typos import classify_amount_diff

RELATION_TEXT = {"1:1": "one-to-one", "1:N": "system line = sum of borrower lines",
                 "N:1": "borrower line = sum of system lines"}


@dataclass
class LineResult:
    borrower_key: str
    borrower_label: str
    budget: int
    prior: int
    current: int
    status: str = "OK"  # OK | REVIEW | EXCEPTION
    match_type: str = ""  # EXACT, LABEL_VARIANT, SUMMATION, NEW_LINE, AMBIGUOUS, ...
    rule_id: str = ""
    rule_name: str = ""
    relation: str = ""
    confidence: float = 0.0
    system_keys: list = field(default_factory=list)
    system_labels: list = field(default_factory=list)
    system_budget: Optional[int] = None
    system_prior: Optional[int] = None
    budget_diff: int = 0
    budget_diff_type: str = ""
    prior_diff: int = 0
    prior_diff_type: str = ""
    how_label_was_read: list = field(default_factory=list)
    issues: list = field(default_factory=list)  # exception reason codes touching this line


@dataclass
class ValidationResult:
    loan_id: str
    draw_no: Optional[int]
    lines: list
    system_only: list  # system lines with no borrower line
    exceptions: list
    rule_results: list
    match_rules: list
    config_version: str
    category_tieout: list = field(default_factory=list)

    @property
    def summary(self) -> dict:
        st = Counter(l.status for l in self.lines)
        return {"borrower_lines": len(self.lines), "ok": st.get("OK", 0), "review": st.get("REVIEW", 0),
                "exception": st.get("EXCEPTION", 0), "system_lines_not_in_draw": len(self.system_only),
                "by_rule": dict(Counter(l.rule_id or "none" for l in self.lines)),
                "by_match_type": dict(Counter(l.match_type for l in self.lines)),
                "blocking_exceptions": sum(1 for e in self.exceptions if e.severity == "BLOCKING")}

    def to_dict(self) -> dict:
        return {"loan_id": self.loan_id, "draw_no": self.draw_no, "config_version": self.config_version,
                "summary": self.summary, "lines": [asdict(l) for l in self.lines],
                "system_only": self.system_only, "exceptions": [e.to_dict() for e in self.exceptions],
                "rule_results": self.rule_results}

    # ---- reports ---------------------------------------------------------
    def to_markdown(self) -> str:
        s = self.summary
        tie = ["", "| Category | Budget gap | after misfiled lines | Paid-to-date gap | after misfiled lines |",
               "|---|---|---|---|---|"] + [
            f"| {t['category']} | {usd(t['budget_gap'])} | {usd(t['budget_gap_after_misfiles'])} | "
            f"{usd(t['prior_gap'])} | {usd(t['prior_gap_after_misfiles'])} |" for t in self.category_tieout]
        out = [f"# Draw validation - loan {self.loan_id}" + (f", draw {self.draw_no}" if self.draw_no else ""), *tie, "",
               f"{s['borrower_lines']} borrower lines: **{s['ok']} OK**, **{s['review']} review**, "
               f"**{s['exception']} exception**; {s['system_lines_not_in_draw']} system line(s) not in the draw.", "",
               "| Status | Borrower line | System line(s) | Rule | Match | Conf. | Budget diff | Prior diff | Issues |",
               "|---|---|---|---|---|---|---|---|---|"]
        order = {"EXCEPTION": 0, "REVIEW": 1, "OK": 2}
        for l in sorted(self.lines, key=lambda x: (order[x.status], x.borrower_key)):
            bd = f"{usd(l.budget_diff)} {l.budget_diff_type}" if l.budget_diff else ""
            pdf = f"{usd(l.prior_diff)} {l.prior_diff_type}" if l.prior_diff else ""
            out.append(f"| {l.status} | {l.borrower_label} | {' + '.join(l.system_labels) or '-'} | {l.rule_id} | "
                       f"{l.match_type} | {l.confidence:.2f} | {bd} | {pdf} | {', '.join(l.issues)} |")
        for x in self.system_only:
            out.append(f"| EXCEPTION | - | {x['label']} | - | MISSING_FROM_DRAW | - | {usd(-x['budget'])} | | |")
        out += ["", "## Exceptions", ""]
        out += [f"- **{e.severity} {e.reason_code}**: {e.message}" for e in self.exceptions]
        return "\n".join(out)

    def to_excel(self, path):
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        fills = {"OK": "D1E7DD", "REVIEW": "FFF3CD", "EXCEPTION": "F8D7DA"}
        wb = Workbook()
        ws = wb.active
        ws.title = "Line results"
        ws.append(["Status", "Borrower item", "Borrower line", "Budget", "Prior", "This draw", "System line(s)",
                   "System budget", "System prior", "Rule", "Match type", "Confidence", "Budget diff",
                   "Budget diff type", "Prior diff", "Prior diff type", "How the system label was read", "Issues"])
        for l in self.lines:
            ws.append([l.status, l.borrower_key, l.borrower_label, l.budget / 100, l.prior / 100, l.current / 100,
                       " + ".join(l.system_labels), None if l.system_budget is None else l.system_budget / 100,
                       None if l.system_prior is None else l.system_prior / 100, f"{l.rule_id} {l.rule_name}".strip(),
                       l.match_type, round(l.confidence, 2), l.budget_diff / 100 if l.budget_diff else None,
                       l.budget_diff_type, l.prior_diff / 100 if l.prior_diff else None, l.prior_diff_type,
                       "; ".join(l.how_label_was_read), ", ".join(l.issues)])
            ws.cell(ws.max_row, 1).fill = PatternFill("solid", fgColor=fills[l.status])
        for row in ws.iter_rows(min_row=2):
            for i in (3, 4, 5, 7, 8, 12, 14):
                row[i].number_format = '#,##0.00'
        s2 = wb.create_sheet("System lines not in draw")
        s2.append(["System item", "System line", "Budget", "Prior", "Why"])
        for x in self.system_only:
            s2.append([x["key"], x["label"], x["budget"] / 100, x["prior"] / 100, "no borrower line matched"])
        s3 = wb.create_sheet("Exceptions")
        s3.append(["Severity", "Reason", "Rule", "Impact", "Message", "Suggested action", "Lines"])
        for e in self.exceptions:
            s3.append([e.severity, e.reason_code, e.rule_id or "", e.impact_cents / 100, e.message,
                       (e.suggestion or {}).get("action", ""), ", ".join(e.line_keys)])
        s5 = wb.create_sheet("Category tie-out")
        s5.append(["Category", "System budget", "Borrower budget", "Budget gap", "Gap after misfiled lines",
                   "System paid-to-date", "Borrower paid-to-date", "Paid-to-date gap", "Gap after misfiled lines"])
        for t in self.category_tieout:
            s5.append([t["category"], t["sor_budget"] / 100, t["borrower_budget"] / 100, t["budget_gap"] / 100,
                       t["budget_gap_after_misfiles"] / 100, t["sor_prior"] / 100, t["borrower_prior"] / 100,
                       t["prior_gap"] / 100, t["prior_gap_after_misfiles"] / 100])
        s4 = wb.create_sheet("Rule catalog")
        s4.append(["Rule", "Name", "Type", "Lines matched", "Parameters"])
        hits = self.summary["by_rule"]
        for r in self.match_rules:
            s4.append([r["id"], r["name"], r["type"], hits.get(r["id"], 0), str(r.get("params", ""))])
        s4.append([])
        s4.append(["Validation rule", "Status", "Target"])
        for r in self.rule_results:
            s4.append([r["rule_id"], r["status"], r.get("target", "")])
        for sheet in wb.worksheets:
            for c in sheet[1]:
                c.font = Font(bold=True)
            for col in sheet.columns:
                sheet.column_dimensions[col[0].column_letter].width = min(60, max(len(str(c.value or "")) for c in col) + 2)
            sheet.freeze_panes = "A2"
        for row in ws.iter_rows(min_row=2):
            row[16].alignment = Alignment(wrap_text=True)
        wb.save(path)


class DrawValidator:
    def __init__(self, cfg):
        self.cfg = cfg
        self.engine = ReconEngine(cfg)
        self.norm = Normalizer(cfg)
        self.auto = cfg.s("auto_accept_confidence", 0.95)

    def validate(self, system_lines, borrower_lines, loan_id, draw_no=None, approvals=(), sources=None,
                 mappings=(), previous_borrower=None) -> ValidationResult:
        rep = self.engine.reconcile(LoanInput(loan_id, system_lines, borrower_lines, None, list(approvals),
                                              sources, list(mappings), previous_borrower=previous_borrower))
        res = rep.change
        fnd = rep.findings
        misfiled = {id(m["group"]): m for m in fnd.misfiles}
        approved = {}
        for c in rep.cleared_changes:  # approved amount per line key, with the approval reference
            for k in c["keys"]:
                a = approved.setdefault(k, [0, set()])
                a[0] += c["delta"]
                a[1].add(c["approval_ref"])
        issues = {}
        for e in rep.exceptions:
            for k in e.line_keys:
                issues.setdefault(k, []).append(e)
        lines = []
        for g in res.groups:
            lb, rb = g.total("left", "budget"), g.total("right", "budget")
            lp, rp = g.total("left", "prior"), g.total("right", "prior")
            mtype = self._match_type(g)
            steps = sorted({s for l in g.left for s in self.norm.explain(l.label)})
            for i, r in enumerate(g.right):
                lr = LineResult(r.key, r.label, r.budget, r.prior, r.current, match_type=mtype, rule_id=g.rule_id,
                                rule_name=g.rule_name, relation=RELATION_TEXT.get(g.relation, g.relation),
                                confidence=round(g.confidence, 3), system_keys=[l.key for l in g.left],
                                system_labels=[l.label for l in g.left], system_budget=lb, system_prior=lp,
                                how_label_was_read=steps)
                if r.children:
                    lr.how_label_was_read = lr.how_label_was_read + [f"rolled up {len(r.children)} trade lines"]
                if i == 0:  # group-level differences are reported once, on the group's first borrower line
                    lr.budget_diff = rb - lb
                    lr.budget_diff_type = self._budget_type(rb, lb, g, approved, fnd.budget_attribution.get(id(g)))
                    lr.prior_diff = rp - lp
                    lr.prior_diff_type = "PRIOR_BOOKED_TO_WRONG_LINE" if id(g) in fnd.prior_misallocated and lr.prior_diff \
                        else self._prior_type(rp, lp)
                if id(g) in misfiled:
                    m = misfiled[id(g)]
                    lr.how_label_was_read = lr.how_label_was_read + [
                        f"filed under {m['sor_category']} in the system, {m['borrower_category']} in the borrower file"]
                self._finish(lr, issues, g)
                lines.append(lr)
        for rg in getattr(res, "regroups", []):
            lb = sum(x.budget for x in rg["left"])
            lp = sum(x.prior for x in rg["left"])
            for r in rg["right"]:
                lr = LineResult(r.key, r.label, r.budget, r.prior, r.current, match_type="REGROUPED", rule_id="S03",
                                rule_name="Regrouped within category", relation=f"{len(rg['left'])} system : "
                                f"{len(rg['right'])} borrower lines, totals tie", confidence=0.9,
                                system_keys=[x.key for x in rg["left"]], system_labels=[x.label for x in rg["left"]],
                                system_budget=lb, system_prior=lp)
                self._finish(lr, issues, None)
                lines.append(lr)
        amb_members = {}
        for a in res.ambiguities:
            for ms in a["candidates"]:
                for m in ms:
                    amb_members.setdefault(m.key, a["target"])
        for r in res.unmatched_right:
            lr = LineResult(r.key, r.label, r.budget, r.prior, r.current, match_type="NEW_LINE",
                            budget_diff=r.budget, budget_diff_type="NEW_LINE")
            self._finish(lr, issues, None)
            lines.append(lr)
        for k, target in sorted(amb_members.items()):
            r = next((x for x in rep.borrower_lines if x.key == k), None)
            if r is not None and not any(l.borrower_key == k for l in lines):
                lr = LineResult(r.key, r.label, r.budget, r.prior, r.current, match_type="AMBIGUOUS",
                                system_keys=[target.key], system_labels=[target.label], status="EXCEPTION",
                                issues=["AMBIGUOUS_CONSOLIDATION"])
                lines.append(lr)
        system_only = [{"key": l.key, "label": l.label, "budget": l.budget, "prior": l.prior,
                        "how_label_was_read": self.norm.explain(l.label)} for l in res.unmatched_left]
        return ValidationResult(loan_id, draw_no, sorted(lines, key=lambda x: x.borrower_key), system_only,
                                rep.exceptions, rep.rule_results, self.cfg.s("match_rules") or [], self.cfg.version,
                                fnd.category_tieout)

    # ---- classification --------------------------------------------------
    @staticmethod
    def _match_type(g) -> str:
        if g.relation in ("1:N", "N:1"):
            return "SUMMATION"
        if g.pass_name in ("exact_norm_label", "exact_cost_code", "ledger_alias", "learned"):
            l, r = g.left[0], g.right[0]
            return "EXACT" if l.label.strip().lower() == r.label.strip().lower() else "LABEL_VARIANT"
        if g.pass_name == "identical_numbers":
            return "SAME_AMOUNTS_LABEL_VARIANT"
        return "LABEL_VARIANT_AMOUNTS_DIFFER"

    @staticmethod
    def _budget_type(rb, lb, g, approved, attribution=None) -> str:
        if rb == lb:
            return ""
        cls = classify_amount_diff(rb, lb)
        if attribution == "SOR_ERROR":
            return "SOR_VALUE_WRONG (borrower unchanged since last draw)"
        if attribution == "BOTH_MOVED":
            return "SOR_WRONG_AND_BUDGET_CHANGED"
        appr = next((approved[l.key] for l in g.left + g.right if l.key in approved), None)
        if appr and appr[0] == rb - lb:
            return "APPROVED_CHANGE (" + ", ".join(sorted(appr[1])) + ")"
        if appr:
            from .money import usd as _u
            return f"BUDGET_CHANGE (partly approved: {_u(appr[0])} by {', '.join(sorted(appr[1]))})"
        if attribution == "REAL_CHANGE":
            return "BUDGET_CHANGE (this period)"
        if cls["pattern"] in STRONG_TYPO_PATTERNS:
            return f"PROBABLE_SYSTEM_TYPO ({cls['pattern']})"
        if cls["pattern"] == "ROUNDING":
            return "ROUNDING"
        return "BUDGET_CHANGE" + (" (or single-digit typo)" if cls["pattern"] == "WRONG_DIGIT" else "")

    @staticmethod
    def _prior_type(rp, lp) -> str:
        if rp == lp:
            return ""
        cls = classify_amount_diff(rp, lp)
        return "PRIOR_MISMATCH" + (f" ({cls['pattern']} in system value)" if cls["pattern"] in STRONG_TYPO_PATTERNS else "")

    def _finish(self, lr, issues, g):
        keys = [lr.borrower_key] + lr.system_keys
        es = {e.reason_code: e for k in keys for e in issues.get(k, [])}
        lr.issues = sorted(es)
        blocking = [e for e in es.values() if e.severity == "BLOCKING"]
        review = [e for e in es.values() if e.severity == "REVIEW"]
        diff = (lr.budget_diff and not lr.budget_diff_type.startswith(("APPROVED_CHANGE", "ROUNDING"))) or lr.prior_diff
        if blocking or diff or lr.match_type == "NEW_LINE":
            lr.status = "EXCEPTION"
        elif review or (g is not None and g.confidence < self.auto):
            lr.status = "REVIEW"
        else:
            lr.status = "OK"
