"""System-of-record (SOR) integration: the last mile.

After the ledger is restructured and the draw is posted, the SOR must end up holding exactly the same lines,
budgets and paid-to-date. The ledger stays the engine's source of truth; the SOR is updated through an adapter:

  1. build    diff ledger versions into ordered SOR instructions:
              CREATE_LINE, UPDATE_LINE (label / category / cost code / budget / paid-to-date), RETIRE_LINE, POST_DRAW
  2. apply    the adapter applies them; every instruction has a stable id, so a retry never applies one twice
  3. verify   read the SOR back and compare line by line with the ledger; any difference is a task, never ignored

SorAdapter is the seam to your real SOR (database tables, a REST API or a batch upload). FileSorAdapter is a
CSV-backed stand-in used for the demo and tests.
"""
from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Protocol

from .money import to_cents, usd


class SorAdapter(Protocol):
    def export(self, loan_id: str) -> list: ...
    def apply(self, loan_id: str, instructions: list) -> dict: ...


def _iid(loan_id, tag, *parts) -> str:
    return "U-" + hashlib.sha1("|".join([loan_id, tag, *map(str, parts)]).encode()).hexdigest()[:12]


def build_instructions(loan_id, base, restructured, posted, draw_record, sor_map) -> list:
    """base/restructured/posted: BudgetVersion. sor_map: ledger line_id -> SOR key (lines that exist in the SOR)."""
    out = []
    tag = f"draw-{posted.draw_no}"
    for lid in sorted(restructured.lines):
        new = restructured.lines[lid]
        old = base.lines.get(lid)
        if lid not in sor_map:
            if new.status == "ACTIVE":
                out.append({"id": _iid(loan_id, tag, "create", lid), "op": "CREATE_LINE", "line_id": lid,
                            "label": new.label, "category": new.category, "cost_code": new.cost_code,
                            "budget": new.budget, "prior": new.drawn})
            continue
        key = sor_map[lid]
        if new.status == "RETIRED" and (old is None or old.status != "RETIRED"):
            out.append({"id": _iid(loan_id, tag, "retire", lid), "op": "RETIRE_LINE", "sor_key": key, "line_id": lid})
            continue
        fields = {}
        if old is not None:
            for f_, a, b in (("label", old.label, new.label), ("category", old.category, new.category),
                             ("cost_code", old.cost_code, new.cost_code), ("budget", old.budget, new.budget),
                             ("prior", old.drawn, new.drawn), ("status", old.status, new.status)):
                if a != b:
                    fields[f_] = b
        if fields:
            out.append({"id": _iid(loan_id, tag, "update", lid), "op": "UPDATE_LINE", "sor_key": key,
                        "line_id": lid, "fields": fields})
    for ln in (draw_record or {}).get("lines", []):
        out.append({"id": _iid(loan_id, tag, "post", ln["line_id"]), "op": "POST_DRAW", "line_id": ln["line_id"],
                    "sor_key": sor_map.get(ln["line_id"]), "amount": ln["amount"], "draw_no": posted.draw_no})
    return out


def verify(loan_id, posted, sor_rows, sor_map) -> list:
    """Read-back check. Returns a list of differences (empty = SOR matches the ledger exactly)."""
    by_key = {r["key"]: r for r in sor_rows}
    diffs = []
    mapped = set()
    for lid, l in sorted(posted.lines.items()):
        key = sor_map.get(lid)
        if l.status == "RETIRED":
            if key and by_key.get(key, {}).get("status", "ACTIVE") != "RETIRED":
                diffs.append(f"{lid} {l.label}: retired in the ledger but active in the SOR")
            continue
        if not key or key not in by_key:
            diffs.append(f"{lid} {l.label}: missing from the SOR")
            continue
        mapped.add(key)
        r = by_key[key]
        if r["budget"] != l.budget:
            diffs.append(f"{lid} {l.label}: SOR budget {usd(r['budget'])} vs ledger {usd(l.budget)}")
        if r["prior"] != l.drawn:
            diffs.append(f"{lid} {l.label}: SOR paid-to-date {usd(r['prior'])} vs ledger {usd(l.drawn)}")
        if r.get("label") != l.label:
            diffs.append(f"{lid}: SOR label '{r.get('label')}' vs ledger '{l.label}'")
    for key, r in by_key.items():
        if key not in mapped and r.get("status", "ACTIVE") == "ACTIVE" and (r["budget"] or r["prior"]):
            diffs.append(f"SOR line {key} {r.get('label')} has no ledger line")
    return diffs


class FileSorAdapter:
    """CSV-backed SOR stand-in: <root>/<loan_id>.csv plus a journal of applied instruction ids."""

    FIELDS = ["key", "label", "category", "cost_code", "budget", "prior", "status"]

    def __init__(self, root):
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _p(self, loan_id):
        return self.root / f"{loan_id}.csv"

    def load_export(self, loan_id, export_csv):
        """Seed the stand-in SOR from a real SOR export (onboarding)."""
        rows = []
        for r in csv.DictReader(open(export_csv)):
            rows.append({"key": r["key"], "label": r["label"], "category": r.get("category") or "",
                         "cost_code": r.get("cost_code") or "", "budget": to_cents(r["budget"]),
                         "prior": to_cents(r.get("prior")), "status": r.get("status") or "ACTIVE"})
        self._write(loan_id, rows)

    def export(self, loan_id):
        if not self._p(loan_id).exists():
            return []
        out = []
        for r in csv.DictReader(open(self._p(loan_id))):
            out.append({**r, "budget": int(r["budget"]), "prior": int(r["prior"])})
        return out

    def _write(self, loan_id, rows):
        with open(self._p(loan_id), "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=self.FIELDS)
            w.writeheader()
            w.writerows(rows)

    def apply(self, loan_id, instructions):
        journal_p = self.root / f"{loan_id}.journal.json"
        journal = json.loads(journal_p.read_text()) if journal_p.exists() else {}
        rows = {r["key"]: r for r in self.export(loan_id)}
        created = {}
        for ins in instructions:
            if ins["id"] in journal:  # idempotent replay
                created.update(journal[ins["id"]].get("created", {}))
                continue
            result = {}
            if ins["op"] == "CREATE_LINE":
                key = f"N{len([k for k in rows if k.startswith('N')]) + 1:03d}"
                rows[key] = {"key": key, "label": ins["label"], "category": ins["category"] or "",
                             "cost_code": ins["cost_code"] or "", "budget": ins["budget"], "prior": ins["prior"],
                             "status": "ACTIVE"}
                result["created"] = {ins["line_id"]: key}
                created[ins["line_id"]] = key
            elif ins["op"] == "UPDATE_LINE":
                rows[ins["sor_key"]].update({k: (v or "") if k in ("category", "cost_code") else v
                                             for k, v in ins["fields"].items()})
            elif ins["op"] == "RETIRE_LINE":
                rows[ins["sor_key"]].update({"budget": 0, "prior": 0, "status": "RETIRED"})
            elif ins["op"] == "POST_DRAW":
                key = ins["sor_key"] or created.get(ins["line_id"])
                rows[key]["prior"] = int(rows[key]["prior"]) + ins["amount"]
            journal[ins["id"]] = result
        self._write(loan_id, list(rows.values()))
        journal_p.write_text(json.dumps(journal, indent=1))
        return {"created": created}
