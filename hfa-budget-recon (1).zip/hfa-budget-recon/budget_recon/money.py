"""Money helpers. All amounts are integer cents internally; never floats."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP


def to_cents(value) -> int:
    """Parse '$1,234.50', '(1,234.50)', '1234.5', Decimal or number (dollars) into integer cents."""
    if value is None:
        return 0
    if isinstance(value, bool):
        raise ValueError("boolean is not an amount")
    if isinstance(value, (int, float, Decimal)):
        d = Decimal(str(value))
    else:
        s = str(value).strip()
        if s in ("", "-", "—"):
            return 0
        neg = s.startswith("(") and s.endswith(")")
        s = s.strip("()").replace("$", "").replace(",", "").strip()
        if s.startswith("-"):
            neg, s = (not neg), s[1:]
        try:
            d = Decimal(s)
        except InvalidOperation as exc:
            raise ValueError(f"not an amount: {value!r}") from exc
        if neg:
            d = -d
    return int((d * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def usd(cents: int) -> str:
    sign = "-" if cents < 0 else ""
    c = abs(int(cents))
    return f"{sign}${c // 100:,}.{c % 100:02d}"
