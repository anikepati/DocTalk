"""Roll contractor trade lines (AIA G703 schedule of values) up to the loan-budget line they belong to.

The G703 normally has 30-60 trade lines while the loan budget has one 'Construction contract' line.
That is a difference in level of detail, not a consolidation error, so it is handled structurally.
"""
from __future__ import annotations

from .models import Line, ReconException
from .money import usd


def rollup(lines, normalizer, side: str):
    """Returns (lines_after_rollup, exceptions)."""
    if lines is None:
        return None, []
    codes = normalizer.codes
    trades, keep = {}, []
    for l in lines:
        parent = codes.get(l.cost_code, {}).get("rollup_to") if l.cost_code else None
        if parent:
            trades.setdefault(parent, []).append(l)
        else:
            keep.append(l)
    excs = []
    for parent, kids in sorted(trades.items()):
        existing = [l for l in keep if l.cost_code == parent]
        sums = {c: sum(k.col(c) for k in kids) for c in ("budget", "prior", "current", "retainage")}
        if existing:
            # summary line already present: trades are supporting detail; check they agree
            head = existing[0]
            for c in ("budget", "prior", "current"):
                if head.col(c) != sums[c]:
                    excs.append(ReconException(
                        "TRADE_DETAIL_MISMATCH", "BLOCKING", "extraction",
                        f"{side}: trade lines under {parent} sum to {usd(sums[c])} {c}, summary line shows {usd(head.col(c))}",
                        impact_cents=abs(head.col(c) - sums[c]), line_keys=[head.key] + [k.key for k in kids],
                    ))
            continue
        info = codes[parent]
        toks = normalizer.tokens(info["name"])
        keep.append(Line(
            key=f"{side.upper()}-ROLLUP-{parent}",
            label=f"{info['name']} (rollup of {len(kids)} trade lines)",
            budget=sums["budget"], prior=sums["prior"], current=sums["current"], retainage=sums["retainage"],
            cost_code=parent, category=info["category"], norm_label=" ".join(toks), tokens=toks,
            children=tuple(k.key for k in kids), source_ref="rollup",
        ))
    return keep, excs
