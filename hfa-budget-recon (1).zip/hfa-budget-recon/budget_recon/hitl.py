"""Human-in-the-loop work queue. The LOB's only job in the new operating model: decide the tasks the
system could not decide by policy. Each task says what was found, the evidence, the allowed actions, how
many distinct approvers it needs, which queue owns it and when it is due."""
from __future__ import annotations

import datetime as _dt
import hashlib
from dataclasses import asdict, dataclass, field
from typing import Optional

ACTION_HELP = {
    "APPROVE": "approve as proposed (money moves need an approval_ref: change order, memo or wire)",
    "REJECT": "reject this change; the draw goes back to the borrower",
    "ACCEPT": "accept the extracted figures as they are",
    "ACKNOWLEDGE": "noted; proceed",
    "OVERRIDE": "proceed despite the exception (reason required)",
    "ADJUST_DRAW": "fund a different amount on one line (borrower_key, amount_cents)",
    "RESOLVE_WITH_OPS": "supply the restructuring ops yourself (ops)",
    "RETURN_TO_BORROWER": "send the draw back for a corrected file (note required)",
}


class TaskError(ValueError):
    pass


@dataclass
class Task:
    task_id: str
    loan_id: str
    submission_id: str
    kind: str  # EXTRACTION_REVIEW | RESTRUCTURE_OP | PLAN_ISSUE | DRAW_EXCEPTION | DRAW_SIGNOFF
    stage: str  # extraction | restructure | post
    ref: str  # op index, exception id, check code ...
    title: str
    detail: str
    allowed_actions: list
    queue: str
    created_at: str
    due_at: str
    approvals_needed: int = 1
    evidence: dict = field(default_factory=dict)
    status: str = "OPEN"  # OPEN | DONE | CANCELLED
    outcome: Optional[str] = None
    decisions: list = field(default_factory=list)

    @staticmethod
    def make_id(submission_id, kind, ref) -> str:
        return "T-" + hashlib.sha1(f"{submission_id}|{kind}|{ref}".encode()).hexdigest()[:10]


class TaskQueue:
    def __init__(self, repo, clock=None):
        self.repo = repo
        self.clock = clock or (lambda: _dt.datetime.now(_dt.timezone.utc))

    def open(self, loan_id, submission_id, kind, stage, ref, title, detail, actions, queue, sla_hours,
             approvals_needed=1, evidence=None) -> Task:
        tid = Task.make_id(submission_id, kind, ref)
        existing = self.get(loan_id, tid)
        if existing:
            return existing  # idempotent: re-running a stage never duplicates or resets a task
        now = self.clock()
        t = Task(tid, loan_id, submission_id, kind, stage, ref, title, detail, list(actions), queue,
                 now.isoformat(timespec="seconds"), (now + _dt.timedelta(hours=sla_hours)).isoformat(timespec="seconds"),
                 approvals_needed, evidence or {})
        self.save(t)
        return t

    def save(self, t: Task):
        self.repo.save_record(t.loan_id, "tasks", t.task_id, asdict(t))

    def get(self, loan_id, task_id) -> Optional[Task]:
        d = self.repo.load_record(loan_id, "tasks", task_id)
        return Task(**d) if d else None

    def list(self, status=None, loan_id=None, queue=None, submission_id=None):
        out = [Task(**d) for d in self.repo.list_records("tasks", loan_id)]
        return [t for t in out if (status is None or t.status == status) and (queue is None or t.queue == queue)
                and (submission_id is None or t.submission_id == submission_id)]

    def decide(self, t: Task, action: str, user: str, payload=None) -> Task:
        payload = payload or {}
        if t.status != "OPEN":
            raise TaskError(f"task {t.task_id} is {t.status}")
        if action not in t.allowed_actions:
            raise TaskError(f"{action} is not allowed here; allowed: {t.allowed_actions}")
        if not user or user.startswith(("policy:", "system")):
            raise TaskError("a decision must come from a named person")
        if action in ("OVERRIDE", "RETURN_TO_BORROWER", "REJECT") and not payload.get("note"):
            raise TaskError(f"{action} needs a note explaining why")
        if action == "APPROVE" and any(d["user"] == user and d["action"] == "APPROVE" for d in t.decisions):
            raise TaskError("the same person cannot approve twice; a second, different approver is required")
        t.decisions.append({"action": action, "user": user, "payload": payload,
                            "at": self.clock().isoformat(timespec="seconds")})
        approvals = [d for d in t.decisions if d["action"] == "APPROVE"]
        if action != "APPROVE" or len(approvals) >= t.approvals_needed:
            t.status, t.outcome = "DONE", action
        self.save(t)
        return t

    def cancel_open(self, loan_id, submission_id, reason):
        for t in self.list("OPEN", loan_id, submission_id=submission_id):
            t.status, t.outcome = "CANCELLED", reason
            self.save(t)
