"""Intake and extraction: turn the borrower's latest file into canonical lines, then validate the result
before anything downstream trusts it.

Extractors are pluggable (the Extractor protocol):
  ExcelExtractor  deterministic: finds the header row by synonyms, reads sections, subtotals and grand total
  CsvExtractor    deterministic: already-tabular files (and the output of upstream extraction jobs)
  LLMExtractor    PDFs and scans: an injected model client (e.g. Gemini) returns JSON in a fixed schema;
                  the SAME validation runs on its output, so a model mistake cannot slip through unchecked
"""
from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional, Protocol

from .models import Line
from .money import to_cents, usd

HEADER_SYNONYMS = {
    "key": ["item no", "item", "item number", "line no", "line", "no", "code"],
    "label": ["description of work", "description", "line item", "budget line", "budget item", "cost item"],
    "budget": ["scheduled value", "revised budget", "current budget", "approved budget", "total budget", "budget",
               "budget amount"],
    "prior": ["work completed from previous application", "from previous application", "previous applications",
              "previously requested", "prior draws", "drawn to date prior", "previous"],
    "current": ["work completed this period", "this period", "this draw", "current request", "current draw",
                "requested this period", "amount requested"],
    "balance": ["balance to finish", "balance remaining", "remaining", "balance"],
    "retainage": ["retainage this period", "retainage"],
}
SECTION_CATEGORIES = [("acquisition", "ACQUISITION"), ("hard", "HARD"), ("construction", "HARD"),
                      ("soft", "SOFT"), ("reserve", "OTHER"), ("other", "OTHER")]


@dataclass
class ExtractionResult:
    lines: list
    meta: dict = field(default_factory=dict)  # loan_id, draw_no, period_to, sheet, method
    checks: list = field(default_factory=list)  # {"code","severity","detail","line"}
    file_hash: str = ""

    @property
    def blocking(self):
        return [c for c in self.checks if c["severity"] == "BLOCKING"]

    @property
    def confidence(self) -> float:
        if self.blocking:
            return 0.0
        return max(0.0, 1.0 - 0.05 * len(self.checks))


class Extractor(Protocol):
    def supports(self, path: Path) -> bool: ...
    def extract(self, path: Path) -> ExtractionResult: ...


def file_hash(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _norm(s) -> str:
    return re.sub(r"[^a-z0-9 ]+", " ", str(s or "").lower()).strip()


def _num(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return 0
    return to_cents(v)


def _meta_from_text(text: str) -> dict:
    meta = {}
    m = re.search(r"loan\s*(?:no|number|#|id)?\.?\s*[:#]?\s*([A-Z]{2,}[A-Z0-9-]*\d)", text, re.I)
    if m:
        meta["loan_id"] = m.group(1).upper()
    m = re.search(r"(?:application|draw|request)\s*(?:no|number|#)?\.?\s*[:#]?\s*(\d{1,3})\b", text, re.I)
    if m:
        meta["draw_no"] = int(m.group(1))
    m = re.search(r"period\s*to\s*[:]?\s*(\d{4}-\d{2}-\d{2})", text, re.I)
    if m:
        meta["period_to"] = m.group(1)
    return meta


def validate(lines, totals=None, subtotals=None) -> list:
    """Arithmetic checks shared by every extractor. totals/subtotals: {"budget": cents, ...}."""
    checks = []
    for l in lines:
        if l.reported_balance is not None and l.reported_balance != l.balance:
            checks.append({"code": "LINE_MATH", "severity": "BLOCKING", "line": l.key,
                           "detail": f"{l.label}: budget - prior - current = {usd(l.balance)}, file shows {usd(l.reported_balance)}"})
        if min(l.budget, l.prior, l.current) < 0:
            checks.append({"code": "NEGATIVE_AMOUNT", "severity": "BLOCKING", "line": l.key, "detail": l.label})
    for name, (rows, tot) in (subtotals or {}).items():
        for col, val in tot.items():
            got = sum(r.col(col) for r in rows)
            if got != val:
                checks.append({"code": "SUBTOTAL_MISMATCH", "severity": "BLOCKING", "line": name,
                               "detail": f"{name} {col}: lines sum to {usd(got)}, subtotal row shows {usd(val)}"})
    for col, val in (totals or {}).items():
        got = sum(l.col(col) for l in lines)
        if got != val:
            checks.append({"code": "GRAND_TOTAL_MISMATCH", "severity": "BLOCKING", "line": "TOTAL",
                           "detail": f"{col}: lines sum to {usd(got)}, total row shows {usd(val)}"})
    keys = [l.key for l in lines]
    for k in sorted({k for k in keys if keys.count(k) > 1}):
        checks.append({"code": "DUPLICATE_ITEM_NO", "severity": "WARNING", "line": k, "detail": "item number repeats"})
    if not lines:
        checks.append({"code": "NO_LINES", "severity": "BLOCKING", "line": "", "detail": "no budget lines found"})
    return checks


class ExcelExtractor:
    max_header_scan = 40

    def supports(self, path):
        return Path(path).suffix.lower() in (".xlsx", ".xlsm")

    def _match_header(self, row):
        cols = {}
        for idx, cell in enumerate(row):
            h = _norm(cell)
            if not h:
                continue
            for field_name, syns in HEADER_SYNONYMS.items():
                if field_name in cols:
                    continue
                if any(h == s or h.startswith(s) for s in syns):
                    cols[field_name] = idx
                    break
        return cols

    def extract(self, path):
        from openpyxl import load_workbook
        wb = load_workbook(path, data_only=True, read_only=True)
        best = None
        for ws in wb.worksheets:
            rows = [list(r) for r in ws.iter_rows(values_only=True)]
            for i, row in enumerate(rows[: self.max_header_scan]):
                cols = self._match_header(row)
                if "label" in cols and "budget" in cols and (best is None or len(cols) > len(best[2])):
                    best = (ws.title, rows, cols, i)
        if best is None:
            return ExtractionResult([], {"method": "excel"}, [{"code": "HEADER_NOT_FOUND", "severity": "BLOCKING",
                                                              "line": "", "detail": "no row with a description and a budget column"}],
                                    file_hash(path))
        sheet, rows, cols, hdr = best
        checks = [{"code": "COLUMN_MISSING", "severity": "WARNING", "line": "", "detail": f"no '{c}' column"}
                  for c in ("prior", "current") if c not in cols]
        meta = _meta_from_text(" ".join(str(c) for r in rows[:hdr] for c in r if c is not None))
        meta.update({"method": "excel", "sheet": sheet, "header_row": hdr + 1})
        lines, section, sec_rows, subtotals, totals = [], None, [], {}, None

        def get(row, f):
            i = cols.get(f)
            return row[i] if i is not None and i < len(row) else None

        for rn, row in enumerate(rows[hdr + 1:], start=hdr + 2):
            label = get(row, "label")
            nums = {f: get(row, f) for f in ("budget", "prior", "current", "balance", "retainage")}
            has_num = any(v not in (None, "") for v in nums.values())
            if label is None and not has_num:
                continue
            lab = str(label or "").strip()
            low = lab.lower()
            try:
                vals = {f: _num(nums[f]) for f in ("budget", "prior", "current", "retainage")}
            except ValueError as exc:
                checks.append({"code": "UNPARSEABLE_AMOUNT", "severity": "BLOCKING", "line": f"row {rn}", "detail": str(exc)})
                continue
            if "total" in low:
                tot = {f: vals[f] for f in ("budget", "prior", "current") if nums[f] not in (None, "")}
                if "sub" in low or (section and "grand" not in low and low != "total"):
                    subtotals[lab] = (list(sec_rows), tot)
                else:
                    totals = tot
                continue
            if lab and not has_num:  # section header
                section = next((cat for kw, cat in SECTION_CATEGORIES if kw in low), None)
                sec_rows = []
                continue
            key = str(get(row, "key")).strip() if get(row, "key") not in (None, "") else f"R{rn}"
            line = Line(key, lab, vals["budget"], vals["prior"], vals["current"], vals["retainage"],
                        reported_balance=_num(nums["balance"]) if nums["balance"] not in (None, "") else None,
                        category=section, source_ref=f"{Path(path).name}!{sheet}:row {rn}")
            lines.append(line)
            sec_rows.append(line)
        checks += validate(lines, totals, subtotals)
        return ExtractionResult(lines, meta, checks, file_hash(path))


class CsvExtractor:
    def supports(self, path):
        return Path(path).suffix.lower() == ".csv"

    def extract(self, path):
        from .io import read_lines
        p = Path(path)
        lines = read_lines(p) or []
        meta = {"method": "csv"}
        side = p.parent / "loan.json"
        if side.exists():
            meta.update({k: v for k, v in json.loads(side.read_text()).items() if k in ("loan_id", "draw_no")})
        return ExtractionResult(lines, meta, validate(lines), file_hash(path))


EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "loan_id": {"type": "string"}, "draw_no": {"type": "integer"}, "period_to": {"type": "string"},
        "lines": {"type": "array", "items": {"type": "object", "properties": {
            "item_no": {"type": "string"}, "description": {"type": "string"}, "section": {"type": "string"},
            "scheduled_value": {"type": "string"}, "previous": {"type": "string"}, "this_period": {"type": "string"},
            "balance": {"type": "string"}, "retainage": {"type": "string"}, "page": {"type": "integer"}},
            "required": ["description", "scheduled_value"]}},
        "totals": {"type": "object", "properties": {"scheduled_value": {"type": "string"},
                                                    "previous": {"type": "string"}, "this_period": {"type": "string"}}},
    },
    "required": ["lines"],
}

EXTRACTION_PROMPT = (
    "Extract every budget line from this construction draw request (AIA G702/G703 or lender budget form). "
    "Copy amounts exactly as printed, as strings, without rounding or computing anything. Include the section "
    "heading each line sits under, the page number, and the grand-total row separately in 'totals'. "
    "Do not invent lines, do not merge lines, and leave a field empty if it is not printed."
)


class LLMExtractor:
    """client(prompt, file_bytes, mime_type, schema) -> dict matching EXTRACTION_SCHEMA."""

    def __init__(self, client: Callable, suffixes=(".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff")):
        self.client, self.suffixes = client, suffixes

    def supports(self, path):
        return Path(path).suffix.lower() in self.suffixes

    def extract(self, path):
        p = Path(path)
        mime = "application/pdf" if p.suffix.lower() == ".pdf" else "image/" + p.suffix.lower().lstrip(".")
        out = self.client(EXTRACTION_PROMPT, p.read_bytes(), mime, EXTRACTION_SCHEMA)
        lines, checks = [], []
        for i, r in enumerate(out.get("lines", []), start=1):
            try:
                sec = _norm(r.get("section"))
                lines.append(Line(r.get("item_no") or f"P{r.get('page', 0)}-{i}", r["description"].strip(),
                                  _num(r.get("scheduled_value")), _num(r.get("previous")), _num(r.get("this_period")),
                                  _num(r.get("retainage")),
                                  reported_balance=_num(r["balance"]) if r.get("balance") else None,
                                  category=next((c for kw, c in SECTION_CATEGORIES if kw in sec), None),
                                  source_ref=f"{p.name}:page {r.get('page', '?')}"))
            except (ValueError, KeyError) as exc:
                checks.append({"code": "UNPARSEABLE_AMOUNT", "severity": "BLOCKING", "line": f"#{i}", "detail": str(exc)})
        t = out.get("totals") or {}
        totals = {c: _num(t[k]) for k, c in (("scheduled_value", "budget"), ("previous", "prior"),
                                             ("this_period", "current")) if t.get(k)}
        if not totals:
            checks.append({"code": "NO_TOTAL_ROW", "severity": "WARNING", "line": "",
                           "detail": "model returned no grand total; arithmetic cross-check is weaker"})
        checks += validate(lines, totals)
        meta = {k: out[k] for k in ("loan_id", "draw_no", "period_to") if out.get(k)}
        meta["method"] = "llm"
        return ExtractionResult(lines, meta, checks, file_hash(path))


def extract_file(path, extractors) -> ExtractionResult:
    for e in extractors:
        if e.supports(Path(path)):
            return e.extract(Path(path))
    return ExtractionResult([], {"method": "none"}, [{"code": "UNSUPPORTED_FILE", "severity": "BLOCKING", "line": "",
                                                       "detail": f"no extractor for {Path(path).suffix}"}], file_hash(path))
