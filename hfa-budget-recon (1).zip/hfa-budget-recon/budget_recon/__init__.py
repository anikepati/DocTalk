"""Deterministic budget reconciliation engine for HFA construction-loan draws."""
__version__ = "0.5.0"
