"""Label normalization, cost-code assignment and category inference. Fully deterministic."""
from __future__ import annotations

import re
from dataclasses import replace

from .config import Config
from .models import Line
from .similarity import label_similarity, osa_distance


class Normalizer:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        ab = cfg.abbreviations
        self.phrases = sorted(ab["phrases"].items(), key=lambda kv: (-len(kv[0]), kv[0]))
        self.phrase_res = [
            (re.compile(r"(?<![a-z0-9])" + re.escape(p) + r"(?![a-z0-9])"), v) for p, v in self.phrases
        ]
        self.noise = [re.compile(x, re.I) for x in ab.get("noise_patterns", [])]
        self.token_map = ab["tokens"]
        self.stop = set(ab["stopwords"])
        self.vocab = set(ab.get("vocabulary", []))
        for v in list(self.token_map.values()) + [v for _, v in self.phrases]:
            self.vocab.update(v.split())
        self.codes = {c["code"]: c for c in cfg.cost_codes}
        for c in cfg.cost_codes:
            for s in [c["name"], *c.get("synonyms", [])]:
                self.vocab.update(self._basic(s))
        self.vocab = {w for w in self.vocab if w and not w.isdigit()}

        # synonym index built with the SAME pipeline used for incoming labels
        self.exact = {}
        self.synonyms = []  # (tokens, code)
        token_cats = {}
        for c in cfg.cost_codes:
            for s in [c["name"], *c.get("synonyms", [])]:
                toks = self.tokens(s)
                if not toks:
                    continue
                key = " ".join(toks)
                self.exact.setdefault(key, set()).add(c["code"])
                self.synonyms.append((toks, c["code"]))
                for t in toks:
                    token_cats.setdefault(t, set()).add(c["category"])
        # a token is a category signal only if it points at exactly one category
        self.token_category = {t: next(iter(cs)) for t, cs in token_cats.items() if len(cs) == 1}

    # ---- label pipeline -------------------------------------------------
    def _basic(self, raw: str) -> list:
        s = raw.lower().replace("'", "").replace("’", "")
        for rx in self.noise:  # free-form notes keyed with the label: "(per CO #3)", dates, "rev."
            s = rx.sub(" ", s)
        for rx, v in self.phrase_res:
            s = rx.sub(" " + v + " ", s)
        s = s.replace("&", " and ")
        s = re.sub(r"[^a-z0-9]+", " ", s)
        out = []
        for t in s.split():
            out.extend(self.token_map.get(t, t).split())
        return out

    def _spell(self, t: str) -> str:
        if t in self.vocab or len(t) < 5 or t.isdigit():
            return t
        cands = sorted(w for w in self.vocab if abs(len(w) - len(t)) <= 1 and osa_distance(t, w) == 1)
        return cands[0] if len(cands) == 1 else t

    def explain(self, raw: str) -> list:
        """Human-readable account of how a free-form label was cleaned up (for reviewers and audit)."""
        steps = []
        low = raw.lower().replace("'", "").replace("’", "")
        for rx in self.noise:
            for m in rx.finditer(low):
                if m.group(0).strip():
                    steps.append(f"removed note '{m.group(0).strip()}'")
            low = rx.sub(" ", low)
        for rx, v in self.phrase_res:
            for m in rx.finditer(low):
                steps.append(f"'{m.group(0)}' -> '{v}'")
            low = rx.sub(" " + v + " ", low)
        low = re.sub(r"[^a-z0-9]+", " ", low.replace("&", " and "))
        for t in low.split():
            if t in self.token_map and self.token_map[t] != t:
                steps.append(f"'{t}' -> '{self.token_map[t]}'")
            for x in self.token_map.get(t, t).split():
                fixed = self._spell(x)
                if fixed != x:
                    steps.append(f"spelling '{x}' -> '{fixed}'")
        return steps

    def tokens(self, raw: str) -> tuple:
        out = []
        for t in self._basic(raw):
            t = self._spell(t)
            if t in self.stop or t.isdigit() or re.fullmatch(r"\d+[a-z]?", t):
                continue
            out.append(t)
        return tuple(out)

    # ---- classification -------------------------------------------------
    def assign_code(self, toks: tuple):
        if not toks:
            return None
        hit = self.exact.get(" ".join(toks))
        if hit and len(hit) == 1:
            return next(iter(hit))
        threshold = self.cfg.s("code_match_threshold", 0.85)
        best = {}
        for syn_toks, code in self.synonyms:
            sc = label_similarity(toks, syn_toks)
            if sc > best.get(code, 0):
                best[code] = sc
        ranked = sorted(best.items(), key=lambda kv: (-kv[1], kv[0]))
        if not ranked or ranked[0][1] < threshold:
            return None
        if len(ranked) > 1 and ranked[0][1] - ranked[1][1] < 0.02:
            return None  # two codes fit equally well: do not guess
        return ranked[0][0]

    def infer_category(self, toks: tuple) -> str:
        cats = {self.token_category[t] for t in toks if t in self.token_category}
        return next(iter(cats)) if len(cats) == 1 else "UNK"

    def normalize(self, line: Line) -> Line:
        toks = self.tokens(line.label)
        code = line.cost_code or self.assign_code(toks)
        if line.category:
            cat = line.category.upper()
        elif code and code in self.codes:
            cat = self.codes[code]["category"]
        else:
            cat = self.infer_category(toks)
        return replace(line, tokens=toks, norm_label=" ".join(toks), cost_code=code, category=cat)

    def normalize_all(self, lines):
        return [self.normalize(l) for l in lines] if lines is not None else None
