"""Budget-change analysis: tie each line-level budget change to an approval, or infer a reallocation.

Reallocations are rarely recorded in a structured table on day one, so the engine detects moves
that net to zero (e.g. contingency down, construction up) and asks a reviewer to attach the approval.
"""
from __future__ import annotations

from .grouping import tolerance
from .models import ReconException
from .money import usd


def _entry(keys, labels, codes, norms, delta, kind):
    return {"keys": keys, "labels": labels, "codes": codes, "norms": norms, "delta": delta, "kind": kind}


def collect_deltas(change_result, skip=()):
    entries = []
    for g in change_result.groups:
        if id(g) in skip:
            continue  # flagged as a probable keying error, not a budget change
        delta = g.total("right", "budget") - g.total("left", "budget")
        if delta:
            lines = g.left + g.right
            entries.append(_entry([l.key for l in lines], [l.label for l in g.right] or [l.label for l in g.left],
                                  {l.cost_code for l in lines if l.cost_code}, {l.norm_label for l in lines}, delta, "CHANGED"))
    for l in change_result.unmatched_left:
        if l.budget:
            entries.append(_entry([l.key], [l.label], {l.cost_code} - {None}, {l.norm_label}, -l.budget, "REMOVED"))
    for l in change_result.unmatched_right:
        if l.budget:
            entries.append(_entry([l.key], [l.label], {l.cost_code} - {None}, {l.norm_label}, l.budget, "NEW"))
    return entries


def analyse_changes(entries, approvals, cfg):
    """approvals: dicts {approval_ref, cost_code?, norm_label?, delta (cents)}.

    Returns (exceptions, cleared_entries, approved_net_change_cents).
    """
    excs, cleared, open_entries = [], [], []
    unused = list(approvals)
    for e in entries:
        # an approval may cover all of a line's change, or part of it (same line, same direction, not larger)
        for a in list(unused):
            same_line = (a.get("cost_code") and a["cost_code"] in e["codes"]) or \
                        (a.get("norm_label") and a["norm_label"] in e["norms"])
            if same_line and a["delta"] and (a["delta"] > 0) == (e["delta"] > 0) and abs(a["delta"]) <= abs(e["delta"]):
                unused.remove(a)
                cleared.append({**e, "delta": a["delta"], "approval_ref": a["approval_ref"]})
                e = {**e, "delta": e["delta"] - a["delta"]}
                if e["delta"] == 0:
                    break
        if e["delta"]:
            open_entries.append(e)
    approved_net = sum(a["delta"] for a in approvals)

    if open_entries:
        inc = sum(e["delta"] for e in open_entries if e["delta"] > 0)
        dec = sum(e["delta"] for e in open_entries if e["delta"] < 0)
        moves = [{"lines": e["labels"], "change": usd(e["delta"]), "kind": e["kind"]} for e in open_entries]
        keys = [k for e in open_entries for k in e["keys"]]
        if inc > 0 and dec < 0 and abs(inc + dec) <= tolerance(inc, cfg):
            excs.append(ReconException(
                "IMPLIED_REALLOCATION", "BLOCKING", "change",
                f"Budget moved {usd(inc)} between lines with no recorded approval (net change {usd(inc + dec)}).",
                impact_cents=inc, line_keys=keys, evidence={"moves": moves},
                suggestion={"action": "Attach the reallocation / change-order approval, or reject the revision",
                            "moves": moves},
            ))
        else:
            for e in open_entries:
                excs.append(ReconException(
                    "UNAPPROVED_BUDGET_CHANGE", "BLOCKING", "change",
                    f"{', '.join(e['labels'])}: budget {e['kind'].lower()} by {usd(e['delta'])} with no approval "
                    f"(all open changes net to {usd(inc + dec)}).",
                    impact_cents=abs(e["delta"]), line_keys=e["keys"], evidence={"kind": e["kind"]},
                    suggestion={"action": "Attach approval; a net increase also needs a matching Sources change"},
                ))
    for a in unused:
        excs.append(ReconException(
            "APPROVAL_NOT_APPLIED", "WARNING", "change",
            f"Approval {a['approval_ref']} ({usd(a['delta'])}) does not match any budget change in this submission.",
            impact_cents=abs(a["delta"]), evidence={"approval": {k: (usd(v) if k == 'delta' else v) for k, v in a.items()}},
        ))
    return excs, cleared, approved_net
