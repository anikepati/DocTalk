"""Classify the difference between a source amount and a keyed amount into a keying-error pattern."""


def classify_amount_diff(expected: int, keyed: int) -> dict:
    """expected = borrower source value, keyed = LOB value; both integer cents.

    Returns {"pattern": ..., "suggested_cents": ...}. Never applied automatically.
    """
    if expected == keyed:
        return {"pattern": "NONE", "suggested_cents": expected}
    diff = abs(expected - keyed)
    if diff < 100:
        return {"pattern": "ROUNDING", "suggested_cents": expected}
    a, b = str(abs(expected)), str(abs(keyed))
    if len(a) == len(b):
        pos = [i for i in range(len(a)) if a[i] != b[i]]
        if len(pos) == 2 and pos[1] == pos[0] + 1 and a[pos[0]] == b[pos[1]] and a[pos[1]] == b[pos[0]]:
            return {"pattern": "TRANSPOSED_DIGITS", "suggested_cents": expected}
        if len(pos) == 1:
            return {"pattern": "WRONG_DIGIT", "suggested_cents": expected}
    if expected and keyed:
        if expected == keyed * 100 or keyed == expected * 100:
            return {"pattern": "DECIMAL_SHIFT", "suggested_cents": expected}
    if abs(len(a) - len(b)) == 1:
        longer, shorter = (a, b) if len(a) > len(b) else (b, a)
        for i in range(len(longer)):
            if longer[:i] + longer[i + 1:] == shorter:
                kind = "DROPPED_DIGIT" if len(a) > len(b) else "EXTRA_DIGIT"
                return {"pattern": kind, "suggested_cents": expected}
    return {"pattern": "UNEXPLAINED", "suggested_cents": expected}
