"""Budget restructuring ("retro"): typed operations, change sets, and an apply step that enforces
money-conservation invariants and produces a new immutable budget version.

Invariants enforced on every change set:
  I1  base version matches the ledger's current version (optimistic concurrency)
  I2  total budget changes only through FUNDING_CHANGE (needs a Sources change) or CORRECT_BUDGET (fixes an SOR value)
  I3  total drawn (cash already disbursed) changes only through CORRECT_DRAWN ops (which need evidence)
  I4  SPLIT / MERGE conserve budget, drawn and retainage exactly
  I5  no negative budget or drawn; every ACTIVE line has budget >= drawn
  I6  RETIRED lines are zero; CLOSED lines have budget == drawn
  I7  a 1:1 alias points to at most one ACTIVE line
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Optional

from .ledger import BudgetVersion, LedgerLine
from .money import usd

OP_KINDS = {
    "SPLIT", "MERGE", "REGROUP", "CORRECT_BUDGET", "CREATE", "REALLOCATE", "FUNDING_CHANGE", "RECLASS_DRAWS", "CORRECT_DRAWN",
    "ADD_ALIAS", "ADD_GROUP_ALIAS", "RELABEL", "RECATEGORIZE", "RETIRE", "CLOSE",
}
# ops that move money or history between lines need a recorded approval (or explicit checker override)
APPROVAL_REQUIRED = {"REALLOCATE", "FUNDING_CHANGE", "RECLASS_DRAWS", "CORRECT_DRAWN", "RECATEGORIZE"}
# CORRECT_BUDGET fixes a value the SOR got wrong (keying / allocation error). It is not a budget change, so it needs
# a reviewer's confirmation (policy) but no change order.


@dataclass
class Op:
    kind: str
    params: dict
    reason: str = ""
    evidence: dict = field(default_factory=dict)
    approval_ref: Optional[str] = None

    @property
    def requires_approval(self) -> bool:
        return self.kind in APPROVAL_REQUIRED

    def describe(self) -> str:
        p = self.params
        if self.kind == "SPLIT":
            kids = ", ".join(f"{c['label']} {usd(c['budget'])}" for c in p["children"])
            return f"Split {p['source']} into: {kids}"
        if self.kind == "MERGE":
            return f"Merge {', '.join(p['sources'])} into {p['into']['label']}"
        if self.kind == "REGROUP":
            return (f"Regroup {', '.join(p['sources'])} into: "
                    + ", ".join(f"{c['label']} {usd(c['budget'])}" for c in p["children"]))
        if self.kind == "CORRECT_BUDGET":
            return f"Correct the system budget of {p['line']} by {usd(p['amount'])} ({p.get('basis', 'SOR value wrong')})"
        if self.kind == "CREATE":
            return f"Create line {p['spec']['label']} ({p['spec']['ref']})"
        if self.kind in ("REALLOCATE", "RECLASS_DRAWS"):
            what = "budget" if self.kind == "REALLOCATE" else "prior draws"
            return f"Move {usd(p['amount'])} of {what} from {p['from']} to {p['to']}"
        if self.kind == "FUNDING_CHANGE":
            return f"Change total budget by {usd(p['amount'])} on {p['line']} (needs Sources change)"
        if self.kind == "CORRECT_DRAWN":
            return f"Correct disbursement history of {p['line']} by {usd(p['amount'])}"
        if self.kind == "ADD_ALIAS":
            return f"Recognize '{p['alias']}' as {p['line']}"
        if self.kind == "ADD_GROUP_ALIAS":
            return f"Recognize '{p['alias']}' as the group {', '.join(p['lines'])}"
        if self.kind == "RELABEL":
            return f"Rename {p['line']} to '{p['label']}'"
        if self.kind == "RECATEGORIZE":
            return f"Recategorize {p['line']} as {p['category']} ({p.get('cost_code')})"
        if self.kind in ("RETIRE", "CLOSE"):
            return f"{self.kind.title()} {p['line']}"
        return f"{self.kind} {json.dumps(p, sort_keys=True)}"


@dataclass
class ChangeSet:
    change_set_id: str
    loan_id: str
    base_version: int
    ops: list
    status: str = "DRAFT"  # DRAFT -> SUBMITTED -> APPROVED -> COMMITTED | REJECTED
    created_by: str = "engine"
    maker: Optional[str] = None
    checker: Optional[str] = None
    notes: list = field(default_factory=list)
    open_issues: list = field(default_factory=list)  # what the planner could NOT resolve
    committed_version: Optional[int] = None
    overrides: list = field(default_factory=list)

    @staticmethod
    def make_id(loan_id, base_version, ops) -> str:
        raw = json.dumps([loan_id, base_version, [[o.kind, o.params] for o in ops]], sort_keys=True, default=str)
        return "CS-" + hashlib.sha1(raw.encode()).hexdigest()[:12]

    def to_dict(self) -> dict:
        d = asdict(self)
        d["ops"] = [{**asdict(o), "requires_approval": o.requires_approval, "summary": o.describe()} for o in self.ops]
        return d

    @classmethod
    def from_dict(cls, d) -> "ChangeSet":
        d = dict(d)
        d["ops"] = [Op(o["kind"], o["params"], o.get("reason", ""), o.get("evidence", {}), o.get("approval_ref"))
                    for o in d["ops"]]
        return cls(**d)


class ChangeSetError(ValueError):
    def __init__(self, errors):
        super().__init__("; ".join(errors))
        self.errors = errors


def apply_change_set(version: BudgetVersion, cs: ChangeSet):
    """Pure function: returns (new_version, ref_map). Raises ChangeSetError; never partially applies."""
    errors = []
    if cs.base_version != version.version_no:
        raise ChangeSetError([f"I1: change set is based on version {cs.base_version}, ledger is at {version.version_no}"])
    nv = version.successor("RESTRUCTURE", cs.change_set_id)
    lines = nv.lines
    ref = {}
    funding_delta = drawn_delta = correction_delta = 0
    before_budget, before_drawn = version.total_budget(), version.total_drawn()

    def rid(x):
        lid = ref.get(x, x)
        if lid not in lines:
            raise ChangeSetError([f"unknown line {x}"])
        return lid

    def new_line(spec, lineage, budget=0, drawn=0, retainage=0):
        lid = nv.mint_line_id()
        ref[spec["ref"]] = lid
        lines[lid] = LedgerLine(lid, spec["label"], spec.get("category") or "UNK", budget, drawn, retainage,
                                spec.get("cost_code"), aliases=tuple(spec.get("aliases", ())),
                                lineage=tuple(lineage), created_in_version=nv.version_no)
        return lines[lid]

    for i, op in enumerate(cs.ops):
        if op.kind not in OP_KINDS:
            errors.append(f"op {i}: unknown kind {op.kind}")
            continue
        p = op.params
        try:
            if op.kind == "SPLIT":
                src = lines[rid(p["source"])]
                kids = p["children"]
                for col, attr in (("budget", "budget"), ("drawn", "drawn"), ("retainage", "retainage")):
                    if sum(c.get(col, 0) for c in kids) != getattr(src, attr):
                        errors.append(f"op {i} I4: split children {col} {usd(sum(c.get(col, 0) for c in kids))} "
                                      f"!= source {usd(getattr(src, attr))}")
                for c in kids:
                    new_line(c, [src.line_id], c["budget"], c.get("drawn", 0), c.get("retainage", 0))
                src.budget = src.drawn = src.retainage = 0
                src.status = "RETIRED"
            elif op.kind == "MERGE":
                srcs = [lines[rid(s)] for s in p["sources"]]
                nl = new_line(p["into"], [s.line_id for s in srcs], sum(s.budget for s in srcs),
                              sum(s.drawn for s in srcs), sum(s.retainage for s in srcs))
                for s in srcs:
                    s.budget = s.drawn = s.retainage = 0
                    s.status = "RETIRED"
                nl.aliases = tuple(sorted(set(nl.aliases)))
            elif op.kind == "REGROUP":
                srcs = [lines[rid(x)] for x in p["sources"]]
                kids = p["children"]
                for col in ("budget", "drawn", "retainage"):
                    if sum(c.get(col, 0) for c in kids) != sum(getattr(x, col) for x in srcs):
                        errors.append(f"op {i} I4: regroup {col} not conserved")
                for c in kids:
                    new_line(c, [x.line_id for x in srcs], c["budget"], c.get("drawn", 0), c.get("retainage", 0))
                for x in srcs:
                    x.budget = x.drawn = x.retainage = 0
                    x.status = "RETIRED"
            elif op.kind == "CORRECT_BUDGET":
                lines[rid(p["line"])].budget += p["amount"]
                correction_delta += p["amount"]
            elif op.kind == "CREATE":
                new_line(p["spec"], p.get("lineage", ["new"]))
            elif op.kind == "REALLOCATE":
                a, b = lines[rid(p["from"])], lines[rid(p["to"])]
                if p["amount"] <= 0:
                    errors.append(f"op {i}: reallocation amount must be positive")
                a.budget -= p["amount"]
                b.budget += p["amount"]
            elif op.kind == "FUNDING_CHANGE":
                lines[rid(p["line"])].budget += p["amount"]
                funding_delta += p["amount"]
            elif op.kind == "RECLASS_DRAWS":
                a, b = lines[rid(p["from"])], lines[rid(p["to"])]
                a.drawn -= p["amount"]
                b.drawn += p["amount"]
            elif op.kind == "CORRECT_DRAWN":
                lines[rid(p["line"])].drawn += p["amount"]
                drawn_delta += p["amount"]
            elif op.kind == "ADD_ALIAS":
                l = lines[rid(p["line"])]
                l.aliases = tuple(sorted(set(l.aliases) | {p["alias"]}))
            elif op.kind == "ADD_GROUP_ALIAS":
                for x in p["lines"]:
                    l = lines[rid(x)]
                    l.group_aliases = tuple(sorted(set(l.group_aliases) | {p["alias"]}))
            elif op.kind == "RELABEL":
                lines[rid(p["line"])].label = p["label"]
            elif op.kind == "RECATEGORIZE":
                l = lines[rid(p["line"])]
                l.category, l.cost_code = p["category"], p.get("cost_code", l.cost_code)
            elif op.kind == "RETIRE":
                lines[rid(p["line"])].status = "RETIRED"
            elif op.kind == "CLOSE":
                lines[rid(p["line"])].status = "CLOSED"
        except KeyError as exc:
            errors.append(f"op {i} ({op.kind}): missing {exc}")
        except ChangeSetError as exc:
            errors.extend(f"op {i}: {e}" for e in exc.errors)

    # ---- end-state invariants ----------------------------------------------
    if nv.total_budget() - before_budget != funding_delta + correction_delta:
        errors.append(f"I2: total budget moved {usd(nv.total_budget() - before_budget)} but funding changes and "
                      f"SOR corrections total {usd(funding_delta + correction_delta)}")
    if nv.total_drawn() - before_drawn != drawn_delta:
        errors.append(f"I3: total drawn moved {usd(nv.total_drawn() - before_drawn)} but corrections "
                      f"total {usd(drawn_delta)}")
    alias_owner = {}
    for l in lines.values():
        if l.budget < 0 or l.drawn < 0:
            errors.append(f"I5: {l.line_id} {l.label} has negative budget or drawn")
        if l.status == "ACTIVE" and l.drawn > l.budget:
            errors.append(f"I5: {l.line_id} {l.label} drawn {usd(l.drawn)} exceeds budget {usd(l.budget)}")
        if l.status == "RETIRED" and (l.budget or l.drawn):
            errors.append(f"I6: retired {l.line_id} {l.label} still has budget {usd(l.budget)} / drawn {usd(l.drawn)}")
        if l.status == "CLOSED" and l.budget != l.drawn:
            errors.append(f"I6: closed {l.line_id} {l.label} must have budget == drawn")
        if l.status == "ACTIVE":
            for a in l.aliases:
                if a in alias_owner:
                    errors.append(f"I7: alias '{a}' points to both {alias_owner[a]} and {l.line_id}")
                alias_owner[a] = l.line_id
    if errors:
        raise ChangeSetError(errors)
    if funding_delta and nv.total_sources is not None:
        nv.total_sources += funding_delta  # sources must be updated in the same approval
    return nv, ref
