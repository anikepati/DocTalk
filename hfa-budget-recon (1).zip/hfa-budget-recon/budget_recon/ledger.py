"""The budget ledger: versioned, append-only budget state per loan with STABLE line ids.

Every budget line gets a line_id that never changes. Borrower and LOB labels are attached as aliases,
so once a restructuring is committed the next draw matches by alias, 1:1, with no fuzzy matching.
Lineage (parent line ids) records how lines were split, merged or created, so history can always be
rolled forward or back for audit.
"""
from __future__ import annotations

import copy
import datetime as _dt
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional, Protocol

from .models import Line


@dataclass
class LedgerLine:
    line_id: str
    label: str
    category: str
    budget: int  # cents
    drawn: int = 0  # cumulative disbursed through the last posted draw, cents
    retainage: int = 0  # cumulative retainage held, cents
    cost_code: Optional[str] = None
    status: str = "ACTIVE"  # ACTIVE | CLOSED (no more budget, keeps history) | RETIRED (zero, history only)
    aliases: tuple = ()  # 1:1 aliases: a borrower label that means exactly this line
    group_aliases: tuple = ()  # a borrower label that means a GROUP of lines (policy keep_system_detail)
    lineage: tuple = ()  # parent line ids
    created_in_version: int = 1

    @property
    def remaining(self) -> int:
        return self.budget - self.drawn


@dataclass
class BudgetVersion:
    loan_id: str
    version_no: int
    lines: dict  # line_id -> LedgerLine
    source: str  # BOOTSTRAP | RESTRUCTURE | DRAW
    change_ref: str = ""
    total_sources: Optional[int] = None
    draw_no: Optional[int] = None  # last posted draw
    created_at: str = field(default_factory=lambda: _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"))
    next_seq: int = 1  # for minting new line ids

    # ---- views -----------------------------------------------------------
    def active(self):
        return [l for l in self.lines.values() if l.status == "ACTIVE"]

    def total_budget(self) -> int:
        return sum(l.budget for l in self.lines.values())

    def total_drawn(self) -> int:
        return sum(l.drawn for l in self.lines.values())

    def alias_index(self) -> dict:
        idx = {}
        for l in self.active():
            for a in l.aliases:
                idx.setdefault(a, []).append(l.line_id)
        return idx

    def to_recon_lines(self, normalizer) -> list:
        """Expose ACTIVE ledger lines to the matcher as the 'approved' side (key = line_id)."""
        out = []
        for l in sorted(self.active(), key=lambda x: x.line_id):
            n = normalizer.normalize(Line(l.line_id, l.label, l.budget, l.drawn, 0, l.retainage,
                                          cost_code=l.cost_code, category=l.category, source_ref="ledger"))
            n.aliases = tuple(sorted(set(l.aliases) | {n.norm_label}))
            n.group_aliases = tuple(sorted(l.group_aliases))
            out.append(n)
        return out

    def mint_line_id(self) -> str:
        lid = f"{self.loan_id}-L{self.next_seq:04d}"
        self.next_seq += 1
        return lid

    def successor(self, source: str, change_ref: str) -> "BudgetVersion":
        nv = copy.deepcopy(self)
        nv.version_no = self.version_no + 1
        nv.source, nv.change_ref = source, change_ref
        nv.created_at = _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")
        return nv

    # ---- serialization ---------------------------------------------------
    def to_dict(self) -> dict:
        d = asdict(self)
        d["lines"] = {k: {**asdict(v), "aliases": list(v.aliases), "group_aliases": list(v.group_aliases),
                          "lineage": list(v.lineage)} for k, v in self.lines.items()}
        return d

    @classmethod
    def from_dict(cls, d) -> "BudgetVersion":
        d = dict(d)
        d["lines"] = {k: LedgerLine(**{**v, "aliases": tuple(v["aliases"]), "group_aliases": tuple(v["group_aliases"]),
                                       "lineage": tuple(v["lineage"])}) for k, v in d["lines"].items()}
        return cls(**d)


def bootstrap_version(loan_id: str, approved_lines, normalizer, total_sources=None) -> BudgetVersion:
    """Create version 1 from the system-of-record budget (one-off migration per loan)."""
    v = BudgetVersion(loan_id, 1, {}, "BOOTSTRAP", "import", total_sources=total_sources)
    for l in approved_lines:
        n = normalizer.normalize(l)
        lid = v.mint_line_id()
        v.lines[lid] = LedgerLine(lid, l.label, n.category or "UNK", l.budget, l.prior, l.retainage,
                                  n.cost_code, aliases=(n.norm_label,), lineage=(f"legacy:{l.key}",))
    return v


# ---------------------------------------------------------------- persistence
class ConcurrencyError(RuntimeError):
    pass


class Repository(Protocol):
    def current(self, loan_id: str) -> Optional[BudgetVersion]: ...
    def get(self, loan_id: str, version_no: int) -> BudgetVersion: ...
    def save(self, version: BudgetVersion) -> None: ...
    def save_record(self, loan_id: str, kind: str, record_id: str, body: dict) -> None: ...
    def load_record(self, loan_id: str, kind: str, record_id: str) -> Optional[dict]: ...
    def list_records(self, kind: str, loan_id: Optional[str] = None) -> list: ...


class InMemoryRepository:
    def __init__(self):
        self.versions, self.records = {}, {}

    def current(self, loan_id):
        vs = self.versions.get(loan_id)
        return copy.deepcopy(vs[-1]) if vs else None

    def get(self, loan_id, version_no):
        return copy.deepcopy(self.versions[loan_id][version_no - 1])

    def save(self, version):
        vs = self.versions.setdefault(version.loan_id, [])
        expected = len(vs) + 1
        if version.version_no != expected:
            raise ConcurrencyError(f"{version.loan_id}: expected version {expected}, got {version.version_no}")
        vs.append(copy.deepcopy(version))

    def save_record(self, loan_id, kind, record_id, body):
        self.records[(loan_id, kind, record_id)] = copy.deepcopy(body)

    def load_record(self, loan_id, kind, record_id):
        r = self.records.get((loan_id, kind, record_id))
        return copy.deepcopy(r) if r is not None else None

    def list_records(self, kind, loan_id=None):
        return [copy.deepcopy(v) for (l, k, _), v in sorted(self.records.items())
                if k == kind and (loan_id is None or l == loan_id)]


class JsonFileRepository:
    """File-backed repository for demos and tests. Production: Postgres (see sql/schema.sql), same interface."""

    def __init__(self, root):
        self.root = Path(root)

    def _dir(self, loan_id):
        d = self.root / loan_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def current(self, loan_id):
        files = sorted(self._dir(loan_id).glob("budget_v*.json"))
        return BudgetVersion.from_dict(json.loads(files[-1].read_text())) if files else None

    def get(self, loan_id, version_no):
        return BudgetVersion.from_dict(json.loads((self._dir(loan_id) / f"budget_v{version_no:04d}.json").read_text()))

    def save(self, version):
        cur = self.current(version.loan_id)
        expected = (cur.version_no + 1) if cur else 1
        if version.version_no != expected:
            raise ConcurrencyError(f"{version.loan_id}: expected version {expected}, got {version.version_no}")
        p = self._dir(version.loan_id) / f"budget_v{version.version_no:04d}.json"
        with open(p, "x") as f:  # 'x' = never overwrite an existing version
            json.dump(version.to_dict(), f, indent=2)

    def save_record(self, loan_id, kind, record_id, body):
        d = self._dir(loan_id) / kind
        d.mkdir(exist_ok=True)
        (d / f"{record_id}.json").write_text(json.dumps(body, indent=2, default=str))

    def load_record(self, loan_id, kind, record_id):
        p = self._dir(loan_id) / kind / f"{record_id}.json"
        return json.loads(p.read_text()) if p.exists() else None

    def list_records(self, kind, loan_id=None):
        if not self.root.exists():
            return []
        loans = [loan_id] if loan_id else sorted(d.name for d in self.root.iterdir() if d.is_dir())
        out = []
        for l in loans:
            d = self.root / l / kind
            if d.exists():
                out += [json.loads(p.read_text()) for p in sorted(d.glob("*.json"))]
        return out
