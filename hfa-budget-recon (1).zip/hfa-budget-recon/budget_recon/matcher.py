"""Pass-based matching engine. Each pass sees only the lines earlier passes left unmatched.

Passes: 1 learned mappings -> 2 exact -> 3 identical numbers (1:1) -> 4 consolidation / split
(multi-column subset-sum) -> 5 label pairing (values may differ) -> 6 residuals.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
from scipy.optimize import linear_sum_assignment

from .grouping import SearchLimit, find_subsets, tolerance
from .models import MatchGroup
from .similarity import label_similarity, token_overlap_support


def compatible(a, b) -> bool:
    return a.category == b.category or "UNK" in (a.category, b.category)


@dataclass
class MatchResult:
    groups: list = field(default_factory=list)
    ambiguities: list = field(default_factory=list)  # dicts: target, candidates (list of line lists)
    search_limits: list = field(default_factory=list)
    unmatched_left: list = field(default_factory=list)
    unmatched_right: list = field(default_factory=list)
    regroups: list = field(default_factory=list)  # filled by structure.analyse: M:N regroupings in a category


DEFAULT_RULES = [
    {"id": "M00", "name": "Known alias", "type": "ledger_alias"},
    {"id": "M01", "name": "Confirmed mapping", "type": "learned"},
    {"id": "M02", "name": "Same label or cost code, same amounts", "type": "exact"},
    {"id": "M03", "name": "Same amounts, label variant", "type": "identical_amounts", "params": {"min_label_similarity": 0.5}},
    {"id": "M04", "name": "Summation into one right line", "type": "summation", "params": {"target_side": "right"}},
    {"id": "M05", "name": "Summation into one left line", "type": "summation", "params": {"target_side": "left"}},
    {"id": "M06", "name": "Label variant, amounts differ", "type": "fuzzy_label", "params": {"min_similarity": 0.80}},
]


class Matcher:
    def __init__(self, cfg, cols, comparison: str, loan_id: str):
        self.cfg, self.cols, self.comparison, self.loan_id = cfg, tuple(cols), comparison, loan_id
        self.rules = [r for r in (cfg.s("match_rules") or DEFAULT_RULES) if r.get("enabled", True)]
        self.rule = {}

    # ---- helpers --------------------------------------------------------
    def _vec(self, line):
        return line.vector(self.cols)

    def _pair_score(self, a, b) -> float:
        s = label_similarity(a.tokens, b.tokens)
        if a.cost_code and a.cost_code == b.cost_code:
            s = max(s, 0.9)
        return s

    def _ties(self, va, vb) -> bool:
        return all(abs(x - y) <= tolerance(y, self.cfg) for x, y in zip(va, vb))

    def _evidence_strength(self, vec) -> int:
        return sum(1 for v in vec if v != 0)

    # ---- main -----------------------------------------------------------
    def run(self, left, right, mappings=()) -> MatchResult:
        self.L = {l.key: l for l in left}
        self.R = {r.key: r for r in right}
        self.free_l = [l.key for l in sorted(left, key=lambda x: x.key)]
        self.free_r = [r.key for r in sorted(right, key=lambda x: x.key)]
        self.res = MatchResult()
        self.ambiguous_keys = set()
        for rule in self.rules:
            self.rule = rule
            prm = rule.get("params", {})
            kind = rule["type"]
            if kind == "ledger_alias":
                self._pass_ledger_alias()
            elif kind == "learned":
                self._pass_learned(mappings)
            elif kind == "exact":
                self._pass_exact()
            elif kind == "identical_amounts":
                self._pass_identical_numbers(prm.get("min_label_similarity", 0.5))
            elif kind == "summation":
                self._pass_groups(target_side=prm.get("target_side", "right"))
            elif kind == "fuzzy_label":
                self._pass_labels(prm.get("min_similarity"))
            else:
                raise ValueError(f"unknown match rule type {kind} ({rule.get('id')})")
        self.res.unmatched_left = [self.L[k] for k in self.free_l if k not in self.ambiguous_keys]
        self.res.unmatched_right = [self.R[k] for k in self.free_r if k not in self.ambiguous_keys]
        return self.res

    def _take(self, lkeys, rkeys, relation, pass_name, conf, notes=None):
        for k in lkeys:
            self.free_l.remove(k)
        for k in rkeys:
            self.free_r.remove(k)
        g = MatchGroup(self.comparison, relation, [self.L[k] for k in lkeys], [self.R[k] for k in rkeys],
                       pass_name, conf, notes or [], self.rule.get("id", ""), self.rule.get("name", ""))
        self.res.groups.append(g)
        return g

    # ---- pass 0: ledger aliases (after a restructuring, the next draw lands here 1:1) ----
    def _pass_ledger_alias(self):
        if not any(self.L[k].aliases or self.L[k].group_aliases for k in self.free_l):
            return
        for rk in list(self.free_r):
            r = self.R[rk]
            hits = [k for k in self.free_l if r.norm_label in self.L[k].aliases]
            if len(hits) == 1:
                self._take(hits, [rk], "1:1", "ledger_alias", 1.0, ["known alias of ledger line"])
                continue
            if not hits:
                grp = [k for k in self.free_l if r.norm_label in self.L[k].group_aliases]
                if grp:
                    self._take(grp, [rk], "N:1" if len(grp) > 1 else "1:1", "ledger_group_alias", 1.0,
                               ["known group alias (system detail kept)"])

    # ---- pass 1: confirmed mappings from earlier draws -------------------
    def _pass_learned(self, mappings):
        for m in mappings:
            if m.get("loan_id") not in (self.loan_id, "*") or m.get("comparison") != self.comparison:
                continue
            lk = self._find_by_norm(self.free_l, self.L, m["left"])
            rk = self._find_by_norm(self.free_r, self.R, m["right"])
            if lk is None or rk is None:
                continue
            lv = tuple(sum(self.L[k].col(c) for k in lk) for c in self.cols)
            rv = tuple(sum(self.R[k].col(c) for k in rk) for c in self.cols)
            if self.comparison == "keying" and not self._ties(rv, lv):
                continue  # mapping known, but numbers disagree: let later passes explain why
            relation = "1:1" if len(lk) == len(rk) == 1 else ("N:1" if len(rk) == 1 else "1:N")
            self._take(lk, rk, relation, "learned", 1.0, [f"confirmed mapping {m.get('mapping_id', '')}".strip()])

    @staticmethod
    def _find_by_norm(free, index, labels):
        keys = []
        for lab in labels:
            hits = [k for k in free if index[k].norm_label == lab and k not in keys]
            if len(hits) != 1:
                return None
            keys.append(hits[0])
        return keys

    # ---- pass 2: exact (same label or same unique cost code, same numbers) ----
    def _pass_exact(self):
        for attr in ("norm_label", "cost_code"):
            idx_l, idx_r = {}, {}
            for k in self.free_l:
                v = getattr(self.L[k], attr)
                if v:
                    idx_l.setdefault((v, self._vec(self.L[k])), []).append(k)
            for k in self.free_r:
                v = getattr(self.R[k], attr)
                if v:
                    idx_r.setdefault((v, self._vec(self.R[k])), []).append(k)
            for key in sorted(idx_l, key=str):
                if key in idx_r and len(idx_l[key]) == 1 and len(idx_r[key]) == 1:
                    lk, rk = idx_l[key][0], idx_r[key][0]
                    if lk in self.free_l and rk in self.free_r:
                        self._take([lk], [rk], "1:1", f"exact_{attr}", 1.0)

    # ---- pass 3: identical numbers, label differs (abbreviations, typos) ----
    def _pass_identical_numbers(self, min_sim=0.5):
        buckets_l, buckets_r = {}, {}
        for k in self.free_l:
            v = self._vec(self.L[k])
            if any(v):
                buckets_l.setdefault(v, []).append(k)
        for k in self.free_r:
            v = self._vec(self.R[k])
            if any(v):
                buckets_r.setdefault(v, []).append(k)
        for vec in sorted(buckets_l):
            if vec not in buckets_r:
                continue
            ls, rs = buckets_l[vec], buckets_r[vec]
            m = np.full((len(ls), len(rs)), -1.0)
            for i, lk in enumerate(ls):
                for j, rk in enumerate(rs):
                    if compatible(self.L[lk], self.R[rk]):
                        m[i, j] = self._pair_score(self.L[lk], self.R[rk])
            rows, cols = linear_sum_assignment(-m)
            k_strength = self._evidence_strength(vec)
            for i, j in sorted(zip(rows, cols)):
                sim = m[i, j]
                if sim < 0:
                    continue
                unique = len(ls) == 1 and len(rs) == 1
                if not unique and sim < min_sim:
                    continue
                conf = min(1.0, 0.55 + 0.1 * k_strength + 0.3 * sim)
                self._take([ls[i]], [rs[j]], "1:1", "identical_numbers", conf,
                           [f"numbers tie on {k_strength} column(s); label similarity {sim:.2f}"])

    # ---- pass 4: consolidations and splits -------------------------------
    def _pass_groups(self, target_side: str):
        tgt_free, tgt_idx = (self.free_r, self.R) if target_side == "right" else (self.free_l, self.L)
        pool_free, pool_idx = (self.free_l, self.L) if target_side == "right" else (self.free_r, self.R)
        cap = self.cfg.s("group_pool_cap", 40)
        margin = self.cfg.s("ambiguity_support_margin", 0.25)
        targets = sorted(list(tgt_free), key=lambda k: (-tgt_idx[k].budget, k))
        for tk in targets:
            if tk not in tgt_free or tk in self.ambiguous_keys:
                continue
            t = tgt_idx[tk]
            tvec = self._vec(t)
            if not any(tvec) or any(v < 0 for v in tvec):
                continue
            pool = [pool_idx[k] for k in pool_free
                    if k not in self.ambiguous_keys and compatible(pool_idx[k], t)
                    and any(self._vec(pool_idx[k])) and all(v >= 0 for v in self._vec(pool_idx[k]))]
            if len(pool) < 2:
                continue
            if len(pool) > cap:
                self.res.search_limits.append({"target": t, "reason": f"pool of {len(pool)} > cap {cap}"})
                continue
            try:
                sols = find_subsets(tvec, pool, self.cols, self.cfg)
            except SearchLimit:
                self.res.search_limits.append({"target": t, "reason": "node limit reached"})
                continue
            if not sols:
                continue
            ranked = []
            for sol in sols:
                members = [pool[i] for i in sol]
                support = sum(token_overlap_support(t.tokens, m.tokens) for m in members) / len(members)
                ranked.append((support, members))
            ranked.sort(key=lambda x: (-x[0], [m.key for m in x[1]]))
            best_support, members = ranked[0]
            k_strength = self._evidence_strength(tvec)
            base = 0.82 if k_strength >= 2 else 0.62
            conf = min(1.0, base + 0.15 * best_support)
            notes = [f"{len(members)} lines tie on {k_strength} numeric column(s); label support {best_support:.2f}"]
            if len(ranked) > 1:
                if best_support - ranked[1][0] < margin:
                    self.ambiguous_keys.add(tk)
                    for _, ms in ranked:
                        self.ambiguous_keys.update(m.key for m in ms)
                    self.res.ambiguities.append({"target": t, "target_side": target_side,
                                                 "candidates": [ms for _, ms in ranked]})
                    continue
                conf = min(conf, 0.90)
                notes.append(f"{len(ranked)} groups tie numerically; chosen by label support")
            mkeys = [m.key for m in members]
            if target_side == "right":
                self._take(mkeys, [tk], "N:1", "consolidation", conf, notes)
            else:
                self._take([tk], mkeys, "1:N", "split", conf, notes)

    # ---- pass 5: label pairing; numbers may differ -----------------------
    def _pass_labels(self, threshold=None):
        if not self.free_l or not self.free_r:
            return
        thr = threshold if threshold is not None else self.cfg.s("label_match_threshold", 0.80)
        ls = [k for k in self.free_l if k not in self.ambiguous_keys]
        rs = [k for k in self.free_r if k not in self.ambiguous_keys]
        if not ls or not rs:
            return
        m = np.full((len(ls), len(rs)), -1.0)
        for i, lk in enumerate(ls):
            for j, rk in enumerate(rs):
                if compatible(self.L[lk], self.R[rk]):
                    m[i, j] = self._pair_score(self.L[lk], self.R[rk])
        rows, cols = linear_sum_assignment(-m)
        code_count_l, code_count_r = {}, {}
        for k in ls:
            code_count_l[self.L[k].cost_code] = code_count_l.get(self.L[k].cost_code, 0) + 1
        for k in rs:
            code_count_r[self.R[k].cost_code] = code_count_r.get(self.R[k].cost_code, 0) + 1
        for i, j in sorted(zip(rows, cols)):
            if m[i, j] < thr:
                continue
            a, b = self.L[ls[i]], self.R[rs[j]]
            conf, notes = float(m[i, j]), [f"label similarity {m[i, j]:.2f}; numbers differ"]
            if a.cost_code and a.cost_code == b.cost_code and code_count_l[a.cost_code] == 1 and code_count_r[b.cost_code] == 1:
                conf = max(conf, 0.97)
                notes.append(f"only line with cost code {a.cost_code} on both sides")
            self._take([ls[i]], [rs[j]], "1:1", "label", conf, notes)
