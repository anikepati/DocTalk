"""Straight-through processing (STP) policy: decides, from configuration, what the system may do on its own
and what must go to a person. Keeping this in one place makes the bank's risk appetite explicit, versioned
and auditable (every automatic approval records the policy id that allowed it)."""
from __future__ import annotations


class StpPolicy:
    def __init__(self, cfg):
        p = cfg.s("stp", {})
        self.p = p
        self.policy_id = p.get("policy_id", "STP")

    @property
    def approver(self) -> str:
        return f"policy:{self.policy_id}"

    def op_route(self, op):
        """Returns (route, reason, approvals_needed). route: AUTO | HUMAN."""
        p, k = self.p, op.kind
        if k in p.get("always_auto_ops", []):
            return "AUTO", "cosmetic; the related match decision is reviewed separately", 0
        if k in p.get("always_human_ops", []):
            n = 2 if k in p.get("dual_approval_ops", []) else 1
            return "HUMAN", f"{k} always needs a person" + (" (two approvers)" if n == 2 else ""), n
        if k in p.get("auto_with_recorded_approval", []):
            if op.approval_ref:
                return "AUTO", f"matches recorded approval {op.approval_ref}", 0
            return "HUMAN", "no recorded approval covers this move", 1
        if k in p.get("confidence_ops", []):
            conf = op.evidence.get("confidence", 0)
            if conf >= p.get("auto_min_confidence", 0.95):
                return "AUTO", f"match confidence {conf:.2f}", 0
            return "HUMAN", f"match confidence {conf:.2f} below {p.get('auto_min_confidence', 0.95)}", 1
        if k in p.get("auto_ops", []):
            conf = op.evidence.get("confidence", 1.0)
            if conf >= p.get("auto_min_confidence", 0.95):
                return "AUTO", "structural, no money moves", 0
            return "HUMAN", f"based on a match with confidence {conf:.2f}", 1
        return "HUMAN", f"{k} is not covered by the auto policy", 1

    def extraction_ok(self, ext) -> bool:
        return not ext.blocking and ext.confidence >= self.p.get("extraction_min_confidence", 0.95)

    def needs_signoff(self, draw_total_cents: int) -> bool:
        return draw_total_cents > self.p.get("auto_post_max_draw_cents", 0)

    def exception_actions(self, reason_code: str) -> list:
        acts = ["RETURN_TO_BORROWER"]
        if reason_code in self.p.get("adjustable_exceptions", []):
            acts.insert(0, "ADJUST_DRAW")
        if reason_code in self.p.get("overridable_exceptions", []):
            acts.insert(0, "OVERRIDE")
        return acts

    def sla_hours(self, kind) -> int:
        return self.p.get("sla_hours", {}).get(kind, 24)

    def queue(self, kind) -> str:
        return self.p.get("queues", {}).get(kind, "default")
