"""Multi-column subset-sum search used to detect consolidations and splits.

A candidate group must tie on EVERY numeric column at once (e.g. budget, prior draws and this
draw). Round-number budgets collide constantly; four columns colliding by chance is rare.
"""
from __future__ import annotations


class SearchLimit(Exception):
    pass


def tolerance(target: int, cfg) -> int:
    return max(cfg.s("group_tolerance_cents", 500), int(abs(target) * cfg.s("group_tolerance_pct", 0.0001)))


def find_subsets(target_vec, pool, cols, cfg, max_solutions=5):
    """Return up to max_solutions groups (tuples of pool indexes) whose column sums tie with target_vec.

    pool: list of Lines with non-negative values. Deterministic order: pool sorted by primary desc, key.
    """
    max_size = cfg.s("group_max_size", 6)
    node_limit = cfg.s("search_node_limit", 200000)
    n_cols = len(cols)
    # primary column = the one with the largest target value (best pruning)
    p = max(range(n_cols), key=lambda i: (abs(target_vec[i]), -i))
    tol = [tolerance(t, cfg) for t in target_vec]
    vecs = [l.vector(cols) for l in pool]
    order = sorted(range(len(pool)), key=lambda i: (-vecs[i][p], pool[i].key))
    vecs = [vecs[i] for i in order]
    suffix = [0] * (len(vecs) + 1)
    for i in range(len(vecs) - 1, -1, -1):
        suffix[i] = suffix[i + 1] + vecs[i][p]

    solutions = []
    nodes = 0

    def ties(sums):
        return all(abs(sums[c] - target_vec[c]) <= tol[c] for c in range(n_cols))

    def dfs(start, chosen, sums):
        nonlocal nodes
        nodes += 1
        if nodes > node_limit:
            raise SearchLimit()
        if len(chosen) >= 2 and ties(sums):
            solutions.append(tuple(order[i] for i in chosen))
            if len(solutions) >= max_solutions:
                return True
        if len(chosen) == max_size:
            return False
        for j in range(start, len(vecs)):
            v = vecs[j]
            if sums[p] + v[p] > target_vec[p] + tol[p]:
                continue
            if sums[p] + suffix[j] < target_vec[p] - tol[p]:
                break
            new = [sums[c] + v[c] for c in range(n_cols)]
            if any(new[c] > target_vec[c] + tol[c] for c in range(n_cols)):
                continue  # all values non-negative: overshoot can never come back
            if dfs(j + 1, chosen + [j], new):
                return True
        return False

    dfs(0, [], [0] * n_cols)
    return solutions
