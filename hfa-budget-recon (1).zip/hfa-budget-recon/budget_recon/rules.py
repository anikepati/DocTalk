"""Config-driven rule engine with a safe expression evaluator (whitelisted AST; no attributes, no imports)."""
from __future__ import annotations

import ast

from .models import ReconException
from .money import usd

_ALLOWED_NODES = (
    ast.Expression, ast.BoolOp, ast.And, ast.Or, ast.UnaryOp, ast.Not, ast.USub, ast.UAdd,
    ast.BinOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod,
    ast.Compare, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
    ast.Name, ast.Load, ast.Constant, ast.Call, ast.IfExp, ast.Tuple, ast.List,
)
_FUNCS = {"abs": abs, "min": min, "max": max, "round": round}


class RuleError(ValueError):
    pass


def compile_expr(expr: str):
    tree = ast.parse(expr, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_NODES):
            raise RuleError(f"disallowed syntax {type(node).__name__} in: {expr}")
        if isinstance(node, ast.Call) and not (isinstance(node.func, ast.Name) and node.func.id in _FUNCS):
            raise RuleError(f"only {sorted(_FUNCS)} may be called: {expr}")
        if isinstance(node, ast.Name) and node.id.startswith("_"):
            raise RuleError(f"illegal name {node.id}")
    names = {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)} - set(_FUNCS)
    return compile(tree, "<rule>", "eval"), names


class _Fmt(dict):
    def __missing__(self, key):
        return "{" + key + "}"


class RuleEngine:
    def __init__(self, rules: list, settings: dict):
        self.settings = settings
        self.rules = []
        for r in rules:
            code, names = compile_expr(r["expression"])
            when = compile_expr(r["when"]) if r.get("when") else None
            self.rules.append((r, code, names, when))

    def evaluate(self, scope: str, ctx: dict, line_keys=()):
        """Returns (exceptions, results). results: list of {rule_id, status, missing}."""
        env = {**self.settings.get("rule_params", {}), **ctx}
        excs, results = [], []
        for r, code, names, when in self.rules:
            if r.get("scope") != scope or not r.get("active", True):
                continue
            needed = set(names) | (when[1] if when else set())
            missing = sorted(n for n in needed if env.get(n) is None)
            if missing:
                results.append({"rule_id": r["rule_id"], "status": "NOT_EVALUATED", "missing": missing})
                continue
            safe = {"__builtins__": {}, **_FUNCS}
            if when and not eval(when[0], safe, env):
                results.append({"rule_id": r["rule_id"], "status": "NOT_APPLICABLE"})
                continue
            ok = bool(eval(code, safe, env))
            results.append({"rule_id": r["rule_id"], "status": "PASS" if ok else "FAIL"})
            if not ok:
                fmt = _Fmt(env)
                fmt.update({k + "_usd": usd(v) for k, v in env.items() if isinstance(v, int) and not isinstance(v, bool)})
                impact = env.get(r["impact"]) if r.get("impact") else 0
                excs.append(ReconException(
                    reason_code=r["reason_code"], severity=r["severity"], comparison="rules",
                    message=r["message"].format_map(fmt), impact_cents=int(impact or 0),
                    line_keys=list(line_keys), evidence={k: env.get(k) for k in sorted(names)},
                    suggestion=r.get("suggestion"), rule_id=r["rule_id"],
                ))
        return excs, results
