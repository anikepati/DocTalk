"""Deterministic string similarity (stdlib only)."""
from difflib import SequenceMatcher


def ratio(a: str, b: str) -> float:
    if not a and not b:
        return 1.0
    return SequenceMatcher(None, a, b).ratio()


def token_set_ratio(a_tokens, b_tokens) -> float:
    a, b = set(a_tokens), set(b_tokens)
    if not a or not b:
        return 0.0
    inter = " ".join(sorted(a & b))
    s1 = (inter + " " + " ".join(sorted(a - b))).strip()
    s2 = (inter + " " + " ".join(sorted(b - a))).strip()
    if inter:
        return max(ratio(inter, s1), ratio(inter, s2), ratio(s1, s2))
    return ratio(s1, s2)


def label_similarity(a_tokens, b_tokens) -> float:
    """Blend of token-set ratio (forgives extra words) and sorted-token ratio (penalises them)."""
    if not a_tokens or not b_tokens:
        return 0.0
    sorted_ratio = ratio(" ".join(sorted(a_tokens)), " ".join(sorted(b_tokens)))
    return 0.5 * token_set_ratio(a_tokens, b_tokens) + 0.5 * sorted_ratio


def osa_distance(a: str, b: str) -> int:
    """Optimal string alignment distance (Levenshtein + adjacent transposition)."""
    la, lb = len(a), len(b)
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            cost = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def token_overlap_support(target_tokens, member_tokens) -> float:
    """Share of a member's words that appear (or prefix-match, >=3 chars) in the target label."""
    mt = set(member_tokens)
    if not mt:
        return 0.0
    tt = set(target_tokens)

    def hit(t):
        for u in tt:
            if t == u:
                return True
            if len(t) >= 3 and len(u) >= 3 and (t.startswith(u) or u.startswith(t)):
                return True
        return False

    return sum(1 for t in mt if hit(t)) / len(mt)
