"""REST API over ReconService (FastAPI). Thin by design: all logic lives in the service and below.

Run:  RECON_STORE=/data/recon uvicorn budget_recon.api:app
Production: swap JsonFileRepository for a Postgres repository with the same interface, put auth in front,
and take maker / checker identities from the authenticated principal, never from the request body.
"""
from __future__ import annotations

import os
from typing import Optional

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from .config import load_config
from .io import load_loan
from .ledger import JsonFileRepository
from .posting import PostingError
from .restructure import ChangeSet, ChangeSetError
from .service import ReconService, WorkflowError

app = FastAPI(title="HFA draw processing", version="0.3.0")
_svc: Optional[ReconService] = None
_pipe = None


def pipeline():
    """The operating model: the system processes the borrower's file; people work the task queue."""
    global _pipe
    if _pipe is None:
        from .pipeline import FolderFeeds, Pipeline
        _pipe = Pipeline(load_config(os.environ.get("RECON_CONFIG")),
                         JsonFileRepository(os.environ.get("RECON_STORE", "./store")),
                         FolderFeeds(os.environ.get("RECON_FEEDS", "./feeds")))
    return _pipe


class Onboard(BaseModel):
    approved_budget_file: str


class Submission(BaseModel):
    file: str  # production: an object-store key written by the intake channel (email, portal, SFTP)
    loan_id: Optional[str] = None
    draw_no: Optional[int] = None


class Decision(BaseModel):
    action: str
    user: str  # production: taken from the authenticated principal, not the body
    approval_ref: Optional[str] = None
    note: Optional[str] = None
    borrower_key: Optional[str] = None
    amount_cents: Optional[int] = None


@app.post("/loans/{loan_id}/onboard")
def onboard(loan_id: str, body: Onboard):
    v = pipeline().onboard(loan_id, body.approved_budget_file)
    return {"loan_id": loan_id, "ledger_version": v.version_no, "lines": len(v.lines)}


@app.post("/submissions")
def submit(body: Submission):
    p = pipeline()
    try:
        sub = p.receive(body.file, body.loan_id, body.draw_no)
    except ValueError as exc:
        raise HTTPException(422, str(exc))
    return {k: sub[k] for k in ("submission_id", "loan_id", "draw_no", "state", "stage", "history")}


@app.get("/tasks")
def tasks(status: str = "OPEN", queue: Optional[str] = None, loan_id: Optional[str] = None):
    from dataclasses import asdict
    return [asdict(t) for t in pipeline().tasks.list(status, loan_id, queue)]


@app.post("/loans/{loan_id}/tasks/{task_id}/decision")
def decide(loan_id: str, task_id: str, d: Decision):
    from .hitl import TaskError
    payload = {k: v for k, v in d.model_dump().items() if k not in ("action", "user") and v is not None}
    try:
        sub = pipeline().decide(loan_id, task_id, d.action.upper(), d.user, payload)
    except TaskError as exc:
        raise HTTPException(409, str(exc))
    return {k: sub.get(k) for k in ("submission_id", "state", "stage", "history", "draw_total", "returned_reasons")}


@app.get("/loans/{loan_id}/submissions")
def submissions(loan_id: str):
    return pipeline().repo.list_records("submissions", loan_id)


def service() -> ReconService:
    global _svc
    if _svc is None:
        _svc = ReconService(load_config(os.environ.get("RECON_CONFIG")),
                            JsonFileRepository(os.environ.get("RECON_STORE", "./store")))
    return _svc


class DrawRef(BaseModel):
    folder: str  # production: a submission id whose files were extracted upstream


class Approval(BaseModel):
    maker: str
    checker: str
    approval_refs: dict = {}
    overrides: dict = {}


class Resolution(BaseModel):
    folder: str
    exception_id: str
    action: str
    user: str
    note: str = ""
    borrower_key: Optional[str] = None
    adjust_current_cents: Optional[int] = None


def _guard(fn):
    try:
        return fn()
    except (WorkflowError, PostingError, ChangeSetError) as exc:
        raise HTTPException(status_code=409, detail=str(exc))


@app.post("/draws/plan")
def plan(req: DrawRef):
    svc = service()
    loan = load_loan(req.folder)
    rep = svc.identify(loan)
    cs = svc.plan(loan, rep)
    return {"recon": rep.to_dict(), "change_set": cs.to_dict()}


@app.post("/loans/{loan_id}/change-sets/{cs_id}/commit")
def commit(loan_id: str, cs_id: str, body: Approval):
    svc = service()
    stored = svc.repo.load_record(loan_id, "change_sets", cs_id)
    if not stored:
        raise HTTPException(404, "change set not found")
    cs = ChangeSet.from_dict(stored)

    def run():
        if cs.status == "DRAFT":
            svc.submit(cs, body.maker)
        if cs.status == "SUBMITTED":
            svc.approve(cs, body.checker, body.approval_refs, body.overrides)
        v = svc.commit(cs)
        return {"change_set_id": cs_id, "ledger_version": v.version_no}
    return _guard(run)


@app.post("/draws/resolve")
def resolve(r: Resolution):
    svc = service()
    import json
    from pathlib import Path
    meta = json.loads((Path(r.folder) / "loan.json").read_text())
    svc.resolve(meta["loan_id"], meta["draw_no"], r.exception_id, r.action, r.user, r.note,
                r.adjust_current_cents, r.borrower_key)
    return {"ok": True}


@app.post("/draws/post")
def post(req: DrawRef):
    svc = service()
    import json
    from pathlib import Path
    loan = load_loan(req.folder)
    draw_no = json.loads((Path(req.folder) / "loan.json").read_text())["draw_no"]
    v, rec = _guard(lambda: svc.post(loan, draw_no))
    return {"ledger_version": v.version_no, "draw_no": rec.draw_no, "total_cents": rec.total, "lines": rec.lines}


@app.get("/loans/{loan_id}/ledger")
def ledger(loan_id: str, version: Optional[int] = None):
    svc = service()
    v = svc.repo.get(loan_id, version) if version else svc.repo.current(loan_id)
    if v is None:
        raise HTTPException(404, "no ledger for loan")
    return v.to_dict()
