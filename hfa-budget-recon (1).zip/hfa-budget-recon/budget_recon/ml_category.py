"""Optional ML fallback for line categories (ACQUISITION / HARD / SOFT / OTHER).

Used only when the deterministic path leaves a line's category unknown: no cost-code match, no section heading,
no category words. Every prediction carries its confidence, and the model ABSTAINS (returns None) when:
  * the label has no word the model learned from ("Misc 1", "Item 7", "Allowance"): it would be guessing from
    the amount alone, which is exactly where it was confidently wrong in evaluation
  * its confidence is below the configured threshold

Enable in config/settings.json:  "ml_category": {"model": "ml/model/category_model.joblib", "min_confidence": 0.9}
"""
from __future__ import annotations

import math
from functools import lru_cache
from pathlib import Path

GENERIC = {"misc", "miscellaneous", "other", "item", "items", "line", "allowance", "tbd", "various", "general",
           "na", "n", "a", "budget", "cost", "costs", "total", "sub"}


@lru_cache(maxsize=4)
def _load(path):
    import joblib
    return joblib.load(path)


class CategoryModel:
    def __init__(self, path, normalizer, min_confidence=0.9):
        self.bundle = _load(str(Path(path)))
        self.pipe = self.bundle["pipeline"]
        self.norm = normalizer
        self.min_conf = min_confidence
        word = self.pipe.named_steps["features"].named_transformers_["word"]
        self.vocab = {t for t in word.vocabulary_ if " " not in t}

    def predict(self, label, section="", budget_share=None) -> dict:
        import pandas as pd
        toks = [t for t in self.norm.tokens(label) if t not in GENERIC]
        known = [t for t in toks if t in self.vocab]
        if not known:
            return {"category": None, "confidence": 0.0, "abstained": True,
                    "reason": "label has no recognizable words; the amount alone is not evidence"}
        X = pd.DataFrame({"label_raw": [label.lower()], "label_norm": [" ".join(self.norm.tokens(label)) or label.lower()],
                          "section": [(section or "none").lower()],
                          "log_share": [math.log(max(budget_share or 0.005, 1e-6))]})
        p = self.pipe.predict_proba(X)[0]
        i = int(p.argmax())
        conf = float(p[i])
        out = {"category": str(self.pipe.classes_[i]), "confidence": round(conf, 3),
               "probabilities": {str(c): round(float(x), 3) for c, x in zip(self.pipe.classes_, p)},
               "abstained": conf < self.min_conf, "reason": None}
        if out["abstained"]:
            out["reason"] = f"confidence {conf:.2f} below {self.min_conf}"
            out["category"] = None
        return out
