"""Loading loan inputs from a folder of CSV/JSON files and writing reports (JSON, Markdown, Excel)."""
from __future__ import annotations

import csv
import json
from pathlib import Path

from .models import Line, LoanInput
from .money import to_cents, usd


def read_lines(path: Path):
    if not path.exists():
        return None
    out = []
    with path.open(newline="", encoding="utf-8-sig") as f:
        for i, row in enumerate(csv.DictReader(f), start=2):
            row = {k.strip().lower(): (v or "").strip() for k, v in row.items() if k}
            out.append(Line(
                key=row.get("key") or f"{path.stem}-{i}",
                label=row["label"],
                budget=to_cents(row.get("budget")),
                prior=to_cents(row.get("prior")),
                current=to_cents(row.get("current")),
                retainage=to_cents(row.get("retainage")),
                reported_balance=to_cents(row["balance"]) if row.get("balance") else None,
                cost_code=row.get("cost_code") or None,
                category=row.get("category") or None,
                source_ref=f"{path.name}:row {i}",
            ))
    return out


def load_loan(folder) -> LoanInput:
    d = Path(folder)
    meta = json.loads((d / "loan.json").read_text()) if (d / "loan.json").exists() else {}
    approvals = []
    if (d / "approvals.csv").exists():
        with (d / "approvals.csv").open(newline="") as f:
            for r in csv.DictReader(f):
                approvals.append({"approval_ref": r["approval_ref"], "cost_code": r.get("cost_code") or None,
                                  "label": r.get("label") or None, "delta": to_cents(r["delta"])})
    sources = None
    if (d / "sources.csv").exists():
        with (d / "sources.csv").open(newline="") as f:
            sources = [{"source": r["source"], "amount": to_cents(r["amount"])} for r in csv.DictReader(f)]
    mappings = json.loads((d / "mappings.json").read_text()) if (d / "mappings.json").exists() else []
    return LoanInput(
        loan_id=meta.get("loan_id", d.name),
        approved=read_lines(d / "approved.csv"),
        borrower=read_lines(d / "borrower.csv"),
        lob=read_lines(d / "lob_entry.csv"),
        approvals=approvals, sources=sources, mappings=mappings,
    )


def mapping_from_group(group, loan_id: str, mapping_id: str = "") -> dict:
    """What gets saved when a reviewer confirms a match group (line_mapping table)."""
    return {
        "mapping_id": mapping_id, "loan_id": loan_id, "comparison": group.comparison,
        "left": [l.norm_label for l in group.left], "right": [l.norm_label for l in group.right],
        "relation": group.relation,
    }


def to_markdown(rep, cfg) -> str:
    auto = cfg.s("auto_accept_confidence", 0.95)
    lines = [f"# Reconciliation - loan {rep.loan_id}", "",
             f"Can post: **{'YES' if rep.can_post else 'NO'}**  |  exceptions: {rep.counts()}  |  "
             f"engine {rep.engine_version}, config {rep.config_version}", ""]
    if rep.keying:
        lines.append(f"Keying check auto-matched {rep.auto_match_rate('keying', auto):.0%} of borrower lines.")
    lines.append(f"Change check auto-matched {rep.auto_match_rate('change', auto):.0%} of approved lines.")
    lines += ["", "| # | Exception id | Severity | Reason | Impact | Message |", "|---|---|---|---|---|---|"]
    for i, e in enumerate(rep.exceptions, 1):
        lines.append(f"| {i} | {e.exception_id} | {e.severity} | {e.reason_code} | {usd(e.impact_cents)} | {e.message} |")
    ctx = rep.loan_context
    lines += ["", f"Uses {usd(ctx['total_budget'])}, approved {usd(ctx['approved_total'])}, "
                  f"sources {usd(ctx['total_sources']) if ctx.get('total_sources') is not None else 'n/a'}, "
                  f"this draw {usd(ctx['this_draw'])}, hard-cost complete {ctx.get('pct_complete')}%"]
    return "\n".join(lines)


def to_excel(rep, path):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Exceptions"
    head = ["Severity", "Reason code", "Comparison", "Rule", "Impact", "Message", "Suggested action", "Lines"]
    ws.append(head)
    fills = {"BLOCKING": "F8D7DA", "REVIEW": "FFF3CD", "WARNING": "FFF3CD", "INFO": "E2E3E5"}
    for e in rep.exceptions:
        ws.append([e.severity, e.reason_code, e.comparison, e.rule_id or "", e.impact_cents / 100, e.message,
                   (e.suggestion or {}).get("action", ""), ", ".join(e.line_keys)])
        ws.cell(ws.max_row, 1).fill = PatternFill("solid", fgColor=fills[e.severity])
        ws.cell(ws.max_row, 5).number_format = '"$"#,##0.00'
    for res, name in ((rep.keying, "Keying matches"), (rep.change, "Change matches")):
        if res is None:
            continue
        s = wb.create_sheet(name)
        s.append(["Pass", "Relation", "Confidence", "Left lines", "Right lines", "Notes"])
        for g in res.groups:
            s.append([g.pass_name, g.relation, round(g.confidence, 3), "; ".join(l.label for l in g.left),
                      "; ".join(l.label for l in g.right), "; ".join(g.notes)])
        for l in res.unmatched_left:
            s.append(["unmatched", "1:0", 0, l.label, "", ""])
        for l in res.unmatched_right:
            s.append(["unmatched", "0:1", 0, "", l.label, ""])
    s = wb.create_sheet("Proposed budget")
    s.append(["Key", "Label", "Cost code", "Category", "Budget", "Prior", "Current", "Balance"])
    for l in rep.proposed_budget:
        s.append([l.key, l.label, l.cost_code, l.category, l.budget / 100, l.prior / 100, l.current / 100, l.balance / 100])
        for c in range(5, 9):
            s.cell(s.max_row, c).number_format = '"$"#,##0.00'
    for sheet in wb.worksheets:
        for c in sheet[1]:
            c.font = Font(bold=True)
        for col in sheet.columns:
            width = min(80, max(len(str(c.value or "")) for c in col) + 2)
            sheet.column_dimensions[col[0].column_letter].width = width
    wb.save(path)
