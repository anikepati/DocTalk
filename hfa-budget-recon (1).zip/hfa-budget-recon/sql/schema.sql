-- PostgreSQL schema for the reconciliation engine. Business tables are append-only; config is versioned.

CREATE TABLE loan (
    loan_id        text PRIMARY KEY,
    developer_id   text,
    hfa_program    text,
    status         text NOT NULL DEFAULT 'CONSTRUCTION'
);

CREATE TABLE budget_version (
    version_id     bigserial PRIMARY KEY,
    loan_id        text NOT NULL REFERENCES loan,
    version_no     int  NOT NULL,
    source         text NOT NULL CHECK (source IN ('BOOTSTRAP','RESTRUCTURE','DRAW')),
    change_ref     text,                       -- change_set_id or draw-N
    draw_no        int,                        -- last posted draw as of this version
    total_sources_cents bigint,
    effective_at   timestamptz NOT NULL DEFAULT now(),
    approved_by    text,
    recon_run_id   bigint,
    UNIQUE (loan_id, version_no)
);

-- Ledger: one row per line per version (append-only). line_id is STABLE across versions.
CREATE TABLE budget_line (
    version_id      bigint NOT NULL REFERENCES budget_version,
    line_id         text   NOT NULL,           -- e.g. HFA-1001-L0021, never reused
    label           text   NOT NULL,
    cost_code       text,
    category        text   NOT NULL,
    status          text   NOT NULL CHECK (status IN ('ACTIVE','CLOSED','RETIRED')),
    budget_cents    bigint NOT NULL CHECK (budget_cents >= 0),
    drawn_cents     bigint NOT NULL DEFAULT 0 CHECK (drawn_cents >= 0),
    retainage_cents bigint NOT NULL DEFAULT 0,
    aliases         text[] NOT NULL DEFAULT '{}',   -- normalized borrower/LOB labels meaning this line
    group_aliases   text[] NOT NULL DEFAULT '{}',   -- labels meaning a group of lines (keep_system_detail)
    lineage         text[] NOT NULL DEFAULT '{}',   -- parent line_ids (split / merge / create)
    created_in_version int NOT NULL,
    PRIMARY KEY (version_id, line_id),
    CHECK (status <> 'ACTIVE'  OR budget_cents >= drawn_cents),
    CHECK (status <> 'CLOSED'  OR budget_cents  = drawn_cents),
    CHECK (status <> 'RETIRED' OR (budget_cents = 0 AND drawn_cents = 0))
);
CREATE INDEX budget_line_alias ON budget_line USING gin (aliases);

-- Restructuring ("retro") change sets: maker-checker, idempotent, linked to the version they produced
CREATE TABLE change_set (
    change_set_id     text PRIMARY KEY,         -- hash of loan, base version and ops
    loan_id           text NOT NULL REFERENCES loan,
    base_version      int  NOT NULL,
    status            text NOT NULL CHECK (status IN ('DRAFT','SUBMITTED','APPROVED','COMMITTED','REJECTED','NOT_NEEDED')),
    maker             text,
    checker           text CHECK (checker IS NULL OR checker <> maker),
    open_issues       jsonb NOT NULL DEFAULT '[]',
    overrides         jsonb NOT NULL DEFAULT '[]',
    committed_version int,
    created_at        timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE change_set_op (
    change_set_id   text NOT NULL REFERENCES change_set,
    seq             int  NOT NULL,
    kind            text NOT NULL,              -- SPLIT, MERGE, CREATE, REALLOCATE, FUNDING_CHANGE, RECLASS_DRAWS, ...
    params          jsonb NOT NULL,
    reason          text,
    approval_ref    text,                       -- change order / reallocation memo / wire reference
    PRIMARY KEY (change_set_id, seq)
);

-- Posted draws, by ledger line
CREATE TABLE draw_posting (
    loan_id         text NOT NULL REFERENCES loan,
    draw_no         int  NOT NULL,
    based_on_version int NOT NULL,
    posted_version  int  NOT NULL,
    line_id         text NOT NULL,
    borrower_key    text NOT NULL,
    amount_cents    bigint NOT NULL,
    retainage_cents bigint NOT NULL DEFAULT 0,
    PRIMARY KEY (loan_id, draw_no, line_id)
);

-- Transactional outbox: events published to Kafka by a relay (exactly-once from the DB's view)
CREATE TABLE outbox_event (
    event_id        bigserial PRIMARY KEY,
    loan_id         text NOT NULL,
    event_type      text NOT NULL,              -- recon.completed, restructure.committed, draw.posted, ...
    payload         jsonb NOT NULL,
    created_at      timestamptz NOT NULL DEFAULT now(),
    published_at    timestamptz
);

CREATE TABLE submission (
    submission_id   bigserial PRIMARY KEY,
    loan_id         text NOT NULL REFERENCES loan,
    draw_no         int,
    submission_hash text NOT NULL UNIQUE,       -- idempotency: same file never posts twice
    received_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE submission_line (
    submission_id   bigint NOT NULL REFERENCES submission,
    side            text   NOT NULL CHECK (side IN ('BORROWER','LOB')),
    line_key        text   NOT NULL,
    raw_label       text   NOT NULL,
    norm_label      text,
    cost_code       text,
    category        text,
    budget_cents    bigint NOT NULL,
    prior_cents     bigint NOT NULL DEFAULT 0,
    current_cents   bigint NOT NULL DEFAULT 0,
    retainage_cents bigint NOT NULL DEFAULT 0,
    reported_balance_cents bigint,
    source_ref      text,                       -- file, sheet, cell / page
    PRIMARY KEY (submission_id, side, line_key)
);

CREATE TABLE recon_run (
    run_id          bigserial PRIMARY KEY,
    submission_id   bigint NOT NULL REFERENCES submission,
    engine_version  text NOT NULL,
    config_version  text NOT NULL,
    can_post        boolean NOT NULL,
    report_json     jsonb NOT NULL,
    run_at          timestamptz NOT NULL DEFAULT now(),
    UNIQUE (submission_id, engine_version, config_version)
);

CREATE TABLE match_group (
    group_id        bigserial PRIMARY KEY,
    run_id          bigint NOT NULL REFERENCES recon_run,
    comparison      text NOT NULL CHECK (comparison IN ('keying','change')),
    relation        text NOT NULL,
    pass_name       text NOT NULL,
    confidence      numeric(4,3) NOT NULL,
    left_keys       text[] NOT NULL,
    right_keys      text[] NOT NULL,
    notes           text[]
);

CREATE TABLE line_mapping (                    -- the learning loop
    mapping_id      bigserial PRIMARY KEY,
    scope           text NOT NULL CHECK (scope IN ('LOAN','DEVELOPER','GLOBAL')),
    scope_id        text NOT NULL,
    comparison      text NOT NULL,
    left_labels     text[] NOT NULL,           -- normalized labels
    right_labels    text[] NOT NULL,
    relation        text NOT NULL,
    confirmed_by    text NOT NULL,
    confirmed_at    timestamptz NOT NULL DEFAULT now(),
    retired_at      timestamptz
);
CREATE INDEX line_mapping_scope ON line_mapping (scope, scope_id, comparison) WHERE retired_at IS NULL;

CREATE TABLE reallocation_approval (
    approval_ref    text NOT NULL,
    loan_id         text NOT NULL REFERENCES loan,
    cost_code       text,
    label           text,
    delta_cents     bigint NOT NULL,
    approved_at     timestamptz NOT NULL,
    document_ref    text                        -- memo / change order in FileNet
);

CREATE TABLE recon_exception (
    exception_id    bigserial PRIMARY KEY,
    run_id          bigint NOT NULL REFERENCES recon_run,
    reason_code     text NOT NULL,
    severity        text NOT NULL CHECK (severity IN ('BLOCKING','REVIEW','WARNING','INFO')),
    comparison      text NOT NULL,
    rule_id         text,
    impact_cents    bigint NOT NULL DEFAULT 0,
    line_keys       text[],
    evidence        jsonb,
    suggestion      jsonb,
    status          text NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','ACCEPTED','CORRECTED','REJECTED')),
    resolved_by     text,
    resolved_at     timestamptz,
    resolution      jsonb
);
CREATE INDEX recon_exception_open ON recon_exception (severity, impact_cents DESC) WHERE status = 'OPEN';

-- Versioned configuration (mirrors config/*.json)
CREATE TABLE cfg_document (
    name            text NOT NULL,              -- settings | abbreviations | cost_codes | rules
    version         int  NOT NULL,
    body            jsonb NOT NULL,
    active_from     timestamptz NOT NULL,
    approved_by     text NOT NULL,
    PRIMARY KEY (name, version)
);
