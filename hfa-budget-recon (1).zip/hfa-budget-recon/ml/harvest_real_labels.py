"""Harvest REAL training labels from your own files, at no labeling cost.

Borrower draw files group lines under section headings (HARD COSTS, SOFT COSTS, ...). Each line under a heading
becomes a labeled example. SOR exports with a category column add more. Where both sources have the same line,
agreeing labels are kept and disagreements are written to a separate file for a person to adjudicate. Those
disagreements are the most valuable examples you have.

    python ml/harvest_real_labels.py --borrower-dir /data/draws --sor-dir /data/sor_exports --out ml/data/real
Then train on real + synthetic:
    python ml/train.py --extra ml/data/real/real_line_items.csv
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from budget_recon.config import load_config  # noqa: E402
from budget_recon.extract import ExcelExtractor  # noqa: E402
from budget_recon.io import read_lines  # noqa: E402
from budget_recon.normalize import Normalizer  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--borrower-dir", required=True)
    ap.add_argument("--sor-dir")
    ap.add_argument("--out", default=str(ROOT / "ml/data/real"))
    a = ap.parse_args()
    norm = Normalizer(load_config())
    rows, by_norm = [], {}
    for f in sorted(Path(a.borrower_dir).rglob("*.xls*")):
        ext = ExcelExtractor().extract(f)
        if ext.blocking:
            continue  # only files that foot
        total = sum(l.budget for l in ext.lines) or 1
        dev = ext.meta.get("loan_id", f.stem)
        for l in ext.lines:
            if not l.category:
                continue  # no heading above it: no free label
            r = {"developer": dev, "budget": f.stem, "label": l.label, "section": "", "budget_share": l.budget / total,
                 "category": l.category, "canonical": "", "source": f"borrower:{f.name}"}
            rows.append(r)
            by_norm.setdefault(" ".join(norm.tokens(l.label)), set()).add(l.category)
    conflicts = []
    for f in sorted(Path(a.sor_dir).rglob("*.csv")) if a.sor_dir else []:
        lines = read_lines(f) or []
        total = sum(l.budget for l in lines) or 1
        for l in lines:
            if not l.category:
                continue
            key = " ".join(norm.tokens(l.label))
            seen = by_norm.get(key)
            r = {"developer": f.stem, "budget": f.stem, "label": l.label, "section": "", "budget_share": l.budget / total,
                 "category": l.category.upper(), "canonical": "", "source": f"sor:{f.name}"}
            if seen and r["category"] not in seen:
                conflicts.append({**r, "borrower_categories": "|".join(sorted(seen))})
            else:
                rows.append(r)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    fields = ["developer", "budget", "label", "section", "budget_share", "category", "canonical", "source"]
    with open(out / "real_line_items.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    with open(out / "conflicts_to_adjudicate.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields + ["borrower_categories"])
        w.writeheader()
        w.writerows(conflicts)
    print(f"{len(rows)} labeled rows ({len({r['label'].lower() for r in rows})} distinct labels); "
          f"{len(conflicts)} conflicts to adjudicate")


if __name__ == "__main__":
    main()
