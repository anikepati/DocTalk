"""Train and evaluate the line-item category model.

Model: TF-IDF character 2-5-grams on the raw label + word 1-2-grams on the engine's normalized label + section
heading words + log budget share -> multinomial logistic regression (balanced classes). Calibrated enough to
abstain: lines below the confidence threshold go to review instead of being guessed.

Three honest tests (never a random row split, which leaks a developer's style into the test set):
  1. unseen developers   20% of developer styles held out entirely
  2. unseen items        ~15% of budget items (all their phrasings) held out entirely: does it generalize to
                         vocabulary it has never seen?
  3. sample files        labels from this repo's sample borrower files and SOR exports (not synthetic, though
                         written by the same author: treat as a sanity check, not proof)

    python ml/train.py            # writes ml/model/category_model.joblib and ml/model/metrics.json
"""
from __future__ import annotations

import csv
import json
import math
import random
import sys
from pathlib import Path

import joblib
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from budget_recon.config import load_config  # noqa: E402
from budget_recon.normalize import Normalizer  # noqa: E402

CLASSES = ["ACQUISITION", "HARD", "SOFT", "OTHER"]
AMBIGUOUS_WORDS = ("contingency", "closing", "title", "insurance", "fee", "interest", "reserve", "bond", "environmental")
NORM = Normalizer(load_config())


def features(rows):
    return {
        "label_raw": [r["label"].lower() for r in rows],
        "label_norm": [" ".join(NORM.tokens(r["label"])) or r["label"].lower() for r in rows],
        "section": [(r.get("section") or "none").lower() for r in rows],
        "log_share": [[math.log(max(float(r.get("budget_share") or 1e-4), 1e-6))] for r in rows],
    }


class Frame(dict):
    """Minimal column container so ColumnTransformer can select by name without pandas."""

    def __getitem__(self, k):
        v = dict.__getitem__(self, k) if isinstance(k, str) else None
        if isinstance(k, list):
            return np.array([x[0] for x in dict.__getitem__(self, k[0])]).reshape(-1, 1)
        return v


def to_frame(rows):
    import pandas as pd
    f = features(rows)
    return pd.DataFrame({"label_raw": f["label_raw"], "label_norm": f["label_norm"], "section": f["section"],
                         "log_share": [x[0] for x in f["log_share"]]})


def build(use_context=True):
    parts = [("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(2, 5), min_df=2, sublinear_tf=True), "label_raw"),
             ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True), "label_norm")]
    if use_context:
        parts += [("section", TfidfVectorizer(), "section"), ("share", StandardScaler(), ["log_share"])]
    return Pipeline([("features", ColumnTransformer(parts)),
                     ("clf", LogisticRegression(C=4.0, max_iter=4000, class_weight="balanced"))])


def evaluate(model, rows, name):
    X, y = to_frame(rows), [r["category"] for r in rows]
    proba = model.predict_proba(X)
    pred = model.classes_[proba.argmax(1)]
    conf = proba.max(1)
    amb = [i for i, r in enumerate(rows) if any(w in r["label"].lower() for w in AMBIGUOUS_WORDS)]
    curve = []
    for t in (0.0, 0.6, 0.7, 0.8, 0.9, 0.95):
        keep = conf >= t
        curve.append({"threshold": t, "coverage": round(float(keep.mean()), 4),
                      "accuracy_on_covered": round(float((pred[keep] == np.array(y)[keep]).mean()), 4) if keep.any() else None})
    return {
        "set": name, "rows": len(rows),
        "accuracy": round(accuracy_score(y, pred), 4), "macro_f1": round(f1_score(y, pred, average="macro"), 4),
        "ambiguous_word_rows": len(amb),
        "ambiguous_word_accuracy": round(float(np.mean([pred[i] == y[i] for i in amb])), 4) if amb else None,
        "per_class": classification_report(y, pred, labels=CLASSES, output_dict=True, zero_division=0),
        "confusion": {"labels": CLASSES, "matrix": confusion_matrix(y, pred, labels=CLASSES).tolist()},
        "abstain_curve": curve,
        "errors": [{"label": rows[i]["label"], "section": rows[i].get("section", ""), "true": y[i], "pred": pred[i],
                    "confidence": round(float(conf[i]), 3)} for i in range(len(rows)) if pred[i] != y[i]][:25],
    }


def sample_file_rows():
    """Labels from the repo's sample borrower files and SOR exports, with known categories."""
    from budget_recon.extract import ExcelExtractor
    from budget_recon.io import read_lines
    rows = []
    for f in ("sample/inbox/HFA-1001_draw07.xlsx", "sample/inbox/HFA-2001_draw19.xlsx"):
        lines = ExcelExtractor().extract(ROOT / f).lines
        total = sum(l.budget for l in lines)
        sec = {"ACQUISITION": "ACQUISITION COSTS", "HARD": "HARD COSTS", "SOFT": "SOFT COSTS", "OTHER": "RESERVES"}
        rows += [{"label": l.label, "section": sec[l.category], "budget_share": l.budget / total, "category": l.category}
                 for l in lines]
    sor = read_lines(ROOT / "sample/onboarding_d18/HFA-2001_sor_export_after_draw18.csv")
    total = sum(l.budget for l in sor)
    truth = {"S30": "SOFT", "S20": "SOFT", "S21": "SOFT", "S15": "SOFT", "S29": "SOFT"}  # misfiled / generic lines
    for l in sor:  # SOR rows carry no section heading: the label and amount must do the work
        rows.append({"label": l.label, "section": "", "budget_share": l.budget / total,
                     "category": truth.get(l.key, l.category)})
    return rows


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--extra", action="append", default=[], help="additional labeled CSVs (e.g. harvested real labels)")
    a = ap.parse_args()
    rows = list(csv.DictReader(open(ROOT / "ml/data/synthetic_line_items.csv")))
    for f in a.extra:
        extra = list(csv.DictReader(open(f)))
        for r in extra:
            r.setdefault("canonical", "")
            r["canonical"] = r["canonical"] or ("real:" + r["label"].lower())
        rows += extra
        print(f"added {len(extra)} rows from {f}")
    report = {}

    # 1) unseen developers
    groups = [r["developer"] for r in rows]
    tr, te = next(GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=0).split(rows, groups=groups))
    train, test = [rows[i] for i in tr], [rows[i] for i in te]
    for ctx in (False, True):
        m = build(ctx).fit(to_frame(train), [r["category"] for r in train])
        report[f"unseen_developers{'_with_context' if ctx else '_text_only'}"] = evaluate(m, test, "unseen developers")

    # 2) unseen items: whole canonical items held out, stratified by class
    rng = random.Random(1)
    by_cat = {}
    for r in rows:
        by_cat.setdefault(r["category"], set()).add(r["canonical"])
    held = {c for cat, items in by_cat.items() for c in rng.sample(sorted(items), max(1, round(len(items) * 0.15)))}
    train2 = [r for r in rows if r["canonical"] not in held]
    test2 = [r for r in rows if r["canonical"] in held]
    m2 = build(True).fit(to_frame(train2), [r["category"] for r in train2])
    report["unseen_items"] = evaluate(m2, test2, "unseen items: " + ", ".join(sorted(held)))

    # final model on everything, then the sample-file sanity check
    final = build(True).fit(to_frame(rows), [r["category"] for r in rows])
    report["sample_files"] = evaluate(final, sample_file_rows(), "sample borrower files and SOR exports")

    out = ROOT / "ml/model"
    out.mkdir(parents=True, exist_ok=True)
    joblib.dump({"pipeline": final, "classes": list(final.classes_), "trained_rows": len(rows),
                 "version": "category-model-0.1"}, out / "category_model.joblib")
    (out / "metrics.json").write_text(json.dumps(report, indent=1, default=str))
    for k, v in report.items():
        cov = {c["threshold"]: (c["coverage"], c["accuracy_on_covered"]) for c in v["abstain_curve"]}
        print(f"{k:<32} n={v['rows']:<6} acc={v['accuracy']:.3f} macroF1={v['macro_f1']:.3f} "
              f"ambiguous={v['ambiguous_word_accuracy']} @0.9 cov/acc={cov[0.9]}")


if __name__ == "__main__":
    main()
