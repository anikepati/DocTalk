"""Synthetic training data for budget-line categorization (ACQUISITION / HARD / SOFT / OTHER).

Each synthetic "developer" has its own writing style (case, separators, abbreviation and typo habits, numbering,
CSI division codes, notes) and produces one to three budgets. A budget is a realistic mix of items, each rendered
as a free-form label with context: the section heading it sits under (when the file has sections) and its share
of the total budget.

The hard cases are generated on purpose:
  * ambiguous words whose category depends on a qualifier or the section: contingency, closing costs, title,
    insurance, fees, bond, environmental, interest vs. reserve
  * combined lines ("A&E / Survey"), vendor names, change-order notes, typos, abbreviations
  * a small rate of lines placed under the wrong section heading (noise in the context, not in the label)

Ground truth is the category of the underlying item, never the heading. All of it is invented.

    python ml/synth.py --developers 600 --seed 7 --out ml/data
"""
from __future__ import annotations

import argparse
import csv
import math
import random
from pathlib import Path

# (canonical item, alternative phrasings, typical share of total development cost (low, high))
VOCAB = {
    "ACQUISITION": [
        ("Land", ["Land acquisition", "Land purchase", "Site acquisition", "Purchase price - land", "Land cost"], (0.04, 0.15)),
        ("Building acquisition", ["Existing building purchase", "Acquisition of improvements", "Building purchase price"], (0.05, 0.25)),
        ("Acquisition closing costs", ["Closing costs - acquisition", "Acquisition closing", "Purchase closing costs"], (0.002, 0.01)),
        ("Transfer taxes", ["Real estate transfer tax", "Deed transfer tax", "Recordation tax - acquisition"], (0.001, 0.008)),
        ("Brokerage commission", ["Broker fee - land", "Acquisition broker commission", "Real estate commission"], (0.002, 0.01)),
        ("Title insurance - acquisition", ["Owner's title policy", "Title - land purchase"], (0.001, 0.004)),
        ("Extension payments", ["Option extension fees", "Purchase option payments"], (0.0005, 0.004)),
        ("Holding costs", ["Carrying costs - land", "Pre-closing holding costs"], (0.001, 0.006)),
    ],
    "HARD": [
        ("Sitework", ["Site work", "Site improvements", "Site development", "Earthwork", "Grading and excavation"], (0.02, 0.07)),
        ("Demolition", ["Demo", "Building demolition", "Selective demolition"], (0.003, 0.02)),
        ("Environmental remediation", ["Asbestos abatement", "Lead paint abatement", "Soil remediation", "Hazmat abatement"], (0.002, 0.02)),
        ("Concrete", ["Cast-in-place concrete", "Foundations", "Concrete slabs"], (0.04, 0.10)),
        ("Masonry", ["Brick veneer", "CMU walls", "Masonry work"], (0.01, 0.04)),
        ("Metals", ["Structural steel", "Misc metals", "Steel framing"], (0.01, 0.05)),
        ("Rough carpentry", ["Framing", "Wood framing", "Rough framing"], (0.06, 0.14)),
        ("Finish carpentry", ["Millwork", "Trim carpentry", "Cabinets and countertops", "Casework"], (0.01, 0.04)),
        ("Roofing", ["Roof", "Roofing and sheet metal", "Membrane roofing"], (0.01, 0.03)),
        ("Waterproofing", ["Thermal and moisture protection", "Insulation", "Sealants and caulking"], (0.005, 0.02)),
        ("Doors and windows", ["Openings", "Windows", "Doors, frames and hardware", "Storefront"], (0.02, 0.05)),
        ("Drywall", ["Gypsum board", "Drywall and acoustical", "Interior partitions"], (0.03, 0.06)),
        ("Flooring", ["Floor coverings", "LVT and carpet", "Resilient flooring"], (0.01, 0.03)),
        ("Painting", ["Paint and wall coverings", "Interior painting"], (0.007, 0.02)),
        ("Specialties", ["Toilet accessories", "Signage", "Mailboxes", "Fire extinguishers"], (0.002, 0.008)),
        ("Appliances", ["Residential appliances", "Unit appliances", "Kitchen appliances"], (0.006, 0.02)),
        ("Elevators", ["Conveying systems", "Elevator installation"], (0.01, 0.03)),
        ("Fire sprinklers", ["Fire protection", "Sprinkler system", "Fire suppression"], (0.008, 0.02)),
        ("Plumbing", ["Plumbing and domestic water", "Plumbing fixtures"], (0.04, 0.08)),
        ("HVAC", ["Mechanical", "Heating and air conditioning", "Mechanical HVAC"], (0.04, 0.09)),
        ("Electrical", ["Electrical systems", "Power and lighting", "Electric"], (0.04, 0.09)),
        ("Low voltage", ["Telecom and data", "Security and access control", "Fire alarm"], (0.005, 0.02)),
        ("Site utilities", ["Water and sewer laterals", "Storm drainage", "Utility connections - site"], (0.005, 0.02)),
        ("Paving", ["Asphalt paving", "Parking lot", "Curbs and sidewalks"], (0.005, 0.02)),
        ("Landscaping", ["Landscape and irrigation", "Hardscape", "Plantings"], (0.003, 0.012)),
        ("Off-site improvements", ["Offsite work", "Public right-of-way improvements", "Street improvements"], (0.002, 0.015)),
        ("General requirements", ["General conditions", "GC general conditions", "Site supervision"], (0.03, 0.07)),
        ("General contractor overhead and profit", ["GC fee", "Contractor overhead", "Contractor profit", "Builder's profit"], (0.03, 0.07)),
        ("Payment and performance bond", ["P&P bond", "Contractor bond", "Performance bond premium"], (0.005, 0.012)),
        ("GC insurance", ["Contractor's general liability", "GC liability insurance"], (0.004, 0.01)),
        ("Hard cost contingency", ["Construction contingency", "Hard contingency", "Owner's construction contingency"], (0.02, 0.06)),
        ("Furniture fixtures and equipment", ["FF&E", "Common area furniture", "Furnishings"], (0.002, 0.01)),
        ("Solar PV system", ["Photovoltaic system", "Rooftop solar", "Renewable energy system"], (0.003, 0.015)),
    ],
    "SOFT": [
        ("Architect", ["Architectural fees", "Architecture and design", "Design architect"], (0.02, 0.05)),
        ("Architect construction administration", ["Architect CA", "Construction administration - architect"], (0.003, 0.01)),
        ("Civil engineering", ["Civil engineer", "Site civil design"], (0.003, 0.01)),
        ("Structural engineering", ["Structural engineer"], (0.002, 0.008)),
        ("MEP engineering", ["Mechanical electrical plumbing engineering", "MEP design"], (0.003, 0.01)),
        ("Survey", ["ALTA survey", "Boundary and topographic survey", "Surveying"], (0.0005, 0.002)),
        ("Geotechnical report", ["Soils report", "Geotech", "Geotechnical engineering"], (0.0005, 0.002)),
        ("Phase I environmental", ["Phase I ESA", "Environmental site assessment", "Environmental report"], (0.0003, 0.002)),
        ("Appraisal", ["Appraisal report", "Appraisal fee"], (0.0003, 0.0015)),
        ("Market study", ["Market analysis", "Market feasibility study"], (0.0003, 0.0015)),
        ("Legal", ["Attorney fees", "Borrower legal", "Legal counsel", "Lender legal"], (0.004, 0.012)),
        ("Title and recording", ["Title and recording - construction loan", "Recording fees", "Lender's title policy"], (0.001, 0.005)),
        ("Builder's risk insurance", ["Builders risk", "Course of construction insurance", "Property insurance during construction"], (0.004, 0.01)),
        ("Real estate taxes during construction", ["Property taxes - construction period", "RE taxes"], (0.002, 0.008)),
        ("Construction interest", ["Construction loan interest", "Interest reserve", "Construction period interest",
                                   "Capitalized interest"], (0.03, 0.07)),
        ("Construction loan fees", ["Loan origination fee", "Lender fees", "Construction loan closing costs", "Loan closing costs"], (0.004, 0.012)),
        ("Bond issuance costs", ["Cost of issuance", "Bond counsel", "Issuer fees"], (0.005, 0.015)),
        ("Tax credit fees", ["LIHTC allocation fee", "HFA fees", "Compliance monitoring fee", "Tax credit application fee"], (0.002, 0.008)),
        ("Syndication costs", ["Investor legal and syndication", "Equity bridge costs"], (0.001, 0.005)),
        ("Developer fee", ["Developer overhead", "Development fee", "Deferred developer fee"], (0.06, 0.12)),
        ("Development consultant", ["Owner's representative", "Owner's rep", "Project management"], (0.003, 0.01)),
        ("Permits", ["Building permits", "Permit fees", "Plan review fees"], (0.003, 0.012)),
        ("Impact fees", ["Development impact fees", "School impact fees", "Park fees"], (0.004, 0.02)),
        ("Utility tap fees", ["Water and sewer tap fees", "Utility connection fees", "Meter fees"], (0.002, 0.008)),
        ("Marketing and lease-up", ["Marketing", "Lease-up costs", "Advertising and marketing"], (0.001, 0.005)),
        ("Accounting and cost certification", ["Cost certification", "Audit", "Accounting"], (0.0005, 0.002)),
        ("Soft cost contingency", ["Soft contingency", "Owner's soft contingency"], (0.005, 0.02)),
        ("Relocation", ["Tenant relocation", "Relocation costs"], (0.002, 0.01)),
        ("Third-party inspections", ["Construction inspections", "Lender's inspector", "Special inspections"], (0.0005, 0.003)),
        ("Utilities during construction", ["Temporary utilities - owner", "Construction utilities"], (0.0005, 0.003)),
    ],
    "OTHER": [
        ("Operating reserve", ["Operating deficit reserve", "Operating reserve escrow"], (0.008, 0.03)),
        ("Replacement reserve", ["Capital replacement reserve", "Reserve for replacements"], (0.002, 0.01)),
        ("Lease-up reserve", ["Rent-up reserve", "Lease up reserve"], (0.003, 0.012)),
        ("Debt service reserve", ["DSRF", "Debt service reserve fund"], (0.005, 0.02)),
        ("Tax and insurance escrow", ["Tax and insurance reserve", "Escrows - taxes and insurance"], (0.001, 0.005)),
        ("Social services reserve", ["Resident services reserve", "Supportive services reserve"], (0.002, 0.01)),
    ],
}

# deliberately ambiguous bare labels: category comes only from the section / budget-share context
AMBIGUOUS = {
    "Contingency": ["HARD", "SOFT"],
    "Closing costs": ["ACQUISITION", "SOFT"],
    "Title": ["ACQUISITION", "SOFT"],
    "Insurance": ["HARD", "SOFT"],
    "Fees": ["SOFT", "HARD"],
}

HEADINGS = {
    "ACQUISITION": ["ACQUISITION COSTS", "Land & Acquisition", "ACQUISITION", "Purchase Costs"],
    "HARD": ["HARD COSTS", "Construction Costs", "HARD CONSTRUCTION COSTS", "Direct Costs"],
    "SOFT": ["SOFT COSTS", "Indirect Costs", "SOFT / INDIRECT COSTS", "Professional Fees & Soft Costs"],
    "OTHER": ["RESERVES", "Reserves & Escrows", "OTHER COSTS", "Capitalized Reserves"],
}

ABBREV = {
    "construction": ["constr", "const", "cnstr"], "building": ["bldg"], "contingency": ["contg", "cont", "conting"],
    "insurance": ["ins", "insur"], "engineering": ["eng", "engr"], "engineer": ["engr"], "architect": ["arch", "archt"],
    "architectural": ["arch"], "environmental": ["env", "enviro"], "general": ["gen"], "contractor": ["contr"],
    "overhead": ["OH"], "profit": ["P"], "interest": ["int"], "reserve": ["res", "rsv"], "developer": ["dev"],
    "development": ["dev"], "marketing": ["mktg"], "acquisition": ["acq", "acqn"], "replacement": ["repl"],
    "operating": ["op", "oper"], "electrical": ["elec"], "mechanical": ["mech"], "plumbing": ["plumb"],
    "survey": ["srvy"], "permits": ["pmts"], "professional": ["prof"], "services": ["svcs"],
    "management": ["mgmt"], "equipment": ["equip"], "improvements": ["impr", "imps"], "utilities": ["utils"],
    "doors": ["drs"], "windows": ["wndws"], "landscaping": ["landscp"], "carpentry": ["carp"],
    "requirements": ["reqs"], "consultant": ["consult"], "accounting": ["acctg"], "taxes": ["tx"],
    "and": ["&", "/", "+"], "certification": ["cert"], "assessment": ["assmt"], "inspections": ["insp"],
    "fees": ["fee"], "estate": ["est"], "real": ["RE"], "system": ["sys"], "systems": ["sys"],
}
NOTES = [" - per CO #{n}", " (rev {m}/{d})", " (allowance)", " - Bldg {b}", " Phase {p}", " incl. tax", " (see memo)",
         " - {vendor}", " (revised)", " - CO{n}", " per draw {n}", " (owner)"]
VENDORS = ["ABC Electric", "Smith Plumbing", "Acme Roofing", "Delta Mechanical", "Rivera Law", "Kim & Associates",
           "Northstar Engineering", "Summit Surveying", "Apex Concrete", "BlueLine Title"]
CSI = {"Concrete": "03", "Masonry": "04", "Metals": "05", "Rough carpentry": "06", "Finish carpentry": "06",
       "Roofing": "07", "Waterproofing": "07", "Doors and windows": "08", "Drywall": "09", "Flooring": "09",
       "Painting": "09", "Specialties": "10", "Appliances": "11", "Elevators": "14", "Fire sprinklers": "21",
       "Plumbing": "22", "HVAC": "23", "Electrical": "26", "Low voltage": "27", "Sitework": "31", "Paving": "32",
       "Landscaping": "32", "Site utilities": "33"}
KEYBOARD = "qwertyuiopasdfghjklzxcvbnm"


def typo(word, rng):
    if len(word) < 4 or not word.isalpha():
        return word
    i = rng.randrange(1, len(word) - 1)
    kind = rng.choice(["del", "ins", "sub", "swap"])
    if kind == "del":
        return word[:i] + word[i + 1:]
    if kind == "ins":
        return word[:i] + word[i] + word[i:]
    if kind == "sub":
        k = KEYBOARD.find(word[i].lower())
        near = KEYBOARD[max(0, k - 1):k + 2] if k >= 0 else KEYBOARD
        return word[:i] + rng.choice(near) + word[i + 1:]
    return word[:i] + word[i + 1] + word[i] + word[i + 2:]


class Style:
    """One developer's (or LOB keyer's) writing habits."""

    def __init__(self, rng):
        self.case = rng.choice(["title", "upper", "lower", "asis", "asis"])
        self.abbrev = rng.choice([0.0, 0.1, 0.3, 0.6])
        self.typo = rng.choice([0.0, 0.0, 0.02, 0.05, 0.1])
        self.notes = rng.choice([0.0, 0.05, 0.15])
        self.numbering = rng.choice(["none", "none", "dot", "csi", "item"])
        self.combine = rng.choice([0.0, 0.03, 0.08])
        self.tag_prefix = rng.random() < 0.06  # e.g. "HC - Concrete": rare but real
        self.has_sections = rng.random() < 0.75
        self.wrong_heading = rng.choice([0.0, 0.0, 0.03])
        self.phrasing = rng.random()  # preference for canonical vs alternative phrasing
        self.ambiguous = rng.choice([0.0, 0.03, 0.08])


def render(text, style, rng, n):
    words = []
    for w in text.replace(",", "").split():
        lw = w.lower()
        if lw in ABBREV and rng.random() < style.abbrev:
            w = rng.choice(ABBREV[lw])
        elif rng.random() < style.typo:
            w = typo(w, rng)
        words.append(w)
    s = " ".join(words)
    if rng.random() < style.notes:
        s += rng.choice(NOTES).format(n=rng.randint(1, 30), m=rng.randint(1, 12), d=rng.randint(1, 28),
                                      b=rng.choice("ABC"), p=rng.randint(1, 3), vendor=rng.choice(VENDORS))
    s = {"title": s.title(), "upper": s.upper(), "lower": s.lower(), "asis": s}[style.case]
    if style.numbering == "dot":
        s = f"{n}. {s}"
    elif style.numbering == "item":
        s = f"{n:02d} {s}"
    return s


def make_budget(style, rng):
    picks = []
    for cat, items in VOCAB.items():
        k = {"ACQUISITION": (1, 4), "HARD": (8, 22), "SOFT": (8, 20), "OTHER": (1, 4)}[cat]
        chosen = rng.sample(items, min(len(items), rng.randint(*k)))
        if cat == "ACQUISITION" and not any(c[0] in ("Land", "Building acquisition") for c in chosen):
            chosen.append(items[0])
        picks += [(cat, c) for c in chosen]
    rows = []
    for i, (cat, (canon, alts, (lo, hi))) in enumerate(picks, start=1):
        base = canon if rng.random() < style.phrasing else rng.choice(alts)
        if rng.random() < style.ambiguous:
            amb = [a for a, cats in AMBIGUOUS.items() if cat in cats]
            if amb:
                base = rng.choice(amb)
        if style.numbering == "csi" and canon in CSI:
            base = f"{CSI[canon]} {rng.choice(['00 00', '- '])} {base}".replace("  ", " ")
        if rng.random() < style.combine:
            same = [c for c in VOCAB[cat] if c[0] != canon]
            other = rng.choice(same)
            base = f"{base} {rng.choice(['/', '&', '+', 'and'])} {other[0]}"
        if style.tag_prefix:
            base = f"{ {'HARD': 'HC', 'SOFT': 'SC', 'ACQUISITION': 'ACQ', 'OTHER': 'RES'}[cat]} - {base}"
        share = math.exp(rng.uniform(math.log(lo), math.log(hi)))
        heading = ""
        if style.has_sections:
            hcat = cat if rng.random() >= style.wrong_heading else rng.choice([c for c in HEADINGS if c != cat])
            heading = rng.choice(HEADINGS[hcat])
        rows.append({"label": render(base, style, rng, i), "section": heading, "budget_share": round(share, 6),
                     "category": cat, "canonical": canon})
    return rows


def generate(n_developers=600, seed=7):
    rng = random.Random(seed)
    out = []
    for d in range(n_developers):
        style = Style(rng)
        for b in range(rng.randint(1, 3)):
            for r in make_budget(style, rng):
                out.append({"developer": f"DEV{d:04d}", "budget": f"DEV{d:04d}-B{b}", **r})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--developers", type=int, default=600)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "data"))
    a = ap.parse_args()
    rows = generate(a.developers, a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "synthetic_line_items.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    labels = {r["label"].lower() for r in rows}
    by = {}
    for r in rows:
        by[r["category"]] = by.get(r["category"], 0) + 1
    print(f"{len(rows)} rows, {len(labels)} distinct labels, {len({r['developer'] for r in rows})} developers; by class {by}")


if __name__ == "__main__":
    main()
