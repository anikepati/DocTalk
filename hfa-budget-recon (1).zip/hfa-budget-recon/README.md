# HFA draw validation rule engine (reference implementation)

**Start here.** The core of this package is a deterministic, config-driven rule engine. It validates the
borrower's **latest draw** against the bank's existing line items, which LOB users keyed as free-form text.
It handles:

- **Label variances:** abbreviations (`Drs & Windows`, `GC OH&P / Gen Req`), notes keyed into the label (`Site Work - per CO #2`, `Finishes (rev 9/14)`), case, punctuation and line numbers.
- **Typos in labels:** `Elecrtical`, `Plumbng`, `Masonary`, corrected only when exactly one vocabulary word is one edit away.
- **Summation:** one system line equals several borrower lines, or the reverse. A group must tie on every amount column at once, so round numbers can't fake a match.
- **Typos in amounts:** transposed digits, dropped or extra digits and decimal shifts in system values are flagged as probable keying errors, not budget changes.

```bash
pip install -e ".[test]"
python -m budget_recon validate sample/inbox/HFA-1001_draw07.xlsx \
       --system sample/validation/HFA-1001_system_lines.csv --xlsx validation.xlsx
python -m pytest -q tests/test_validation.py
```

Output: one row per borrower line with status (OK / REVIEW / EXCEPTION), the matched system line(s), the
rule that fired, confidence, how the free-form label was read, and each amount difference classified as
`PROBABLE_SYSTEM_TYPO`, `BUDGET_CHANGE`, `APPROVED_CHANGE`, `PRIOR_MISMATCH` or `NEW_LINE`.

### Rule catalog (`config/match_rules.json`; reorder or disable without code changes)

| Id | Rule | Handles |
|---|---|---|
| M00 | Known alias | Labels confirmed on earlier draws |
| M01 | Confirmed mapping | Groupings a reviewer confirmed on an earlier draw |
| M02 | Same label or cost code, same amounts | Abbreviations, notes and typos, after normalization |
| M03 | Same amounts on every column, label variant | Wording that has nothing in common but identical numbers (sent to review) |
| M04 | Summation: one borrower line = several system lines | The borrower consolidated |
| M05 | Summation: one system line = several borrower lines | The LOB consolidated when keying |
| M06 | Label variant or typo, amounts differ | Then classifies each difference (typo, change, prior mismatch) |

Validation rules R01–R07 (`config/rules.json`) then check overruns, draws on unapproved lines, net
budget change, Sources = Uses and contingency burn.

Structure checks (`structure.py`) run after matching:

- **Category tie-out:** Acquisition, Hard, Soft and Other totals for both budget and paid-to-date.
- **Misfiled lines:** a line in a different category in the SOR than in the borrower file.
- **M:N regrouping:** unmatched lines within a category that add up on both sides.
- **The borrower's previous draw file as a third reference:** tells an SOR keying error from a real budget change, and checks the borrower's own continuity.

## Category model (optional ML fallback)

`ml/` contains:

- `synth.py`: synthetic data generator, 41.5k labeled lines in 600 writing styles
- `train.py`: character n-gram plus context logistic regression
- `harvest_real_labels.py`: free labels from your own files
- `model/category_model.joblib`
- `MODEL_CARD.md`: results and limits

On items it has never seen, the model is 94% accurate, and 99% on the 80% of lines it is confident about.
It abstains on labels with no meaningful words. It fills only categories the rules leave unknown, and only when
enabled in `settings.json`.

## Full process: borrower Excel to a verified SOR update

```bash
S=./store; F=sample/feeds; R=./sor
# onboard a loan mid-project: the SOR export after draw 18, plus the borrower's draw-18 file
python -m budget_recon onboard HFA-2001 sample/onboarding_d18/HFA-2001_sor_export_after_draw18.csv \
       --last-draw 18 --previous sample/onboarding_d18/HFA-2001_draw18.xlsx --store $S --feeds $F --sor $R
python -m budget_recon process sample/inbox/HFA-2001_draw19.xlsx --store $S --feeds $F --sor $R   # opens review tasks
python -m budget_recon tasks --store $S                                                         # the LOB's queue
python -m budget_recon decide HFA-2001 <task_id> approve --user maria --ref CO-22 --store $S --feeds $F --sor $R
python -m budget_recon process sample/inbox/HFA-2001_draw20.xlsx --store $S --feeds $F --sor $R   # straight-through
```

The steps are: read and check → clean labels → match → check structure → classify and apply rules → plan the
fix → route by policy (automatic, or the review queue) → restructure the ledger → post the draw → update the SOR
→ read the SOR back and compare.
`sor.SorAdapter` is the seam to the real SOR (`export`, `apply`). `FileSorAdapter` is a CSV stand-in.

## Scenario catalog

`tests/test_scenarios.py` has one test per scenario id, 63 scenarios in all:

- **A1–A10:** intake and extraction
- **B1–B8:** labels
- **C1–C6:** amounts
- **D1–D9:** structure
- **E1–E4:** category
- **F1–F5:** budget changes
- **G1–G6:** paid-to-date
- **H1–H5:** this draw's request
- **I1–I2:** sources
- **J1–J8:** process and controls, including SOR read-back

The design doc lists each scenario with how it is handled.

**Not covered yet:**

- Paid-to-date and funding order per funding source (Sources is checked as one total)
- M:N regrouping that crosses categories
- Retainage carried in the paid-to-date column

---

The sections below describe the restructuring and workflow modules in more detail.

## Later phases: restructuring and end-to-end processing

A deterministic, config-driven engine for reconciling HFA construction-loan draws. It covers the whole
lifecycle of a draw:

1. **Identify:** find what differs between the borrower's draw file, the LOB's entry and the bank's budget.
2. **Restructure:** turn each difference into a balanced, approved budget change: split, merge, new line, reallocation, draw reclass and so on.
3. **Post:** post the draw against the restructured budget, so the next draw matches line for line.

No LLM is involved in matching or in any decision. LLM extraction of the borrower's Excel or PDF happens
upstream and produces `borrower.csv`.

## Architecture (modules)

| Layer | Module | Responsibility |
|---|---|---|
| Domain: identify | `normalize.py`, `hierarchy.py`, `grouping.py`, `matcher.py`, `typos.py`, `changes.py`, `rules.py`, `engine.py` | Three checks (keying, change, rules) producing match groups and exceptions |
| Domain: ledger | `ledger.py` | Versioned, append-only budget with **stable line ids**, aliases, lineage; repository interface |
| Domain: restructure | `restructure.py` | 13 typed operations, change sets, apply step enforcing invariants I1–I7 |
| Domain: plan | `planner.py` | Turns findings into a balanced change set with exact amounts (case catalog below) |
| Domain: post | `posting.py` | Posts a draw against an aligned ledger; allocates across alias groups |
| Application | `service.py` | identify → plan → submit → approve (maker-checker) → commit → resolve → post; emits events |
| Interfaces | `__main__.py` (CLI), `api.py` (FastAPI) | Thin adapters over the service |
| Config | `config/*.json` | Settings, policies, abbreviations, cost codes, rules (versioned; Postgres `cfg_document`) |
| Storage | `ledger.JsonFileRepository`, `sql/schema.sql` | File store for demos; Postgres schema with the same contract (adapter to be written) |

## Case catalog (each one has a test in `tests/test_restructure.py`)

| # | Situation | Operations produced |
|---|---|---|
| C1 | Approved budget holds a merged line the borrower reports separately | `SPLIT`, with each child's budget **and prior draws** taken from the borrower file |
| C2a | Borrower reports several ledger lines as one (policy `adopt_borrower_structure`) | `MERGE` |
| C2b | Same, policy `keep_system_detail` | `ADD_GROUP_ALIAS`; draws allocated across the group by remaining balance |
| C3 | Wording or abbreviation only | `ADD_ALIAS` / `RELABEL` |
| C4 | New line funded from contingency | `CREATE` + `REALLOCATE` (contingency first, same category first) |
| C5 | New line with new money | `CREATE` + `FUNDING_CHANGE` (Sources updated in the same approval) |
| C6 | New line already carrying prior draws booked elsewhere | `CREATE` + `RECLASS_DRAWS` (total disbursed unchanged) |
| C7 | Borrower dropped a line with no draws | `REALLOCATE` its budget away + `RETIRE` |
| C8 | Borrower dropped a line that has draws | `CLOSE` at budget = drawn (history never erased) + review issue |
| C9 | Prior draws disagree and don't net out (missed or duplicate disbursement record) | `CORRECT_DRAWN`; needs a wire or funding reference |
| C10 | Category changed (e.g. Soft to Hard) | `RECATEGORIZE`; needs approval (eligible basis, source restrictions) |
| C11 | Two groupings fit equally | No guess: open issue blocks approval |
| C12 | Contractor adds a G703 trade line | Nothing: the roll-up absorbs it |

## Run

```bash
pip install -e ".[api,test]"
S=./store
budget-recon plan   sample/loan_1001/draw_07 --store $S --out cs7.json
budget-recon commit cs7.json --store $S --maker ana --checker raj --approval 22=WIRE-2026-0612 --approval 23=CO-14 --approval 24=CO-14
budget-recon plan   sample/loan_1001/draw_07 --store $S          # remaining exceptions, with ids
budget-recon resolve sample/loan_1001/draw_07 --store $S --exception EX-... --action CORRECTED --user ana
budget-recon resolve sample/loan_1001/draw_07 --store $S --exception EX-... --action ADJUST_DRAW --user raj --adjust B27=32000
budget-recon post   sample/loan_1001/draw_07 --store $S
budget-recon plan   sample/loan_1001/draw_08 --store $S          # 100% ledger-alias matches, nothing to restructure
budget-recon post   sample/loan_1001/draw_08 --store $S
uvicorn budget_recon.api:app                                     # same flow over REST
python -m pytest -q                                              # 52 tests
```

Op indexes in the `commit` example are from the sample's plan output. The sample is illustrative and all its figures are invented.

## What is not done yet

- A Postgres repository adapter (the schema is written; the repository interface is fixed).
- An outbox relay to Kafka (events are emitted to an `EventSink`; the outbox table is in the schema).
- Authentication and authorization; mapping maker and checker to authenticated principals.
- Developer-scope and global mappings with retirement on reviewer override.
- M:N regroupings (the borrower regroups several lines into a different set of several lines). These are not recognized as such: they show up as changed, new and removed lines. The plan stays balanced, but a reviewer has to recognize the regrouping and can add manual ops at `submit`.
- Calibrating all thresholds against posted history.
