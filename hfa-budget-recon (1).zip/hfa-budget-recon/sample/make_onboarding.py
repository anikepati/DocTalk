"""Builds the mid-project onboarding scenario (loan HFA-2001, automation starts at draw 19 of 36).

    sample/onboarding_d18/HFA-2001_sor_export_after_draw18.csv   what the SOR holds after 18 hand-keyed draws
    sample/onboarding_d18/HFA-2001_draw18.xlsx                   the borrower's previous file (third reference)
    sample/inbox/HFA-2001_draw19.xlsx                            the borrower's latest file
    sample/feeds/HFA-2001/approvals.csv, sources.csv             reference data

Every distortion below is one catalogued scenario; all figures are invented.
"""
import csv
import shutil
from pathlib import Path

from make_inbox import SECTIONS, num  # noqa: E402  (run from the sample folder or via python sample/...)
from openpyxl import Workbook
from openpyxl.styles import Font

HERE = Path(__file__).resolve().parent
LOAN = "HFA-2001"


def write_xlsx(rows, out, draw_no, period):
    wb = Workbook()
    ws = wb.active
    ws.title = "G703"
    for t in ("Maple Court Apartments - Continuation Sheet", f"Loan No: {LOAN}", f"Application No: {draw_no}",
              f"Period To: {period}", ""):
        ws.append([t] if t else [])
    ws.append(["Item No", "Description of Work", "Scheduled Value", "From Previous Application", "This Period",
               "Balance to Finish", "Retainage"])
    for c in ws[6]:
        c.font = Font(bold=True)
    grand = [0.0] * 4
    for title, keys in SECTIONS:
        ws.append([None, title])
        sub = [0.0] * 4
        for k in keys:
            if k not in rows:
                continue
            r = rows[k]
            vals = [r["budget"], r["prior"], r["current"], round(r["budget"] - r["prior"] - r["current"], 2)]
            ws.append([k, r["label"], *vals, 0])
            sub = [a + b for a, b in zip(sub, vals)]
        ws.append([None, f"Total {title.title()}", *[round(x, 2) for x in sub]])
        grand = [a + b for a, b in zip(grand, sub)]
    ws.append([None, "GRAND TOTAL", *[round(x, 2) for x in grand]])
    wb.save(out)


def main():
    src = {r["key"]: r for r in csv.DictReader(open(HERE / "loan_1001/draw_07/borrower.csv"))}
    d19 = {k: {"label": r["label"], "budget": num(r["budget"]), "prior": num(r["prior"]), "current": num(r["current"])}
           for k, r in src.items()}
    # draw 18: before change order CO-21 (Finishes +36,000 from contingency) and before the new Solar PV line
    d18 = {}
    for k, r in d19.items():
        if k == "B33":
            continue
        budget = {"B09": 1864000.0, "B14": 550000.0}.get(k, r["budget"])
        cur18 = round(min(r["prior"], budget * 0.04), 2) if r["prior"] else 0.0
        d18[k] = {"label": r["label"], "budget": budget, "prior": round(r["prior"] - cur18, 2), "current": cur18}

    out = HERE / "onboarding_d18"
    out.mkdir(exist_ok=True)
    (HERE / "inbox").mkdir(exist_ok=True)
    write_xlsx(d18, out / f"{LOAN}_draw18.xlsx", 18, "2026-10-31")
    write_xlsx(d19, HERE / "inbox" / f"{LOAN}_draw19.xlsx", 19, "2026-11-30")

    # ---- the SOR after 18 hand-keyed draws: budget as of draw 18, paid-to-date = prior + request of draw 18
    cat = {k: c for title, keys in SECTIONS for k in keys
           for c in [{"ACQUISITION COSTS": "ACQUISITION", "HARD COSTS": "HARD", "SOFT COSTS": "SOFT", "RESERVES": "OTHER"}[title]]}
    lob_label = {"B01": "Land Acq.", "B02": "Acq Closing", "B03": "Site Work - per CO #2", "B04": "CONCRETE",
                 "B05": "Masonary", "B06": "Rough Carp/Framing", "B07": "Roofng", "B08": "Drs & Windows",
                 "B09": "Finishes (rev 9/14)", "B10": "Plumbng", "B11": "HVAC/Mech", "B12": "Elecrtical",
                 "B13": "GC OH&P / Gen Req", "B14": "Constuction Contg 5%", "B18": "Permits & Impact",
                 "B19": "Legal (outside counsel)", "B24": "Bldrs Risk Ins", "B25": "Constr. Int. Reserve",
                 "B26": "Fin Fees / COI", "B27": "HFA Fees", "B28": "Mktg/Lease Up", "B29": "Misc 1",
                 "B30": "Soft Contg", "B31": "Op Reserve", "B32": "Repl Reserve"}
    sor = []
    for k in ("B01", "B02", "B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12", "B13", "B14",
              "B18", "B19", "B24", "B25", "B26", "B27", "B28", "B29", "B30", "B31", "B32"):
        r = d18[k]
        sor.append({"key": "S" + k[1:], "label": lob_label[k], "category": cat[k], "budget": r["budget"],
                    "prior": round(r["prior"] + r["current"], 2)})
    by = {x["key"]: x for x in sor}
    # D1  merged line: Architect + Engineering + Survey keyed as one line
    a = [d18[k] for k in ("B15", "B16", "B17")]
    sor.append({"key": "S15", "label": "A&E + Survey", "category": "SOFT", "budget": sum(x["budget"] for x in a),
                "prior": round(sum(x["prior"] + x["current"] for x in a), 2)})
    # D3  M:N regrouping: Appraisal, Environmental, Market Study, Title keyed as two lines with a different split
    rg = [d18[k] for k in ("B20", "B21", "B22", "B23")]
    tb, tp = sum(x["budget"] for x in rg), round(sum(x["prior"] + x["current"] for x in rg), 2)
    sor.append({"key": "S20", "label": "3rd party reports", "category": "SOFT", "budget": 110000.0, "prior": 70000.0})
    sor.append({"key": "S21", "label": "Title & studies", "category": "SOFT", "budget": tb - 110000.0, "prior": tp - 70000.0})
    by["S30"]["category"] = "HARD"                       # E3  soft contingency filed under Hard
    by["S10"]["budget"], by["S11"]["budget"] = 1000000.0, 1030000.0  # F4  budgets keyed against the wrong trades
    by["S12"]["prior"] += 7500.0                         # G2  a draw booked to Electrical instead of Roofing
    by["S07"]["prior"] -= 7500.0
    by["S25"]["prior"] -= 12000.0                        # G3  a disbursement never recorded in the SOR
    by["S18"]["budget"] = 42850.0                        # C1  transposed digits (48,250)
    by["S19"]["prior"] = round(by["S19"]["prior"] / 10, 2)  # G5  dropped digit in paid-to-date
    with open(out / f"{LOAN}_sor_export_after_draw18.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=["key", "label", "category", "budget", "prior"])
        w.writeheader()
        for x in sorted(sor, key=lambda x: x["key"]):
            w.writerow({**x, "budget": f"{x['budget']:.2f}", "prior": f"{x['prior']:.2f}"})

    # draw 20: what the borrower sends after draw 19 was funded (HFA fees capped at the $32,000 remaining)
    cur20 = {"B05": 64000, "B06": 115000, "B07": 104000, "B08": 122000, "B09": 380000, "B10": 147000, "B11": 157500,
             "B12": 172500, "B13": 95000, "B15": 9000, "B16": 4750, "B19": 8250, "B21": 10000, "B23": 5000,
             "B25": 62000, "B33": 20000}
    funded19 = {**{k: r["current"] for k, r in d19.items()}, "B27": 32000.0}
    d20 = {k: {"label": r["label"], "budget": r["budget"], "prior": round(r["prior"] + funded19[k], 2),
               "current": float(cur20.get(k, 0))} for k, r in d19.items()}
    write_xlsx(d20, HERE / "inbox" / f"{LOAN}_draw20.xlsx", 20, "2026-12-31")

    feeds = HERE / "feeds" / LOAN
    feeds.mkdir(parents=True, exist_ok=True)
    shutil.copy(HERE / "loan_1001/draw_07/sources.csv", feeds / "sources.csv")
    (feeds / "approvals.csv").write_text("approval_ref,cost_code,label,delta\n"   # F1 change order on file
                                         "CO-21,T-09,,36000.00\nCO-21,HC-0900,,-36000.00\n")
    print("onboarding scenario written for", LOAN)


if __name__ == "__main__":
    main()
