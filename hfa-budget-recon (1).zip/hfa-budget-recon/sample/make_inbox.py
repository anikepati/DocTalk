"""Builds the illustrative borrower Excel files (G703-style continuation sheets) in sample/inbox from the CSV
fixtures, plus the onboarding budget and reference feeds. All figures are invented.

    python sample/make_inbox.py
"""
import csv
import shutil
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font

HERE = Path(__file__).resolve().parent
SECTIONS = [("ACQUISITION COSTS", ["B01", "B02"]),
            ("HARD COSTS", ["B03", "B04", "B05", "B06", "B07", "B08", "B09", "B10", "B11", "B12", "B33", "B13", "B14"]),
            ("SOFT COSTS", ["B15", "B16", "B17", "B18", "B19", "B20", "B21", "B22", "B23", "B24", "B25", "B26",
                            "B27", "B28", "B29", "B30"]),
            ("RESERVES", ["B31", "B32"])]


def num(s):
    s = (s or "0").replace(",", "").replace("$", "")
    return round(float(s), 2)


def build(draw_folder, out, draw_no, period):
    rows = {r["key"]: r for r in csv.DictReader(open(draw_folder / "borrower.csv"))}
    wb = Workbook()
    ws = wb.active
    ws.title = "Continuation Sheet"
    ws.append(["Riverside Commons - Application and Certificate for Payment, Continuation Sheet"])
    ws.append(["Loan No: HFA-1001"])
    ws.append([f"Application No: {draw_no}"])
    ws.append([f"Period To: {period}"])
    ws.append([])
    ws.append(["Item No", "Description of Work", "Scheduled Value", "Work Completed From Previous Application",
               "Work Completed This Period", "Balance to Finish", "Retainage"])
    for c in ws[6]:
        c.font = Font(bold=True)
    grand = [0.0, 0.0, 0.0, 0.0]
    for title, keys in SECTIONS:
        ws.append([None, title])
        ws.cell(ws.max_row, 2).font = Font(bold=True)
        sub = [0.0, 0.0, 0.0, 0.0]
        for k in keys:
            if k not in rows:
                continue
            r = rows[k]
            vals = [num(r["budget"]), num(r["prior"]), num(r["current"]), num(r.get("balance"))]
            ws.append([k, r["label"], *vals, 0])
            sub = [a + b for a, b in zip(sub, vals)]
        ws.append([None, f"Total {title.title()}", *[round(x, 2) for x in sub]])
        grand = [a + b for a, b in zip(grand, sub)]
    ws.append([])
    ws.append([None, "GRAND TOTAL", *[round(x, 2) for x in grand]])
    for col in "CDEFG":
        for cell in ws[col][6:]:
            cell.number_format = '#,##0.00'
    ws.column_dimensions["B"].width = 40
    wb.save(out)


if __name__ == "__main__":
    inbox = HERE / "inbox"
    inbox.mkdir(exist_ok=True)
    build(HERE / "loan_1001" / "draw_07", inbox / "HFA-1001_draw07.xlsx", 7, "2026-10-31")
    build(HERE / "loan_1001" / "draw_08", inbox / "HFA-1001_draw08.xlsx", 8, "2026-11-30")
    onboard = HERE / "onboarding"
    onboard.mkdir(exist_ok=True)
    shutil.copy(HERE / "loan_1001" / "draw_07" / "approved.csv", onboard / "HFA-1001_approved_budget.csv")
    feeds = HERE / "feeds" / "HFA-1001"
    feeds.mkdir(parents=True, exist_ok=True)
    shutil.copy(HERE / "loan_1001" / "draw_07" / "sources.csv", feeds / "sources.csv")
    # the change order for the construction contract is on file; the solar reallocation is not
    (feeds / "approvals.csv").write_text("approval_ref,cost_code,label,delta\n"
                                         "CO-14,HC-0300,,36000.00\nCO-14,HC-0900,,-36000.00\n")
    print("wrote", sorted(p.name for p in inbox.iterdir()))
