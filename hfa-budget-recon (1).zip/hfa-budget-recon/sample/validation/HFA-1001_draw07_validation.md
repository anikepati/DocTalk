# Draw validation - loan HFA-1001, draw 7

33 borrower lines: **25 OK**, **2 review**, **6 exception**; 0 system line(s) not in the draw.

| Status | Borrower line | System line(s) | Rule | Match | Conf. | Budget diff | Prior diff | Issues |
|---|---|---|---|---|---|---|---|---|
| EXCEPTION | Finishes | Finishes (rev 9/14) | M06 | LABEL_VARIANT_AMOUNTS_DIFFER | 1.00 | $36,000.00 BUDGET_CHANGE |  | IMPLIED_REALLOCATION |
| EXCEPTION | Hard Cost Contingency | Constuction Contg 5% | M06 | LABEL_VARIANT_AMOUNTS_DIFFER | 0.97 | -$96,000.00 BUDGET_CHANGE |  | IMPLIED_REALLOCATION |
| EXCEPTION | Permits & Impact Fees | Permits & Impact | M06 | LABEL_VARIANT_AMOUNTS_DIFFER | 1.00 | $5,400.00 PROBABLE_SYSTEM_TYPO (TRANSPOSED_DIGITS) |  | PROBABLE_KEYING_ERROR |
| EXCEPTION | Legal | Legal (outside counsel) | M06 | LABEL_VARIANT_AMOUNTS_DIFFER | 0.97 |  | $89,100.00 PRIOR_MISMATCH (DROPPED_DIGIT in system value) | PRIOR_DRAW_MISMATCH |
| EXCEPTION | HFA / Tax Credit Fees | HFA Fees | M02 | LABEL_VARIANT | 1.00 |  |  | LINE_OVERRUN |
| EXCEPTION | Solar PV System | - |  | NEW_LINE | 0.00 | $60,000.00 NEW_LINE |  | DRAW_ON_UNAPPROVED_LINE, IMPLIED_REALLOCATION |
| REVIEW | Appraisal | 3rd Pty Rpts | M05 | SUMMATION | 0.82 |  |  | BASELINE_CONSOLIDATION |
| REVIEW | Environmental (Phase I) | 3rd Pty Rpts | M05 | SUMMATION | 0.82 |  |  | BASELINE_CONSOLIDATION |
| OK | Land Acquisition | Land Acq. | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Acquisition Closing Costs | Acq Closing | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Sitework | Site Work - per CO #2 | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Concrete | CONCRETE | M02 | EXACT | 1.00 |  |  |  |
| OK | Masonry | Masonary | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Rough Carpentry / Framing | Rough Carp/Framing | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Roofing | Roofng | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Doors & Windows | Drs & Windows | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Plumbing | Plumbng | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | HVAC | HVAC/Mech | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Electrical | Elecrtical | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | General Contractor Overhead & Profit | GC OH&P / Gen Req | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Architect | A&E + Survey | M05 | SUMMATION | 0.97 |  |  | BASELINE_CONSOLIDATION |
| OK | Engineering | A&E + Survey | M05 | SUMMATION | 0.97 |  |  | BASELINE_CONSOLIDATION |
| OK | Survey | A&E + Survey | M05 | SUMMATION | 0.97 |  |  | BASELINE_CONSOLIDATION |
| OK | Market Study | Mkt Study | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Title & Recording | Title/Rec. | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Builder's Risk Insurance | Bldrs Risk Ins | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Construction Interest Reserve | Constr. Int. Reserve | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Financing Fees / Cost of Issuance | Fin Fees / COI | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Marketing / Lease-Up | Mktg/Lease Up | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Developer Fee | Dev Fee | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Soft Cost Contingency | Soft Contg | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Operating Reserve | Op Reserve | M02 | LABEL_VARIANT | 1.00 |  |  |  |
| OK | Replacement Reserve | Repl Reserve | M02 | LABEL_VARIANT | 1.00 |  |  |  |

## Exceptions

- **BLOCKING IMPLIED_REALLOCATION**: Budget moved $96,000.00 between lines with no recorded approval (net change $0.00).
- **BLOCKING PRIOR_DRAW_MISMATCH**: Legal: borrower shows prior draws $99,000.00, system has $9,900.00. Looks like DROPPED_DIGIT in the system value.
- **BLOCKING DRAW_ON_UNAPPROVED_LINE**: Solar PV System: $15,000.00 requested on a line that is not in the approved budget.
- **BLOCKING LINE_OVERRUN**: HFA / Tax Credit Fees: draws to date $64,000.00 + this draw $40,000.00 exceed budget $96,000.00 by $8,000.00.
- **BLOCKING PROBABLE_KEYING_ERROR**: Permits & Impact Fees: system budget $42,850.00 vs borrower $48,250.00 (TRANSPOSED_DIGITS): most likely mistyped when it was entered, not a budget change.
- **REVIEW BASELINE_CONSOLIDATION**: 3rd Pty Rpts (approved) = Environmental (Phase I) + Appraisal (borrower), confidence 0.82.
- **INFO BASELINE_CONSOLIDATION**: A&E + Survey (approved) = Architect + Engineering + Survey (borrower), confidence 0.97.
