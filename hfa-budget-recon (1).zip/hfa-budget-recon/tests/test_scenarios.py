"""The scenario catalog: one test per scenario id (see docs / README). A scenario is 'covered' only if its test
asserts the specific outcome the catalog promises."""
import tempfile
from pathlib import Path

import pytest
from openpyxl import Workbook

from budget_recon.config import load_config
from budget_recon.engine import ReconEngine
from budget_recon.extract import ExcelExtractor, LLMExtractor
from budget_recon.hitl import TaskError
from budget_recon.ledger import InMemoryRepository, JsonFileRepository, bootstrap_version
from budget_recon.models import Line, LoanInput
from budget_recon.money import to_cents as c
from budget_recon.normalize import Normalizer
from budget_recon.pipeline import FolderFeeds, Pipeline
from budget_recon.planner import Planner
from budget_recon.restructure import ChangeSetError, apply_change_set
from budget_recon.sor import FileSorAdapter
from budget_recon.validate import DrawValidator

ROOT = Path(__file__).resolve().parent.parent
S = ROOT / "sample"
CFG = load_config()
NORM = Normalizer(CFG)


def SL(key, label, budget, prior=0, category=None):
    return Line(key, label, c(budget), c(prior), category=category)


def BL(key, label, budget, prior=0, current=0, category=None):
    return Line(key, label, c(budget), c(prior), c(current), category=category)


def recon(system, borrower, previous=None, approvals=(), sources=None, cfg=CFG):
    return ReconEngine(cfg).reconcile(LoanInput("T", system, borrower, None, list(approvals), sources,
                                                previous_borrower=previous))


def codes(rep):
    return [e.reason_code for e in rep.exceptions]


def validate(system, borrower, previous=None, approvals=(), cfg=CFG):
    return DrawValidator(cfg).validate(system, borrower, "T", 1, approvals, previous_borrower=previous)


def row(res, label):
    return [l for l in res.lines if l.borrower_label == label][0]


def xlsx(tmp, rows, header=("Item No", "Description of Work", "Scheduled Value", "From Previous Application",
                            "This Period", "Balance to Finish"), pre=("Loan No: T-1", "Application No: 3"),
         sheet_first="Cover"):
    wb = Workbook()
    wb.active.title = sheet_first
    wb.active.append(["Summary page"])
    ws = wb.create_sheet("Detail")
    for p in pre:
        ws.append([p])
    ws.append([])
    ws.append(list(header))
    for r in rows:
        ws.append(list(r))
    p = Path(tmp) / "f.xlsx"
    wb.save(p)
    return p


# =========================================================== A. intake and extraction
def test_A1_standard_g703_excel():
    ext = ExcelExtractor().extract(S / "inbox/HFA-1001_draw07.xlsx")
    assert ext.meta["loan_id"] == "HFA-1001" and ext.meta["draw_no"] == 7 and len(ext.lines) == 33 and not ext.checks
    assert {l.category for l in ext.lines} == {"ACQUISITION", "HARD", "SOFT", "OTHER"}


def test_A2_other_layout_other_sheet_other_column_names(tmp_path):
    p = xlsx(tmp_path, [(1, "Concrete", "1,000.00", "400", "100", "500")],
             header=("Line", "Budget Item", "Revised Budget", "Prior Draws", "Current Request", "Remaining"))
    ext = ExcelExtractor().extract(p)
    assert ext.meta["sheet"] == "Detail" and ext.lines[0].budget == c(1000) and ext.lines[0].current == c(100)


def test_A3_pdf_through_model_is_validated(tmp_path):
    pdf = tmp_path / "d.pdf"
    pdf.write_bytes(b"%PDF")
    out = {"lines": [{"description": "Legal", "scheduled_value": "100", "previous": "10", "this_period": "5",
                      "balance": "85"}], "totals": {"scheduled_value": "100", "previous": "10", "this_period": "5"}}
    ext = LLMExtractor(lambda *a: out).extract(pdf)
    assert ext.meta["method"] == "llm" and not ext.checks


def test_A4_line_does_not_foot(tmp_path):
    ext = ExcelExtractor().extract(xlsx(tmp_path, [(1, "Legal", 100, 10, 5, 80)]))
    assert [x["code"] for x in ext.checks] == ["LINE_MATH"]


def test_A5_subtotal_and_grand_total_mismatch(tmp_path):
    ext = ExcelExtractor().extract(xlsx(tmp_path, [(None, "SOFT COSTS"), (1, "Legal", 100, 10, 5, 85),
                                                   (None, "Total Soft Costs", 90, 10, 5), (None, "GRAND TOTAL", 95, 10, 5)]))
    assert {x["code"] for x in ext.checks} == {"SUBTOTAL_MISMATCH", "GRAND_TOTAL_MISMATCH"}


def test_A6_unparseable_amount(tmp_path):
    ext = ExcelExtractor().extract(xlsx(tmp_path, [(1, "Legal", "1O0.00", 10, 5, 85)]))
    assert ext.checks[0]["code"] == "UNPARSEABLE_AMOUNT" and ext.blocking


def _pipe(repo=None, sor=None, cfg=CFG):
    p = Pipeline(cfg, repo or InMemoryRepository(), FolderFeeds(S / "feeds"), sor=sor)
    p.onboard("HFA-1001", S / "onboarding/HFA-1001_approved_budget.csv")
    return p


def test_A7_same_file_twice_is_idempotent():
    p = _pipe()
    a = p.receive(S / "inbox/HFA-1001_draw07.xlsx")
    assert p.receive(S / "inbox/HFA-1001_draw07.xlsx")["submission_id"] == a["submission_id"]
    assert len(p.repo.list_records("submissions", "HFA-1001")) == 1


def test_A8_unidentifiable_loan_or_draw(tmp_path):
    p = _pipe()
    with pytest.raises(ValueError, match="which loan"):
        p.receive(xlsx(tmp_path, [(1, "Legal", 100, 10, 5, 85)], pre=("no identifiers here",)))


def test_A9_out_of_sequence_and_already_posted(tmp_path):
    p = Pipeline(CFG, InMemoryRepository(), FolderFeeds(S / "feeds"))
    p.onboard("HFA-1001", S / "onboarding/HFA-1001_approved_budget.csv", last_draw_no=6)
    sub = p.receive(S / "loan_1001/draw_08/borrower.csv", loan_id="HFA-1001", draw_no=9)
    assert any(t.ref == "SEQUENCE" for t in p.tasks.list("OPEN"))
    old = p.receive(S / "loan_1001/draw_07/borrower.csv", loan_id="HFA-1001", draw_no=5)
    assert old["reject_reason"]["code"] == "DRAW_ALREADY_POSTED"


def test_A10_corrected_resubmission_supersedes_the_earlier_file(tmp_path):
    p = _pipe()
    first = p.receive(S / "inbox/HFA-1001_draw07.xlsx")
    assert first["state"] == "AWAITING_REVIEW"
    from openpyxl import load_workbook
    wb = load_workbook(S / "inbox/HFA-1001_draw07.xlsx")
    wb.active["A1"] = "Corrected resubmission"
    fixed = tmp_path / "HFA-1001_draw07_v2.xlsx"
    wb.save(fixed)
    p.receive(fixed)
    old = p.repo.load_record("HFA-1001", "submissions", first["submission_id"])
    assert old["state"] == "SUPERSEDED"
    assert all(t.submission_id != first["submission_id"] for t in p.tasks.list("OPEN"))


# =========================================================== B. labels
@pytest.mark.parametrize("sid,system_label,borrower_label", [
    ("B1", "Legal", "Legal"),
    ("B2", "Drs & Windows", "Doors & Windows"),
    ("B3", "Site Work - per CO #2", "Sitework"),
    ("B4", "Elecrtical", "Electrical"),
    ("B5", "3. CONCRETE", "Concrete"),
])
def test_B1_to_B5_label_variants(sid, system_label, borrower_label):
    res = validate([SL("S1", system_label, 500, 100)], [BL("B1", borrower_label, 500, 100)])
    assert res.lines[0].status == "OK" and res.lines[0].rule_id == "M02", sid


def test_B6_unrelated_wording_same_amounts_goes_to_review():
    res = validate([SL("S1", "Owner's rep", 72000, 18000), SL("S2", "Legal", 5000)],
                   [BL("B1", "Development consultant", 72000, 18000), BL("B2", "Legal", 5000)])
    assert row(res, "Development consultant").status == "REVIEW"


def test_B7_borrower_renames_a_line_then_next_draw_matches_by_alias():
    v = bootstrap_version("T", [SL("S1", "Marketing", 90000, 1000)], NORM)
    b = [BL("B1", "Lease-up promotion", 90000, 1000)]
    rep = ReconEngine(CFG).reconcile(LoanInput("T", None, b), ledger=v)
    cs = Planner(CFG).plan(v, rep)
    assert "ADD_ALIAS" in [o.kind for o in cs.ops]
    nv, _ = apply_change_set(v, cs)
    rep2 = ReconEngine(CFG).reconcile(LoanInput("T", None, b), ledger=nv)
    assert rep2.change.groups[0].pass_name == "ledger_alias"


def test_B8_generic_system_label_never_auto_matches():
    res = validate([SL("S1", "Misc 1", 1650000, 495000, "SOFT")], [BL("B1", "Developer Fee", 1650000, 495000, 0, "SOFT")])
    assert res.lines[0].status == "REVIEW" and res.lines[0].confidence < 0.95


# =========================================================== C. amounts
@pytest.mark.parametrize("sid,system,borrower,pattern", [
    ("C1", 42850, 48250, "TRANSPOSED_DIGITS"),
    ("C2", 16500, 165000, "DROPPED_DIGIT"),
    ("C3", 412, 41200, "DECIMAL_SHIFT"),
])
def test_C1_to_C3_amount_typos_are_not_budget_changes(sid, system, borrower, pattern):
    rep = recon([SL("S1", "Permits", system)], [BL("B1", "Permits", borrower)])
    assert "PROBABLE_KEYING_ERROR" in codes(rep), sid
    assert not {"UNAPPROVED_BUDGET_CHANGE", "IMPLIED_REALLOCATION", "UNAPPROVED_NET_CHANGE"} & set(codes(rep))


def test_C4_single_wrong_digit_is_treated_as_a_change():
    res = validate([SL("S1", "Sitework", 640000)], [BL("B1", "Sitework", 650000)])
    assert res.lines[0].budget_diff_type == "BUDGET_CHANGE (or single-digit typo)"


def test_C5_rounding_is_not_an_exception():
    res = validate([SL("S1", "Legal", "8,333.33")], [BL("B1", "Legal", "8,333.00")])
    assert res.lines[0].budget_diff_type == "ROUNDING" and res.lines[0].status == "OK"


def test_C6_duplicate_amounts_are_paired_by_label_or_not_at_all():
    res = validate([SL("S1", "Appraisal", 25000, 25000), SL("S2", "Survey", 25000, 25000)],
                   [BL("B1", "Survey", 25000, 25000), BL("B2", "Appraisal", 25000, 25000)])
    assert row(res, "Survey").system_labels == ["Survey"] and row(res, "Appraisal").system_labels == ["Appraisal"]
    junk = validate([SL("S1", "Item A", 25000, 25000), SL("S2", "Item B", 25000, 25000)],
                    [BL("B1", "Appraisal", 25000, 25000), BL("B2", "Survey", 25000, 25000)])
    assert {l.status for l in junk.lines} != {"OK"}  # never a silent guess


# =========================================================== D. structure
def test_D1_system_line_is_a_sum_of_borrower_lines():
    res = validate([SL("S1", "A&E + Survey", 287500, 201000)],
                   [BL("B1", "Architect", 180000, 150000), BL("B2", "Engineering", 95000, 38500),
                    BL("B3", "Survey", 12500, 12500)])
    assert {l.rule_id for l in res.lines} == {"M05"}


def test_D2_borrower_line_is_a_sum_of_system_lines():
    res = validate([SL("S1", "Architect", 180000, 150000), SL("S2", "Engineering", 95000, 38500)],
                   [BL("B1", "Architecture & Engineering", 275000, 188500)])
    assert res.lines[0].rule_id == "M04"


def test_D3_regrouped_m_to_n_within_a_category():
    sys_ = [SL("S1", "3rd party reports", 110000, 70000, "SOFT"), SL("S2", "Title & studies", 90000, 50000, "SOFT")]
    bor = [BL("B1", "Appraisal", 25000, 25000, 0, "SOFT"), BL("B2", "Environmental", 50000, 30000, 0, "SOFT"),
           BL("B3", "Market Study", 50000, 50000, 0, "SOFT"), BL("B4", "Title & Recording", 75000, 15000, 0, "SOFT")]
    res = validate(sys_, bor)
    assert {l.match_type for l in res.lines} == {"REGROUPED"} and not res.system_only
    v = bootstrap_version("T", sys_, NORM)
    rep = ReconEngine(CFG).reconcile(LoanInput("T", None, bor), ledger=v)
    cs = Planner(CFG).plan(v, rep)
    assert [o.kind for o in cs.ops if o.kind == "REGROUP"] == ["REGROUP"]
    nv, _ = apply_change_set(v, cs)
    assert nv.total_budget() == v.total_budget() and nv.total_drawn() == v.total_drawn()


def test_D4_trade_detail_vs_summary_line_rolls_up():
    rep = recon([SL("S1", "Construction Contract", 3000000, 1000000)],
                [BL("T1", "Concrete", 1000000, 600000), BL("T2", "Framing", 1200000, 300000), BL("T3", "Electrical", 800000, 100000)])
    assert rep.change.groups[0].right[0].children == ("T1", "T2", "T3")


def test_D5_trade_detail_on_both_sides_is_compared_trade_by_trade():
    rep = recon([SL("S1", "Plumbng", 980000), SL("S2", "Elecrtical", 1150000)],
                [BL("B1", "Plumbing", 980000), BL("B2", "Electrical", 1150000)])
    assert len(rep.change.groups) == 2 and not rep.change.groups[0].right[0].children


def test_D6_new_borrower_line():
    res = validate([SL("S1", "Legal", 5000)], [BL("B1", "Legal", 5000), BL("B2", "Solar PV System", 60000, 0, 15000)])
    assert row(res, "Solar PV System").match_type == "NEW_LINE"


def test_D7_D8_lines_dropped_by_the_borrower():
    for drawn, expect in ((0, "RETIRE"), (30000, "CLOSE")):
        v = bootstrap_version("T", [SL("S1", "Marketing", 90000, drawn), SL("S2", "Soft Cost Contingency", 150000)], NORM)
        rep = ReconEngine(CFG).reconcile(LoanInput("T", None, [BL("B1", "Soft Cost Contingency", 240000 - drawn)]), ledger=v)
        assert expect in [o.kind for o in Planner(CFG).plan(v, rep).ops]


def test_D9_ambiguous_grouping_is_never_guessed():
    res = validate([SL("S1", "Third party reports", 75000)],
                   [BL("B1", "Appraisal", 25000), BL("B2", "Environmental", 50000), BL("B3", "Market Study", 50000)],
                   cfg=CFG.override(change_columns=["budget"]))
    assert {l.match_type for l in res.lines} == {"AMBIGUOUS"}


# =========================================================== E. category
def _hard_soft():
    sys_ = [SL("S1", "Concrete", 1000000, 500000, "HARD"), SL("S2", "Legal", 165000, 99000, "SOFT"),
            SL("S3", "Soft Contg", 150000, 22000, "HARD")]
    bor = [BL("B1", "Concrete", 1000000, 500000, 0, "HARD"), BL("B2", "Legal", 165000, 99000, 0, "SOFT"),
           BL("B3", "Soft Cost Contingency", 150000, 22000, 0, "SOFT")]
    return sys_, bor


def test_E1_category_totals_tie():
    sys_, bor = _hard_soft()
    sys_[2] = SL("S3", "Soft Contg", 150000, 22000, "SOFT")
    rep = recon(sys_, bor)
    assert [t["budget_gap"] for t in rep.findings.category_tieout] == [0, 0]
    assert not [x for x in codes(rep) if x.startswith("CATEGORY")]


def test_E2_gap_localized_to_a_category():
    sys_, bor = _hard_soft()
    sys_[1] = SL("S2", "Legal", 160000, 99000, "SOFT")
    rep = recon(sys_, bor)
    gaps = {t["category"]: t["budget_gap_after_misfiles"] for t in rep.findings.category_tieout}
    assert gaps["SOFT"] == c(5000) and gaps["HARD"] == 0


def test_E3_line_misfiled_in_the_wrong_category():
    rep = recon(*_hard_soft())
    assert "CATEGORY_MISFILED" in codes(rep)
    t = {x["category"]: x for x in rep.findings.category_tieout}
    assert t["HARD"]["budget_gap"] == -c(150000) and t["HARD"]["budget_gap_after_misfiles"] == 0


def test_E4_budget_moved_across_categories_is_a_reallocation():
    sys_ = [SL("S1", "Hard Cost Contingency", 500000, 0, "HARD"), SL("S2", "Legal", 165000, 0, "SOFT")]
    bor = [BL("B1", "Hard Cost Contingency", 480000, 0, 0, "HARD"), BL("B2", "Legal", 185000, 0, 0, "SOFT")]
    rep = recon(sys_, bor)
    assert "IMPLIED_REALLOCATION" in codes(rep) and "CATEGORY_MISFILED" not in codes(rep)


# =========================================================== F. budget changes
def test_F1_full_and_partial_approvals():
    appr = [{"approval_ref": "CO-21", "cost_code": "T-09", "delta": c(36000)},
            {"approval_ref": "CO-21", "cost_code": "HC-0900", "delta": c(-36000)}]
    res = validate([SL("S1", "Finishes", 1864000), SL("S2", "Hard Cost Contingency", 550000)],
                   [BL("B1", "Finishes", 1900000), BL("B2", "Hard Cost Contingency", 454000), BL("B3", "Solar PV System", 60000)],
                   approvals=appr)
    assert row(res, "Finishes").budget_diff_type == "APPROVED_CHANGE (CO-21)"
    assert row(res, "Hard Cost Contingency").budget_diff_type.startswith("BUDGET_CHANGE (partly approved")


def test_F2_unapproved_reallocation():
    rep = recon([SL("S1", "Finishes", 1864000), SL("S2", "Hard Cost Contingency", 550000)],
                [BL("B1", "Finishes", 1900000), BL("B2", "Hard Cost Contingency", 514000)])
    assert "IMPLIED_REALLOCATION" in codes(rep)


def test_F3_net_increase_needs_sources():
    rep = recon([SL("S1", "Legal", 165000)], [BL("B1", "Legal", 175000)], sources=[{"source": "Loan", "amount": c(165000)}])
    assert {"UNAPPROVED_NET_CHANGE", "SOURCES_NE_USES"} <= set(codes(rep))


def test_F4_previous_file_tells_sor_error_from_real_change():
    sys_ = [SL("S1", "Plumbing", 1000000), SL("S2", "HVAC", 1030000), SL("S3", "Finishes", 1864000),
            SL("S4", "Hard Cost Contingency", 550000)]
    prev = [BL("P1", "Plumbing", 980000), BL("P2", "HVAC", 1050000), BL("P3", "Finishes", 1864000),
            BL("P4", "Hard Cost Contingency", 550000)]
    now = [BL("B1", "Plumbing", 980000), BL("B2", "HVAC", 1050000), BL("B3", "Finishes", 1900000),
           BL("B4", "Hard Cost Contingency", 514000)]
    res = validate(sys_, now, previous=prev)
    assert row(res, "Plumbing").budget_diff_type.startswith("SOR_VALUE_WRONG")
    assert row(res, "Finishes").budget_diff_type == "BUDGET_CHANGE (this period)"
    without = validate(sys_, now)
    assert row(without, "Plumbing").budget_diff_type.startswith("BUDGET_CHANGE")  # ambiguous without the 3rd reference


def test_F5_sor_wrong_and_budget_changed():
    rep = recon([SL("S1", "Plumbing", 1000000)], [BL("B1", "Plumbing", 990000)], previous=[BL("P1", "Plumbing", 980000)])
    assert "BUDGET_BOTH_MOVED" in codes(rep)


# =========================================================== G. paid to date
def test_G1_paid_to_date_ties():
    assert not [x for x in codes(recon([SL("S1", "Legal", 100, 40)], [BL("B1", "Legal", 100, 40, 10)]))
                if "PRIOR" in x]


def test_G2_draws_booked_to_the_wrong_line():
    rep = recon([SL("S1", "Electrical", 1150000, 410000, "HARD"), SL("S2", "Roofing", 520000, 252500, "HARD")],
                [BL("B1", "Electrical", 1150000, 402500, 0, "HARD"), BL("B2", "Roofing", 520000, 260000, 0, "HARD")])
    assert codes(rep).count("PRIOR_MISALLOCATED") == 2 and "PRIOR_DRAW_MISMATCH" not in codes(rep)


def test_G3_missing_disbursement_record_with_consistent_borrower_history():
    rep = recon([SL("S1", "Construction Interest Reserve", 1200000, 398000)],
                [BL("B1", "Construction Interest Reserve", 1200000, 410000, 62000)],
                previous=[BL("P1", "Construction Interest Reserve", 1200000, 350000, 60000)])
    e = [x for x in rep.exceptions if x.reason_code == "PRIOR_DRAW_MISMATCH"][0]
    assert "missing or duplicating a disbursement record" in e.message


def test_G4_duplicate_disbursement_record_is_corrected_downwards():
    v = bootstrap_version("T", [SL("S1", "Legal", 165000, 110000)], NORM)
    rep = ReconEngine(CFG).reconcile(LoanInput("T", None, [BL("B1", "Legal", 165000, 99000)]), ledger=v)
    op = [o for o in Planner(CFG).plan(v, rep).ops if o.kind == "CORRECT_DRAWN"][0]
    assert op.params["amount"] == -c(11000)


def test_G5_typo_in_paid_to_date():
    res = validate([SL("S1", "Legal", 165000, 9900)], [BL("B1", "Legal", 165000, 99000)])
    assert res.lines[0].prior_diff_type == "PRIOR_MISMATCH (DROPPED_DIGIT in system value)"


def test_G6_borrower_history_breaks_continuity():
    rep = recon([SL("S1", "Legal", 165000, 99000)], [BL("B1", "Legal", 165000, 99000)],
                previous=[BL("P1", "Legal", 165000, 80000, 10000)])
    assert "BORROWER_CONTINUITY_BREAK" in codes(rep)


# =========================================================== H. this draw's request
def test_H1_overrun():
    assert "LINE_OVERRUN" in codes(recon([SL("S1", "HFA Fees", 96000, 64000)], [BL("B1", "HFA Fees", 96000, 64000, 40000)]))


def test_H2_draw_on_a_line_not_in_the_approved_budget():
    assert "DRAW_ON_UNAPPROVED_LINE" in codes(recon([SL("S1", "Legal", 1000)],
                                                    [BL("B1", "Legal", 1000), BL("B2", "Solar PV System", 60000, 0, 15000)]))


def test_H3_negative_request():
    assert "NEGATIVE_AMOUNT" in codes(recon([SL("S1", "Legal", 1000, 500)], [BL("B1", "Legal", 1000, 500, -100)]))


def test_H4_retainage_rule_is_configurable():
    rules = [dict(r, active=True) if r["rule_id"] == "R07" else r for r in CFG.rules]
    from budget_recon.config import Config
    cfg = Config(CFG.settings, CFG.abbreviations, CFG.cost_codes, rules, "t")
    b = Line("B1", "Concrete", c(1000000), c(400000), c(100000), c(0), category="HARD")
    assert "RETAINAGE_SHORT" in codes(recon([SL("S1", "Concrete", 1000000, 400000, "HARD")], [b], cfg=cfg))
    assert "RETAINAGE_SHORT" not in codes(recon([SL("S1", "Concrete", 1000000, 400000, "HARD")], [b]))


def test_H5_request_on_a_line_the_ledger_cannot_resolve_is_refused_at_posting():
    from budget_recon.posting import PostingError, post_draw
    v = bootstrap_version("T", [SL("S1", "Arch/Eng", 275000, 100000)], NORM)
    lines = ReconEngine(CFG).reconcile(LoanInput("T", None, [BL("B1", "Architect", 180000, 60000, 5000),
                                                             BL("B2", "Engineering", 95000, 40000)]), ledger=v).borrower_lines
    with pytest.raises(PostingError, match="STRUCTURE_NOT_ALIGNED"):
        post_draw(v, lines, 1)


# =========================================================== I. sources
def test_I1_sources_equal_uses():
    rep = recon([SL("S1", "Legal", 1000)], [BL("B1", "Legal", 1000)], sources=[{"source": "Loan", "amount": c(1000)}])
    assert "SOURCES_NE_USES" not in codes(rep)


def test_I2_sources_do_not_cover_uses():
    rep = recon([SL("S1", "Legal", 1000)], [BL("B1", "Legal", 1000)], sources=[{"source": "Loan", "amount": c(900)}])
    assert "SOURCES_NE_USES" in codes(rep)


# =========================================================== J. process, controls and the SOR
def _onboarded(tmp):
    sor = FileSorAdapter(Path(tmp) / "sor")
    p = Pipeline(CFG, JsonFileRepository(Path(tmp) / "store"), FolderFeeds(S / "feeds"), sor=sor)
    p.onboard("HFA-2001", S / "onboarding_d18/HFA-2001_sor_export_after_draw18.csv", 18,
              S / "onboarding_d18/HFA-2001_draw18.xlsx")
    return p, sor


def _clear(p, loan):
    refs = {"CORRECT_DRAWN": "WIRE-1", "RECLASS_DRAWS": "HIST-1", "REALLOCATE": "CO-22", "RECATEGORIZE": "MEMO-1"}
    for t in p.tasks.list("OPEN", loan):
        k = t.title.split(":")[0]
        if t.kind == "DRAW_EXCEPTION":
            continue
        pay = {"approval_ref": refs[k]} if t.evidence.get("requires_approval_ref") else {}
        p.decide(loan, t.task_id, "APPROVE", "maria", pay)
        if t.approvals_needed == 2:
            p.decide(loan, t.task_id, "APPROVE", "dev", pay)
    over = [t for t in p.tasks.list("OPEN", loan) if t.title == "LINE_OVERRUN"][0]
    return p.decide(loan, over.task_id, "ADJUST_DRAW", "maria", {"amount_cents": c(32000)})


def test_J1_onboard_mid_project_at_draw_18_then_draws_19_and_20(tmp_path):
    p, sor = _onboarded(tmp_path)
    s19 = p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    kinds = sorted({t.title.split(":")[0] for t in p.tasks.list("OPEN", "HFA-2001")})
    assert {"REGROUP", "CORRECT_BUDGET", "RECLASS_DRAWS", "CORRECT_DRAWN", "RECATEGORIZE", "REALLOCATE"} <= set(kinds)
    s19 = _clear(p, "HFA-2001")
    assert s19["state"] == "SOR_SYNCED" and s19["draw_total"] == c(1581720)
    rows = {r["key"]: r for r in sor.export("HFA-2001")}
    assert rows["S10"]["budget"] == c(980000) and rows["S30"]["category"] == "SOFT"
    assert rows["S15"]["status"] == "RETIRED" and any(r["label"] == "Solar PV System" for r in rows.values())
    s20 = p.receive(S / "inbox/HFA-2001_draw20.xlsx")
    assert s20["state"] == "SOR_SYNCED" and s20["human_tasks"] == 0 and s20["sor_instructions"] == {"POST_DRAW": 16}


def test_J2_dual_approval_and_named_people(tmp_path):
    p, _ = _onboarded(tmp_path)
    p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    t = [x for x in p.tasks.list("OPEN") if x.approvals_needed == 2][0]
    p.decide("HFA-2001", t.task_id, "APPROVE", "maria", {"approval_ref": "W"})
    with pytest.raises(TaskError):
        p.decide("HFA-2001", t.task_id, "APPROVE", "maria", {"approval_ref": "W"})
    with pytest.raises(TaskError):
        p.decide("HFA-2001", t.task_id, "APPROVE", "policy:STP-v1", {"approval_ref": "W"})


def test_J3_return_to_borrower_leaves_ledger_and_sor_untouched(tmp_path):
    p, sor = _onboarded(tmp_path)
    before = sor.export("HFA-2001")
    p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    t = [x for x in p.tasks.list("OPEN") if x.title.startswith("REALLOCATE")][0]
    sub = p.decide("HFA-2001", t.task_id, "REJECT", "maria", {"note": "Solar not approved"})
    assert sub["state"] == "RETURNED_TO_BORROWER" and p.repo.current("HFA-2001").version_no == 1
    assert sor.export("HFA-2001") == before


def test_J4_stale_change_set_is_rejected():
    v = bootstrap_version("T", [SL("S1", "Arch/Eng", 275000, 100000)], NORM)
    rep = ReconEngine(CFG).reconcile(LoanInput("T", None, [BL("B1", "Architect", 180000, 60000),
                                                           BL("B2", "Engineering", 95000, 40000)]), ledger=v)
    cs = Planner(CFG).plan(v, rep)
    nv, _ = apply_change_set(v, cs)
    with pytest.raises(ChangeSetError, match="I1"):
        apply_change_set(nv, cs)


def test_J5_sor_updates_are_idempotent(tmp_path):
    p, sor = _onboarded(tmp_path)
    p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    _clear(p, "HFA-2001")
    ins = p.repo.load_record("HFA-2001", "sor_updates", "draw-19")["instructions"]
    snapshot = sor.export("HFA-2001")
    sor.apply("HFA-2001", ins)  # replay
    assert sor.export("HFA-2001") == snapshot


def test_J6_sor_read_back_mismatch_opens_a_task(tmp_path):
    class Lossy(FileSorAdapter):
        def apply(self, loan_id, instructions):  # simulates an SOR that silently drops one update
            return super().apply(loan_id, [i for i in instructions if i["op"] != "RETIRE_LINE"])
    sor = Lossy(tmp_path / "sor")
    p = Pipeline(CFG, JsonFileRepository(tmp_path / "store"), FolderFeeds(S / "feeds"), sor=sor)
    p.onboard("HFA-2001", S / "onboarding_d18/HFA-2001_sor_export_after_draw18.csv", 18,
              S / "onboarding_d18/HFA-2001_draw18.xlsx")
    p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    sub = _clear(p, "HFA-2001")
    assert sub["state"] == "POSTED" and [t.kind for t in p.tasks.list("OPEN")] == ["SOR_SYNC_MISMATCH"]


def test_J7_large_draw_needs_sign_off():
    cfg = CFG.override(stp={**CFG.s("stp"), "auto_post_max_draw_cents": c(1000000)})
    p = Pipeline(cfg, InMemoryRepository(), FolderFeeds(S / "feeds"))
    p.onboard("HFA-1001", S / "onboarding/HFA-1001_approved_budget.csv")
    p.receive(S / "inbox/HFA-1001_draw07.xlsx")
    for t in p.tasks.list("OPEN"):
        k = t.title.split(":")[0]
        pay = {"approval_ref": "X"} if t.evidence.get("requires_approval_ref") else {}
        p.decide("HFA-1001", t.task_id, "APPROVE", "maria", pay)
        if t.approvals_needed == 2:
            p.decide("HFA-1001", t.task_id, "APPROVE", "dev", pay)
    for t in p.tasks.list("OPEN"):
        if t.title == "LINE_OVERRUN":
            p.decide("HFA-1001", t.task_id, "ADJUST_DRAW", "maria", {"amount_cents": c(32000)})
    assert [t.kind for t in p.tasks.list("OPEN")] == ["DRAW_SIGNOFF"]


def test_J8_an_approval_is_used_once(tmp_path):
    p, _ = _onboarded(tmp_path)
    p.receive(S / "inbox/HFA-2001_draw19.xlsx")
    _clear(p, "HFA-2001")
    assert "CO-21" in p._used_approval_refs("HFA-2001") and not p._open_approvals("HFA-2001")
