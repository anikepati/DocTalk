"""Draw validation rule engine: borrower's latest draw vs free-form, LOB-keyed system lines."""
from pathlib import Path

import pytest
from openpyxl import load_workbook

from budget_recon.config import load_config
from budget_recon.extract import ExcelExtractor
from budget_recon.io import read_lines
from budget_recon.models import Line
from budget_recon.money import to_cents as c
from budget_recon.normalize import Normalizer
from budget_recon.validate import DrawValidator

ROOT = Path(__file__).resolve().parent.parent
CFG = load_config()


def S(key, label, budget, prior=0):
    return Line(key, label, c(budget), c(prior))


def B(key, label, budget, prior=0, current=0):
    return Line(key, label, c(budget), c(prior), c(current))


def run(system, borrower, cfg=CFG, approvals=()):
    return DrawValidator(cfg).validate(system, borrower, "T", 1, approvals)


def row(res, label):
    return [l for l in res.lines if l.borrower_label == label][0]


# ---------------------------------------------------------------- label variance and typos
@pytest.mark.parametrize("system_label,borrower_label", [
    ("Site Work - per CO #2", "Sitework"),                       # free-text note
    ("Finishes (rev 9/14)", "Finishes"),                         # revision note + date
    ("Elecrtical", "Electrical"),                                # transposed letters
    ("Plumbng", "Plumbing"),                                     # missing letter
    ("Masonary", "Masonry"),                                     # extra letter
    ("Drs & Windows", "Doors & Windows"),                        # abbreviation
    ("GC OH&P / Gen Req", "General Contractor Overhead & Profit"),
    ("Constr. Int. Reserve", "Construction Interest Reserve"),
    ("Bldrs Risk Ins", "Builder's Risk Insurance"),
    ("CONCRETE", "Concrete"),                                    # case
    ("3. Legal", "Legal"),                                       # leading line number
])
def test_free_form_label_variants_match_with_no_exception(system_label, borrower_label):
    res = run([S("S1", system_label, 500000, 100000), S("S2", "Other", 10000)],
              [B("B1", borrower_label, 500000, 100000, 5000), B("B2", "Other", 10000)])
    r = row(res, borrower_label)
    assert r.status == "OK" and r.system_labels == [system_label] and r.rule_id in ("M02", "M03")


def test_explanation_shows_how_each_label_was_read():
    n = Normalizer(CFG)
    assert n.explain("Site Work - per CO #2") == ["removed note 'per co #2'"]
    assert "spelling 'elecrtical' -> 'electrical'" in n.explain("Elecrtical")
    assert "'drs' -> 'doors'" in n.explain("Drs & Windows")


def test_same_amounts_different_wording_matches_on_numbers():
    res = run([S("S1", "Owner's rep", 72000, 18000), S("S2", "Legal", 50000)],
              [B("B1", "Development consultant", 72000, 18000), B("B2", "Legal", 50000)])
    r = row(res, "Development consultant")
    assert r.rule_id == "M03" and r.match_type == "SAME_AMOUNTS_LABEL_VARIANT"
    assert r.status == "REVIEW"  # numbers agree, words don't: a person confirms once


def test_label_typo_beyond_spelling_with_changed_amount():
    res = run([S("S1", "Arcitectural Svcs", 180000, 150000)], [B("B1", "Architectural Services", 190000, 150000)])
    r = row(res, "Architectural Services")
    assert r.rule_id == "M06" and r.budget_diff == c(10000) and r.status == "EXCEPTION"


# ---------------------------------------------------------------- summation
def test_system_line_is_sum_of_borrower_lines():
    res = run([S("S1", "A&E + Survey", 287500, 201000)],
              [B("B1", "Architect", 180000, 150000), B("B2", "Engineering", 95000, 38500),
               B("B3", "Survey", 12500, 12500)])
    assert {l.rule_id for l in res.lines} == {"M05"} and {l.status for l in res.lines} == {"OK"}


def test_borrower_line_is_sum_of_system_lines():
    res = run([S("S1", "Architect", 180000, 150000), S("S2", "Engineering", 95000, 38500)],
              [B("B1", "Architecture & Engineering", 275000, 188500)])
    r = res.lines[0]
    assert r.rule_id == "M04" and r.match_type == "SUMMATION" and r.system_labels == ["Architect", "Engineering"]


def test_round_numbers_need_every_column_to_tie():
    system = [S("S1", "3rd Pty Rpts", 75000, 55000), S("S2", "Mkt Study (per memo)", 50000, 50000)]
    borrower = [B("B1", "Appraisal", 25000, 25000), B("B2", "Environmental", 50000, 30000),
                B("B3", "Market Study", 50000, 50000)]
    good = run(system, borrower)
    assert sorted(row(good, x).system_labels[0] for x in ("Appraisal", "Environmental")) == ["3rd Pty Rpts"] * 2
    budget_only = run([system[0]], borrower, CFG.override(change_columns=["budget"]))
    assert {l.match_type for l in budget_only.lines} == {"AMBIGUOUS"}  # refuses to guess


# ---------------------------------------------------------------- amount typos vs real changes
def test_transposed_budget_is_a_typo_not_a_budget_change():
    res = run([S("S1", "Permits & Impact", 42850, 48250)], [B("B1", "Permits & Impact Fees", 48250, 48250)])
    r = res.lines[0]
    assert r.budget_diff_type == "PROBABLE_SYSTEM_TYPO (TRANSPOSED_DIGITS)"
    codes = [e.reason_code for e in res.exceptions]
    assert "PROBABLE_KEYING_ERROR" in codes
    assert not {"IMPLIED_REALLOCATION", "UNAPPROVED_BUDGET_CHANGE", "UNAPPROVED_NET_CHANGE"} & set(codes)


def test_dropped_digit_in_prior_draws():
    res = run([S("S1", "Legal (outside counsel)", 165000, 9900)], [B("B1", "Legal", 165000, 99000)])
    assert res.lines[0].prior_diff_type == "PRIOR_MISMATCH (DROPPED_DIGIT in system value)"


def test_single_wrong_digit_stays_a_budget_change():
    res = run([S("S1", "Sitework", 640000), S("S2", "Contingency - hard", 100000)],
              [B("B1", "Sitework", 650000), B("B2", "Hard Cost Contingency", 90000)])
    assert row(res, "Sitework").budget_diff_type == "BUDGET_CHANGE (or single-digit typo)"
    assert "IMPLIED_REALLOCATION" in [e.reason_code for e in res.exceptions]


def test_recorded_approval_marks_change_as_approved():
    appr = [{"approval_ref": "CO-14", "cost_code": "T-09", "delta": c(36000)},
            {"approval_ref": "CO-14", "cost_code": "HC-0900", "delta": c(-36000)}]
    res = run([S("S1", "Finishes (rev 9/14)", 1864000), S("S2", "Constuction Contg", 550000)],
              [B("B1", "Finishes", 1900000), B("B2", "Hard Cost Contingency", 514000)], approvals=appr)
    assert {l.budget_diff_type for l in res.lines} == {"APPROVED_CHANGE (CO-14)"} and {l.status for l in res.lines} == {"OK"}


# ---------------------------------------------------------------- new and missing lines
def test_new_borrower_line_and_system_line_missing_from_draw():
    res = run([S("S1", "Legal", 50000), S("S2", "Marketing", 90000)],
              [B("B1", "Legal", 50000), B("B2", "Solar PV System", 60000, 0, 15000)])
    assert row(res, "Solar PV System").match_type == "NEW_LINE"
    assert [x["label"] for x in res.system_only] == ["Marketing"]


# ---------------------------------------------------------------- rules are configuration
def test_disabling_a_rule_changes_behaviour_without_code():
    rules = [r for r in CFG.s("match_rules") if r["id"] != "M05"]
    res = run([S("S1", "A&E + Survey", 287500, 201000)],
              [B("B1", "Architect", 180000, 150000), B("B2", "Engineering", 95000, 38500),
               B("B3", "Survey", 12500, 12500)], CFG.override(match_rules=rules))
    assert "M05" not in {l.rule_id for l in res.lines}


# ---------------------------------------------------------------- the sample, end to end
def test_sample_free_form_system_lines_vs_latest_borrower_file(tmp_path):
    borrower = ExcelExtractor().extract(ROOT / "sample/inbox/HFA-1001_draw07.xlsx").lines
    system = read_lines(ROOT / "sample/validation/HFA-1001_system_lines.csv")
    res = DrawValidator(CFG).validate(system, borrower, "HFA-1001", 7)
    s = res.summary
    assert (s["ok"], s["review"], s["exception"], s["system_lines_not_in_draw"]) == (25, 2, 6, 0)
    exc = {l.borrower_label: (l.budget_diff_type or l.prior_diff_type or l.match_type or ",".join(l.issues))
           for l in res.lines if l.status == "EXCEPTION"}
    assert exc["Permits & Impact Fees"].startswith("PROBABLE_SYSTEM_TYPO")
    assert exc["Legal"].startswith("PRIOR_MISMATCH")
    assert exc["Finishes"] == "BUDGET_CHANGE" and exc["Solar PV System"] == "NEW_LINE"
    out = tmp_path / "v.xlsx"
    res.to_excel(out)
    assert load_workbook(out).sheetnames == ["Line results", "System lines not in draw", "Exceptions", "Category tie-out",
                                                  "Rule catalog"]
