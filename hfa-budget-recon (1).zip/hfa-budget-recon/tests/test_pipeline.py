"""Autonomous processing with HITL: the system takes the borrower's latest file and does the full job;
people only decide the tasks policy routes to them."""
import shutil
from pathlib import Path

import pytest
from openpyxl import load_workbook

from budget_recon.config import load_config
from budget_recon.extract import LLMExtractor
from budget_recon.hitl import TaskError
from budget_recon.ledger import InMemoryRepository, JsonFileRepository
from budget_recon.pipeline import FolderFeeds, Pipeline

ROOT = Path(__file__).resolve().parent.parent
S = ROOT / "sample"
CFG = load_config()
L = "HFA-1001"
D7, D8 = S / "inbox/HFA-1001_draw07.xlsx", S / "inbox/HFA-1001_draw08.xlsx"


def pipeline(repo=None, cfg=CFG, extractors=None):
    p = Pipeline(cfg, repo or InMemoryRepository(), FolderFeeds(S / "feeds"), extractors=extractors)
    p.onboard(L, S / "onboarding/HFA-1001_approved_budget.csv")
    return p


def open_tasks(p, kind=None):
    return [t for t in p.tasks.list("OPEN") if kind is None or t.kind == kind]


def by_title(p, prefix):
    return [t for t in open_tasks(p) if t.title.startswith(prefix)][0]


def clear_draw7(p):
    p.decide(L, by_title(p, "SPLIT").task_id, "APPROVE", "maria")
    p.decide(L, by_title(p, "REALLOCATE").task_id, "APPROVE", "maria", {"approval_ref": "CO-15"})
    cd = by_title(p, "CORRECT_DRAWN").task_id
    p.decide(L, cd, "APPROVE", "maria", {"approval_ref": "WIRE-2026-0612"})
    p.decide(L, cd, "APPROVE", "dev", {"approval_ref": "WIRE-2026-0612"})
    over = open_tasks(p, "DRAW_EXCEPTION")[0]
    return p.decide(L, over.task_id, "ADJUST_DRAW", "maria", {"amount_cents": 3200000})


def test_policy_routes_only_what_it_cannot_decide():
    p = pipeline()
    sub = p.receive(D7)
    assert sub["state"] == "AWAITING_REVIEW" and sub["stage"] == "restructure"
    routes = {r["route"] for r in sub["routing"]}
    assert routes == {"AUTO", "HUMAN"} and sum(r["route"] == "AUTO" for r in sub["routing"]) == 22
    titles = sorted(t.title.split(":")[0] for t in open_tasks(p))
    assert titles == ["CORRECT_DRAWN", "REALLOCATE", "SPLIT"]
    # the change order on file (CO-14) let the $36,000 move through without a person
    assert any(r["kind"] == "REALLOCATE" and r["route"] == "AUTO" for r in sub["routing"])
    assert p.repo.current(L).version_no == 1  # nothing committed until the review is done


def test_controls_on_decisions():
    p = pipeline()
    p.receive(D7)
    with pytest.raises(TaskError, match="approval_ref"):
        p.decide(L, by_title(p, "REALLOCATE").task_id, "APPROVE", "maria")
    cd = by_title(p, "CORRECT_DRAWN").task_id
    p.decide(L, cd, "APPROVE", "maria", {"approval_ref": "WIRE-1"})
    with pytest.raises(TaskError, match="second, different approver"):
        p.decide(L, cd, "APPROVE", "maria", {"approval_ref": "WIRE-1"})
    with pytest.raises(TaskError, match="named person"):
        p.decide(L, cd, "APPROVE", "system", {"approval_ref": "WIRE-1"})
    with pytest.raises(TaskError, match="note"):
        p.decide(L, by_title(p, "SPLIT").task_id, "REJECT", "maria")


def test_full_process_draw7_with_review_then_draw8_straight_through(tmp_path):
    p = pipeline(JsonFileRepository(tmp_path))
    p.receive(D7)
    sub = clear_draw7(p)
    assert sub["state"] == "POSTED" and sub["draw_total"] == 158172000 and sub["human_tasks"] == 4
    assert [h["state"] for h in sub["history"]] == ["RECEIVED", "EXTRACTED", "PLANNED", "RESTRUCTURED", "POSTED"]
    s8 = p.receive(D8)
    assert s8["state"] == "POSTED" and s8["human_tasks"] == 0 and s8["draw_total"] == 147600000
    assert p.receive(D8)["submission_id"] == s8["submission_id"]  # same file again: idempotent
    assert p.repo.current(L).version_no == 4


def test_reviewer_returns_draw_to_borrower_and_ledger_is_untouched():
    p = pipeline()
    p.receive(D7)
    sub = p.decide(L, by_title(p, "REALLOCATE").task_id, "REJECT", "maria",
                   {"note": "Solar PV is not in the approved scope; send change order request"})
    assert sub["state"] == "RETURNED_TO_BORROWER" and "Solar" in sub["returned_reasons"][0]["note"]
    assert not open_tasks(p)  # remaining tasks cancelled
    assert p.repo.current(L).version_no == 1
    assert any(e["type"] == "submission.returned" for e in p.events.events)


def test_bad_extraction_goes_to_review_first(tmp_path):
    bad = tmp_path / "HFA-1001_draw07.xlsx"
    shutil.copy(D7, bad)
    wb = load_workbook(bad)
    ws = wb.active
    for row in ws.iter_rows(min_row=7):
        if row[1].value == "Legal":
            row[4].value = 825.0  # this-period amount mistyped in the file itself
    wb.save(bad)
    p = pipeline()
    sub = p.receive(bad)
    assert sub["stage"] == "extraction" and open_tasks(p, "EXTRACTION_REVIEW")
    sub = p.decide(L, open_tasks(p, "EXTRACTION_REVIEW")[0].task_id, "RETURN_TO_BORROWER", "maria",
                   {"note": "Legal line does not foot; resubmit"})
    assert sub["state"] == "RETURNED_TO_BORROWER"


def test_rejections_not_onboarded_and_already_posted(tmp_path):
    p = Pipeline(CFG, InMemoryRepository(), FolderFeeds(S / "feeds"))
    assert p.receive(D7)["reject_reason"]["code"] == "ONBOARDING_REQUIRED"
    p = pipeline()
    p.receive(D7)
    clear_draw7(p)
    other = tmp_path / "resent_draw07.xlsx"
    wb = load_workbook(D7)
    wb.active["A1"] = "Resent by borrower"
    wb.save(other)
    assert p.receive(other)["reject_reason"]["code"] == "DRAW_ALREADY_POSTED"


def test_large_draw_needs_credit_signoff():
    cfg = CFG.override(stp={**CFG.s("stp"), "auto_post_max_draw_cents": 100000000})
    p = pipeline(cfg=cfg)
    p.receive(D7)
    clear_draw7(p)
    sign = open_tasks(p, "DRAW_SIGNOFF")
    assert sign and sign[0].queue == "credit-officer"
    assert p.decide(L, sign[0].task_id, "APPROVE", "credit.lee")["state"] == "POSTED"


def test_lob_entry_is_shadow_only_during_transition():
    p = pipeline()
    sub = p.receive(D7, lob_file=S / "loan_1001/draw_07/lob_entry.csv")
    assert sub["lob_shadow"]["keying_exceptions"] > 0
    sub = clear_draw7(p)
    assert sub["state"] == "POSTED"  # LOB typos did not create tasks or block posting


def test_out_of_sequence_draw_is_flagged():
    p = pipeline()
    p.receive(D7)
    clear_draw7(p)
    sub = p.receive(S / "loan_1001/draw_08/borrower.csv", loan_id=L, draw_no=10)
    assert any(t.ref == "SEQUENCE" for t in open_tasks(p))


def test_llm_extractor_output_is_validated_like_any_other(tmp_path):
    pdf = tmp_path / "draw.pdf"
    pdf.write_bytes(b"%PDF-1.4 fake")

    def fake_gemini(prompt, data, mime, schema):
        assert mime == "application/pdf" and "Do not invent lines" in prompt
        return {"loan_id": "HFA-1001", "draw_no": 7, "lines": [
            {"description": "Legal", "section": "Soft Costs", "scheduled_value": "165,000.00",
             "previous": "99,000.00", "this_period": "8,250.00", "balance": "57,750.00", "page": 2},
            {"description": "Survey", "section": "Soft Costs", "scheduled_value": "12,500.00",
             "previous": "12,500.00", "this_period": "0", "balance": "0", "page": 2}],
            "totals": {"scheduled_value": "177,500.00", "previous": "111,500.00", "this_period": "8,500.00"}}

    ext = LLMExtractor(fake_gemini).extract(pdf)
    assert ext.lines[0].category == "SOFT" and ext.lines[0].source_ref == "draw.pdf:page 2"
    assert [c["code"] for c in ext.checks] == ["GRAND_TOTAL_MISMATCH"]  # model total off by $250: caught
