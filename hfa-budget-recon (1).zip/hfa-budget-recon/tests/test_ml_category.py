"""ML fallback for categories: only fills UNK, abstains on uninformative labels, never overrides rules."""
from pathlib import Path

import pytest

from budget_recon.config import load_config
from budget_recon.engine import ReconEngine
from budget_recon.models import Line, LoanInput
from budget_recon.money import to_cents as c

ROOT = Path(__file__).resolve().parent.parent
MODEL = ROOT / "ml/model/category_model.joblib"
pytestmark = pytest.mark.skipif(not MODEL.exists(), reason="run python ml/train.py first")


def cfg():
    return load_config().override(ml_category={"model": str(MODEL), "min_confidence": 0.9})


def test_model_fills_unknown_category_and_abstains_on_generic_labels():
    system = [Line("S1", "Third party reports", c(75000), c(55000)), Line("S2", "Misc 1", c(1650000), c(495000)),
              Line("S3", "Construction contract", c(18000000), c(6000000))]
    rep = ReconEngine(cfg()).reconcile(LoanInput("T", system, [Line("B1", "Legal", c(1000))]))
    got = {m["label"]: m for m in rep.ml_categorized}
    assert got["Third party reports"]["category"] == "SOFT" and not got["Third party reports"]["abstained"]
    assert got["Misc 1"]["abstained"] and got["Misc 1"]["category"] is None
    assert {"CATEGORY_BY_MODEL", "CATEGORY_UNKNOWN"} <= {e.reason_code for e in rep.exceptions}


def test_model_never_overrides_a_rule_based_category():
    system = [Line("S1", "Soft Contg", c(150000), category="HARD")]  # LOB's category stays; misfile logic owns it
    rep = ReconEngine(cfg()).reconcile(LoanInput("T", system, [Line("B1", "Soft Cost Contingency", c(150000))]))
    assert rep.ml_categorized == []


def test_without_configuration_the_engine_is_unchanged():
    rep = ReconEngine(load_config()).reconcile(LoanInput("T", [Line("S1", "Third party reports", c(1))],
                                                         [Line("B1", "Legal", c(1))]))
    assert rep.ml_categorized == []


def test_implausible_amount_lowers_confidence():
    from budget_recon.ml_category import CategoryModel
    from budget_recon.normalize import Normalizer
    m = CategoryModel(MODEL, Normalizer(load_config()), 0.9)
    assert m.predict("Third party reports", "", 0.003)["category"] == "SOFT"
    assert m.predict("Third party reports", "", 0.043)["abstained"]  # a reports line at 4% of the budget is suspicious
