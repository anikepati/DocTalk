"""One test per restructuring case, plus invariants, workflow controls and the draw 7 -> draw 8 lifecycle."""
from pathlib import Path

import pytest

from budget_recon.config import load_config
from budget_recon.engine import ReconEngine
from budget_recon.io import load_loan
from budget_recon.ledger import ConcurrencyError, InMemoryRepository, JsonFileRepository, bootstrap_version
from budget_recon.models import Line, LoanInput
from budget_recon.money import to_cents as c
from budget_recon.normalize import Normalizer
from budget_recon.planner import Planner
from budget_recon.posting import PostingError, post_draw
from budget_recon.restructure import ChangeSet, ChangeSetError, Op, apply_change_set
from budget_recon.service import ReconService, WorkflowError

ROOT = Path(__file__).resolve().parent.parent
CFG = load_config()
NORM = Normalizer(CFG)


def ledger(*rows, sources=None):
    return bootstrap_version("T", [Line(f"A{i}", lab, c(b), c(d)) for i, (lab, b, d) in enumerate(rows, 1)],
                             NORM, sources)


def B(key, label, budget, prior=0, current=0):
    return Line(key, label, c(budget), c(prior), c(current))


def plan(v, borrower, cfg=CFG, approvals=()):
    rep = ReconEngine(cfg).reconcile(LoanInput("T", None, borrower), ledger=v)
    return rep, Planner(cfg).plan(v, rep, approvals)


def kinds(cs):
    return [o.kind for o in cs.ops]


def money_ops(cs):
    return [o for o in cs.ops if o.kind in ("REALLOCATE", "FUNDING_CHANGE", "RECLASS_DRAWS", "CORRECT_DRAWN")]


def commit(v, cs):
    nv, refs = apply_change_set(v, cs)
    return nv, refs


def by_label(v, label):
    return [l for l in v.active() if l.label == label][0]


def realign_and_check(v, borrower):
    """After a commit, the same borrower file must match the ledger 1:1 and need no further restructuring."""
    rep, cs = plan(v, borrower)
    assert {g.pass_name for g in rep.change.groups} <= {"ledger_alias", "ledger_group_alias"}
    assert not rep.change.unmatched_left and not rep.change.unmatched_right
    assert not cs.ops, [o.describe() for o in cs.ops]


# ---------------------------------------------------------------- C1 merged line in the baseline -> SPLIT
def test_c1_split_takes_budget_and_prior_draws_line_by_line():
    v = ledger(("Arch/Eng", 275000, 100000), ("Legal", 50000, 0))
    borrower = [B("B1", "Architect", 180000, 60000), B("B2", "Engineering", 95000, 40000), B("B3", "Legal", 50000)]
    _, cs = plan(v, borrower)
    assert kinds(cs)[0] == "SPLIT" and not money_ops(cs)
    nv, refs = commit(v, cs)
    arch, eng = nv.lines[refs["new:B1"]], nv.lines[refs["new:B2"]]
    assert (arch.budget, arch.drawn, eng.budget, eng.drawn) == (c(180000), c(60000), c(95000), c(40000))
    assert arch.lineage == ("T-L0001",) and nv.lines["T-L0001"].status == "RETIRED"
    realign_and_check(nv, borrower)


# ---------------------------------------------------------------- C2 borrower merges ledger lines
def test_c2a_merge_policy_adopts_borrower_structure():
    v = ledger(("Architect", 180000, 60000), ("Engineering", 95000, 40000))
    borrower = [B("B1", "Architecture & Engineering", 275000, 100000)]
    _, cs = plan(v, borrower)
    assert kinds(cs) == ["MERGE"]
    nv, refs = commit(v, cs)
    m = nv.lines[refs["new:B1"]]
    assert (m.budget, m.drawn, m.lineage) == (c(275000), c(100000), ("T-L0001", "T-L0002"))
    realign_and_check(nv, borrower)


def test_c2b_keep_system_detail_allocates_draw_across_the_group():
    cfg = CFG.override(restructure={"on_borrower_merge": "keep_system_detail"})
    v = ledger(("Architect", 180000, 60000), ("Engineering", 95000, 40000))
    borrower = [B("B1", "Architecture & Engineering", 275000, 100000, 35000)]
    _, cs = plan(v, borrower, cfg)
    assert kinds(cs) == ["ADD_GROUP_ALIAS"]
    nv, _ = commit(v, cs)
    rep = ReconEngine(cfg).reconcile(LoanInput("T", None, borrower), ledger=nv)
    posted, rec = post_draw(nv, rep.borrower_lines, 1)
    # remaining 120,000 and 55,000 -> 35,000 split 24,000 / 11,000 by remaining balance
    assert [x["amount"] for x in rec.lines] == [c(24000), c(11000)]
    assert posted.total_drawn() == c(135000)


# ---------------------------------------------------------------- C3 wording only
def test_c3_label_variant_needs_alias_only():
    v = ledger(("Constr. Int. Reserve", 1200000, 410000))
    _, cs = plan(v, [B("B1", "Construction Interest Reserve", 1200000, 410000)])
    assert set(kinds(cs)) <= {"ADD_ALIAS", "RELABEL"} and not money_ops(cs)


# ---------------------------------------------------------------- C4 new line funded by contingency
def test_c4_new_line_funded_from_contingency_and_next_draw_aligns():
    v = ledger(("Construction Contract", 3000000, 1000000), ("Hard Cost Contingency", 150000, 0))
    borrower = [B("B1", "Construction Contract", 3000000, 1000000), B("B2", "Hard Cost Contingency", 90000),
                B("B3", "Solar PV System", 60000, 0, 15000)]
    rep, cs = plan(v, borrower)
    assert "DRAW_ON_UNAPPROVED_LINE" in [e.reason_code for e in rep.exceptions]  # correct before restructuring
    assert kinds(cs) == ["CREATE", "REALLOCATE"]
    assert cs.ops[1].params == {"from": "T-L0002", "to": "new:B3", "amount": c(60000)}
    nv, _ = commit(v, cs)
    realign_and_check(nv, borrower)
    posted, rec = post_draw(nv, ReconEngine(CFG).reconcile(LoanInput("T", None, borrower), ledger=nv).borrower_lines, 1)
    assert rec.total == c(15000)


# ---------------------------------------------------------------- C5 new line with new money
def test_c5_net_increase_becomes_funding_change_and_updates_sources():
    v = ledger(("Construction Contract", 3000000, 0), sources=c(3000000))
    borrower = [B("B1", "Construction Contract", 3000000), B("B2", "Solar PV System", 60000)]
    _, cs = plan(v, borrower)
    assert kinds(cs) == ["CREATE", "FUNDING_CHANGE"]
    nv, _ = commit(v, cs)
    assert nv.total_budget() == c(3060000) and nv.total_sources == c(3060000)


# ---------------------------------------------------------------- C6 new line that already has draws
def test_c6_new_line_with_prior_draws_reclasses_history_not_cash():
    v = ledger(("Construction Contract", 3000000, 1000000))
    borrower = [B("B1", "Construction Contract", 2940000, 975000), B("B2", "Solar PV System", 60000, 25000, 5000)]
    _, cs = plan(v, borrower)
    assert kinds(cs) == ["CREATE", "RECLASS_DRAWS", "REALLOCATE"]
    nv, refs = commit(v, cs)
    assert nv.total_drawn() == v.total_drawn()  # disbursed cash unchanged
    assert nv.lines[refs["new:B2"]].drawn == c(25000)
    realign_and_check(nv, borrower)


# ---------------------------------------------------------------- C7 / C8 dropped lines
def test_c7_dropped_line_without_draws_is_retired_and_budget_released():
    v = ledger(("Marketing", 90000, 0), ("Soft Cost Contingency", 150000, 0))
    _, cs = plan(v, [B("B1", "Soft Cost Contingency", 240000)])
    assert kinds(cs) == ["REALLOCATE", "RETIRE"]
    nv, _ = commit(v, cs)
    assert nv.lines["T-L0001"].status == "RETIRED" and nv.lines["T-L0002"].budget == c(240000)


def test_c8_dropped_line_with_draws_is_closed_never_erased():
    v = ledger(("Marketing", 90000, 30000), ("Soft Cost Contingency", 150000, 0))
    _, cs = plan(v, [B("B1", "Soft Cost Contingency", 210000)])
    assert "CLOSE" in kinds(cs) and cs.open_issues[0]["code"] == "DROPPED_LINE_HAS_DRAWS"
    nv, _ = commit(v, cs)
    mk = nv.lines["T-L0001"]
    assert (mk.status, mk.budget, mk.drawn) == ("CLOSED", c(30000), c(30000))
    assert nv.total_drawn() == v.total_drawn()


# ---------------------------------------------------------------- C9 missing disbursement record
def test_c9_prior_draw_gap_needs_evidence_before_approval():
    repo = InMemoryRepository()
    svc = ReconService(CFG, repo)
    v = ledger(("Construction Interest Reserve", 1200000, 398000))
    repo.save(v)
    rep, cs = plan(v, [B("B1", "Construction Interest Reserve", 1200000, 410000)])
    assert kinds(cs) == ["CORRECT_DRAWN"]
    svc.submit(cs, "maker")
    with pytest.raises(WorkflowError, match="approval reference"):
        svc.approve(cs, "checker")
    svc.approve(cs, "checker", approval_refs={0: "WIRE-2026-0612"})
    assert svc.commit(cs).total_drawn() == c(410000)


# ---------------------------------------------------------------- C10 category change
def test_c10_category_change_is_explicit_and_needs_approval():
    v = ledger(("Marketing", 90000, 0))
    line = B("B1", "Marketing", 90000)
    line.category = "HARD"
    _, cs = plan(v, [line])
    op = [o for o in cs.ops if o.kind == "RECATEGORIZE"][0]
    assert op.requires_approval and op.params["category"] == "HARD"


# ---------------------------------------------------------------- C11 ambiguity blocks approval
def test_c11_ambiguous_group_blocks_approval():
    cfg = CFG.override(change_columns=["budget"])
    v = ledger(("Third Party Reports", 75000, 0))
    borrower = [B("B1", "Appraisal", 25000), B("B2", "Environmental", 50000), B("B3", "Market Study", 50000)]
    _, cs = plan(v, borrower, cfg)
    assert cs.open_issues and cs.open_issues[0]["code"] == "AMBIGUOUS_CONSOLIDATION"
    repo = InMemoryRepository()
    repo.save(v)
    svc = ReconService(cfg, repo)
    svc.submit(cs, "maker")
    with pytest.raises(WorkflowError, match="unresolved planning issues"):
        svc.approve(cs, "checker", overrides={i: "test" for i in range(len(cs.ops))})


# ---------------------------------------------------------------- C12 G703 detail changes need no restructuring
def test_c12_new_trade_line_is_absorbed_by_rollup():
    v = ledger(("Construction Contract", 3000000, 500000))
    borrower = [B("T1", "Concrete", 1000000, 300000), B("T2", "Framing", 1600000, 200000),
                B("T3", "Elevator", 400000, 0)]
    _, cs = plan(v, borrower)
    assert not money_ops(cs) and "SPLIT" not in kinds(cs)


# ---------------------------------------------------------------- invariants and controls
def test_invariant_split_must_conserve_money():
    v = ledger(("Arch/Eng", 275000, 100000))
    bad = ChangeSet("CS-x", "T", 1, [Op("SPLIT", {"source": "T-L0001", "children": [
        {"ref": "new:1", "label": "Architect", "budget": c(180000), "drawn": c(60000)},
        {"ref": "new:2", "label": "Engineering", "budget": c(90000), "drawn": c(40000)}]})])
    with pytest.raises(ChangeSetError, match="I4"):
        apply_change_set(v, bad)


def test_invariant_cash_cannot_vanish_without_a_correction_op():
    v = ledger(("A", 1000, 500), ("B", 1000, 0))
    bad = ChangeSet("CS-x", "T", 1, [Op("RECLASS_DRAWS", {"from": "T-L0001", "to": "T-L0002", "amount": c(600)})])
    with pytest.raises(ChangeSetError, match="negative"):
        apply_change_set(v, bad)


def test_stale_base_version_and_concurrent_save_are_rejected():
    v = ledger(("A", 1000, 0))
    with pytest.raises(ChangeSetError, match="I1"):
        apply_change_set(v, ChangeSet("CS-x", "T", 7, []))
    repo = InMemoryRepository()
    repo.save(v)
    with pytest.raises(ConcurrencyError):
        repo.save(v)


def test_maker_cannot_check_and_commit_is_idempotent():
    repo = InMemoryRepository()
    v = ledger(("Arch/Eng", 275000, 100000))
    repo.save(v)
    svc = ReconService(CFG, repo)
    _, cs = plan(v, [B("B1", "Architect", 180000, 60000), B("B2", "Engineering", 95000, 40000)])
    svc.submit(cs, "ana")
    with pytest.raises(WorkflowError, match="different"):
        svc.approve(cs, "ana")
    svc.approve(cs, "raj")
    v2 = svc.commit(cs)
    assert svc.commit(cs).version_no == v2.version_no == 2  # replay returns the same version


def test_posting_refuses_misaligned_structure_and_double_posting():
    v = ledger(("Arch/Eng", 275000, 100000))
    borrower = [B("B1", "Architect", 180000, 60000, 5000), B("B2", "Engineering", 95000, 40000)]
    lines = ReconEngine(CFG).reconcile(LoanInput("T", None, borrower), ledger=v).borrower_lines
    with pytest.raises(PostingError, match="STRUCTURE_NOT_ALIGNED"):
        post_draw(v, lines, 1)
    _, cs = plan(v, borrower)
    nv, _ = apply_change_set(v, cs)
    posted, _ = post_draw(nv, lines, 1)
    with pytest.raises(PostingError, match="already posted"):
        post_draw(posted, lines, 1)


# ---------------------------------------------------------------- end-to-end lifecycle, file-backed store
def test_lifecycle_draw7_restructure_post_then_draw8_aligns(tmp_path):
    svc = ReconService(CFG, JsonFileRepository(tmp_path))
    d7 = load_loan(ROOT / "sample/loan_1001/draw_07")
    rep = svc.identify(d7)
    cs = svc.plan(d7, rep)
    assert {"SPLIT", "CREATE", "REALLOCATE", "CORRECT_DRAWN"} <= set(kinds(cs))
    svc.submit(cs, "maker.ana")
    svc.approve(cs, "checker.raj", approval_refs={i: ("WIRE-2026-0612" if o.kind == "CORRECT_DRAWN" else "CO-14")
                                                  for i, o in enumerate(cs.ops) if o.requires_approval})
    v2 = svc.commit(cs)
    assert v2.total_budget() == svc.repo.get("HFA-1001", 1).total_budget()  # reallocations only

    rep2 = svc.identify(d7)
    assert {g.pass_name for g in rep2.change.groups} == {"ledger_alias"}
    with pytest.raises(WorkflowError, match="unresolved"):
        svc.post(d7, 7)
    for e in rep2.exceptions:
        if e.reason_code == "LINE_OVERRUN":
            svc.resolve("HFA-1001", 7, e.exception_id, "ADJUST_DRAW", "raj", "cap at remaining", c(32000), "B27")
        elif e.blocks_posting:
            svc.resolve("HFA-1001", 7, e.exception_id, "CORRECTED", "ana", "LOB entry fixed")
    v3, rec = svc.post(d7, 7)
    assert rec.total == c(1581720)

    d8 = load_loan(ROOT / "sample/loan_1001/draw_08")
    rep8 = svc.identify(d8)
    assert rep8.can_post and not rep8.exceptions
    assert svc.plan(d8, rep8).status == "NOT_NEEDED"
    v4, rec8 = svc.post(d8, 8)
    assert rec8.total == c(1476000) and v4.version_no == 4
