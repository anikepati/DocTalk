from pathlib import Path

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi.testclient import TestClient  # noqa: E402

import budget_recon.api as api  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def test_api_plan_commit_post_round_trip(tmp_path, monkeypatch):
    monkeypatch.setenv("RECON_STORE", str(tmp_path))
    api._svc = None
    client = TestClient(api.app)
    d7 = str(ROOT / "sample/loan_1001/draw_07")
    r = client.post("/draws/plan", json={"folder": d7}).json()
    cs = r["change_set"]
    refs = {str(i): "CO-14" for i, o in enumerate(cs["ops"]) if o["requires_approval"]}
    # posting before resolving exceptions is refused with 409
    assert client.post("/draws/post", json={"folder": d7}).status_code == 409
    c = client.post(f"/loans/HFA-1001/change-sets/{cs['change_set_id']}/commit",
                    json={"maker": "ana", "checker": "raj", "approval_refs": refs})
    assert c.status_code == 200 and c.json()["ledger_version"] == 2
    same = client.post(f"/loans/HFA-1001/change-sets/{cs['change_set_id']}/commit",
                       json={"maker": "ana", "checker": "raj", "approval_refs": refs})
    assert same.json()["ledger_version"] == 2  # idempotent
    led = client.get("/loans/HFA-1001/ledger").json()
    assert led["version_no"] == 2 and any(l["label"] == "Solar PV System" for l in led["lines"].values())


def test_api_operating_model_borrower_file_in_tasks_out(tmp_path, monkeypatch):
    monkeypatch.setenv("RECON_STORE", str(tmp_path))
    monkeypatch.setenv("RECON_FEEDS", str(ROOT / "sample/feeds"))
    api._pipe = None
    client = TestClient(api.app)
    client.post("/loans/HFA-1001/onboard",
                json={"approved_budget_file": str(ROOT / "sample/onboarding/HFA-1001_approved_budget.csv")})
    sub = client.post("/submissions", json={"file": str(ROOT / "sample/inbox/HFA-1001_draw07.xlsx")}).json()
    assert sub["state"] == "AWAITING_REVIEW"
    queue = client.get("/tasks", params={"queue": "construction-lending"}).json()
    assert len(queue) == 3
    realloc = [t for t in queue if t["title"].startswith("REALLOCATE")][0]
    refused = client.post(f"/loans/HFA-1001/tasks/{realloc['task_id']}/decision", json={"action": "approve", "user": "maria"})
    assert refused.status_code == 409  # money move without an approval reference
    out = client.post(f"/loans/HFA-1001/tasks/{realloc['task_id']}/decision",
                      json={"action": "reject", "user": "maria", "note": "not in approved scope"}).json()
    assert out["state"] == "RETURNED_TO_BORROWER"
