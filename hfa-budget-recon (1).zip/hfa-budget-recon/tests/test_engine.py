from pathlib import Path

import pytest

from budget_recon.config import load_config
from budget_recon.engine import ReconEngine
from budget_recon.io import load_loan, mapping_from_group
from budget_recon.matcher import Matcher
from budget_recon.models import Line, LoanInput
from budget_recon.money import to_cents
from budget_recon.normalize import Normalizer
from budget_recon.rules import RuleError, compile_expr
from budget_recon.typos import classify_amount_diff

ROOT = Path(__file__).resolve().parent.parent
CFG = load_config()
NORM = Normalizer(CFG)


def L(key, label, budget, prior=0, current=0, **kw):
    return NORM.normalize(Line(key, label, to_cents(budget), to_cents(prior), to_cents(current), **kw))


def codes(rep):
    return sorted(e.reason_code for e in rep.exceptions)


# ---------------------------------------------------------------- normalization
@pytest.mark.parametrize("raw,code", [
    ("Bldg Construction", "HC-0300"),
    ("Constuction Contingency 5%", "HC-0900"),   # misspelled + percent
    ("GC OH&P", "HC-0800"),
    ("Constr. Int. Reserve", "SC-0700"),
    ("Dev Fee", "SC-0900"),
    ("Builder's Risk Insurance", "SC-0500"),
    ("Land Acq.", "AQ-0100"),
    ("Mktg/Lease Up", "SC-0600"),
    ("HFA / Tax Credit Fees", "SC-0800"),
])
def test_label_to_cost_code(raw, code):
    assert NORM.normalize(Line("x", raw)).cost_code == code


def test_consolidated_label_gets_category_not_a_wrong_code():
    l = NORM.normalize(Line("x", "Arch/Eng/Survey"))
    assert l.cost_code is None and l.category == "SOFT"


# ---------------------------------------------------------------- typo patterns
@pytest.mark.parametrize("expected,keyed,pattern", [
    ("48,250", "42,850", "TRANSPOSED_DIGITS"),
    ("8,250", "825", "DROPPED_DIGIT"),
    ("41,200", "412", "DECIMAL_SHIFT"),
    ("12,000", "17,000", "WRONG_DIGIT"),
    ("8,333.33", "8,333.00", "ROUNDING"),
    ("10,000", "13,750", "UNEXPLAINED"),
])
def test_typo_patterns(expected, keyed, pattern):
    assert classify_amount_diff(to_cents(expected), to_cents(keyed))["pattern"] == pattern


# ---------------------------------------------------------------- consolidation
def _reports_pool():
    borrower = [L("B1", "Appraisal", 25000, 25000, 0), L("B2", "Environmental", 50000, 30000, 10000),
                L("B3", "Market Study", 50000, 50000, 0)]
    lob = [L("X", "Third Party Reports", 75000, 55000, 10000), L("M", "Market Study", 50000, 50000, 0)]
    return borrower, lob


def test_multi_column_consolidation_picks_the_only_group_that_ties_on_every_column():
    borrower, lob = _reports_pool()
    res = Matcher(CFG, ["budget", "prior", "current"], "keying", "T").run(borrower, lob)
    grp = [g for g in res.groups if g.relation == "N:1"][0]
    assert sorted(l.key for l in grp.left) == ["B1", "B2"]
    assert not res.ambiguities


def test_budget_only_matching_is_ambiguous_and_engine_refuses_to_guess():
    borrower, lob = _reports_pool()
    lob = lob[:1]  # LOB also missed Market Study: now 25k+50k can be Env or Market
    res = Matcher(CFG, ["budget"], "keying", "T").run(borrower, lob)
    assert len(res.ambiguities) == 1 and len(res.ambiguities[0]["candidates"]) == 2
    assert not [g for g in res.groups if g.relation == "N:1"]


def test_split_is_detected_one_to_many():
    approved = [L("A", "Sitework", 640000, 200000)]
    borrower = [L("B1", "Site Utilities", 410000, 150000), L("B2", "Paving", 230000, 50000)]
    res = Matcher(CFG, ["budget", "prior"], "change", "T").run(approved, borrower)
    assert res.groups[0].relation == "1:N" and len(res.groups[0].right) == 2


def test_single_column_evidence_never_auto_accepts():
    # first draw: prior and current are zero, so only the budget column carries evidence
    borrower = [L("B1", "Architect", 180000), L("B2", "Engineering", 95000)]
    lob = [L("X", "Arch/Eng", 275000)]
    res = Matcher(CFG, ["budget", "prior", "current"], "keying", "T").run(borrower, lob)
    assert res.groups[0].relation == "N:1"
    assert res.groups[0].confidence < CFG.s("auto_accept_confidence")


# ---------------------------------------------------------------- learned mappings
def test_confirmed_mapping_is_reused_on_next_draw():
    borrower, lob = _reports_pool()
    first = Matcher(CFG, ["budget", "prior", "current"], "keying", "T").run(borrower, lob)
    m = mapping_from_group([g for g in first.groups if g.relation == "N:1"][0], "T", "map-1")
    # next draw: new amounts, same structure
    borrower2 = [L("B1", "Appraisal", 25000, 25000, 0), L("B2", "Environmental", 50000, 40000, 5000),
                 L("B3", "Market Study", 50000, 50000, 0)]
    lob2 = [L("X", "Third Party Reports", 75000, 65000, 5000), L("M", "Market Study", 50000, 50000, 0)]
    res = Matcher(CFG, ["budget", "prior", "current"], "keying", "T").run(borrower2, lob2, [m])
    g = [g for g in res.groups if g.relation == "N:1"][0]
    assert g.pass_name == "learned" and g.confidence == 1.0


# ---------------------------------------------------------------- budget changes
def _change_loan(approvals=()):
    approved = [L("A1", "Construction Contract", 10964000, 6000000), L("A2", "Construction Contingency", 550000, 0)]
    borrower = [L("B1", "Construction Contract", 11000000, 6000000, 100000), L("B2", "Hard Cost Contingency", 514000, 0, 0)]
    return LoanInput("T", approved, borrower, approvals=list(approvals))


def test_unrecorded_reallocation_is_inferred():
    rep = ReconEngine(CFG).reconcile(_change_loan())
    assert "IMPLIED_REALLOCATION" in codes(rep) and not rep.can_post


def test_recorded_approvals_clear_the_reallocation():
    appr = [{"approval_ref": "CO-14", "cost_code": "HC-0300", "delta": to_cents(36000)},
            {"approval_ref": "CO-14", "cost_code": "HC-0900", "delta": to_cents(-36000)}]
    rep = ReconEngine(CFG).reconcile(_change_loan(appr))
    assert "IMPLIED_REALLOCATION" not in codes(rep)
    assert {c["approval_ref"] for c in rep.cleared_changes} == {"CO-14"}


def test_unbalanced_change_is_flagged_line_by_line():
    approved = [L("A1", "Legal", 165000, 99000)]
    borrower = [L("B1", "Legal", 175000, 99000, 0)]
    rep = ReconEngine(CFG).reconcile(LoanInput("T", approved, borrower))
    assert "UNAPPROVED_BUDGET_CHANGE" in codes(rep) and "UNAPPROVED_NET_CHANGE" in codes(rep)


# ---------------------------------------------------------------- trade rollup
def test_g703_trade_lines_roll_up_instead_of_failing():
    approved = [L("A1", "Construction Contract", 3000000, 1000000)]
    borrower = [L("T1", "Concrete", 1000000, 600000, 50000), L("T2", "Framing", 1200000, 300000, 100000),
                L("T3", "Electrical", 800000, 100000, 0)]
    rep = ReconEngine(CFG).reconcile(LoanInput("T", approved, borrower))
    assert rep.change.groups[0].right[0].children == ("T1", "T2", "T3")
    assert rep.can_post


# ---------------------------------------------------------------- rules
def test_overrun_and_extraction_math():
    approved = [L("A1", "HFA Fees", 96000, 64000)]
    borrower = [L("B1", "HFA Fees", 96000, 64000, 40000, reported_balance=to_cents(-7000))]
    rep = ReconEngine(CFG).reconcile(LoanInput("T", approved, borrower))
    assert "LINE_OVERRUN" in codes(rep) and "EXTRACTION_MATH_ERROR" in codes(rep)


def test_rules_missing_data_are_not_evaluated_rather_than_failed():
    approved = [L("A1", "Legal", 1000)]
    rep = ReconEngine(CFG).reconcile(LoanInput("T", approved, [L("B1", "Legal", 1000)]))
    r05 = [r for r in rep.rule_results if r["rule_id"] == "R05"][0]
    assert r05["status"] == "NOT_EVALUATED" and "sources_gap" in r05["missing"]


@pytest.mark.parametrize("bad", ["__import__('os')", "budget.__class__", "open('x')", "(lambda: 1)()"])
def test_rule_expressions_are_sandboxed(bad):
    with pytest.raises((RuleError, SyntaxError)):
        compile_expr(bad)


# ---------------------------------------------------------------- end to end sample
def test_sample_loan_end_to_end():
    rep = ReconEngine(CFG).reconcile(load_loan(ROOT / "sample" / "loan_1001" / "draw_07"))
    blocking = sorted(e.reason_code for e in rep.exceptions if e.severity == "BLOCKING")
    assert blocking == sorted(["LOB_MISSING_LINE", "IMPLIED_REALLOCATION", "PRIOR_DRAW_MISMATCH",
                               "LINE_OVERRUN", "PROBABLE_KEYING_ERROR", "PROBABLE_KEYING_ERROR",
                               "DRAW_ON_UNAPPROVED_LINE"])
    assert not rep.can_post
    assert rep.loan_context["total_budget"] == rep.loan_context["total_sources"]
