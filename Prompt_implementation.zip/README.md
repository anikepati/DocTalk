# credit-extract

Per-entity prompt generation and extraction for 20K credit agreements against 200
ground-truth fields, primitive and derivative.

    pip install -r requirements.txt
    make run

Runs the whole pipeline end to end on a synthetic corpus with no API key: parse →
probe → tier → draft specs → compile prompts → extract → derive → evaluate → propose
optimizations → discover unseen fields. Swap `--provider gemini` for the real thing.

## Documents

| File | What it is |
|---|---|
| `docs/PROCESS_FLOW.md` | 10 mermaid diagrams: system flow, tier decision, extraction sequence, DAG, spec lifecycle, GEPA loop, discovery, ER model, OCP topology, cost shape |
| `RUNBOOK.md` | step-by-step operational instructions with checkpoints |
| `entity-prompt-compiler-implementation.md` | architecture and rationale |

## Layout

```
credit_extract/
├── store.py              SQLite reference store (Postgres DDL in migrations/)
├── ingest/pipeline.py    A — parse, families, sections, defined terms, splits
├── probe/matchers.py     B — matcher cascade, type inference, normalization
├── probe/probe.py        B — probe, diagnostics, rule induction, tiering, few-shots
├── probe/draft_specs.py  C — auto-draft specs from probe output
├── compile/compiler.py   D — spec → prompt, 7 archetypes, lint, DAG check
├── runtime/llm.py        providers: Gemini + deterministic simulator
├── runtime/agents.py     E — retrieval, agent factory, routing, extraction
├── derive/dag.py         F — toposort, whitelisted expression eval, contradictions
├── evaluate/harness.py   E.3/H.1 — per-field metrics + error taxonomy
├── optimize/gepa.py      H — spec mutation proposals, Pareto selection
├── discovery/residuals.py J — residuals, clustering, leverage scoring
└── cli.py                driver; each subcommand maps to a RUNBOOK part
```

## The three rules

1. **T3 fields get code, not prompts.** ~25% of the 200 are deterministic functions of
   other fields. The T3 prompt exists for the audit trail; the code owns the value.
2. **RLM belongs at design time.** Use it once per field to author the derivation
   against known answers, then compile that into a cheap deterministic path. Runtime
   RLM is a budgeted escalation exception.
3. **Optimize specs, not prompts.** `prompts/` is build output, regenerated in CI. The
   moment someone hand-edits a compiled prompt, the registry stops being the source of
   truth.

## Sample run

```
B.3 induced deterministic rules: 1
      total_facility_size = coalesce(revolving_commitment_total, 0)
                          + coalesce(term_loan_a_principal, 0)   coverage=1.0

B.4 tier assignment
      administrative_agent_name   T0_PRIMITIVE_SPAN               1.00
      revolving_commitment_total  T1_PRIMITIVE_NORMALIZED         1.00
      lender_commitments          T2_PRIMITIVE_AGGREGATE          0.00
      total_facility_size         T3_DERIVATIVE_DETERMINISTIC     0.47
      is_covenant_lite            T4_DERIVATIVE_JUDGMENT          0.00
      applicable_margin_current   T5_CROSS_DOC                    0.65
```

The probe classifies every field before a single model call. `total_facility_size` is
recognized as arithmetic and never gets an extraction prompt. `lender_commitments` and
the boolean judgments have hit rate 0.00 — the value is never in the text — which is
exactly the signal that routes them away from span extraction.
