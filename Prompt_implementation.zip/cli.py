"""
End-to-end driver. Each subcommand maps to one Part of the RUNBOOK.

    python -m credit_extract.cli all --families 120
"""
from __future__ import annotations

import argparse
import json
import pathlib
import sys

import yaml

from .compile import compiler as C
from .demo.make_corpus import generate
from .derive.dag import run_dag
from .discovery.residuals import cluster_candidates, compute_residuals, contradiction_candidates
from .evaluate.harness import evaluate, gate_report
from .ingest.pipeline import (extract_defined_terms, load_ground_truth, make_splits,
                              parse_and_load, segment_sections, verify_offsets,
                              verify_split_integrity)
from .optimize.gepa import propose
from .probe.draft_specs import write_drafts
from .probe.probe import (classify, confusable_pairs, field_diagnostics, harvest_few_shots,
                          induce_rules, run_probe)
from .runtime.agents import AgentFactory, run_extraction
from .runtime.llm import GeminiProvider, SimulatedProvider
from .store import Store

CROSS_DOC = {"applicable_margin_current"}
ROOT = pathlib.Path(__file__).resolve().parent.parent


def banner(part: str, title: str):
    print(f"\n{'=' * 78}\n  PART {part} — {title}\n{'=' * 78}")


def load_specs(spec_dir: pathlib.Path) -> dict:
    out = {}
    for p in sorted(spec_dir.glob("*.yaml")):
        s = yaml.safe_load(p.read_text())
        if s.get("status") == "active":
            out[s["field_id"]] = C.with_defaults(s)
    return out


def cmd_all(a):
    store = Store(a.db)

    banner("A", "Corpus foundation")
    docs = generate(a.families, seed=a.seed)
    print(f"  generated  {len(docs)} documents in {a.families} families")
    print("  A.1 parse ", parse_and_load(store, docs))
    bad = verify_offsets(store, docs)
    print(f"  A.1 offset round-trip failures: {bad}   {'OK' if bad == 0 else 'BLOCKED'}")
    if bad:
        return 1
    print("  A.3 sections ", segment_sections(store))
    print("  A.4 defined terms ", extract_defined_terms(store))
    splits = make_splits(docs, seed=a.seed)
    print("  A.5 gt ", load_ground_truth(store, docs, splits))
    straddle = verify_split_integrity(store)
    print(f"  A.5 families straddling splits: {straddle}   {'OK' if straddle == 0 else 'BLOCKED'}")
    if straddle:
        return 1

    banner("B", "Grounding probe and tier classification (no LLM)")
    p = run_probe(store, split=None)          # spans for every split (eval needs dev spans)
    types = p["types"]
    print(f"  B.1 probe: {p['fields']} fields, {p['hits']} span hits")
    diag = field_diagnostics(store, "train")
    rules = induce_rules(store, "train", min_coverage=0.98)
    print(f"  B.3 induced deterministic rules: {len(rules)}")
    for f, r in rules.items():
        print(f"        {f} = {r['expr']}   coverage={r['coverage']}")
    classes = classify(store, diag, rules, types, CROSS_DOC)
    print(f"  B.4 tier assignment ({len(classes)} fields)")
    print(f"        {'field':<28}{'tier':<30}{'hit':>6}{'amb':>6}")
    for f, c in sorted(classes.items(), key=lambda kv: kv[1]["tier"]):
        print(f"        {f:<28}{c['tier']:<30}{c['hit_rate']:>6.2f}{c['ambiguity']:>6.1f}")

    banner("C", "Spec authoring")
    conf = confusable_pairs(store, threshold=0.30)
    print(f"  C.2 confusable pairs from span overlap: {sum(len(v) for v in conf.values()) // 2}")
    written = write_drafts(store, classes, conf, str(ROOT / a.specs))
    print(f"  C.1 drafted {len(written)} new specs (existing human-edited specs untouched)")
    shots_dir = ROOT / a.few_shots
    shots_dir.mkdir(exist_ok=True)
    n_abstain = 0
    for fid in classes:
        fs = harvest_few_shots(store, fid, k=3)
        if not fs:
            continue
        n_abstain += any(s["kind"] == "abstention" for s in fs)
        (shots_dir / f"{fid}.yaml").write_text(yaml.safe_dump({"examples": [
            {"evidence": s["evidence"],
             "output": json.dumps({"field_id": fid, "value": s["value"],
                                   "abstain": s["value"] is None, "confidence": 0.95})}
            for s in fs]}, sort_keys=False))
    print(f"  C.3 few-shot sets harvested; {n_abstain} include an abstention example")

    banner("D", "Compile — one prompt per entity")
    rc = C.main_programmatic(str(ROOT / a.specs), str(ROOT / "templates"),
                             str(shots_dir), str(ROOT / a.prompts))
    manifest = json.loads((ROOT / a.prompts / "manifest.json").read_text())
    for m in manifest["prompts"]:
        store.exec("INSERT OR REPLACE INTO prompt_artifact VALUES (?,?,?,?,?)",
                   (m["field_id"], m["spec_version"], m["prompt_hash"], m["template_id"],
                    (ROOT / a.prompts / m["file"]).read_text()))
    print(f"  D compiled {len(manifest['prompts'])} prompts, "
          f"{len(manifest['dag_errors'])} DAG errors, exit={rc}")

    banner("E", "Extraction on dev + F: derivative DAG")
    specs = load_specs(ROOT / a.specs)
    provider = GeminiProvider(a.model) if a.provider == "gemini" else SimulatedProvider(
        seed=a.seed, error_rate=a.error_rate)
    agents = AgentFactory(store, specs).build()
    res = run_extraction(store, agents, provider, "dev", "rel-demo-001")
    print(f"  E.2 {res['claims']} claims from {res['calls']} calls "
          f"(${res['cost_usd']:.4f}, provider={provider.name})")
    dag = run_dag(store, specs, res["run_id"])
    print(f"  F   {dag['derived']} derived values, order={dag['order']}, "
          f"cycles={len(dag['cycle_errors'])}, contradictions={dag['contradictions']}")

    banner("E.3 / H.1", "Per-field eval and error taxonomy")
    results = evaluate(store, res["run_id"], "dev", types)
    print(f"  {'field':<28}{'n':>4}{'acc':>7}{'IoU':>7}{'abst':>7}  dominant error")
    for f, r in sorted(results.items(), key=lambda kv: kv[1]["norm_exact"]):
        errs = {k: v for k, v in r["errors"].items() if k != "correct"}
        dom = max(errs, key=errs.get) if errs else "-"
        flag = " " if r["gate"] else "!"
        print(f" {flag}{f:<28}{r['n']:>4}{r['norm_exact']:>7.2f}{r['evidence_iou']:>7.2f}"
              f"{r['abstain_rate']:>7.2f}  {dom}")
    gr = gate_report(results)
    print(f"\n  gate: {len(gr['passing'])} passing / {len(gr['failing'])} failing")

    banner("H", "Optimization proposals (spec mutations, not prompt edits)")
    for f in gr["failing"][:4]:
        dom = gr["dominant_error"].get(f, "prompt")
        cands = propose(specs[f], dom, __import__("random").Random(a.seed), k=4)
        print(f"  {f:<28} dominant={dom:<14} -> " +
              ", ".join(c.mutation for c in cands))

    banner("J", "Discovery loop")
    print("  J.1 ", compute_residuals(store, res["run_id"]))
    print("  J.3 ", cluster_candidates(store, min_cluster=5))
    contra = contradiction_candidates(store, res["run_id"])
    print(f"  J   contradiction events: {len(contra)}")
    for r in store.q("""SELECT candidate_id, frequency, leverage, compile_target
                        FROM discovery_candidate ORDER BY leverage DESC LIMIT 5"""):
        print(f"        {r['candidate_id']}  freq={r['frequency']:<5} "
              f"leverage={r['leverage']:<8} -> {r['compile_target']}")

    print(f"\n{'=' * 78}\n  PIPELINE COMPLETE — db={a.db}\n{'=' * 78}")
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="credit_extract")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("all", help="run the full pipeline")
    a.add_argument("--db", default="build/corpus.db")
    a.add_argument("--families", type=int, default=120)
    a.add_argument("--seed", type=int, default=7)
    a.add_argument("--specs", default="specs")
    a.add_argument("--few-shots", dest="few_shots", default="few_shots")
    a.add_argument("--prompts", default="prompts")
    a.add_argument("--templates", default="templates")
    a.add_argument("--provider", choices=["simulated", "gemini"], default="simulated")
    a.add_argument("--model", default="gemini-2.5-flash")
    a.add_argument("--error-rate", type=float, default=0.12)
    a.set_defaults(func=cmd_all)
    args = ap.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
