# AgentForge v2 — Meta-Agent Pipeline Generator

A genuine ADK multi-agent system where **agents generate agents**.

## What it is

AgentForge v2 is a SequentialAgent pipeline whose output is another
SequentialAgent pipeline. You give it an Excel, Markdown, PDF, or image.
It produces production-ready ADK agent code — questions.py, YAML tools,
tool_registry, agents/agent.py — identical to the hand-built EDR QA v7.

## The 7-agent SequentialAgent pipeline

```
Input (Excel / Markdown / image)
     ↓
[1] DocumentReaderAgent     — reads file, extracts raw text + tables
     ↓
[2] PlannerAgent            — reasons about what kind of automation this is,
                              how many agents are needed, what data sources,
                              what the dependency chain looks like.
                              Outputs: AutomationPlan (JSON in conversation)
     ↓
[3] DatabaseDiscoveryAgent  — reads the plan, introspects the actual DB schema
                              (list-tables → get-schema → sample-data),
                              maps plan fields to real columns.
                              Outputs: SchemaMap (JSON in conversation)
     ↓
[4] QuestionsGeneratorAgent — reads plan + schema map, writes questions.py
                              with one dataclass per step, exact check logic,
                              depends_on chains, requires_human flags
     ↓
[5] YAMLToolsGeneratorAgent — reads plan + schema map, writes all YAML files:
                              ingest_tools.yaml (sql/rest_api/sftp),
                              q01..qNN_tools.yaml (empty, ready for extras),
                              report_tools.yaml (python verdict tool)
     ↓
[6] PipelineAssemblerAgent  — reads questions.py + YAMLs from conversation,
                              writes tool_registry.py + agents/agent.py +
                              pipeline_runner.py + main.py + mock data + tests
     ↓
[7] ValidatorAgent          — imports and syntax-checks every generated file,
                              runs the report tests, reports pass/fail.
                              On fail: feeds diff back into conversation so
                              PipelineAssemblerAgent can retry.
```

## Key design decisions

- **Agents talk to agents via conversation history** — each agent reads
  all prior agent output. No context.state. No shared dict. Pure ADK.
- **File tools via python YAML tools** — agents write files by calling
  a `write_file` python tool. The tool is sandboxed but allowed to write
  to the output_dir only. Files are also echoed into the conversation so
  downstream agents can read them without disk access.
- **Database discovery is real** — the DatabaseDiscoveryAgent calls
  `list_tables`, `get_table_schema`, `sample_rows` via MCP Toolbox for
  Databases. If no DB is configured, it generates a sensible mock schema
  from the plan's field names.
- **Validator closes the loop** — if any generated file fails import or
  tests fail, the validator writes a structured diff and the conversation
  continues. The assembler reads the diff and regenerates.

## Usage

```bash
# Run the meta-agent on an Excel file
python main.py --input process.xlsx --name edr_qa --out ./generated/

# Run on a Markdown SOP
python main.py --input sop.md --name rro_qa --out ./generated/

# Dry run — only run up to PlannerAgent, show the plan
python main.py --input process.xlsx --name my_qa --dry-run

# Skip DB discovery (no DB available)
python main.py --input process.xlsx --name my_qa --no-db-discovery
```

## Output structure

```
generated/<name>/
  questions.py           ← source of truth, one dataclass per step
  tool_registry.py       ← N+2 ToolConfig entries, instructions from check_logic
  tool_generator.py      ← regenerates Q YAML files
  yaml_runtime.py        ← connection type system (copied from reference)
  mcp_factory.py         ← MCP server factory (copied from reference)
  agents/
    agent.py             ← SequentialAgent builder
  pipeline_runner.py     ← startup + per-run orchestration
  main.py                ← CLI entry point
  config.py              ← settings
  models.py              ← data models
  audit/
    audit_writer.py
  tools/
    ingest_tools.yaml    ← sql connection + SELECT query
    q01_tools.yaml       ← empty by default
    ...
    qNN_tools.yaml
    report_tools.yaml    ← python build_report
  mock/
    mock_data.json       ← 3 records: PASS, FAIL, NEEDS_HUMAN
    mock_runner.py       ← run immediately without DB
  tests/
    test_pipeline.py     ← full pytest suite
  .env.example
  requirements.txt
```
