"""mcp_factory.py — in-memory MCP server for agentforge tools"""
import json
import yaml
import asyncio
from mcp.server import Server
from mcp import types as mcp_types
from pathlib import Path

MCP_TOOL_TYPES = {"python", "sql", "rest_api", "sftp"}

# Reuse yaml_runtime from the edr_qa reference — it handles execution
import sys
sys.path.insert(0, str(Path(__file__).parent.parent / "edr_qa_v7" / "edr_qa_v7"))
try:
    from yaml_runtime import YAMLFunctionRuntime
except ImportError:
    # Fallback: minimal runtime for python tools only
    class YAMLFunctionRuntime:
        def __init__(self, yaml_path):
            import yaml as _y
            with open(yaml_path) as f:
                raw = _y.safe_load(f)
            self.registry = {fn["id"]: fn for fn in raw.get("functions", [])
                             if fn.get("type") in MCP_TOOL_TYPES}

        def execute(self, function_id, inputs):
            fn = self.registry.get(function_id)
            if not fn:
                raise ValueError(f"Unknown: {function_id}")
            if fn.get("type") == "python":
                return self._run_python(fn["python"]["code"], inputs)
            raise ValueError(f"Unsupported type: {fn.get('type')}")

        def _run_python(self, code, inputs):
            import os, json as _j
            ns = {"inputs": inputs, "result": None,
                  "__builtins__": __builtins__, "os": os, "json": _j}
            exec(compile(code, "<tool>", "exec"), ns)
            return ns["result"]


def _schema(fn):
    props = {}
    req   = []
    for name, s in fn.get("inputs", {}).items():
        p = {"type": {"string":"string","integer":"integer","boolean":"boolean",
                      "object":"object","array":"array"}.get(s.get("type","string"),"string")}
        if "default"     in s: p["default"]     = s["default"]
        if "description" in s: p["description"] = s["description"]
        props[name] = p
        if s.get("required"): req.append(name)
    return {"type": "object", "properties": props, "required": req}


def create_mcp_server(yaml_path: str) -> Server:
    runtime = YAMLFunctionRuntime(yaml_path)
    with open(yaml_path) as f:
        all_fns = yaml.safe_load(f).get("functions", [])
    mcp_fns = [fn for fn in all_fns if fn.get("type") in MCP_TOOL_TYPES]
    server  = Server(Path(yaml_path).stem)

    @server.list_tools()
    async def list_tools():
        return [mcp_types.Tool(name=fn["id"], description=fn.get("description",""),
                               inputSchema=_schema(fn)) for fn in mcp_fns]

    @server.call_tool()
    async def call_tool(name, arguments):
        try:
            loop   = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, lambda: runtime.execute(name, inputs=arguments)
            )
            return [mcp_types.TextContent(type="text",
                                          text=json.dumps(result, default=str, indent=2))]
        except Exception as e:
            return [mcp_types.TextContent(type="text",
                                          text=json.dumps({"error": str(e)}))]
    return server
