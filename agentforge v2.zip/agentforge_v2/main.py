"""
AgentForge v2 — Surface-Aware Multi-Agent Pipeline Generator
=============================================================
Reads any input document. Detects surface type. Generates the
correct multi-agent ADK pipeline for that surface.

Usage:
  # Auto-detect surface from document
  python main.py --input process.xlsx --name edr_qa

  # Provide surface hint to skip router ambiguity
  python main.py --input portal_steps.md --name portal_auto --surface thin_client

  # With live DB for real schema discovery
  python main.py --input process.xlsx --name edr_qa --db-conn "${MSSQL_CONN}"

  # With live API for OpenAPI discovery
  python main.py --input api_steps.md --name case_api --api-url https://api.example.com

  # With live browser URL for UI discovery
  python main.py --input portal_steps.md --name portal --app-url https://portal.example.com

  # Desktop app automation
  python main.py --input sap_steps.md --name sap_auto --surface thick_client

Surface types auto-detected from document signals:
  qa_qc       — validate, check, Y/N verdict, compliance, Actimize, EDR, RRO
  thin_client — click, navigate, fill, selector, web browser, Playwright
  thick_client— pyautogui, desktop, Power Platform, SAP, Win32, .exe
  db_system   — SQL, ETL, extract, transform, load, reconcile
  api_system  — REST, endpoint, OpenAPI, OAuth, JSON, webhook
  general     — approval, workflow, route, notify, escalate
"""

import argparse
import asyncio
import json
import logging
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from agents.pipeline import run_meta_pipeline


SURFACE_TYPES = ["qa_qc", "thin_client", "thick_client", "db_system", "api_system", "general"]


def _load_document(path: str) -> str:
    p = Path(path)
    ext = p.suffix.lower()
    if ext in (".xlsx", ".xls"):
        return _load_excel(str(p))
    if ext in (".md", ".markdown", ".txt"):
        return p.read_text(encoding="utf-8", errors="replace")
    if ext == ".pdf":
        return _load_pdf(str(p))
    return p.read_text(encoding="utf-8", errors="replace")


def _load_excel(path: str) -> str:
    try:
        import openpyxl
    except ImportError:
        print("Install: pip install openpyxl", file=sys.stderr); sys.exit(1)
    wb    = openpyxl.load_workbook(path, data_only=True)
    parts = []
    for sheet in wb.sheetnames:
        ws   = wb[sheet]
        rows = list(ws.iter_rows(values_only=True))
        if not rows: continue
        cleaned = []
        for row in rows:
            r = [str(c).strip() if c is not None else "" for c in row]
            if any(r): cleaned.append(r)
        if not cleaned: continue
        parts.append(f"\n=== SHEET: {sheet} ===")
        parts.append("COLUMNS: " + " | ".join(c for c in cleaned[0] if c))
        for row in cleaned[1:]:
            pairs = [f"{cleaned[0][i]}: {v}" for i, v in enumerate(row)
                     if i < len(cleaned[0]) and cleaned[0][i] and v]
            if pairs: parts.append("ROW: " + " | ".join(pairs))
    return "\n".join(parts)


def _load_pdf(path: str) -> str:
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            return "\n".join(
                page.extract_text() or "" for page in pdf.pages
            )
    except ImportError:
        print("Install: pip install pdfplumber", file=sys.stderr)
        return Path(path).read_bytes().decode("utf-8", errors="replace")


def _args():
    p = argparse.ArgumentParser(
        description="AgentForge v2 — Surface-Aware ADK Pipeline Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("--input",   required=True,
                   help="Input document: Excel (.xlsx), Markdown (.md), PDF (.pdf)")
    p.add_argument("--name",    required=True,
                   help="Pipeline name e.g. edr_qa, portal_auto, case_etl")
    p.add_argument("--out",     default="./pipelines",
                   help="Output base directory (default: ./pipelines)")
    p.add_argument("--surface", choices=SURFACE_TYPES, default=None,
                   help="Override surface detection (optional)")
    p.add_argument("--db-conn",  default=None,
                   help="DB connection string for live schema discovery")
    p.add_argument("--api-url",  default=None,
                   help="API base URL for OpenAPI discovery")
    p.add_argument("--app-url",  default=None,
                   help="Browser start URL for UI element discovery")
    p.add_argument("--quiet",    action="store_true", help="Suppress agent output")
    p.add_argument("--run-id",   default=None,       help="Custom run ID")
    p.add_argument("--dry-run",  action="store_true",
                   help="Show IntentSpec + SurfaceSpec only, don't generate files")
    return p.parse_args()


async def main():
    args   = _args()
    logger = logging.getLogger("agentforge")

    if not args.quiet:
        logging.basicConfig(level=logging.WARNING,
                            format="%(levelname)s %(name)s %(message)s")

    for key in ["ANTHROPIC_API_KEY", "GOOGLE_API_KEY"]:
        if not os.environ.get(key):
            print(f"ERROR: {key} not set", file=sys.stderr); sys.exit(1)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"ERROR: Input not found: {input_path}", file=sys.stderr); sys.exit(1)

    print(f"\nLoading: {input_path} ...")
    doc = _load_document(str(input_path))
    print(f"Loaded:  {len(doc):,} characters")

    if args.dry_run:
        doc = "[DRY RUN — show IntentSpec + SurfaceSpec only]\n\n" + doc

    manifest = await run_meta_pipeline(
        document_text=doc,
        pipeline_name=args.name,
        output_dir=args.out,
        surface_hint=args.surface,
        db_conn=args.db_conn,
        api_base_url=args.api_url,
        app_url=args.app_url,
        run_id=args.run_id,
        verbose=not args.quiet,
    )

    print(f"\n{'='*62}")
    print(f"  AgentForge v2 — Complete")
    print(f"{'='*62}")

    if isinstance(manifest, dict):
        print(f"  Pipeline  : {manifest.get('pipeline_name', args.name)}")
        print(f"  Surface   : {manifest.get('surface_type', 'unknown')}")
        print(f"  Output    : {manifest.get('output_directory', '')}")
        print(f"  Files     : {manifest.get('total_files', '?')}")

        if manifest.get("mock_test_results"):
            print(f"\n  Mock tests:")
            for scenario, result in manifest["mock_test_results"].items():
                icon = "✅" if "PASS" in result else ("👤" if "HUMAN" in result else "❌")
                print(f"    {icon}  {scenario}: {result}")

        if manifest.get("next_steps"):
            print(f"\n  Next steps:")
            for step in manifest["next_steps"]:
                print(f"    {step}")

        if manifest.get("surface_notes"):
            print(f"\n  Notes: {manifest['surface_notes']}")

    print()


if __name__ == "__main__":
    asyncio.run(main())
