"""
agents/pipeline.py
==================
AgentForge v2 — 8-agent surface-aware meta-pipeline.

Agent flow:
  1. IntakeAgent           — normalise input document → IntentSpec
  2. SurfaceRouterAgent    — classify surface, select topology → SurfaceSpec
  3. DiscoveryAgent        — surface-specific probe → DB/API/UI/Desktop Spec
  4. PlannerAgent          — build AgentPlan with dep graph + tool assignments
  5. GeneratorAgent ┐      — generate all files for this surface type
  6. ValidatorAgent ┘ loop — validate, fix_request on fail (max 3)
  7. MockDataAgent         — surface-appropriate mock data + runner
  8. WriterAgent           — write files, run mock, deliver manifest
"""

import asyncio
import json
import logging
import os
from contextlib import AsyncExitStack
from pathlib import Path

import yaml as _yaml
from google.adk.agents import LlmAgent, SequentialAgent, LoopAgent
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.genai import types
from mcp.shared.memory import create_connected_server_and_client_session as create_in_memory_pair

from agents.surface_router import SURFACE_ROUTER_INSTRUCTION, TOPOLOGY_TEMPLATES
from agents.discovery     import (DB_DISCOVERY_INSTRUCTION, API_DISCOVERY_INSTRUCTION,
                                   UI_DISCOVERY_INSTRUCTION, DESKTOP_DISCOVERY_INSTRUCTION)
from agents.generator     import build_generator_instruction
from runtime.yaml_runtime import YAMLFunctionRuntime, MCP_TOOL_TYPES
from runtime.mcp_factory  import create_mcp_server
from audit.writer         import AuditWriter

logger = logging.getLogger(__name__)

FAST_MODEL   = "gemini-2.0-flash"
REASON_MODEL = "claude-sonnet-4-6"

TOOLS_DIR = Path(__file__).parent.parent / "tools"


async def _make_tool_agent(name, model, description, instruction, yaml_path, stack):
    tools = []
    if yaml_path and Path(yaml_path).exists():
        with open(yaml_path) as f:
            fns = _yaml.safe_load(f).get("functions", [])
        if [fn for fn in fns if fn.get("type") in MCP_TOOL_TYPES]:
            server    = create_mcp_server(yaml_path)
            cs        = await stack.enter_async_context(create_in_memory_pair(server))
            mcp_tools = await stack.enter_async_context(MCPToolset(client_session=cs))
            tools.extend(mcp_tools)
    return LlmAgent(name=name, model=model, description=description,
                    instruction=instruction, tools=tools)


def _pure_agent(name, model, description, instruction):
    return LlmAgent(name=name, model=model, description=description,
                    instruction=instruction, tools=[])


def _discovery_instruction(surface_type: str) -> str:
    return {
        "qa_qc":        DB_DISCOVERY_INSTRUCTION,
        "db_system":    DB_DISCOVERY_INSTRUCTION,
        "api_system":   API_DISCOVERY_INSTRUCTION,
        "thin_client":  UI_DISCOVERY_INSTRUCTION,
        "thick_client": DESKTOP_DISCOVERY_INSTRUCTION,
        "general":      DB_DISCOVERY_INSTRUCTION,
    }.get(surface_type, DB_DISCOVERY_INSTRUCTION)


# ── Intake instruction ────────────────────────────────────────────────────────

INTAKE_INSTRUCTION = """You are the IntakeAgent — Agent 1 in AgentForge.

YOUR JOB: Read the raw input document and produce a precise IntentSpec.

The document may be Excel rows, markdown, image OCR text, or video transcript.
Normalise it to a structured understanding regardless of source format.

PRODUCE: INTENT_SPEC: followed by JSON (nothing else after the JSON):

{
  "pipeline_name":    "snake_case e.g. edr_qa, rro_qa, power_platform_onboarding",
  "domain":           "one sentence domain e.g. Actimize EDR compliance review",
  "system_name":      "primary system e.g. Actimize, Power Platform, Salesforce",
  "record_identifier": {
    "field":   "ecn_id | case_id | rro_id | task_id",
    "label":   "ECN | Case | RRO | Task",
    "example": "ECN-2024-001"
  },
  "data_source": {
    "type":  "mssql | postgresql | mysql | sqlite | rest_api | sftp | browser | desktop | file",
    "hint":  "any table/view/URL/exe mentioned in the document"
  },
  "questions_count":  15,
  "automation_steps": [
    {
      "number":       1,
      "category":     "Event Creation",
      "description":  "Validate the event description is complete",
      "check_summary":"Match ECN#, Event Type, Workflow Status. Y if all match.",
      "requires_human": false,
      "depends_on":   []
    }
  ],
  "has_human_review": true,
  "categories":       ["Event Creation", "Level 1 Review", "Level 2 Review"],
  "output_hint":      "what the final output should contain"
}
"""

# ── Planner instruction (surface-aware) ───────────────────────────────────────

PLANNER_INSTRUCTION = """You are the PlannerAgent — Agent 4 in AgentForge.

READ from conversation:
- INTENT_SPEC (from IntakeAgent)
- SURFACE_SPEC (from SurfaceRouterAgent)
- Discovery spec: DB_SCHEMA_SPEC | API_SPEC | UI_SPEC | DESKTOP_SPEC

YOUR JOB: Build the complete AgentPlan for this surface type.
The plan drives the GeneratorAgent — every detail must be explicit.

PLANNING STEPS:
1. Confirm surface_type from SURFACE_SPEC
2. Build agent_roles list using surface topology from SURFACE_SPEC.topology.agent_roles
3. For each step agent: extract VERBATIM step description, check/action logic, validation
4. Build dependency graph — trace "if Q{N}" / "if step N fails" references
5. Map discovery fields to step agents (which columns/endpoints/selectors does each need)
6. Assign models from SURFACE_SPEC.topology.model_map
7. Generate connection block from discovery spec

SELF-CHALLENGE before output:
- Any steps missing? Re-read INTENT_SPEC.automation_steps
- Any circular dependencies? Trace all depends_on paths
- Every step agent has the right tool_yaml assigned?
- Connection auth type matches discovery spec?

PRODUCE: AGENT_PLAN: followed by JSON (nothing else):

{
  "pipeline_name":   "edr_qa",
  "surface_type":    "qa_qc",
  "total_agents":    17,
  "agent_roles":     ["ingest_agent", "q01_agent", "...", "q15_agent", "report_agent"],
  "first_agent": {
    "name":      "ingest_agent",
    "model":     "gemini-2.0-flash",
    "tool_yaml": "tools/ingest_tools.yaml",
    "instruction_hint": "Fetch ECN record from Actimize DB. Output all 25 fields."
  },
  "step_agents": [
    {
      "number":         1,
      "name":           "q01_agent",
      "model":          "claude-sonnet-4-6",
      "tool_yaml":      "tools/q01_tools.yaml",
      "category":       "Event Creation",
      "description":    "Validate the event description is complete",
      "check_logic":    "VERBATIM check text from document — do not paraphrase",
      "validation":     "What to validate verbatim",
      "notes":          "Examples/edge cases verbatim or empty string",
      "depends_on":     [],
      "requires_human": false,
      "output_hint":    "Answer Y, N, or N/A with full reasoning",
      "fields_needed":  ["ecn_number", "event_type", "workflow_status"]
    }
  ],
  "final_agents": [
    {
      "name":      "report_agent",
      "model":     "claude-sonnet-4-6",
      "tool_yaml": "tools/report_tools.yaml",
      "instruction_hint": "Collect all 15 answers. Call build_report. Output verdict."
    }
  ],
  "connection": {
    "name":          "actimize_db",
    "type":          "db",
    "auth_type":     "connection_string",
    "env_var":       "MSSQL_CONN",
    "driver":        "mssql+pyodbc",
    "table_or_view": "vw_get_qa_actimize_data"
  },
  "categories":                ["Event Creation", "Level 1 Review"],
  "human_review_steps":        [10, 12, 13, 15],
  "dependency_graph":          {"q1": [], "q2": [1], "q3": [1,2]},
  "discovery_spec_used":       "DB_SCHEMA_SPEC",
  "planner_notes":             "any decisions made"
}
"""

# ── Validator instruction ─────────────────────────────────────────────────────

VALIDATOR_INSTRUCTION = """You are the ValidatorAgent — Agent 6 in AgentForge.

READ: AGENT_PLAN + all FILE: blocks from GeneratorAgent.
If a VALIDATION_REPORT already exists, this is a retry — focus on the fix_request.

VALIDATION CHECKS:

Python files:
  □ Syntax valid (mentally compile)
  □ No circular imports
  □ All dataclass fields present
  □ Question/step count matches AGENT_PLAN.total_agents - fixed_agents

YAML files:
  □ Valid YAML (no tab characters, correct indentation)
  □ connections block present with ${ENV_VAR} refs (NOT hardcoded values)
  □ connection_ref in functions matches connections[].name
  □ Jinja {{ inputs.x }} used for params (NOT ${...})
  □ Python tool code assigns to `result` variable

agents/agent.py:
  □ SequentialAgent used
  □ No context.state
  □ InMemorySessionService.create_session per run
  □ All agents built from registry in order

Surface-specific checks:
  qa_qc:
    □ N+2 agents in build_registry()
    □ First=ingest_agent, Last=report_agent
    □ All check agents use QA_MODEL (claude-sonnet-4-6)
    □ check_logic in each instruction is VERBATIM from AGENT_PLAN
    □ depends_on is acyclic

  thin_client:
    □ playwright connection type in browser_session_tools.yaml
    □ All ${ENV_VAR} references: APP_BASE_URL, APP_USERNAME, APP_PASSWORD
    □ Each action YAML references a valid selector from UI_SPEC
    □ screenshot tool present

  thick_client:
    □ pyautogui connection type in desktop_tools.yaml
    □ ${APP_EXE_PATH} present in .env.example
    □ Each action YAML has coordinates or image_ref from DESKTOP_SPEC
    □ failsafe: true in pyautogui config

  db_system:
    □ Two separate connection objects: source_db + target_db
    □ ${SOURCE_DB_CONN} and ${TARGET_DB_CONN} in .env.example
    □ reconcile tool compares row counts AND checksums
    □ No DELETE without WHERE clause in any generated SQL

  api_system:
    □ auth_type matches API_SPEC.auth_type
    □ All auth env_vars in .env.example
    □ Each call YAML uses Jinja for path params {{ inputs.param }}
    □ aggregate_agent present before report_agent

  general:
    □ notify_tools.yaml has at least one notification channel
    □ audit_tools.yaml present
    □ route_agent is before notify_agent in registry

PRODUCE: VALIDATION_REPORT: followed by JSON:

{
  "passed": true|false,
  "surface_type": "...",
  "file_results": {
    "questions.py":        {"ok": true,  "issues": []},
    "tool_registry.py":    {"ok": false, "issues": ["build_registry returns 16, expected 17"]},
    "tools/ingest_tools.yaml": {"ok": true, "issues": []}
  },
  "critical_issues": ["list of must-fix issues"],
  "fix_request": "If passed=false: exact instructions for GeneratorAgent"
}

If passed=false: also emit NEEDS_REGENERATION: true on a new line.
"""

# ── Mock data instruction (surface-aware) ─────────────────────────────────────

MOCK_DATA_INSTRUCTION = """You are the MockDataAgent — Agent 7 in AgentForge.

READ: AGENT_PLAN + discovery spec + VALIDATION_REPORT (must be passed=true).

Surface type: from AGENT_PLAN.surface_type

Generate mock data appropriate for the surface type:

QA_QC surface:
  5 records: MOCK-PASS-001 (all Y), MOCK-FAIL-001 (Q2→N), MOCK-FAIL-002 (Q6→N),
             MOCK-HUMAN-001 (triggers NEEDS_HUMAN), MOCK-PARTIAL-001 (mix).
  Field values must EXERCISE the check logic — not random values.
  Read check_logic from AGENT_PLAN.step_agents[].check_logic and set fields to trigger each scenario.

THIN_CLIENT surface:
  3 task scenarios: TASK-PASS-001 (all actions succeed), TASK-FAIL-001 (action 3 fails),
                    TASK-PARTIAL-001 (actions 1-4 pass, 5+ skipped).
  Mock the page HTML responses that Playwright would see.
  For each action: expected selector present/absent, expected text values.

THICK_CLIENT surface:
  3 scenarios: all_success, step_3_not_found (image match fails), app_not_started.
  Mock screenshots as descriptions (no actual image generation needed).
  Reference control coordinates from DESKTOP_SPEC.

DB_SYSTEM surface:
  Source data: 100 rows with 5 that have transformation edge cases.
  Pre-transformed data (what extract_agent would fetch).
  Expected post-transform state for reconciliation.

API_SYSTEM surface:
  Mock HTTP responses per endpoint (status code + body JSON).
  Scenarios: all_200, endpoint_3_returns_404, auth_token_expired.

GENERAL surface:
  3 workflow trigger events with different condition outcomes.

EMIT:
FILE: mock/mock_data.json  — the mock data for this surface
FILE: mock/mock_runner.py  — patches yaml_runtime + runs pipeline against mock

mock_runner.py must:
  - Patch YAMLFunctionRuntime.execute() to return mock data
  - For surface qa_qc: serve mock records from mock_data.json by record_id
  - For surface thin_client: intercept playwright calls, return mock page state
  - For surface thick_client: intercept pyautogui calls, return mock screenshots
  - For surface db_system: serve mock source rows, capture load calls
  - For surface api_system: intercept rest_api calls, return mock responses
  - Run all scenarios, print results table
  - --record-id / --task-id / --scenario flag for single run

After files, emit MOCK_COMPLETE: {{"records": N, "scenarios": ["all_pass","fail_q2","needs_human"]}}
"""

# ── Writer instruction ─────────────────────────────────────────────────────────

WRITER_INSTRUCTION = """You are the WriterAgent — Agent 8 (final) in AgentForge.

READ: All FILE: blocks from GeneratorAgent + MockDataAgent.
VALIDATION_REPORT must be passed=true before writing.

YOUR JOB:
1. Write every FILE: block to disk using write_file tool.
2. Generate tests/test_pipeline.py covering:
   - Correct agent count in build_registry()
   - All step agents use correct model
   - YAML files are valid and have required sections
   - Report tool verdict logic (PASS/FAIL/NEEDS_HUMAN)
   - Surface-specific: selectors in thin_client, coordinates in thick_client,
     two connections in db_system, auth config in api_system
3. Call run_syntax_check — fix any issues found.
4. Call run_mock_test — capture results table.
5. Call list_output_files — confirm all expected files present.

PRODUCE: DELIVERY_MANIFEST: followed by JSON:

{
  "pipeline_name":    "edr_qa",
  "surface_type":     "qa_qc",
  "output_directory": "/path/to/output/edr_qa",
  "total_files":      42,
  "files_written":    ["questions.py", "tool_registry.py", "..."],
  "mock_test_results": {
    "MOCK-PASS-001": "PASS (100.0%)",
    "MOCK-FAIL-001": "FAIL (86.7%) — Q2 failed as expected",
    "MOCK-HUMAN-001": "REQUIRES_HUMAN_REVIEW — Q10, Q12 flagged"
  },
  "next_steps": [
    "cd <output_dir>",
    "cp .env.example .env && nano .env",
    "python tool_generator.py",
    "pytest tests/ -v",
    "python main.py --record-id <ID>",
    "python mock/mock_runner.py"
  ],
  "surface_notes": "surface-specific notes e.g. install playwright, run playwright install"
}
"""


async def run_meta_pipeline(
    document_text: str,
    pipeline_name: str,
    output_dir:    str,
    surface_hint:  str | None = None,
    db_conn:       str | None = None,
    api_base_url:  str | None = None,
    app_url:       str | None = None,
    run_id:        str | None = None,
    verbose:       bool = True,
) -> dict:
    """
    Run the 8-agent surface-aware meta pipeline.

    Args:
        document_text: Raw text from Excel/Markdown/video
        pipeline_name: e.g. edr_qa, rro_qa, portal_automation
        output_dir:    Where to write generated files
        surface_hint:  Optional override: qa_qc|thin_client|thick_client|db_system|api_system|general
        db_conn:       DB connection string for live discovery
        api_base_url:  API base URL for OpenAPI discovery
        app_url:       Browser start URL for UI discovery
        run_id:        Custom run ID
        verbose:       Print agent progress
    """
    from datetime import datetime

    run_id  = run_id or f"forge_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
    out_dir = Path(output_dir) / pipeline_name
    out_dir.mkdir(parents=True, exist_ok=True)

    audit = AuditWriter(run_id=run_id, output_dir=str(out_dir / "_meta_audit"))
    audit.start()

    discovery_yaml = str(TOOLS_DIR / "discovery_tools.yaml")
    writer_yaml    = str(TOOLS_DIR / "writer_tools.yaml")

    # Set env vars for discovery tools
    if db_conn:       os.environ["TARGET_DB_CONN"]  = db_conn
    if api_base_url:  os.environ["API_BASE_URL"]    = api_base_url
    if app_url:       os.environ["APP_BASE_URL"]    = app_url

    surface_hint_line = f"\nSurface hint (use this if signals are ambiguous): {surface_hint}" if surface_hint else ""

    user_message = (
        f"Pipeline name: {pipeline_name}\n"
        f"Output directory: {out_dir}{surface_hint_line}\n\n"
        f"DOCUMENT:\n{document_text}"
    )

    async with AsyncExitStack() as stack:

        # Agent 1 — Intake
        intake = _pure_agent(
            "intake_agent", REASON_MODEL,
            "Normalises any input document to IntentSpec",
            INTAKE_INSTRUCTION,
        )

        # Agent 2 — Surface Router
        surface_router = _pure_agent(
            "surface_router_agent", REASON_MODEL,
            "Classifies surface type and selects agent topology",
            SURFACE_ROUTER_INSTRUCTION,
        )

        # Agent 3 — Discovery (connects to real systems if available)
        # Instruction is surface-generic; model will use whichever discovery
        # tools are available. The instruction adapts based on SURFACE_SPEC.
        discovery_instruction = """You are the DiscoveryAgent — Agent 3.
READ SURFACE_SPEC from conversation. Use the tools available to discover the
target system's schema/API/UI/desktop controls.
Produce the appropriate spec: DB_SCHEMA_SPEC, API_SPEC, UI_SPEC, or DESKTOP_SPEC."""

        discovery = await _make_tool_agent(
            "discovery_agent", REASON_MODEL,
            "Probes target system for schema, API spec, UI elements, or desktop controls",
            discovery_instruction,
            discovery_yaml, stack,
        )

        # Agent 4 — Planner
        planner = _pure_agent(
            "planner_agent", REASON_MODEL,
            "Builds complete AgentPlan with dep graph and tool assignments",
            PLANNER_INSTRUCTION,
        )

        # Agent 5 — Generator (instruction built at runtime from surface type)
        # Since we don't know surface type yet, use a general instruction.
        # The actual surface-specific instruction is injected via AGENT_PLAN context.
        generator_instruction = """You are the GeneratorAgent — Agent 5.
READ AGENT_PLAN from conversation. SURFACE_TYPE is in AGENT_PLAN.surface_type.
Generate ALL files for that surface type following the file list for that surface.
Emit each file as FILE: <path> then the content. Emit GENERATION_COMPLETE: at end."""

        generator = _pure_agent(
            "generator_agent", REASON_MODEL,
            "Generates all pipeline files for the detected surface type",
            generator_instruction,
        )

        # Agent 6 — Validator
        validator = _pure_agent(
            "validator_agent", REASON_MODEL,
            "Validates all generated files — syntax, structure, surface-specific rules",
            VALIDATOR_INSTRUCTION,
        )

        # Generator ↔ Validator loop (max 3 iterations)
        gen_val_loop = LoopAgent(
            name="gen_val_loop",
            sub_agents=[generator, validator],
            max_iterations=3,
        )

        # Agent 7 — Mock Data
        mock_agent = _pure_agent(
            "mock_data_agent", REASON_MODEL,
            "Generates surface-appropriate mock data and mock runner",
            MOCK_DATA_INSTRUCTION,
        )

        # Agent 8 — Writer
        writer = await _make_tool_agent(
            "writer_agent", REASON_MODEL,
            "Writes all files to disk, runs mock tests, produces delivery manifest",
            WRITER_INSTRUCTION,
            writer_yaml, stack,
        )

        # Full 8-agent pipeline
        meta_pipeline = SequentialAgent(
            name="agentforge_meta_pipeline",
            sub_agents=[
                intake,
                surface_router,
                discovery,
                planner,
                gen_val_loop,
                mock_agent,
                writer,
            ],
        )

        session_svc = InMemorySessionService()
        await session_svc.create_session(
            app_name="agentforge", user_id=run_id, session_id=run_id,
        )
        runner = Runner(
            agent=meta_pipeline,
            app_name="agentforge",
            session_service=session_svc,
        )

        message = types.Content(role="user", parts=[types.Part(text=user_message)])

        if verbose:
            print(f"\n{'='*62}")
            print(f"  AgentForge v2 — Surface-Aware Meta-Pipeline")
            print(f"  Pipeline: {pipeline_name}  |  Run: {run_id}")
            print(f"  Output:   {out_dir}")
            print(f"{'='*62}")
            print(f"  Agents: Intake → Surface Router → Discovery → Planner")
            print(f"          → [Generator ↔ Validator] → Mock Data → Writer\n")

        agent_icons = {
            "intake_agent":       "📥",
            "surface_router_agent":"🗺️ ",
            "discovery_agent":    "🔍",
            "planner_agent":      "📐",
            "generator_agent":    "⚙️ ",
            "validator_agent":    "✅",
            "mock_data_agent":    "🎭",
            "writer_agent":       "✍️ ",
        }

        final_text     = ""
        current_author = None
        agent_outputs  = {}

        async for event in runner.run_async(
            user_id=run_id, session_id=run_id, new_message=message
        ):
            author = getattr(event, "author", None)
            if author and author != current_author:
                if current_author:
                    audit.record_agent(current_author, agent_outputs.get(current_author, ""))
                current_author = author
                if verbose and author not in ("agentforge_meta_pipeline", "gen_val_loop"):
                    icon = agent_icons.get(author, "▶")
                    print(f"\n  {icon}  {author}")

            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    print(f"       🔧 {call.name}({str(call.args)[:80]})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        text = part.text.strip()
                        agent_outputs[current_author or ""] = text
                        final_text = text
                        if verbose:
                            preview = text[:400]
                            print(f"       → {preview}{'…' if len(text) > 400 else ''}")

        audit.finish(final_text)

        import re
        manifest = None
        m = re.search(r'DELIVERY_MANIFEST:\s*```(?:json)?\s*(.*?)```', final_text, re.DOTALL)
        if m:
            try:
                manifest = json.loads(m.group(1))
            except Exception:
                pass
        if not manifest:
            idx = final_text.find("DELIVERY_MANIFEST:")
            if idx != -1:
                rest = final_text[idx + 18:].strip()
                try:
                    manifest = json.loads(rest[:rest.rfind("}") + 1])
                except Exception:
                    pass

        return manifest or {
            "pipeline_name": pipeline_name,
            "output_directory": str(out_dir),
            "status": "completed",
        }
