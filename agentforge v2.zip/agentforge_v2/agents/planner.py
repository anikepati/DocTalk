"""agents/planner.py — Planner instruction lives in pipeline.py for v2."""
# PLANNER_INSTRUCTION is defined inline in pipeline.py
PLANNER_INSTRUCTION = ""  # overridden by pipeline.py
