"""
agents/generator.py
===================
Agent 5 — Generator

Reads AgentPlan + all discovery specs from conversation.
Generates all files for the correct surface type.

Each surface type produces a different file set:

  qa_qc        → standard questions.py + tool_registry.py + sql YAML
  thin_client  → page_objects.py + playwright YAML tools per action
  thick_client → controls.py + pyautogui YAML tools per interaction
  db_system    → transforms.py + sql YAMLs (source + target connections)
  api_system   → endpoints.py + rest_api YAMLs per call
  general      → workflow.py + mixed YAMLs

All surfaces share: yaml_runtime.py, mcp_factory.py, agents/agent.py,
pipeline_runner.py, main.py, config.py, models.py, audit/audit_writer.py,
.env.example, requirements.txt, pytest.ini.
"""

# ── Generator instructions per surface ───────────────────────────────────────

GENERATOR_BASE_INSTRUCTION = """You are the GeneratorAgent — Agent 5 in AgentForge.

READ from conversation history:
- AGENT_PLAN: (from PlannerAgent)
- Discovery spec (DB_SCHEMA_SPEC, API_SPEC, UI_SPEC, or DESKTOP_SPEC)
- VALIDATION_REPORT: if present — fix the issues listed in fix_request

Surface type: {surface_type}

YOUR JOB: Generate ALL pipeline files for this surface type.
Emit each file as: FILE: <relative/path> then the content in a code block.

SHARED FILES (generate for ALL surface types):
-------------------------------------------------
FILE: yaml_runtime.py
  Full connection type system supporting:
  - db: _DBConnection (SQLAlchemy, ${ENV_VAR} at init, Jinja params at call)
  - rest_api: _RESTConnection (Apigee token auto-refresh, bearer, oauth2, api_key, basic)
  - playwright: _PlaywrightConnection (Playwright sync API, session management)
  - pyautogui: _PyAutoGUIConnection (screenshot, click, type, drag, key)
  - sftp: _SFTPConnection (paramiko)
  - python: RestrictedPython sandbox
  YAMLFunctionRuntime class: loads YAML, validates ${ENV_VAR} at __init__,
  resolves {{ inputs.x }} Jinja at execute() time only.
  MCP_TOOL_TYPES = {{"sql","rest_api","playwright","pyautogui","python","sftp"}}

FILE: mcp_factory.py
  create_mcp_server(yaml_path) -> Server
  Registers all functions whose type is in MCP_TOOL_TYPES as MCP tools.

FILE: agents/agent.py
  _build_agent(config, exit_stack) -> LlmAgent
  run_pipeline(record_id, run_id, output_path, registry, audit, verbose) -> str
  Uses SequentialAgent. No context.state. No manual state tools.
  InMemorySessionService per run. Streams audit events.

FILE: pipeline_runner.py
  PipelineRunner.run(record_id, output_path, verbose) -> dict
  Startup: generates YAMLs, builds registry, validates.
  Per-run: session, retry (max MAX_RETRIES), audit write.

FILE: main.py
  CLI: --record-id, --output, --quiet, --concurrent, --generate-only
  asyncio.run(main())

FILE: config.py — Settings from env vars + configure_logging()
FILE: models.py — Verdict enum, StepResult dataclass, PipelineResult dataclass
FILE: audit/audit_writer.py — AuditWriter class
FILE: audit/__init__.py — empty
FILE: agents/__init__.py — empty
FILE: tests/__init__.py — empty
FILE: requirements.txt — google-adk, google-genai, mcp, anthropic, sqlalchemy,
                         pyodbc, jinja2, python-dotenv, pyyaml, playwright,
                         pyautogui, pillow, aiohttp, RestrictedPython, pytest
FILE: .env.example — all required ${ENV_VAR} with descriptions
FILE: pytest.ini — asyncio_mode=auto, testpaths=tests

SURFACE-SPECIFIC FILES (generate based on surface_type):
---------------------------------------------------------
{surface_specific_instructions}

After all files, emit:
GENERATION_COMPLETE: {{"files_generated": N, "surface_type": "{surface_type}", "pipeline_name": "..."}}
"""

# Surface-specific file instructions injected into the base prompt

QA_QC_INSTRUCTIONS = """
FILE: questions.py
  @dataclass(frozen=True) class {Name}Question with fields:
    number, category, question, validation, check, notes,
    depends_on: tuple[int,...], requires_human: bool, output_hint: str
  {NAME}_QUESTIONS tuple with ALL questions from AGENT_PLAN (check logic VERBATIM)
  {NAME}_QUESTION_MAP dict, HUMAN_REVIEW_QUESTION_NUMBERS frozenset, CATEGORIES tuple

FILE: tool_registry.py
  INGEST_MODEL = "gemini-2.0-flash"
  QA_MODEL = "claude-sonnet-4-6"
  @dataclass ToolConfig: name, yaml_path, description, instruction, model
  _ingest_config() with full instruction listing ALL columns from DB_SCHEMA_SPEC
  _build_q_instruction(q) embedding check logic VERBATIM — never paraphrase
  _question_config(q), _report_config(), build_registry(), validate_yaml_files()

FILE: tool_generator.py
  generate_all_question_yamls(tools_dir, force) -> list[str]
  Q_EXTRA_TOOLS: dict[int, list[dict]] = {{}} with usage comment
  if __name__: block

FILE: tools/ingest_tools.yaml
  connections: block — db type, driver, ${ENV_VAR} auth
  functions: fetch_record — SELECT of ALL columns from DB_SCHEMA_SPEC.columns[].name

FILE: tools/q01_tools.yaml ... tools/qNN_tools.yaml
  functions: [] (empty by default — agents reason from conversation history)
  Header comment: category, depends_on, requires_human

FILE: tools/report_tools.yaml
  python tool: build_report
  Verdict: FAIL > REQUIRES_HUMAN_REVIEW > PASS_WITH_EXCEPTIONS > PASS
  Category breakdown from AGENT_PLAN.categories
  Writes structured JSON: record_id, verdict, pass_rate, answers[], human_items[]
"""

THIN_CLIENT_INSTRUCTIONS = """
FILE: page_objects.py
  @dataclass PageElement: id, type, selector, action_type, page_name, step_number
  @dataclass PageObject: name, url_pattern, elements: list[PageElement]
  PAGE_OBJECTS tuple from UI_SPEC.pages
  ACTION_MAP: dict[int, PageElement] — step_number → element
  get_page_for_step(n) → PageObject

FILE: tool_registry.py
  INGEST_MODEL = "gemini-2.0-flash"
  BROWSER_MODEL = "gemini-2.0-flash"
  REPORT_MODEL = "claude-sonnet-4-6"
  ToolConfig dataclass
  _ingest_config() — reads task params
  _navigate_config() — logs into app, navigates to start screen
  _action_config(n, element) — per-step: click/fill/select with selector
  _verify_config() — checks all expected states occurred
  _report_config() — compiles action log + screenshots → verdict
  build_registry(), validate_yaml_files()

FILE: tool_generator.py
  generate_all_action_yamls(tools_dir, force) -> list[str]
  Each YAML has playwright tools: click, fill, select, screenshot, wait

FILE: tools/browser_session_tools.yaml
  connections:
    - name: browser_session
      type: playwright
      config:
        browser: chromium
        headless: ${PLAYWRIGHT_HEADLESS}
        base_url: ${APP_BASE_URL}
      auth:
        type: form_login
        username: ${APP_USERNAME}
        password: ${APP_PASSWORD}
        login_url: ${APP_LOGIN_URL}
        username_selector: ${LOGIN_USERNAME_SELECTOR}
        password_selector: ${LOGIN_PASSWORD_SELECTOR}
        submit_selector: ${LOGIN_SUBMIT_SELECTOR}
  functions:
    - navigate(url) — goes to URL
    - click(selector) — clicks element
    - fill(selector, value) — fills input
    - select(selector, option) — selects dropdown option
    - screenshot(filename) — takes screenshot
    - wait_for_selector(selector, timeout_ms)
    - get_text(selector) — reads element text
    - assert_text(selector, expected) — verifies text

FILE: tools/action_01_tools.yaml ... action_NN_tools.yaml
  Per-action YAML: the specific playwright tool calls for that step
  selector and value from UI_SPEC.actions[N]

FILE: tools/verify_tools.yaml
  assert_screenshot_match(reference, tolerance)
  assert_text_present(selector, expected_text)
  assert_page_url(expected_pattern)

FILE: tools/report_tools.yaml
  python tool: build_action_report
  Compiles: action_log[], screenshot_paths[], pass_rate
  Verdict: PASS | PARTIAL_PASS | FAIL
  Writes JSON + screenshot index HTML

FILE: screenshots/ — empty dir placeholder
FILE: selectors/ — empty dir with .gitkeep
"""

THICK_CLIENT_INSTRUCTIONS = """
FILE: controls.py
  @dataclass DesktopControl: id, type, label, coordinates, image_ref, used_by_steps
  @dataclass DesktopAction: step_number, description, control_id, action_type, value, wait_ms
  CONTROLS tuple from DESKTOP_SPEC.controls
  ACTIONS tuple from DESKTOP_SPEC.actions
  CONTROL_MAP: dict[str, DesktopControl]

FILE: tool_registry.py
  LAUNCH_MODEL = "gemini-2.0-flash"
  ACTION_MODEL = "gemini-2.0-flash"
  VERIFY_MODEL = "claude-sonnet-4-6"
  REPORT_MODEL = "claude-sonnet-4-6"
  ToolConfig dataclass
  _launch_config() — opens app, verifies window title
  _action_config(n, action) — per desktop interaction with coordinates
  _screenshot_verify_config() — PIL image comparison
  _report_config() — compiles interaction log
  build_registry(), validate_yaml_files()

FILE: tool_generator.py
  generate_all_action_yamls(tools_dir, force) -> list[str]
  EXTRA_TOOLS: dict[int, list[dict]] = {{}}

FILE: tools/desktop_tools.yaml
  connections:
    - name: desktop_session
      type: pyautogui
      config:
        app_name: {app_name}
        exe_path: ${{APP_EXE_PATH}}
        window_title: {window_title}
        screenshot_dir: screenshots/
        failsafe: true
        pause_seconds: 0.5
  functions:
    - launch_app(exe_path, args) — starts application
    - find_window(title_pattern) — locates + focuses window
    - click(x, y) — left click at coordinates
    - double_click(x, y) — double click
    - right_click(x, y) — right click → context menu
    - type_text(text) — types string at current focus
    - press_key(key) — single key: enter, tab, escape, f5
    - hotkey(keys) — key combination: ctrl+c, alt+f4
    - drag(from_x, from_y, to_x, to_y) — drag and drop
    - screenshot(filename) — captures full screen
    - find_image(template_path, confidence) → (x, y) or null
    - click_image(template_path, confidence) — find + click
    - wait_for_image(template_path, timeout_ms) — wait until visible
    - get_screen_text(x, y, w, h) — OCR region via pytesseract
    - assert_image_present(template_path, confidence)
    - assert_window_title(expected_pattern)

FILE: tools/action_01_tools.yaml ... action_NN_tools.yaml
  Per-action YAML: specific pyautogui tool + coordinates/image from DESKTOP_SPEC

FILE: controls/ — directory for reference images (screenshots of each control)
FILE: screenshots/ — empty dir placeholder
FILE: tools/report_tools.yaml — same structure as thin_client report tool
"""

DB_SYSTEM_INSTRUCTIONS = """
FILE: transforms.py
  @dataclass TransformRule: number, name, description, sql_or_logic,
                            source_columns, target_columns, validation_sql
  TRANSFORMS tuple from AGENT_PLAN (rules VERBATIM)
  TRANSFORM_MAP dict

FILE: tool_registry.py
  EXTRACT_MODEL = "gemini-2.0-flash"
  TRANSFORM_MODEL = "claude-sonnet-4-6"
  LOAD_MODEL = "gemini-2.0-flash"
  RECONCILE_MODEL = "claude-sonnet-4-6"
  ToolConfig dataclass
  _extract_config() — queries source DB, outputs dataset summary
  _transform_config(n, rule) — applies one transformation rule
  _load_config() — writes to target DB
  _reconcile_config() — compares source vs target
  build_registry(), validate_yaml_files()

FILE: tools/source_db_tools.yaml
  connections:
    - name: source_db
      type: db
      auth: connection_string, value: ${{SOURCE_DB_CONN}}
  functions:
    - extract_table(table_name, where_clause, limit)
    - get_row_count(table_name, where_clause)
    - get_checksum(table_name, key_column)
    - run_query(sql, params)

FILE: tools/target_db_tools.yaml
  connections:
    - name: target_db
      type: db
      auth: connection_string, value: ${{TARGET_DB_CONN}}
  functions:
    - insert_batch(table_name, rows)
    - upsert_batch(table_name, rows, key_columns)
    - truncate_table(table_name)
    - get_row_count(table_name)
    - get_checksum(table_name, key_column)

FILE: tools/transform_NN_tools.yaml (per transform)
  python tools for data transformation logic (pandas-free: pure Python)

FILE: tools/reconcile_tools.yaml
  python tool: run_reconciliation
  Compares source_count vs target_count, source_checksum vs target_checksum
  Per-table report: MATCH | MISMATCH | MISSING
  Writes reconciliation_report.json

FILE: tools/report_tools.yaml — reconciliation + ETL summary
"""

API_SYSTEM_INSTRUCTIONS = """
FILE: endpoints.py
  @dataclass APIEndpoint: id, method, path, description, inputs, response_fields, used_by_steps
  @dataclass APIAuth: type, env_vars, token_url, scopes
  ENDPOINTS tuple from API_SPEC.endpoints (VERBATIM)
  ENDPOINT_MAP dict
  AUTH_CONFIG from API_SPEC.auth_type

FILE: tool_registry.py
  AUTH_MODEL = "gemini-2.0-flash"
  CALL_MODEL = "claude-sonnet-4-6"
  AGG_MODEL = "claude-sonnet-4-6"
  REPORT_MODEL = "claude-sonnet-4-6"
  ToolConfig dataclass
  _auth_config() — gets token, outputs to conversation
  _call_config(n, endpoint) — makes one API call
  _aggregate_config() — merges all responses
  _report_config() — writes call log + aggregated data
  build_registry(), validate_yaml_files()

FILE: tools/api_auth_tools.yaml
  connections:
    - name: target_api
      type: rest_api
      config:
        base_url: ${{API_BASE_URL}}
        timeout_seconds: 30
      auth:
        type: {auth_type}  # apigee_token | bearer_token | oauth2 | api_key
        # auth_type-specific fields with ${ENV_VAR} references

FILE: tools/call_NN_tools.yaml (per API call step)
  connection_ref: target_api
  functions per endpoint:
    - id: call_{endpoint_id}
      type: rest_api
      config:
        method: GET|POST|PUT|DELETE
        path: /api/v1/... (with {{ inputs.param }} Jinja for path params)
        body: {{ inputs.body }} (for POST/PUT)
        headers: {{}}
      inputs: (from API_SPEC.endpoints[].inputs)

FILE: tools/aggregate_tools.yaml
  python tool: aggregate_responses
  Merges all call results, extracts key fields, computes totals

FILE: tools/report_tools.yaml — API call log + aggregated response report
"""

GENERAL_INSTRUCTIONS = """
FILE: workflow.py
  @dataclass WorkflowCondition: number, name, description, condition_logic,
                                 true_action, false_action, depends_on
  @dataclass NotificationConfig: channel, recipient_env_var, template
  CONDITIONS tuple from AGENT_PLAN (logic VERBATIM)
  NOTIFICATIONS dict
  ROUTING_RULES: dict[str, str]  # condition_result → next_action

FILE: tool_registry.py
  TRIGGER_MODEL = "gemini-2.0-flash"
  DECISION_MODEL = "claude-sonnet-4-6"
  ROUTE_MODEL = "claude-sonnet-4-6"
  NOTIFY_MODEL = "gemini-2.0-flash"
  AUDIT_MODEL = "gemini-2.0-flash"
  ToolConfig dataclass (all 5 agent types)
  build_registry(), validate_yaml_files()

FILE: tools/trigger_tools.yaml
  connections: whatever system triggers the workflow (DB, API, webhook)
  functions: read_trigger_event, get_workflow_params

FILE: tools/decision_NN_tools.yaml (per condition)
  functions: evaluate_condition, lookup_reference_data (if needed)

FILE: tools/route_tools.yaml
  python tool: compute_route — reads all decisions, returns routing decision

FILE: tools/notify_tools.yaml
  connections:
    - name: email_api
      type: rest_api
      auth: bearer_token, value: ${{EMAIL_API_TOKEN}}
    - name: teams_webhook
      type: rest_api
      auth: none
      config: {{base_url: ${{TEAMS_WEBHOOK_URL}}}}
  functions:
    - send_email(to, subject, body)
    - send_teams_message(channel, message)
    - send_slack_message(channel, message)

FILE: tools/audit_tools.yaml
  connections: audit DB or file
  functions:
    - write_workflow_record(workflow_id, decisions, routing, notifications, duration)
    - get_workflow_status(workflow_id)

FILE: tools/report_tools.yaml — workflow completion report
"""

# ── Map surface type to its specific instructions ─────────────────────────────

SURFACE_INSTRUCTIONS = {
    "qa_qc":        QA_QC_INSTRUCTIONS,
    "thin_client":  THIN_CLIENT_INSTRUCTIONS,
    "thick_client": THICK_CLIENT_INSTRUCTIONS,
    "db_system":    DB_SYSTEM_INSTRUCTIONS,
    "api_system":   API_SYSTEM_INSTRUCTIONS,
    "general":      GENERAL_INSTRUCTIONS,
}


def build_generator_instruction(surface_type: str) -> str:
    """Build the full generator instruction for the given surface type."""
    specific = SURFACE_INSTRUCTIONS.get(surface_type, GENERAL_INSTRUCTIONS)
    return GENERATOR_BASE_INSTRUCTION.format(
        surface_type=surface_type,
        surface_specific_instructions=specific,
    )
