"""agents/writer.py — Writer instruction lives in pipeline.py for v2."""
WRITER_INSTRUCTION = ""  # overridden by pipeline.py
