"""
agents/surface_router.py
========================
Agent 2 — Surface Router

Reads IntentSpec from conversation. Classifies surface type.
Selects the agent topology template for that surface.

Six surface types, each producing a different multi-agent topology:

  qa_qc        ingest → q01..qN → report
  thin_client  ingest → navigate → action_01..N → verify → report
  thick_client launch → action_01..N → screenshot_verify → report
  db_system    extract → transform_01..N → load → reconcile
  api_system   auth → call_01..N → aggregate → report
  general      trigger → decision_01..N → route → notify → audit
"""

SURFACE_ROUTER_INSTRUCTION = """You are the SurfaceRouterAgent — Agent 2 in AgentForge.

READ: INTENT_SPEC: block from conversation (output of IntakeAgent).

YOUR JOB: Classify the automation surface type and select the correct agent topology.

CLASSIFICATION (apply in this priority order):

1. QA / QC process → surface_type: "qa_qc"
   Signals: validate, check, Y/N verdict, pass/fail, compliance, quality check,
            Actimize, EDR, RRO, case review, "question N", checklist, audit.
   Topology: ingest_agent → q01_agent...qN_agent → report_agent

2. Thin client / browser → surface_type: "thin_client"
   Signals: click, navigate, fill, button, form, CSS selector, XPath,
            URL, web page, browser, Playwright, portal, web UI.
   Topology: ingest_agent → navigate_agent → action_01..N → verify_agent → report_agent

3. Thick client / desktop → surface_type: "thick_client"
   Signals: Power Platform, SAP, desktop app, pyautogui, Win32, screen coordinates,
            window title, right-click, hotkey, .exe, drag-and-drop.
   Topology: launch_agent → action_01..N → screenshot_verify_agent → report_agent

4. Database / backend → surface_type: "db_system"
   Signals: SQL, SELECT, ETL, extract transform load, reconcile, tables, views,
            stored procedure, migration, data pipeline, row count, checksum.
   Topology: extract_agent → transform_01..N → load_agent → reconcile_agent

5. API system → surface_type: "api_system"
   Signals: REST, endpoint, HTTP, GET/POST, OpenAPI, Swagger, OAuth2,
            API key, JSON response, webhook, Apigee, request/response.
   Topology: auth_agent → call_01..N → aggregate_agent → report_agent

6. General workflow → surface_type: "general"
   Signals: approval, route, notify, escalate, SLA, trigger, assignment,
            human review, email, Teams/Slack, workflow, mixed steps.
   Topology: trigger_agent → decision_01..N → route_agent → notify_agent → audit_agent

SECONDARY SURFACES: If the process spans multiple surface types (e.g. a QA process
that also involves browser navigation to Actimize), list secondary surfaces.
The primary surface drives the topology; secondary surfaces add extra tool types.

STEP COUNT:
  qa_qc:        N = number of distinct check questions (from INTENT_SPEC.questions_count)
  thin_client:  N = number of discrete UI actions in the process
  thick_client: N = number of desktop interactions
  db_system:    N = number of transformation rules
  api_system:   N = number of distinct endpoint calls
  general:      N = number of decision/routing conditions

MODEL ASSIGNMENT:
  Ingest / nav / launch / extract / auth / trigger agents: gemini-2.0-flash (fast I/O)
  All step agents (check, action, transform, call, decision): claude-sonnet-4-6 (reasoning)
  Verify / aggregate / reconcile / route agents:            claude-sonnet-4-6
  Report / notify / audit / writer agents:                  claude-sonnet-4-6

OUTPUT: SURFACE_SPEC: followed by JSON (nothing else):

{
  "surface_type": "qa_qc | thin_client | thick_client | db_system | api_system | general",
  "surface_reasoning": "paragraph explaining detection signals that led to this classification",
  "topology": {
    "pattern":     "e.g. Sequential QA with 15 check agents",
    "agent_roles": ["ingest_agent", "q01_agent", "q02_agent", "...", "qNN_agent", "report_agent"],
    "step_count":   15,
    "total_agents": 17,
    "model_map": {
      "ingest_agent":  "gemini-2.0-flash",
      "q_agents":      "claude-sonnet-4-6",
      "report_agent":  "claude-sonnet-4-6"
    }
  },
  "tool_types_needed": ["sql", "rest_api"],
  "discovery_needed": {
    "db":  true,
    "api": false,
    "ui":  false
  },
  "connection_hints": {
    "primary_type": "db",
    "system_name":  "Actimize",
    "auth_hint":    "connection_string"
  },
  "output_format": "json_verdict | screenshot_log | reconciliation_report | api_log | workflow_log",
  "secondary_surfaces": [],
  "record_identifier": {
    "field": "ecn_id",
    "label": "ECN",
    "example": "ECN-2024-001"
  }
}
"""

# ── Canonical topology templates ──────────────────────────────────────────────

TOPOLOGY_TEMPLATES = {

    "qa_qc": {
        "description": "Sequential QA/QC — one agent per check question",
        "first_agent": "ingest_agent",
        "step_prefix": "q",
        "step_suffix": "_agent",
        "fixed_tail":  ["report_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "claude-sonnet-4-6",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["sql", "rest_api", "python"],
        "output":       "json_verdict",
    },

    "thin_client": {
        "description": "Browser automation — Playwright per UI action",
        "first_agent": "ingest_agent",
        "fixed_head":  ["navigate_agent"],
        "step_prefix": "action_",
        "step_suffix": "_agent",
        "fixed_tail":  ["verify_agent", "report_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "gemini-2.0-flash",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["playwright", "python"],
        "output":       "screenshot_log",
    },

    "thick_client": {
        "description": "Desktop automation — pyautogui + PIL per interaction",
        "first_agent": "launch_agent",
        "step_prefix": "action_",
        "step_suffix": "_agent",
        "fixed_tail":  ["screenshot_verify_agent", "report_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "gemini-2.0-flash",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["pyautogui", "pil", "python"],
        "output":       "screenshot_log",
    },

    "db_system": {
        "description": "ETL pipeline — extract, N transforms, load, reconcile",
        "first_agent": "extract_agent",
        "step_prefix": "transform_",
        "step_suffix": "_agent",
        "fixed_tail":  ["load_agent", "reconcile_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "claude-sonnet-4-6",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["sql", "python"],
        "output":       "reconciliation_report",
    },

    "api_system": {
        "description": "API automation — auth, N calls, aggregate, report",
        "first_agent": "auth_agent",
        "step_prefix": "call_",
        "step_suffix": "_agent",
        "fixed_tail":  ["aggregate_agent", "report_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "claude-sonnet-4-6",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["rest_api", "python"],
        "output":       "api_log",
    },

    "general": {
        "description": "General workflow — trigger, N decisions, route, notify, audit",
        "first_agent": "trigger_agent",
        "step_prefix": "decision_",
        "step_suffix": "_agent",
        "fixed_tail":  ["route_agent", "notify_agent", "audit_agent"],
        "ingest_model": "gemini-2.0-flash",
        "step_model":   "claude-sonnet-4-6",
        "report_model": "claude-sonnet-4-6",
        "tool_types":   ["rest_api", "sql", "python"],
        "output":       "workflow_log",
    },
}


def build_agent_role_list(surface_type: str, step_count: int) -> list[str]:
    """Build the ordered list of agent names for a surface type + step count."""
    tmpl = TOPOLOGY_TEMPLATES[surface_type]
    roles = [tmpl["first_agent"]]
    roles += tmpl.get("fixed_head", [])
    for i in range(1, step_count + 1):
        roles.append(f"{tmpl['step_prefix']}{i:02d}{tmpl['step_suffix']}")
    roles += tmpl["fixed_tail"]
    return roles
