"""
agents/runner.py
================
Builds and runs the AgentForge 7-agent SequentialAgent pipeline.

The SequentialAgent is the pipeline:
  document_reader_agent
  planner_agent
  db_discovery_agent
  questions_generator_agent
  yaml_tools_generator_agent
  pipeline_assembler_agent
  validator_agent

Each agent reads all prior outputs from conversation history.
Tools are loaded from YAML files via in-memory MCP servers.
"""

import logging
from contextlib import AsyncExitStack
from pathlib import Path

import yaml as _yaml
from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from mcp.shared.memory import (
    create_connected_server_and_client_session as create_in_memory_pair,
)

from agents.meta_agents import (
    build_document_reader_agent,
    build_planner_agent,
    build_db_discovery_agent,
    build_questions_generator_agent,
    build_yaml_tools_generator_agent,
    build_pipeline_assembler_agent,
    build_validator_agent,
)

logger = logging.getLogger(__name__)

HERE = Path(__file__).parent.parent  # agentforge_v2/

# Which tool YAML files each agent needs
AGENT_TOOL_YAMLS = {
    "document_reader_agent":    ["tools/document_tools.yaml"],
    "planner_agent":            [],
    "db_discovery_agent":       ["tools/db_discovery_tools.yaml",
                                 "tools/file_tools.yaml"],
    "questions_generator_agent":["tools/file_tools.yaml"],
    "yaml_tools_generator_agent":["tools/file_tools.yaml"],
    "pipeline_assembler_agent": ["tools/file_tools.yaml"],
    "validator_agent":          ["tools/file_tools.yaml",
                                 "tools/validation_tools.yaml"],
}

MCP_TOOL_TYPES = {"sql", "python", "rest_api"}


async def _load_tools_from_yaml(
    yaml_paths: list[str],
    exit_stack: AsyncExitStack,
    app_dir:    Path,
) -> list:
    """Load tools from YAML files via in-memory MCP servers."""
    from mcp_factory import create_mcp_server
    all_tools = []
    for rel_path in yaml_paths:
        full_path = str(app_dir / rel_path)
        try:
            with open(full_path) as f:
                fns = _yaml.safe_load(f).get("functions", [])
            mcp_fns = [fn for fn in fns if fn.get("type") in MCP_TOOL_TYPES]
            if not mcp_fns:
                continue
            server         = create_mcp_server(full_path)
            client_session = await exit_stack.enter_async_context(
                create_in_memory_pair(server)
            )
            mcp_tools = await exit_stack.enter_async_context(
                MCPToolset(client_session=client_session)
            )
            all_tools.extend(mcp_tools)
            logger.debug("Loaded %d tools from %s", len(mcp_fns), rel_path)
        except Exception as e:
            logger.warning("Could not load tools from %s: %s", rel_path, e)
    return all_tools


async def run_agentforge(
    input_path:   str,
    pipeline_name: str,
    output_dir:   str,
    app_name:     str = "agentforge",
    no_db:        bool = False,
    verbose:      bool = True,
) -> dict:
    """
    Run the AgentForge 7-agent pipeline.

    Args:
        input_path:    Path to input Excel or Markdown file
        pipeline_name: Name for the generated pipeline (e.g. "edr_qa")
        output_dir:    Where to write generated files
        app_name:      ADK app name
        no_db:         Skip database discovery (use mock schema)
        verbose:       Print agent progress

    Returns:
        dict with validation report and list of generated files
    """
    Path(output_dir).mkdir(parents=True, exist_ok=True)

    async with AsyncExitStack() as stack:

        # ── Build all 7 agents ─────────────────────────────────────────────
        agents_built = []
        builders = [
            ("document_reader_agent",    build_document_reader_agent),
            ("planner_agent",            build_planner_agent),
            ("db_discovery_agent",       build_db_discovery_agent),
            ("questions_generator_agent",build_questions_generator_agent),
            ("yaml_tools_generator_agent",build_yaml_tools_generator_agent),
            ("pipeline_assembler_agent", build_pipeline_assembler_agent),
            ("validator_agent",          build_validator_agent),
        ]

        for agent_name, builder_fn in builders:
            yaml_paths = AGENT_TOOL_YAMLS.get(agent_name, [])
            # If no_db, skip db discovery tools
            if no_db and agent_name == "db_discovery_agent":
                yaml_paths = ["tools/file_tools.yaml"]
            tools = await _load_tools_from_yaml(yaml_paths, stack, HERE)
            agent = builder_fn(tools)
            agents_built.append(agent)
            logger.debug("Built %s with %d tools", agent_name, len(tools))

        # ── Assemble SequentialAgent ───────────────────────────────────────
        pipeline = SequentialAgent(
            name="agentforge_pipeline",
            sub_agents=agents_built,
        )

        session_service = InMemorySessionService()
        run_id = f"forge_{pipeline_name}"
        await session_service.create_session(
            app_name=app_name,
            user_id=run_id,
            session_id=run_id,
        )

        runner = Runner(
            agent=pipeline,
            app_name=app_name,
            session_service=session_service,
        )

        # ── Initial message ────────────────────────────────────────────────
        trigger = (
            f"Read this document: {input_path}. "
            f"Pipeline name: {pipeline_name}. "
            f"Output directory: {output_dir}. "
            + ("Skip database discovery, generate mock schema. " if no_db else "")
            + "Generate a complete ADK SequentialAgent pipeline."
        )

        message = types.Content(
            role="user",
            parts=[types.Part(text=trigger)],
        )

        if verbose:
            print(f"\n{'='*62}")
            print(f"  AgentForge v2  |  {pipeline_name}")
            print(f"  Input  : {input_path}")
            print(f"  Output : {output_dir}")
            print(f"  Agents : 7-agent SequentialAgent meta-pipeline")
            print(f"{'='*62}")

        # ── Stream execution ───────────────────────────────────────────────
        icons = {
            "document_reader_agent":    "📄",
            "planner_agent":            "🧠",
            "db_discovery_agent":       "🔍",
            "questions_generator_agent":"❓",
            "yaml_tools_generator_agent":"🔧",
            "pipeline_assembler_agent": "⚙️",
            "validator_agent":          "✅",
        }

        response_text  = ""
        current_author = None

        async for event in runner.run_async(
            user_id=run_id,
            session_id=run_id,
            new_message=message,
        ):
            author = getattr(event, "author", None)

            if author and author != current_author:
                current_author = author
                if author not in ("agentforge_pipeline", "user"):
                    icon = icons.get(author, "▶")
                    if verbose:
                        print(f"\n  {icon}  {author}")
                    logger.info("Agent active: %s", author)

            if event.get_function_calls() and verbose:
                for call in event.get_function_calls():
                    args_preview = str(call.args)[:80].replace("\n", " ")
                    print(f"       🔧 {call.name}({args_preview})")

            if event.is_final_response() and event.content:
                for part in event.content.parts:
                    if hasattr(part, "text") and part.text:
                        response_text = part.text.strip()
                        if verbose:
                            preview = response_text[:300].replace("\n", "\n       ")
                            print(f"       → {preview}"
                                  f"{'…' if len(response_text) > 300 else ''}")

        # ── Parse final result ─────────────────────────────────────────────
        import json, re
        validation = {}
        m = re.search(
            r"VALIDATION_REPORT_START\s*(.*?)\s*VALIDATION_REPORT_END",
            response_text, re.DOTALL
        )
        if m:
            try:
                validation = json.loads(m.group(1))
            except Exception:
                validation = {"raw": m.group(1)}

        # Count generated files
        generated_files = []
        out = Path(output_dir)
        if out.exists():
            for f in sorted(out.rglob("*")):
                if f.is_file() and not any(
                    p in str(f) for p in ["__pycache__", ".pyc", ".pytest_cache"]
                ):
                    generated_files.append(str(f.relative_to(out)))

        result = {
            "pipeline_name":   pipeline_name,
            "output_dir":      output_dir,
            "generated_files": generated_files,
            "file_count":      len(generated_files),
            "validation":      validation,
            "passed":          validation.get("overall") == "PASS",
        }

        if verbose:
            status = "✅ PASSED" if result["passed"] else "⚠️  CHECK OUTPUT"
            print(f"\n{'='*62}")
            print(f"  {status}")
            print(f"  Files generated: {result['file_count']}")
            print(f"  Output: {output_dir}")
            print(f"{'='*62}\n")

        return result
