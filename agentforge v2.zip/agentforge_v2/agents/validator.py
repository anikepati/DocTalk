"""agents/validator.py — Validator instruction lives in pipeline.py for v2."""
VALIDATOR_INSTRUCTION = ""  # overridden by pipeline.py
