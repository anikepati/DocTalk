"""agents/mock_agent.py — MockData instruction lives in pipeline.py for v2."""
MOCK_DATA_INSTRUCTION = ""  # overridden by pipeline.py
