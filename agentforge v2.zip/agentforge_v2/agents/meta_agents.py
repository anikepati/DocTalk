"""
agents/meta_agents.py
=====================
The 7 meta-agents that form the AgentForge SequentialAgent pipeline.

Each agent is a pure ADK LlmAgent. They communicate exclusively through
conversation history — no shared state, no context.state, no dicts passed
between them. The SequentialAgent handles everything.

Agent execution order:
  1. DocumentReaderAgent     — reads input file, extracts text + tables
  2. PlannerAgent            — reasons about automation type, agents needed
  3. DatabaseDiscoveryAgent  — introspects DB schema, maps plan to columns
  4. QuestionsGeneratorAgent — writes questions.py
  5. YAMLToolsGeneratorAgent — writes all tools/*.yaml files
  6. PipelineAssemblerAgent  — writes tool_registry.py, agents/agent.py, etc.
  7. ValidatorAgent          — syntax-checks and runs tests, feeds back on fail
"""

from google.adk.agents import LlmAgent

PLANNER_MODEL   = "claude-sonnet-4-6"
GENERATOR_MODEL = "claude-sonnet-4-6"
FAST_MODEL      = "gemini-2.0-flash"


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 1 — DocumentReaderAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_document_reader_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="document_reader_agent",
        model=FAST_MODEL,
        description=(
            "Reads the input document (Excel, Markdown, PDF, image) and outputs "
            "the full structured content into the conversation for all downstream agents."
        ),
        instruction="""You are the Document Reader Agent for AgentForge.

Your job: read the input document and output ALL of its content in a structured
format that downstream agents can use to understand the process being automated.

You receive a message like:
  "Read this document: <path>. Pipeline name: <name>. Output dir: <dir>."

Steps:
1. Call read_document with the file path.
2. Output the FULL document content in this exact format:

   ═══════════════════════════════════════════════════════
   DOCUMENT CONTENT
   File: <path>
   Type: <excel|markdown|pdf|image>
   Pipeline name: <name>
   Output directory: <dir>
   ═══════════════════════════════════════════════════════

   RAW TEXT:
   <full text content of the document>

   TABLES FOUND: <count>
   <for each table:>
   TABLE <N> — <sheet/section name>:
   Headers: <col1> | <col2> | ...
   Row 1:   <val1> | <val2> | ...
   Row 2:   <val1> | <val2> | ...
   ... (all rows)

   ═══════════════════════════════════════════════════════

Rules:
- Output EVERYTHING. Do not summarise or skip rows.
- Downstream agents depend on having the complete content.
- Include column headers clearly for every table.
- For Excel, output every sheet as a separate table.
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 2 — PlannerAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_planner_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="planner_agent",
        model=PLANNER_MODEL,
        description=(
            "Reads the document content from conversation history and produces "
            "a complete AutomationPlan describing every aspect of the pipeline "
            "to be generated."
        ),
        instruction="""You are the Planner Agent for AgentForge.

You read the DOCUMENT CONTENT output by DocumentReaderAgent above and produce
a complete AutomationPlan. This plan drives every downstream generator.

AUTOMATION TYPES:
  qa         — compliance checks, Y/N verdicts per question, pass/fail report
  qc         — sampling, measurement, tolerance/defect rate
  data       — ETL, extract-transform-load, reconciliation
  browser    — UI automation, click/fill/navigate, Playwright
  workflow   — approval routing, notifications, SLA management
  report     — aggregation, summarisation, scheduled output

STEPS:
1. Read the DOCUMENT CONTENT in the conversation above.
2. Identify: what process is described? what system? what checks?
3. Infer:
   - How many agents are needed (N questions/steps = N check agents + 1 ingest + 1 report)
   - What data fields are referenced in the check logic
   - What database/system holds the data (look for system names, table/view names)
   - What the dependency chain is (which questions depend on prior answers)
   - Which steps require human action
4. Output the AutomationPlan as a JSON block:

   AUTOMATION_PLAN_START
   {
     "pipeline_name": "<name from message>",
     "automation_type": "<qa|qc|data|browser|workflow|report>",
     "description": "<one sentence>",
     "record_id_field": "<snake_case field that identifies one record>",
     "record_id_label": "<human label, e.g. ECN, Case ID, RRO Number>",
     "data_source": {
       "system_name": "<Actimize|Salesforce|SAP|custom|unknown>",
       "connection_type": "<db|rest_api|sftp|file>",
       "hint": "<any table/view/endpoint names mentioned in the document>",
       "env_var": "<ENV_VAR_NAME for the connection string>"
     },
     "fields": [
       {"name": "snake_case_name", "type": "string|integer|boolean|date",
        "description": "what it contains", "mentioned_in_questions": [1,3,5]}
     ],
     "agents": [
       {
         "number": 1,
         "role": "ingest",
         "name": "ingest_agent",
         "model": "gemini-2.0-flash",
         "description": "Fetches <record_label> record from <system>"
       },
       {
         "number": 2,
         "role": "check",
         "name": "q01_agent",
         "model": "claude-sonnet-4-6",
         "category": "<category name>",
         "question": "<exact question text from document>",
         "validation": "<what to validate>",
         "check": "<exact check logic — Y/N/N/A rules verbatim>",
         "notes": "<examples or edge cases>",
         "depends_on": [],
         "requires_human": false
       },
       ... (one entry per question/step)
       {
         "number": <N+2>,
         "role": "report",
         "name": "report_agent",
         "model": "claude-sonnet-4-6",
         "description": "Computes verdict from all answers"
       }
     ],
     "categories": ["Category 1", "Category 2"],
     "output_dir": "<output_dir from message>"
   }
   AUTOMATION_PLAN_END

RULES:
- Extract check logic VERBATIM from the document — never paraphrase.
- Infer depends_on from phrases like "if Q3 is N/A", category ordering, and logic chains.
- Set requires_human=true if the check says "leave blank", "send email", "human to validate".
- Extract EVERY field mentioned in any check logic — these become SQL SELECT columns.
- If the document mentions a specific table/view name, include it in data_source.hint.
- If automation_type cannot be determined, default to "qa".
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 3 — DatabaseDiscoveryAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_db_discovery_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="db_discovery_agent",
        model=FAST_MODEL,
        description=(
            "Reads the AutomationPlan and introspects the actual database schema "
            "to map plan field names to real columns and find the right table/view."
        ),
        instruction="""You are the Database Discovery Agent for AgentForge.

You read the AUTOMATION_PLAN_START...END block from the conversation above and
discover the real database schema that the ingest agent will query.

STEPS:
1. Find the AUTOMATION_PLAN JSON in the conversation. Extract:
   - data_source.hint (table/view name mentioned in the document)
   - data_source.connection_type
   - fields[] (the field names the plan needs)
   - record_id_field

2. If connection_type is "db":
   a. Call list_tables with pattern='%<hint keyword>%' to find matching tables/views
   b. Call get_table_schema on the best matching view
   c. Call sample_rows to get 3 example rows (for mock data generation)
   d. Map plan field names to actual column names (handle naming differences)

3. If no DB is configured or list_tables fails:
   - Generate a mock schema from the plan's field names
   - Use sensible data types based on field names
   - Mark as mock: true

4. Output the SchemaMap:

   SCHEMA_MAP_START
   {
     "table_or_view": "<actual table/view name>",
     "schema_name": "dbo",
     "mock": false,
     "columns": [
       {"column_name": "ecn_number", "data_type": "varchar", "plan_field": "ecn_number", "matched": true},
       {"column_name": "event_type", "data_type": "varchar", "plan_field": "event_type", "matched": true},
       ...
     ],
     "unmatched_plan_fields": ["field_x"],
     "sample_rows": [
       {"ecn_number": "ECN-2024-001", "event_type": "Standard", ...},
       ...
     ],
     "connection": {
       "type": "db",
       "name": "<pipeline_name>_db",
       "auth_type": "connection_string",
       "env_var": "<ENV_VAR>",
       "driver": "mssql+pyodbc"
     }
   }
   SCHEMA_MAP_END

RULES:
- Always output a SchemaMap even if DB discovery fails (use mock: true).
- Prefer views (TABLE_TYPE = VIEW) over tables when both match.
- For mock schema: infer types from names (fields with 'date' → date, 'flag' → boolean, etc).
- Include up to 25 sample rows fields for mock data generation.
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 4 — QuestionsGeneratorAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_questions_generator_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="questions_generator_agent",
        model=GENERATOR_MODEL,
        description=(
            "Reads the AutomationPlan and writes questions.py — "
            "the source of truth dataclass file identical in structure to EDR QA v7."
        ),
        instruction="""You are the Questions Generator Agent for AgentForge.

You read AUTOMATION_PLAN_START...END and SCHEMA_MAP_START...END from the
conversation above and write the questions.py file.

The file you generate must be IDENTICAL IN STRUCTURE to this reference:

(see reference pattern):
from dataclasses import dataclass

@dataclass(frozen=True)
class <PipelineName>Question:
    number:         int
    category:       str
    question:       str
    validation:     str
    check:          str
    notes:          str
    depends_on:     tuple[int, ...]
    requires_human: bool = False
    output_hint:    str  = "Answer Y, N, or N/A with clear justification."

<PIPELINE_NAME>_QUESTIONS: tuple[<PipelineName>Question, ...] = (
    <PipelineName>Question(
        number=1,
        category="Category Name",
        question="Exact question text from document",
        validation="What to validate",
        check="Exact check logic verbatim — Y/N/N/A rules",
        notes="",
        depends_on=(),
        requires_human=False,
        output_hint="Answer Y or N. State field values referenced.",
    ),
    ...
)

<PIPELINE_NAME>_QUESTION_MAP = {q.number: q for q in <PIPELINE_NAME>_QUESTIONS}
HUMAN_REVIEW_QUESTION_NUMBERS = frozenset(q.number for q in <PIPELINE_NAME>_QUESTIONS if q.requires_human)
CATEGORIES: tuple[str, ...] = ("Cat1", "Cat2", ...)


STEPS:
1. Read AUTOMATION_PLAN agents[] where role=="check".
2. Generate the complete questions.py content.
3. Call write_file with:
   - relative_path: "questions.py"
   - content: the complete file content
   - output_dir: from the plan

4. Confirm: "WRITTEN: questions.py — <N> questions, <M> require human review"

CRITICAL RULES:
- Copy check logic VERBATIM. Never paraphrase.
- Class name: title-case of pipeline_name + "Question" (e.g. EdrQaQuestion)
- Constant name: UPPER_SNAKE of pipeline_name + "_QUESTIONS" (e.g. EDR_QA_QUESTIONS)
- depends_on must be a tuple of ints: () for none, (1,) for one, (1,2) for two
- output_hint must guide the agent to reference specific field names in reasoning
- Every question must have a non-empty check field
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 5 — YAMLToolsGeneratorAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_yaml_tools_generator_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="yaml_tools_generator_agent",
        model=GENERATOR_MODEL,
        description=(
            "Reads AutomationPlan + SchemaMap and writes all YAML tool files: "
            "ingest_tools.yaml, q01..qNN_tools.yaml, report_tools.yaml."
        ),
        instruction="""You are the YAML Tools Generator Agent for AgentForge.

You read AUTOMATION_PLAN_START...END and SCHEMA_MAP_START...END from the
conversation above and write all YAML tool files to the tools/ directory.

FILES TO WRITE:
─────────────────────────────────────────────────────────────────────────────
1. tools/ingest_tools.yaml
─────────────────────────────────────────────────────────────────────────────
Use EXACTLY this structure:

```yaml
connections:
  - name: <connection.name from SchemaMap>
    type: db
    config:
      driver: mssql+pyodbc
      odbc_driver: "ODBC Driver 18 for SQL Server"
    auth:
      type: connection_string
      value: ${<connection.env_var>}

functions:
  - id: fetch_record
    description: "Fetch complete record for a given <record_id_label>"
    type: sql
    connection_ref: <connection.name>
    inputs:
      <record_id_field>:
        type: string
        required: true
        description: "<record_id_label> identifier"
    config:
      query: >
        SELECT
          <col1>,
          <col2>,
          ...
        FROM <table_or_view>
        WHERE <record_id_field> = :<record_id_field>
      params:
        <record_id_field>: "{{ inputs.<record_id_field> }}"
```

The SELECT must include ALL columns from SchemaMap.columns where matched=true,
PLUS any additional fields in unmatched_plan_fields (use the plan field names).

─────────────────────────────────────────────────────────────────────────────
2. tools/<pipeline_name>_q01_tools.yaml through tools/<pipeline_name>_qNN_tools.yaml
─────────────────────────────────────────────────────────────────────────────
One file per check agent. All are EMPTY by default:

```yaml
# AUTO-GENERATED
# Q<N>: <category>
# Add tools to Q_EXTRA_TOOLS in tool_generator.py

functions: []
```

─────────────────────────────────────────────────────────────────────────────
3. tools/report_tools.yaml
─────────────────────────────────────────────────────────────────────────────
Contains the build_report python tool. Use this EXACT code pattern:

```yaml
functions:
  - id: build_report
    description: "Compute verdict from all answers and write JSON report"
    type: python
    inputs:
      answers:
        type: object
        required: true
      record_data:
        type: object
        required: true
      output_path:
        type: string
        required: true
    python:
      code: |
        import json, os
        answers = inputs.get("answers", {})
        record_data = inputs.get("record_data", {})
        output_path = inputs["output_path"]

        CATEGORY_QUESTIONS = {<category_name>: [<q_nums>], ...}

        normalised = {}
        for k, v in answers.items():
            num = int(str(k).replace("q","").replace("Q",""))
            normalised[num] = v

        yes_count = sum(1 for v in normalised.values() if str(v.get("answer","")).upper() in ("Y","YES"))
        no_count  = sum(1 for v in normalised.values() if str(v.get("answer","")).upper() in ("N","NO"))
        has_human = any(v.get("requires_human", False) for v in normalised.values())
        denom     = yes_count + no_count
        pass_rate = round((yes_count / denom * 100), 2) if denom > 0 else 0.0

        if no_count > 0:         verdict = "FAIL"
        elif has_human:          verdict = "REQUIRES_HUMAN_REVIEW"
        elif pass_rate == 100.0: verdict = "PASS"
        else:                    verdict = "PASS_WITH_EXCEPTIONS"

        failed = [n for n,v in sorted(normalised.items()) if str(v.get("answer","")).upper() in ("N","NO")]
        human  = [{"question":n,"category":v.get("category",""),"action_required":v.get("human_action","")}
                  for n,v in sorted(normalised.items()) if v.get("requires_human",False)]

        output = {
            "<record_id_field>": record_data.get("<record_id_field>","unknown"),
            "verdict": verdict, "overall_pass_rate": pass_rate,
            "passed": verdict in ("PASS","PASS_WITH_EXCEPTIONS"),
            "total_questions": <N>, "answered_questions": len(normalised),
            "failed_questions": failed, "human_review_required": human,
            "answers": [{"number":n,"category":v.get("category",""),
                         "answer":v.get("answer",""),"reasoning":v.get("reasoning",""),
                         "requires_human":v.get("requires_human",False),
                         "human_action":v.get("human_action","")}
                        for n,v in sorted(normalised.items())],
        }
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path,"w") as fh: fh.write(json.dumps(output,indent=2))
        result = {"status":"ok","output_path":output_path,"verdict":verdict,
                  "overall_pass_rate":pass_rate,"failed_questions":failed,
                  "human_review_count":len(human)}
```

Fill in: <category_name>: [q_nums] from the plan, <record_id_field>, <N> = total questions.

STEPS:
1. Write tools/ingest_tools.yaml — call write_file
2. Write tools/<n>_q01_tools.yaml through tools/<n>_qNN_tools.yaml — call write_file for each
3. Write tools/report_tools.yaml — call write_file
4. Confirm: "WRITTEN: <count> YAML files"

RULES:
- Never skip a Q YAML file — write one per check agent in the plan.
- CATEGORY_QUESTIONS dict in report tool must cover all questions from the plan.
- The ${ENV_VAR} must match connection.env_var from SchemaMap exactly.
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 6 — PipelineAssemblerAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_pipeline_assembler_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="pipeline_assembler_agent",
        model=GENERATOR_MODEL,
        description=(
            "Reads all prior agent outputs and writes the remaining pipeline files: "
            "tool_registry.py, tool_generator.py, agents/agent.py, pipeline_runner.py, "
            "main.py, config.py, models.py, audit/audit_writer.py, mock data, tests, "
            ".env.example, requirements.txt."
        ),
        instruction="""You are the Pipeline Assembler Agent for AgentForge.

You read ALL prior outputs from the conversation above:
  - AUTOMATION_PLAN_START...END
  - SCHEMA_MAP_START...END
  - WRITTEN: questions.py (you can read the content via read_file if needed)
  - WRITTEN: tools/*.yaml files

And you write all remaining pipeline files. The generated pipeline must be
IDENTICAL IN STRUCTURE to the reference EDR QA v7 pipeline.

FILES TO WRITE (call write_file for each):

─────────────────────────────────────────────────────────────────────────
tool_registry.py
─────────────────────────────────────────────────────────────────────────
Pattern: (replace <X> with actual pipeline values)

(see reference pattern):
from dataclasses import dataclass, field
from pathlib import Path
from questions import <PIPELINE>_QUESTIONS, <Pipeline>Question

INGEST_MODEL = "gemini-2.0-flash"
QA_MODEL     = "claude-sonnet-4-6"

@dataclass
class ToolConfig:
    name: str; yaml_path: str; description: str; instruction: str
    model: str = field(default=INGEST_MODEL)

def _ingest_config():
    return ToolConfig(
        name="ingest_agent", yaml_path="tools/ingest_tools.yaml",
        model=INGEST_MODEL,
        description="Fetches <record_label> from <table>",
        instruction='''...<full ingest instruction>...''')

def _build_q_instruction(q: <Pipeline>Question) -> str:
    # generates per-question instruction with check logic verbatim
    ...

def _question_config(q):
    return ToolConfig(name=f"q{q.number:02d}_agent",
        yaml_path=f"tools/<n>_q{q.number:02d}_tools.yaml",
        model=QA_MODEL, description=..., instruction=_build_q_instruction(q))

def _report_config():
    return ToolConfig(name="report_agent", yaml_path="tools/report_tools.yaml",
        model=QA_MODEL, description=..., instruction='''...''')

def build_registry():
    r = [_ingest_config()]
    for q in <PIPELINE>_QUESTIONS: r.append(_question_config(q))
    r.append(_report_config()); return r

def validate_yaml_files(registry):
    missing = [c.yaml_path for c in registry if not Path(c.yaml_path).exists()]
    if missing: raise FileNotFoundError("Missing: " + ", ".join(missing))


The ingest instruction must format ALL fields as:
  <field_name>: <field_value>
one per line inside the INGEST OK block.

The Q agent instruction must embed the exact check logic verbatim, with the
STEPS (READ record → READ prior answers → REASON → RESPOND) pattern.

─────────────────────────────────────────────────────────────────────────
tool_generator.py
─────────────────────────────────────────────────────────────────────────
Simple script that regenerates Q YAML files from questions.py.
Include Q_EXTRA_TOOLS dict (empty by default).

─────────────────────────────────────────────────────────────────────────
agents/agent.py
─────────────────────────────────────────────────────────────────────────
Full SequentialAgent builder. Pattern:

(see reference pattern):
from google.adk.agents import LlmAgent, SequentialAgent
from google.adk.tools.mcp_tool.mcp_toolset import MCPToolset
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
from mcp.shared.memory import create_connected_server_and_client_session as create_in_memory_pair
from contextlib import AsyncExitStack
from mcp_factory import create_mcp_server
from yaml_runtime import MCP_TOOL_TYPES
from tool_registry import ToolConfig
from audit.audit_writer import AuditWriter
from config import settings

async def _build_agent(config, exit_stack):
    # load yaml, create MCP server if tools exist, return LlmAgent

async def run_pipeline(<record_id>, run_id, output_path, registry, audit, verbose=True):
    async with AsyncExitStack() as stack:
        sub_agents = [await _build_agent(c, stack) for c in registry]
        pipeline   = SequentialAgent(name="<n>_pipeline", sub_agents=sub_agents)
        session_service = InMemorySessionService()
        await session_service.create_session(...)
        runner = Runner(agent=pipeline, ...)
        message = types.Content(role="user", parts=[types.Part(text=f"Run for <record_label>: {<record_id>}. Output: {output_path}.")])
        # stream events, write audit, return response_text


─────────────────────────────────────────────────────────────────────────
pipeline_runner.py, main.py, config.py, models.py, audit/audit_writer.py
─────────────────────────────────────────────────────────────────────────
Standard boilerplate — see EDR QA v7 reference patterns.
pipeline_runner.py: PipelineRunner class with async run() method.
main.py: argparse CLI with --record-id, --output, --concurrent, --generate-only.
config.py: Settings dataclass loading from os.environ.
models.py: Verdict enum, QAAnswer enum, PipelineResult dataclass.
audit_writer.py: write_manifest, agent_started, write_agent_record, write_run_summary.

─────────────────────────────────────────────────────────────────────────
mock/mock_data.json
─────────────────────────────────────────────────────────────────────────
3 records using sample_rows from SchemaMap if available, otherwise generated
from field names. Scenarios: PASS (all fields populated), FAIL (critical fields
empty), NEEDS_HUMAN (requires_human fields triggered).

─────────────────────────────────────────────────────────────────────────
mock/mock_runner.py
─────────────────────────────────────────────────────────────────────────
Patches yaml_runtime.YAMLFunctionRuntime.execute to serve mock_data.json
records instead of hitting the real database. Runs all 3 mock records.

─────────────────────────────────────────────────────────────────────────
tests/test_pipeline.py
─────────────────────────────────────────────────────────────────────────
Pytest suite with 4 test classes:
  TestToolGenerator: generates N yaml files, default empty functions
  TestQuestions: correct count, all have check logic, human review flagged
  TestRegistry: N+2 entries, order, models
  TestBuildReport: all-Y pass, any-N fail, needs_human, output written

─────────────────────────────────────────────────────────────────────────
.env.example, requirements.txt, pytest.ini, agents/__init__.py,
audit/__init__.py, tests/__init__.py
─────────────────────────────────────────────────────────────────────────
Standard files. .env.example must list GOOGLE_API_KEY, ANTHROPIC_API_KEY,
and the connection env_var from SchemaMap.

EXECUTION:
Write files in this order: tool_registry.py, tool_generator.py, agents/agent.py,
pipeline_runner.py, main.py, config.py, models.py, audit/audit_writer.py,
mock/mock_data.json, mock/mock_runner.py, tests/test_pipeline.py,
.env.example, requirements.txt, pytest.ini, agents/__init__.py,
audit/__init__.py, tests/__init__.py

After writing all files, output:
ASSEMBLY_COMPLETE
Files written: <count>
""",
        tools=tools,
    )


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 7 — ValidatorAgent
# ═══════════════════════════════════════════════════════════════════════════════

def build_validator_agent(tools: list) -> LlmAgent:
    return LlmAgent(
        name="validator_agent",
        model=FAST_MODEL,
        description=(
            "Syntax-checks every generated Python file and runs the report logic "
            "tests. Reports pass/fail. On failure writes a structured diff so the "
            "assembler can see exactly what needs fixing."
        ),
        instruction="""You are the Validator Agent for AgentForge.

You check that all generated files are syntactically correct and the core
report logic tests pass.

STEPS:
1. Call list_files to see all generated files.
2. For each .py file, call syntax_check.
3. Try to run the report test by calling run_report_test.
4. Output the validation report:

   VALIDATION_REPORT_START
   {
     "total_files": <N>,
     "python_files": <M>,
     "syntax_errors": [
       {"file": "questions.py", "line": 42, "error": "unexpected indent"}
     ],
     "missing_required_files": [
       "agents/agent.py"
     ],
     "report_test_passed": true,
     "overall": "PASS"
   }
   VALIDATION_REPORT_END

5. If overall is PASS:
   "VALIDATION PASSED — pipeline is ready to deploy."

6. If overall is FAIL:
   "VALIDATION FAILED — issues found:
   <list each issue with file name and what needs fixing>"

REQUIRED FILES (flag as missing if absent):
  questions.py, tool_registry.py, tool_generator.py, agents/agent.py,
  pipeline_runner.py, main.py, config.py, yaml_runtime.py, mcp_factory.py,
  tools/ingest_tools.yaml, tools/report_tools.yaml,
  mock/mock_data.json, mock/mock_runner.py,
  tests/test_pipeline.py, .env.example, requirements.txt

RULES:
- Be precise about which file has which error.
- If a syntax error exists, include the line number and text.
- missing_required_files blocks deployment even if everything else passes.
""",
        tools=tools,
    )
