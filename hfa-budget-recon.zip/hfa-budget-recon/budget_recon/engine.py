"""Orchestrates a three-way reconciliation for one loan and one draw / revision.

  Keying check   : borrower file  vs  LOB entry       -> typos, consolidations, missed lines (should be identical)
  Change check   : approved budget vs borrower file   -> real budget changes (need approvals), dirty baseline
  Rules          : config-driven checks on the reconciled budget-level groups and the loan totals
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field

from . import __version__
from .changes import analyse_changes, collect_deltas
from .config import Config
from .hierarchy import rollup
from .matcher import Matcher
from .models import LoanInput, ReconException
from .money import usd
from .normalize import Normalizer
from .rules import RuleEngine
from . import structure
from .typos import classify_amount_diff

CONTINGENCY_HARD = "HC-0900"
# patterns that are almost never a genuine budget change; WRONG_DIGIT (640,000 -> 650,000) often is one
STRONG_TYPO_PATTERNS = {"TRANSPOSED_DIGITS", "DROPPED_DIGIT", "EXTRA_DIGIT", "DECIMAL_SHIFT"}


@dataclass
class ReconReport:
    loan_id: str
    engine_version: str
    config_version: str
    run_at: str
    keying: object = None
    change: object = None
    exceptions: list = field(default_factory=list)
    rule_results: list = field(default_factory=list)
    loan_context: dict = field(default_factory=dict)
    cleared_changes: list = field(default_factory=list)
    proposed_budget: list = field(default_factory=list)
    borrower_lines: list = field(default_factory=list)  # normalized + rolled up; what posting uses
    ledger_version: object = None
    findings: object = None  # structure.Findings: category tie-out, misfiles, regroups, attribution
    corrections: list = field(default_factory=list)  # SOR values to correct (not budget changes)

    @property
    def can_post(self) -> bool:
        return not any(e.blocks_posting for e in self.exceptions)

    def counts(self) -> dict:
        out = {}
        for e in self.exceptions:
            out[e.severity] = out.get(e.severity, 0) + 1
        return out

    def auto_match_rate(self, comparison: str, threshold: float) -> float:
        res = self.keying if comparison == "keying" else self.change
        if res is None:
            return 0.0
        total = sum(len(g.left) for g in res.groups) + len(res.unmatched_left)
        auto = sum(len(g.left) for g in res.groups if g.confidence >= threshold)
        return auto / total if total else 1.0

    def to_dict(self) -> dict:
        def mr(res):
            if res is None:
                return None
            return {
                "groups": [g.to_dict() for g in res.groups],
                "unmatched_left": [l.to_dict() for l in res.unmatched_left],
                "unmatched_right": [l.to_dict() for l in res.unmatched_right],
            }
        return {
            "loan_id": self.loan_id,
            "ledger_version": self.ledger_version,
            "engine_version": self.engine_version,
            "config_version": self.config_version,
            "run_at": self.run_at,
            "can_post": self.can_post,
            "exception_counts": self.counts(),
            "exceptions": [e.to_dict() for e in self.exceptions],
            "keying_check": mr(self.keying),
            "change_check": mr(self.change),
            "cleared_changes": [{**c, "codes": sorted(c["codes"]), "norms": sorted(c["norms"]), "delta": usd(c["delta"])}
                                for c in self.cleared_changes],
            "rule_results": self.rule_results,
            "loan_context": {k: (usd(v) if isinstance(v, int) and not isinstance(v, bool) else v)
                             for k, v in self.loan_context.items()},
            "proposed_budget_version": [l.to_dict() for l in self.proposed_budget],
        }


class ReconEngine:
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.norm = Normalizer(cfg)
        self.rules = RuleEngine(cfg.rules, cfg.settings)

    def reconcile(self, loan: LoanInput, ledger=None) -> ReconReport:
        """ledger: current BudgetVersion. When given it replaces loan.approved as the approved side,
        and its aliases let restructured lines match the borrower's lines 1:1."""
        cfg = self.cfg
        rep = ReconReport(loan.loan_id, __version__, cfg.version,
                          _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds"))
        if ledger is not None:
            rep.ledger_version = ledger.version_no
            approved = ledger.to_recon_lines(self.norm)
        else:
            approved = self.norm.normalize_all(loan.approved)
        borrower = self.norm.normalize_all(loan.borrower)
        lob = self.norm.normalize_all(loan.lob)
        previous = self.norm.normalize_all(loan.previous_borrower)

        rep.exceptions += self._extraction_checks(borrower)
        # Trade (G703) detail is compared line by line when BOTH sides carry it; otherwise the side that
        # has it is rolled up to the loan-budget line so the two sides are at the same level.
        raw_borrower = borrower
        both = self._has_trades(approved) and self._has_trades(borrower)
        if not both:
            approved, e1 = rollup(approved, self.norm, "approved")
            borrower, e2 = rollup(borrower, self.norm, "borrower")
            if previous is not None:
                previous, _ = rollup(previous, self.norm, "previous")
            rep.exceptions += e1 + e2
        if lob is not None:
            if not (self._has_trades(lob) and self._has_trades(raw_borrower)):
                lob, e3 = rollup(lob, self.norm, "lob")
                borrower_k, _ = rollup(raw_borrower, self.norm, "borrower")
                rep.exceptions += e3
            else:
                borrower_k = raw_borrower

        # 1) keying check: borrower source document vs LOB entry
        if lob is not None:
            m = Matcher(cfg, cfg.s("keying_columns"), "keying", loan.loan_id)
            rep.keying = m.run(borrower_k, lob, loan.mappings)
            rep.exceptions += self._keying_exceptions(rep.keying)

        # 2) change check: last approved budget vs borrower file (borrower figures are the source of truth)
        m = Matcher(cfg, cfg.s("change_columns"), "change", loan.loan_id)
        rep.change = m.run(approved, borrower, loan.mappings)
        rep.findings = structure.analyse(rep.change, approved, borrower, previous, cfg)
        rep.exceptions += self._change_exceptions(rep.change, rep.findings)
        rep.exceptions += self._structure_exceptions(rep.findings)
        rep.corrections = self._corrections

        approvals = [{**a, "norm_label": " ".join(self.norm.tokens(a["label"])) if a.get("label") else None}
                     for a in loan.approvals]
        chg_excs, rep.cleared_changes, approved_net = analyse_changes(
            collect_deltas(rep.change, skip=self._typo_groups), approvals, cfg)
        rep.exceptions += chg_excs

        # 3) rules
        rep.loan_context = self._loan_context(approved, borrower, loan, approved_net)
        excs, results = self.rules.evaluate("loan", rep.loan_context)
        rep.exceptions += excs
        rep.rule_results += [{**r, "target": "loan"} for r in results]
        for ctx, keys, name in self._group_contexts(rep.change):
            excs, results = self.rules.evaluate("group", ctx, keys)
            rep.exceptions += excs
            rep.rule_results += [{**r, "target": name} for r in results if r["status"] not in ("PASS", "NOT_APPLICABLE")]

        rep.proposed_budget = sorted(borrower, key=lambda l: (l.category or "", l.cost_code or "", l.key))
        rep.borrower_lines = borrower
        order = {"BLOCKING": 0, "REVIEW": 1, "WARNING": 2, "INFO": 3}
        rep.exceptions.sort(key=lambda e: (order[e.severity], -e.impact_cents, e.reason_code))
        return rep

    # ------------------------------------------------------------------
    def _has_trades(self, lines):
        return any(self.norm.codes.get(l.cost_code or "", {}).get("rollup_to") for l in (lines or []))

    def _extraction_checks(self, borrower):
        out = []
        for l in borrower:
            if l.reported_balance is not None and l.reported_balance != l.balance:
                out.append(ReconException(
                    "EXTRACTION_MATH_ERROR", "BLOCKING", "extraction",
                    f"{l.label}: budget - prior - current = {usd(l.balance)} but the file shows balance {usd(l.reported_balance)}. "
                    "Re-extract or check the source document before reconciling.",
                    impact_cents=abs(l.balance - l.reported_balance), line_keys=[l.key],
                ))
        return out

    def _review_or_info(self, conf):
        return "INFO" if conf >= self.cfg.s("auto_accept_confidence", 0.95) else "REVIEW"

    def _keying_exceptions(self, res):
        out, cols = [], self.cfg.s("keying_columns")
        for g in res.groups:
            if g.relation in ("N:1", "1:N"):
                sev = self._review_or_info(g.confidence)
                out.append(ReconException(
                    "LOB_CONSOLIDATION", sev, "keying",
                    f"LOB keyed {len(g.right)} line(s) for {len(g.left)} borrower line(s): "
                    f"{' + '.join(l.label for l in g.left)} = {' + '.join(l.label for l in g.right)} "
                    f"(confidence {g.confidence:.2f}).",
                    line_keys=[l.key for l in g.left + g.right], evidence={"notes": g.notes},
                    suggestion={"action": "Confirm grouping; it will be saved and reused on later draws"},
                ))
                continue
            l, r = g.left[0], g.right[0]
            diffs = [c for c in cols if l.col(c) != r.col(c)]
            for c in diffs:
                cls = classify_amount_diff(l.col(c), r.col(c))
                if cls["pattern"] == "ROUNDING":
                    continue
                code = "PROBABLE_KEYING_ERROR" if cls["pattern"] != "UNEXPLAINED" else "KEYED_AMOUNT_MISMATCH"
                out.append(ReconException(
                    code, "BLOCKING", "keying",
                    f"{r.label}: LOB keyed {c} {usd(r.col(c))}, borrower file shows {usd(l.col(c))} ({cls['pattern']}).",
                    impact_cents=abs(l.col(c) - r.col(c)), line_keys=[l.key, r.key],
                    evidence={"column": c, "pattern": cls["pattern"], "borrower": usd(l.col(c)), "lob": usd(r.col(c))},
                    suggestion={"action": "Correct the LOB entry", "column": c, "value": usd(cls["suggested_cents"])},
                ))
            if not diffs and g.confidence < self.cfg.s("auto_accept_confidence", 0.95):
                out.append(ReconException(
                    "LOW_CONFIDENCE_MATCH", "REVIEW", "keying",
                    f"{l.label} matched to LOB line {r.label} on numbers only (confidence {g.confidence:.2f}).",
                    line_keys=[l.key, r.key], evidence={"notes": g.notes, "pass": g.pass_name},
                ))
        out += self._ambiguity_and_limits(res, "keying")
        for l in res.unmatched_left:
            out.append(ReconException("LOB_MISSING_LINE", "BLOCKING", "keying",
                                      f"Borrower line {l.label} ({usd(l.budget)}) was not keyed by the LOB.",
                                      impact_cents=l.budget, line_keys=[l.key]))
        for r in res.unmatched_right:
            out.append(ReconException("LOB_EXTRA_LINE", "BLOCKING", "keying",
                                      f"LOB line {r.label} ({usd(r.budget)}) has no source in the borrower file.",
                                      impact_cents=r.budget, line_keys=[r.key]))
        return out

    def _change_exceptions(self, res, f=None):
        out = []
        f = f or structure.Findings()
        self._typo_groups = set()
        self._typo_delta = 0
        self._corrections = []
        cont = {c["line"].key: c for c in f.continuity}
        for g in res.groups:
            keys = [l.key for l in g.left + g.right]
            names = " + ".join(l.label for l in g.right)
            if g.relation in ("N:1", "1:N"):
                which = "BASELINE_CONSOLIDATION" if g.relation == "1:N" else "BORROWER_CONSOLIDATION"
                out.append(ReconException(
                    which, self._review_or_info(g.confidence), "change",
                    f"{' + '.join(l.label for l in g.left)} (system) = {names} (borrower), confidence {g.confidence:.2f}.",
                    line_keys=keys, evidence={"notes": g.notes},
                    suggestion={"action": "Confirm; the next budget version stores the borrower's line detail"}
                    if which == "BASELINE_CONSOLIDATION" else {"action": "Confirm grouping"},
                ))
            elif g.confidence < self.cfg.s("auto_accept_confidence", 0.95):
                out.append(ReconException(
                    "LOW_CONFIDENCE_MATCH", "REVIEW", "change",
                    f"System {g.left[0].label} matched to borrower {g.right[0].label} (confidence {g.confidence:.2f}).",
                    line_keys=keys, evidence={"notes": g.notes, "pass": g.pass_name},
                ))
            lb, rb = g.total("left", "budget"), g.total("right", "budget")
            if lb != rb:
                cls = classify_amount_diff(rb, lb)  # borrower file = source; system value = what was keyed
                attr = f.budget_attribution.get(id(g))
                if attr == "SOR_ERROR" or (attr is None and cls["pattern"] in STRONG_TYPO_PATTERNS):
                    self._typo_groups.add(id(g))
                    self._typo_delta += rb - lb
                    self._corrections.append({"group": g, "column": "budget", "amount": rb - lb,
                                              "basis": "previous borrower file unchanged" if attr else cls["pattern"]})
                    why = ("the borrower's budget for this line has not changed since their last draw, so the "
                           "system value is wrong" if attr else f"{cls['pattern']}: most likely mistyped when entered")
                    out.append(ReconException(
                        "SOR_BUDGET_ERROR" if attr else "PROBABLE_KEYING_ERROR", "BLOCKING", "change",
                        f"{names}: system budget {usd(lb)} vs borrower {usd(rb)}; {why}. Not a budget change.",
                        impact_cents=abs(lb - rb), line_keys=keys,
                        evidence={"column": "budget", "pattern": cls["pattern"], "system": usd(lb), "borrower": usd(rb),
                                  "attribution": attr or "typo pattern"},
                        suggestion={"action": "Correct the system value", "value": usd(rb)},
                    ))
                elif cls["pattern"] == "ROUNDING":
                    self._typo_groups.add(id(g))  # under $1: noted, never treated as a budget change
                    self._typo_delta += rb - lb
                    out.append(ReconException(
                        "ROUNDING_DIFFERENCE", "INFO", "change",
                        f"{names}: system {usd(lb)} vs borrower {usd(rb)} (rounding).",
                        impact_cents=abs(lb - rb), line_keys=keys, evidence={"column": "budget"},
                    ))
                elif attr == "BOTH_MOVED":
                    out.append(ReconException(
                        "BUDGET_BOTH_MOVED", "BLOCKING", "change",
                        f"{names}: system {usd(lb)}, borrower now {usd(rb)}, and neither equals the borrower's previous "
                        "file. The system value and the budget both changed; resolve the system value first.",
                        impact_cents=abs(lb - rb), line_keys=keys, evidence={"column": "budget"},
                    ))
            lp, rp = g.total("left", "prior"), g.total("right", "prior")
            if lp != rp:
                cls = classify_amount_diff(rp, lp)
                if id(g) in f.prior_misallocated:
                    out.append(ReconException(
                        "PRIOR_MISALLOCATED", "REVIEW", "change",
                        f"{names}: paid-to-date {usd(lp)} in the system vs {usd(rp)} per borrower. Paid-to-date for the "
                        "category ties, so draws were booked to the wrong line; total disbursed is unaffected.",
                        impact_cents=abs(lp - rp), line_keys=keys, evidence={"column": "prior", "pattern": cls["pattern"]},
                        suggestion={"action": "Reclass paid-to-date between the lines (no cash movement)"},
                    ))
                    continue
                hint = f" Looks like {cls['pattern']} in the system value." if cls["pattern"] in STRONG_TYPO_PATTERNS else ""
                if f.has_previous and all(r.key not in cont for r in g.right):
                    hint += (" The borrower's own history is consistent (last prior + last request = this prior), "
                             "so the system is missing or duplicating a disbursement record.")
                out.append(ReconException(
                    "PRIOR_DRAW_MISMATCH", "BLOCKING", "change",
                    f"{names}: borrower shows prior draws {usd(rp)}, system has {usd(lp)}.{hint}",
                    impact_cents=abs(lp - rp), line_keys=keys,
                    evidence={"column": "prior", "pattern": cls["pattern"]},
                    suggestion={"action": "Reconcile draw history (missed or duplicated funding) before posting"},
                ))
        out += self._ambiguity_and_limits(res, "change")
        return out

    def _structure_exceptions(self, f):
        out = []
        for rg in f.regroups:
            out.append(ReconException(
                "REGROUPED_WITHIN_CATEGORY", "REVIEW", "change",
                f"{rg['category']}: system lines {', '.join(l.label for l in rg['left'])} and borrower lines "
                f"{', '.join(r.label for r in rg['right'])} add up to the same budget and paid-to-date. The lines were "
                "grouped differently when keyed; adopt the borrower's line detail.",
                line_keys=[x.key for x in rg["left"] + rg["right"]],
                evidence={"budget": usd(sum(r.budget for r in rg["right"])), "prior": usd(sum(r.prior for r in rg["right"]))},
                suggestion={"action": "Confirm; restructuring replaces the system lines with the borrower's lines"},
            ))
        for m in f.misfiles:
            g = m["group"]
            out.append(ReconException(
                "CATEGORY_MISFILED", "REVIEW", "change",
                f"{' + '.join(l.label for l in g.left)} is filed under {m['sor_category']} in the system but "
                f"{m['borrower_category']} in the borrower file ({usd(m['budget'])}).",
                impact_cents=m["budget"], line_keys=[x.key for x in g.left + g.right],
                suggestion={"action": f"Move the line to {m['borrower_category']}; check source restrictions"},
            ))
        for c in f.continuity:
            r = c["line"]
            out.append(ReconException(
                "BORROWER_CONTINUITY_BREAK", "BLOCKING", "extraction",
                f"{r.label}: borrower's previous file showed {usd(c['previous_prior'])} prior + "
                f"{usd(c['previous_request'])} requested, but this file shows {usd(r.prior)} prior.",
                impact_cents=abs(r.prior - c["previous_prior"] - c["previous_request"]), line_keys=[r.key],
                suggestion={"action": "Ask the borrower to explain or correct the previous-application column"},
            ))
        for t in f.category_tieout:
            gb, gp = t["budget_gap_after_misfiles"], t["prior_gap_after_misfiles"]
            if gb or gp:
                out.append(ReconException(
                    "CATEGORY_GAP", "INFO", "change",
                    f"{t['category']}: after moving misfiled lines, budget differs by {usd(gb)} and paid-to-date by "
                    f"{usd(gp)}; the line-level findings for this category explain it.",
                    impact_cents=abs(gb) + abs(gp), evidence=t,
                ))
        return out

    def _ambiguity_and_limits(self, res, comparison):
        out = []
        for a in res.ambiguities:
            t = a["target"]
            out.append(ReconException(
                "AMBIGUOUS_CONSOLIDATION", "BLOCKING", comparison,
                f"{t.label} ({usd(t.budget)}) can be explained by {len(a['candidates'])} different groups of lines; "
                "the engine will not guess.",
                impact_cents=t.budget, line_keys=[t.key],
                evidence={"candidates": [[f"{m.label} {usd(m.budget)}" for m in ms] for ms in a["candidates"]]},
                suggestion={"action": "Pick the correct group; it is saved for later draws"},
            ))
        for s in res.search_limits:
            out.append(ReconException("SEARCH_LIMIT", "REVIEW", comparison,
                                      f"Consolidation search skipped for {s['target'].label}: {s['reason']}.",
                                      line_keys=[s["target"].key]))
        return out

    def _loan_context(self, approved, borrower, loan, approved_net):
        def tot(lines, pred=lambda l: True, col="budget"):
            return sum(l.col(col) for l in lines if pred(l))
        hard_work = lambda l: l.category == "HARD" and l.cost_code != CONTINGENCY_HARD
        ctx = {
            "total_budget": tot(borrower),
            "approved_total": tot(approved),
            "approved_net_change": approved_net,
            "total_sources": sum(s["amount"] for s in loan.sources) if loan.sources else None,
            "this_draw": tot(borrower, col="current"),
        }
        ctx["net_change"] = ctx["total_budget"] - ctx["approved_total"]
        # a probable keying error in the system value is not a budget change: keep it out of the net-change test
        ctx["probable_typo_delta"] = getattr(self, "_typo_delta", 0)
        ctx["unapproved_net_change"] = ctx["net_change"] - approved_net - ctx["probable_typo_delta"]
        ctx["sources_gap"] = (ctx["total_sources"] - ctx["total_budget"]) if ctx["total_sources"] is not None else None
        hb = tot(borrower, hard_work)
        done = tot(borrower, hard_work, "prior") + tot(borrower, hard_work, "current")
        ctx["pct_complete"] = round(100.0 * done / hb, 2) if hb else None
        cont_appr = tot(approved, lambda l: l.cost_code == CONTINGENCY_HARD)
        cont_now = tot(borrower, lambda l: l.cost_code == CONTINGENCY_HARD)
        cont_drawn = tot(borrower, lambda l: l.cost_code == CONTINGENCY_HARD, "prior") + \
            tot(borrower, lambda l: l.cost_code == CONTINGENCY_HARD, "current")
        ctx["contingency_budget_approved"] = cont_appr
        ctx["contingency_used_pct"] = round(100.0 * ((cont_appr - cont_now) + cont_drawn) / cont_appr, 2) if cont_appr else None
        return ctx

    def _group_contexts(self, res):
        def ctx(label, category, b, p, c, ret, ab, ap):
            return {"label": label, "category": category, "budget": b, "prior": p, "current": c,
                    "retainage": ret, "approved_budget": ab, "approved_prior": ap,
                    "remaining": b - p, "overrun": p + c - b}
        for g in res.groups:
            src = g.right
            label = " + ".join(l.label for l in src)
            yield (ctx(label, src[0].category, g.total("right", "budget"), g.total("right", "prior"),
                       g.total("right", "current"), g.total("right", "retainage"),
                       g.total("left", "budget"), g.total("left", "prior")),
                   [l.key for l in g.left + g.right], label)
        for l in res.unmatched_right:  # new lines: no approved budget
            yield (ctx(l.label, l.category, l.budget, l.prior, l.current, l.retainage, 0, 0), [l.key], l.label)
