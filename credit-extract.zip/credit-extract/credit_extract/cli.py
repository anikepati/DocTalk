"""
End-to-end driver. Every subcommand maps to one PART of the RUNBOOK.

    python -m credit_extract.cli all              # everything, synthetic corpus
    python -m credit_extract.cli probe --db ...   # one part at a time
"""
from __future__ import annotations

import argparse
import json
import pathlib
import random
import sys

import yaml

from .compile import compiler as C
from .demo.make_corpus import generate
from .derive.dag import run_dag
from .discovery.adjudication import build_board, deviation_scan, promote_to_spec
from .discovery.residuals import cluster_candidates, compute_residuals, contradiction_candidates
from .evaluate.harness import evaluate, gate_report
from .evaluate.segment import label_audit_sample, segment_eval
from .ingest.pipeline import (extract_defined_terms, load_ground_truth, make_splits,
                              parse_and_load, segment_sections, verify_offsets,
                              verify_split_integrity)
from .mine.rlm import canonicalize, fold_into_spec, mine, validate_recipes
from .optimize.driver import optimize_field
from .probe.draft_specs import write_drafts
from .probe.probe import (classify, confusable_pairs, field_diagnostics, harvest_few_shots,
                          induce_rules, run_probe)
from .release.manager import cut_release, gate_check, open_test_split, regression
from .runtime.agents import AgentFactory, run_extraction
from .runtime.escalation import run_escalation
from .runtime.llm import GeminiProvider, SimulatedProvider
from .runtime.planner import estimate_cost, plan_bundles, project_to_scale
from .runtime.validators import demote_failures, run_validators
from .store import Store

CROSS_DOC = {"applicable_margin_current"}
ROOT = pathlib.Path(__file__).resolve().parent.parent


def banner(part, title):
    print(f"\n{'=' * 78}\n  PART {part} — {title}\n{'=' * 78}")


def paths_of(a):
    return {k: str(ROOT / getattr(a, k)) for k in ("specs", "templates", "few_shots", "prompts")}


def provider_of(a):
    return (GeminiProvider(a.model) if a.provider == "gemini"
            else SimulatedProvider(seed=a.seed, error_rate=a.error_rate))


def load_specs(spec_dir) -> dict:
    out = {}
    for p in sorted(pathlib.Path(spec_dir).glob("*.yaml")):
        s = yaml.safe_load(p.read_text())
        if s.get("status") in ("active", "shadow"):
            out[s["field_id"]] = C.with_defaults(s)
    return out


# ----------------------------------------------------------------- PART A

def part_ingest(store, a):
    banner("A", "Corpus foundation")
    docs = generate(a.families, seed=a.seed)
    print(f"  generated {len(docs)} documents in {a.families} families")
    print("  A.1 parse       ", parse_and_load(store, docs))
    bad = verify_offsets(store, docs)
    print(f"  A.1 offset round-trip failures: {bad}   {'OK' if bad == 0 else 'BLOCKED'}")
    assert bad == 0, "offset drift — every downstream span would be meaningless"
    print("  A.3 sections    ", segment_sections(store))
    print("  A.4 defined terms", extract_defined_terms(store))
    print("  A.5 ground truth", load_ground_truth(store, docs, make_splits(docs, seed=a.seed)))
    straddle = verify_split_integrity(store)
    print(f"  A.5 families straddling splits: {straddle}   {'OK' if straddle == 0 else 'BLOCKED'}")
    assert straddle == 0, "split leakage"
    return docs


# ----------------------------------------------------------------- PART B

def part_probe(store, a):
    banner("B", "Grounding probe and tier classification (no LLM)")
    p = run_probe(store, split=None)      # spans for all splits; eval needs dev spans
    print(f"  B.1 {p['fields']} fields, {p['hits']} span hits")
    diag = field_diagnostics(store, "train")
    rules = induce_rules(store, "train", min_coverage=0.98)
    print(f"  B.3 induced deterministic rules: {len(rules)}")
    for f, r in rules.items():
        print(f"        {f} = {r['expr']}  coverage={r['coverage']}")
    classes = classify(store, diag, rules, p["types"], CROSS_DOC)
    print(f"  B.4 {'field':<28}{'tier':<30}{'hit':>6}{'amb':>6}")
    for f, c in sorted(classes.items(), key=lambda kv: kv[1]["tier"]):
        print(f"      {f:<28}{c['tier']:<30}{c['hit_rate']:>6.2f}{c['ambiguity']:>6.1f}")
    return classes, p["types"]


# ----------------------------------------------------------------- PART C/D

def part_specs(store, a, classes):
    banner("C", "Spec authoring")
    conf = confusable_pairs(store, threshold=0.30)
    print(f"  C.2 confusable pairs: {sum(len(v) for v in conf.values()) // 2}")
    written = write_drafts(store, classes, conf, str(ROOT / a.specs))
    print(f"  C.1 drafted {len(written)} new specs (human-edited specs untouched)")
    shots = ROOT / a.few_shots
    shots.mkdir(exist_ok=True)
    n_ab = 0
    for fid in classes:
        fs = harvest_few_shots(store, fid, k=3)
        if not fs:
            continue
        n_ab += any(s["kind"] == "abstention" for s in fs)
        shots.joinpath(f"{fid}.yaml").write_text(yaml.safe_dump({"examples": [
            {"evidence": s["evidence"],
             "output": json.dumps({"field_id": fid, "value": s["value"],
                                   "abstain": s["value"] is None, "confidence": 0.95})}
            for s in fs]}, sort_keys=False))
    print(f"  C.3 few-shot sets harvested; {n_ab} include an abstention example")


def part_compile(store, a):
    banner("D", "Compile — one prompt per entity")
    rc = C.main_programmatic(str(ROOT / a.specs), str(ROOT / a.templates),
                             str(ROOT / a.few_shots), str(ROOT / a.prompts))
    man = json.loads((ROOT / a.prompts / "manifest.json").read_text())
    for m in man["prompts"]:
        store.exec("INSERT OR REPLACE INTO prompt_artifact VALUES (?,?,?,?,?)",
                   (m["field_id"], m["spec_version"], m["prompt_hash"], m["template_id"],
                    (ROOT / a.prompts / m["file"]).read_text()))
    print(f"  D {len(man['prompts'])} prompts, {len(man['dag_errors'])} DAG errors, exit={rc}")
    return man


# ----------------------------------------------------------------- PART E/F

def part_extract(store, a, specs, split="dev"):
    banner("E/F", "Extraction · validators · escalation · derivative DAG")
    prov = provider_of(a)
    bundles = plan_bundles(specs)
    est = estimate_cost(specs, a.families, bundles)
    proj = project_to_scale(specs, bundles, target_fields=200, n_docs=20_000)
    print(f"  E.1 {len(bundles)} bundles, {proj['fields_per_bundle']} fields/bundle")
    print(f"      this corpus  : {est['bundled_calls']:,} calls, ${est['total_usd']:,.2f}")
    print(f"      projected 200 fields x 20K docs: {proj['naive_calls']:,} naive -> "
          f"{proj['bundled_calls']:,} bundled ({proj['call_reduction']:.0%} reduction)")

    agents = AgentFactory(store, specs).build()
    res = run_extraction(store, agents, prov, split, "rel-demo-001")
    print(f"  E.2 {res['claims']} claims / {res['calls']} calls "
          f"(${res['cost_usd']:.4f}, provider={prov.name})")

    dag = run_dag(store, specs, res["run_id"])
    print(f"  F   {dag['derived']} derived, cycles={len(dag['cycle_errors'])}, "
          f"contradictions={dag['contradictions']}")

    v = run_validators(store, res["run_id"], specs)
    demoted = demote_failures(store, res["run_id"])
    print(f"  E.5 validators: {v['checks']} checks, {v['failures']} failures, "
          f"{demoted} accepted claims demoted to escalation")
    if v["unknown_validators"]:
        print(f"      unknown validators referenced by specs: {v['unknown_validators']}")

    esc = run_escalation(store, prov, res["run_id"], specs, budget_pct=a.rlm_budget)
    print(f"  G.6 escalation: cap={esc['budget_cap']} resolved={esc['resolved']} "
          f"budget_breached={esc['budget_breached']}")
    return res["run_id"]


# ----------------------------------------------------------------- PART E.3/H

def part_eval(store, a, run_id, types, split="dev"):
    banner("E.3 / H.1", "Per-field eval, segmentation, error taxonomy")
    results = evaluate(store, run_id, split, types)
    print(f"  {'field':<28}{'n':>4}{'acc':>7}{'IoU':>7}{'abst':>7}  dominant error")
    for f, r in sorted(results.items(), key=lambda kv: kv[1]["norm_exact"]):
        errs = {k: v for k, v in r["errors"].items() if k != "correct"}
        dom = max(errs, key=errs.get) if errs else "-"
        print(f" {' ' if r['gate'] else '!'}{f:<28}{r['n']:>4}{r['norm_exact']:>7.2f}"
              f"{r['evidence_iou']:>7.2f}{r['abstain_rate']:>7.2f}  {dom}")
    gr = gate_report(results)
    print(f"\n  gate: {len(gr['passing'])} passing / {len(gr['failing'])} failing")

    seg = segment_eval(store, run_id, split, types, by="amendment_depth")
    spread = {f: v for f, v in seg.items() if v.get("_spread", 0) > 0.15}
    print(f"  E.4 fields with >15pt spread across amended vs clean families: {len(spread)}")
    for f, v in list(spread.items())[:4]:
        print(f"        {f:<28}{ {k: x['acc'] for k, x in v.items() if k != '_spread'} }")

    if gr["failing"]:
        worst = gr["failing"][0]
        rows = label_audit_sample(store, run_id, worst, split, types, n=3)
        print(f"  H.2 label audit sample for {worst} ({len(rows)} disagreements shown):")
        for r in rows[:2]:
            print(f"        gold={r['gold']!r} pred={r['predicted']!r} conf={r['confidence']}")
    return results, gr


# ----------------------------------------------------------------- PART G

def part_mine(store, a, specs, classes):
    banner("G", "RLM derivation mining (design time)")
    targets = [f for f, c in classes.items()
               if c["tier"] in ("T4_DERIVATIVE_JUDGMENT", "T5_CROSS_DOC")]
    print(f"  G.2 mining {len(targets)} unresolved fields: {targets}")
    prov = provider_of(a)
    recipes = mine(store, prov, targets, samples=a.mine_samples)
    canon = {f: canonicalize(rs) for f, rs in recipes.items()}
    for f, c in canon.items():
        print(f"        {f:<28} kind={c['dominant_kind']:<16} agreement={c['agreement']} "
              f"-> {c['verdict']}")
    cov = validate_recipes(store, canon, "train")
    for f, v in cov.items():
        print(f"  G.4 {f:<28} anchor_coverage={v['anchor_coverage']}")
    for f, c in canon.items():
        if f in specs and c["verdict"] == "specifiable":
            new = fold_into_spec(specs[f], c)
            print(f"  G.5 {f} -> spec v{new['version']} "
                  f"({len(new.get('decision_procedure', []))} conditions)")
    if not recipes:
        print("        (simulated provider returns no derivations; run with --provider gemini)")
    return canon


# ----------------------------------------------------------------- PART H

def part_optimize(store, a, specs, gr, types):
    banner("H", "Ralph + GEPA — optimize the failing tail")
    prov = provider_of(a)
    fields = gr["failing"][:a.optimize_n]
    print(f"  H.3 optimizing {len(fields)} fields (k={a.k}, rounds={a.rounds})")
    out = []
    for f in fields:
        dom = gr["dominant_error"].get(f, "prompt")
        r = optimize_field(store, specs, f, dom, prov, types, paths_of(a),
                           k=a.k, rounds=a.rounds, seed=a.seed)
        out.append(r)
        print(f"      {f:<28} {dom:<14} {r['baseline']:.2f} -> {r['final']:.2f} "
              f"({r['gain']:+.2f}) v{r['version']} [{r['disposition']}]")
    return out


# ----------------------------------------------------------------- PART I

def part_release(store, a, specs, results, dev_run, types):
    banner("I", "Release gates")
    gc = gate_check(results)
    print(f"  I   pass rate {gc['pass_rate']:.0%} — release "
          f"{'ALLOWED' if gc['release_allowed'] else 'BLOCKED'}")
    rel = cut_release(store, a.release, specs, a.model, signed_by="pipeline")
    print(f"  I.1 {rel}")
    test_run = None
    if gc["release_allowed"]:
        prov = provider_of(a)
        agents = AgentFactory(store, specs).build()
        res = run_extraction(store, agents, prov, "test", a.release)
        run_dag(store, specs, res["run_id"])
        test_res = evaluate(store, res["run_id"], "test", types)
        test_run = res["run_id"]
        print(f"  I.2 test split opened once: {open_test_split(store, test_run, results, test_res)}")
        print(f"  I.3 regression vs dev: {regression(store, dev_run, test_run)['blocked']=}")
    else:
        print("  I.2 test split NOT opened — gates must pass first")
    return test_run


# ----------------------------------------------------------------- PART J

def part_discover(store, a, run_id, specs):
    banner("J", "Discovery loop and adjudication board")
    print("  J.1", compute_residuals(store, run_id))
    print("  J.3", cluster_candidates(store, min_cluster=5))
    dev = deviation_scan(store)
    print(f"  J.4 deviation outliers: {len(dev)}")
    contra = contradiction_candidates(store, run_id)
    print(f"  J   contradiction events: {len(contra)}")
    board = build_board(store, limit=5)
    print(f"  J.5 adjudication board (leverage-sorted):")
    for b in board:
        print(f"        {b['candidate_id']}  freq={b['frequency']:<5} "
              f"coverage={b['coverage']:<6} leverage={b['leverage']:<8} "
              f"-> {b['proposed_target']} (retires {b['retires_items']} items)")
    promoted = [b for b in board if b["proposed_target"] == "new_entity_spec"]
    if promoted and a.promote:
        p = promote_to_spec(store, promoted[0]["candidate_id"], "discovered_field_001",
                            str(ROOT / a.specs))
        print(f"  J.6 promoted -> {pathlib.Path(p).name} (status: shadow, no gate until labeled)")
    return board


# ----------------------------------------------------------------- commands

def cmd_all(a):
    store = Store(a.db)
    part_ingest(store, a)
    classes, types = part_probe(store, a)
    part_specs(store, a, classes)
    part_compile(store, a)
    specs = load_specs(ROOT / a.specs)
    run_id = part_extract(store, a, specs)
    results, gr = part_eval(store, a, run_id, types)
    part_mine(store, a, specs, classes)
    if a.optimize_n:
        part_optimize(store, a, specs, gr, types)
    part_release(store, a, specs, results, run_id, types)
    part_discover(store, a, run_id, specs)
    print(f"\n{'=' * 78}\n  PIPELINE COMPLETE — db={a.db}\n{'=' * 78}")
    return 0


def cmd_part(a):
    store = Store(a.db)
    types = {r["field_id"]: r["value_type"] for r in store.q(
        "SELECT field_id, value_type FROM tier_assignment")}
    specs = load_specs(ROOT / a.specs)
    last = store.one("SELECT run_id FROM extraction_run ORDER BY started_at DESC LIMIT 1")
    run_id = last["run_id"] if last else None

    if a.cmd == "ingest":
        part_ingest(store, a)
    elif a.cmd == "probe":
        part_probe(store, a)
    elif a.cmd == "specs":
        classes = {r["field_id"]: {"tier": r["tier"], "archetype": r["archetype"],
                                   "value_type": r["value_type"], "hit_rate": r["hit_rate"],
                                   "ambiguity": r["ambiguity"],
                                   "top_sections": json.loads(r["top_sections"]),
                                   "rule_expr": r["rule_expr"],
                                   "rule_coverage": r["rule_coverage"],
                                   "rule_inputs": json.loads(r["notes"] or "[]")}
                   for r in store.q("SELECT * FROM tier_assignment")}
        part_specs(store, a, classes)
    elif a.cmd == "compile":
        part_compile(store, a)
    elif a.cmd == "extract":
        part_extract(store, a, specs)
    elif a.cmd == "eval":
        part_eval(store, a, run_id, types)
    elif a.cmd == "mine":
        classes = {r["field_id"]: {"tier": r["tier"]} for r in store.q("SELECT * FROM tier_assignment")}
        part_mine(store, a, specs, classes)
    elif a.cmd == "optimize":
        results, gr = part_eval(store, a, run_id, types)
        part_optimize(store, a, specs, gr, types)
    elif a.cmd == "release":
        results = evaluate(store, run_id, "dev", types)
        part_release(store, a, specs, results, run_id, types)
    elif a.cmd == "discover":
        part_discover(store, a, run_id, specs)
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(prog="credit_extract")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, fn in [("all", cmd_all)] + [(n, cmd_part) for n in
                     ("ingest", "probe", "specs", "compile", "extract",
                      "eval", "mine", "optimize", "release", "discover")]:
        p = sub.add_parser(name)
        p.add_argument("--db", default="build/corpus.db")
        p.add_argument("--families", type=int, default=80)
        p.add_argument("--seed", type=int, default=7)
        p.add_argument("--specs", default="specs")
        p.add_argument("--few-shots", dest="few_shots", default="few_shots")
        p.add_argument("--prompts", default="prompts")
        p.add_argument("--templates", default="templates")
        p.add_argument("--provider", choices=["simulated", "gemini"], default="simulated")
        p.add_argument("--model", default="gemini-2.5-flash")
        p.add_argument("--error-rate", type=float, default=0.12)
        p.add_argument("--rlm-budget", type=float, default=0.05)
        p.add_argument("--mine-samples", type=int, default=5)
        p.add_argument("--optimize-n", type=int, default=2)
        p.add_argument("--k", type=int, default=4)
        p.add_argument("--rounds", type=int, default=2)
        p.add_argument("--release", default="rel-2026-001")
        p.add_argument("--promote", action="store_true", default=True)
        p.set_defaults(func=fn)
    a = ap.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
