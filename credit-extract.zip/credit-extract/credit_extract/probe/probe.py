"""
Stage B — grounding probe, rule induction, tier classification.

The highest-leverage stage in the system and the only one that uses no model at all.
Everything it produces — tiers, section anchors, few-shot spans, disambiguation
pairs — is otherwise paid for in hand-authoring.
"""
from __future__ import annotations

import itertools
import math
from collections import Counter, defaultdict

from ..store import Store
from .matchers import find_spans, infer_type, norm_money, norm_percent


def run_probe(store: Store, split: str | None = "train", sample: int | None = None) -> dict:
    """B.1 — every field against every labeled document, all hits recorded."""
    docs = {r["doc_id"]: r["full_text"]
            for r in store.q("SELECT doc_id, full_text FROM document_text")}
    sections = defaultdict(list)
    for r in store.q("SELECT doc_id, section_id, heading, char_start, char_end FROM document_section"):
        sections[r["doc_id"]].append((r["char_start"], r["char_end"], r["section_id"], r["heading"]))

    gt = (store.q("SELECT doc_id, field_id, value_norm FROM ground_truth")
          if split is None else
          store.q("SELECT doc_id, field_id, value_norm FROM ground_truth WHERE split=?", (split,)))
    by_field = defaultdict(list)
    for r in gt:
        by_field[r["field_id"]].append((r["doc_id"], r["value_norm"]))

    types = {f: infer_type([v for _, v in rows]) for f, rows in by_field.items()}
    store.exec("DELETE FROM probe_hit")
    rows_out = []
    for fid, rows in by_field.items():
        if sample:
            rows = rows[:sample]
        for doc_id, value in rows:
            text = docs.get(doc_id)
            if text is None:
                continue
            for mt, s, e, sc in find_spans(text, value, types[fid]):
                sec = next((sid for cs, ce, sid, _ in sections[doc_id] if cs <= s < ce), None)
                rows_out.append((fid, doc_id, mt, sec, s, e, sc))
    store.write("INSERT INTO probe_hit VALUES (?,?,?,?,?,?,?)", rows_out)
    return {"fields": len(by_field), "hits": len(rows_out), "types": types}


def field_diagnostics(store: Store, split: str = "train") -> dict:
    """B.2 — hit rate, ambiguity, section concentration."""
    out = {}
    gt_counts = {r["field_id"]: r["n"] for r in store.q(
        "SELECT field_id, COUNT(*) n FROM ground_truth WHERE split=? GROUP BY field_id", (split,))}
    for fid, n_gt in gt_counts.items():
        hits = store.q("""SELECT doc_id, section_id FROM probe_hit p
                          WHERE field_id=? AND doc_id IN
                          (SELECT doc_id FROM ground_truth WHERE split=? AND field_id=?)""",
                       (fid, split, fid))
        docs_hit = {h["doc_id"] for h in hits}
        per_doc = Counter(h["doc_id"] for h in hits)
        secs = Counter(h["section_id"] for h in hits if h["section_id"])
        total = sum(secs.values()) or 1
        entropy = -sum((c / total) * math.log2(c / total) for c in secs.values()) if secs else 0.0
        out[fid] = {
            "n_labeled": n_gt,
            "hit_rate": round(len(docs_hit) / n_gt, 4),
            "ambiguity": round(sum(per_doc.values()) / max(1, len(per_doc)), 2),
            "section_entropy": round(entropy, 3),
            "top_sections": [s for s, _ in secs.most_common(3)],
        }
    return out


# ---------------------------------------------------------------- rule induction

def _num(v):
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return norm_money(v) if isinstance(v, str) else None


def induce_rules(store: Store, split: str = "train", min_coverage: float = 0.98) -> dict:
    """
    B.3 — try to reproduce a field's value from OTHER ground-truth fields.

    Bounded operator set: identity, sum over a subset, difference, ratio, and boolean
    presence. A field reproduced at >= min_coverage is T3 and must never get an
    extraction prompt — it gets code.

    Critical discipline: the expression is validated on EVERY labeled document, not the
    subset it was induced from. A rule that fits 20 documents and fails corpus-wide is
    worse than no rule, because it looks authoritative.
    """
    rows = store.q("SELECT doc_id, field_id, value_norm FROM ground_truth WHERE split=?", (split,))
    table = defaultdict(dict)
    for r in rows:
        table[r["doc_id"]][r["field_id"]] = r["value_norm"]
    fields = sorted({f for d in table.values() for f in d})
    # An OPTIONAL component present in only a minority of documents is exactly the
    # interesting case (a term tranche that half the deals do not have), so the
    # presence threshold has to sit well below half.
    numeric = [f for f in fields
               if sum(_num(d.get(f)) is not None for d in table.values()) > len(table) * 0.25]

    found = {}
    for target in numeric:
        others = [f for f in numeric if f != target]
        docs = [d for d in table.values() if _num(d.get(target)) is not None]
        if len(docs) < 10:
            continue

        # identity / aliasing
        for f in others:
            ok = [d for d in docs if _num(d.get(f)) is not None]
            if ok and sum(abs(_num(d[target]) - _num(d[f])) < 1e-6 for d in ok) / len(ok) >= min_coverage:
                found[target] = {"expr": f, "inputs": [f],
                                 "coverage": round(sum(abs(_num(d[target]) - _num(d[f])) < 1e-6
                                                       for d in ok) / len(ok), 4)}
                break
        if target in found:
            continue

        # sums over subsets, treating a missing optional input as absent (not zero)
        for k in (2, 3):
            for combo in itertools.combinations(others, k):
                hits = 0
                for d in docs:
                    s = sum(_num(d.get(f)) or 0 for f in combo)
                    if abs(_num(d[target]) - s) < 1e-6:
                        hits += 1
                cov = hits / len(docs)
                if cov >= min_coverage:
                    found[target] = {
                        "expr": " + ".join(f"coalesce({f}, 0)" for f in combo),
                        "inputs": list(combo), "coverage": round(cov, 4)}
                    break
            if target in found:
                break
    return found


# ---------------------------------------------------------------- classification

TIER_RULES = [
    ("T3_DERIVATIVE_DETERMINISTIC", "derive_deterministic"),
    ("T2_PRIMITIVE_AGGREGATE", "table_extract"),
    ("T0_PRIMITIVE_SPAN", "span_extract"),
    ("T1_PRIMITIVE_NORMALIZED", "normalize_extract"),
    ("T4_DERIVATIVE_JUDGMENT", "rule_apply"),
]


def classify(store: Store, diag: dict, rules: dict, types: dict,
             cross_doc_fields: set[str] | None = None) -> dict:
    """B.4 — deterministic tier assignment from probe diagnostics."""
    cross_doc_fields = cross_doc_fields or set()
    out = {}
    for fid, d in diag.items():
        vt = types.get(fid, "string")
        hit, amb = d["hit_rate"], d["ambiguity"]

        if fid in rules:
            tier, arch = "T3_DERIVATIVE_DETERMINISTIC", "derive_deterministic"
        elif fid in cross_doc_fields:
            tier, arch = "T5_CROSS_DOC", "crossref_resolve"
        elif vt == "list":
            tier, arch = "T2_PRIMITIVE_AGGREGATE", "table_extract"
        elif hit >= 0.85 and vt in ("string", "enum"):
            tier, arch = "T0_PRIMITIVE_SPAN", ("enum_classify" if vt == "enum" else "span_extract")
        elif hit >= 0.85:
            tier, arch = "T1_PRIMITIVE_NORMALIZED", "normalize_extract"
        elif hit >= 0.40:
            tier, arch = "T1_PRIMITIVE_NORMALIZED", "normalize_extract"
        else:
            tier, arch = "T4_DERIVATIVE_JUDGMENT", "rule_apply"

        out[fid] = {
            "tier": tier, "archetype": arch, "value_type": vt,
            "hit_rate": hit, "ambiguity": amb, "section_entropy": d["section_entropy"],
            "top_sections": d["top_sections"],
            "rule_expr": rules.get(fid, {}).get("expr"),
            "rule_coverage": rules.get(fid, {}).get("coverage"),
            "rule_inputs": rules.get(fid, {}).get("inputs", []),
        }
    store.exec("DELETE FROM tier_assignment")
    store.write("INSERT INTO tier_assignment VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                [(f, v["tier"], v["archetype"], v["value_type"], v["hit_rate"], v["ambiguity"],
                  v["section_entropy"], Store.j(v["top_sections"]), v["rule_expr"],
                  v["rule_coverage"], Store.j(v["rule_inputs"])) for f, v in out.items()])
    return out


def confusable_pairs(store: Store, threshold: float = 0.30) -> dict:
    """
    C.2 — fields whose true spans land in the SAME section are the fields the model
    will confuse. This is where the disambiguation block comes from, and it is the
    single highest-value section of a generated prompt.
    """
    sec = defaultdict(Counter)
    for r in store.q("SELECT field_id, section_id FROM probe_hit WHERE section_id IS NOT NULL"):
        sec[r["field_id"]][r["section_id"]] += 1
    out = defaultdict(list)
    for a, b in itertools.combinations(sorted(sec), 2):
        sa, sb = set(sec[a]), set(sec[b])
        if not sa or not sb:
            continue
        j = len(sa & sb) / len(sa | sb)
        if j >= threshold:
            out[a].append(b)
            out[b].append(a)
    return dict(out)


def harvest_few_shots(store: Store, field_id: str, k: int = 3, window: int = 260) -> list[dict]:
    """
    C.3 — select for DIVERSITY, never the first k matches: different sections,
    different surface forms, and at least one abstention case. Without an abstention
    example a model effectively never abstains, and across 20K documents that means
    confident wrong values instead of routable gaps.
    """
    hits = store.q("""SELECT p.doc_id, p.section_id, p.char_start, p.char_end, p.match_type,
                             g.value_norm, t.full_text
                      FROM probe_hit p
                      JOIN ground_truth g ON g.doc_id=p.doc_id AND g.field_id=p.field_id
                      JOIN document_text t ON t.doc_id=p.doc_id
                      WHERE p.field_id=?""", (field_id,))
    seen_sec, seen_type, picked = set(), set(), []
    for h in hits:
        key = (h["section_id"], h["match_type"])
        if h["section_id"] in seen_sec and h["match_type"] in seen_type:
            continue
        seen_sec.add(h["section_id"])
        seen_type.add(h["match_type"])
        s = max(0, h["char_start"] - window // 2)
        picked.append({
            "doc_id": h["doc_id"],
            "evidence": h["full_text"][s:h["char_end"] + window // 2],
            "value": h["value_norm"],
            "span": [h["char_start"], h["char_end"]],
            "kind": "positive",
        })
        if len(picked) >= k - 1:
            break

    miss = store.q("""SELECT g.doc_id, t.full_text FROM ground_truth g
                      JOIN document_text t ON t.doc_id=g.doc_id
                      WHERE g.field_id=? AND g.doc_id NOT IN
                        (SELECT doc_id FROM probe_hit WHERE field_id=?) LIMIT 1""",
                   (field_id, field_id))
    if miss:
        picked.append({"doc_id": miss[0]["doc_id"], "evidence": miss[0]["full_text"][:400],
                       "value": None, "span": None, "kind": "abstention"})
    return picked[:k]
