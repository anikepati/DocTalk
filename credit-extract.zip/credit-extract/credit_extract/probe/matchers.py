"""Matcher cascade for the grounding probe. No LLM anywhere in this module."""
from __future__ import annotations

import re
from datetime import date, datetime
from difflib import SequenceMatcher

DATE_FORMATS = ["%Y-%m-%d", "%B %d, %Y", "%b %d, %Y", "%m/%d/%Y", "%d %B %Y"]
SCALE = {"thousand": 1_000, "million": 1_000_000, "mm": 1_000_000,
         "billion": 1_000_000_000, "bn": 1_000_000_000}


def norm_money(s: str) -> int | None:
    s = s.strip().lower().replace(",", "")
    neg = s.startswith("(") and s.endswith(")")
    m = re.search(r"\$?\s*([\d.]+)\s*(thousand|million|billion|mm|bn)?", s)
    if not m:
        return None
    try:
        v = float(m.group(1))
    except ValueError:
        return None
    if m.group(2):
        v *= SCALE[m.group(2)]
    v = int(round(v))
    return -v if neg else v


def norm_date(s: str) -> str | None:
    s = s.strip()
    for f in DATE_FORMATS:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except ValueError:
            continue
    return None


def norm_percent(s: str) -> float | None:
    s = s.strip().lower()
    m = re.search(r"([\d.]+)\s*(%|percent|bps|basis points)?", s)
    if not m:
        return None
    v = float(m.group(1))
    if m.group(2) in ("bps", "basis points"):
        return round(v / 10_000, 6)
    if m.group(2) in ("%", "percent"):
        return round(v / 100, 6)
    return round(v, 6) if v < 1 else round(v / 100, 6)


def infer_type(values: list[str]) -> str:
    sample = [v for v in values if v][:60]
    if not sample:
        return "string"
    if all(v.lower() in ("true", "false") for v in sample):
        return "boolean"
    if all("=" in v and "|" in v or v.count("=") >= 1 and "|" in v for v in sample):
        return "list"
    if all(norm_date(v) for v in sample):
        return "date"
    if all(re.fullmatch(r"-?\d+(\.\d+)?", v) for v in sample):
        floats = [float(v) for v in sample]
        return "percent" if all(0 < f < 1 for f in floats) else "money"
    if len({v for v in sample}) <= max(3, len(sample) // 10):
        return "enum"
    return "string"


def _spans(text: str, needle: str):
    if not needle or len(needle) < 2:
        return
    start = 0
    low_t, low_n = text.lower(), needle.lower()
    while True:
        i = low_t.find(low_n, start)
        if i < 0:
            return
        yield i, i + len(needle)
        start = i + 1


def find_spans(text: str, value: str, vtype: str) -> list[tuple[str, int, int, float]]:
    """Return (match_type, start, end, score). Every hit, not just the first —
    the count is what tells you a field is ambiguous rather than merely hard."""
    hits: list[tuple[str, int, int, float]] = []
    if value is None:
        return hits

    for s, e in _spans(text, value):
        hits.append(("exact", s, e, 1.0))

    if vtype == "money":
        target = norm_money(value)
        if target is not None:
            pat = re.compile(r"\$\s?[\d,]+(?:\.\d+)?(?:\s*(?:million|billion|thousand|mm|bn))?",
                             re.IGNORECASE)
            for m in pat.finditer(text):
                if norm_money(m.group(0)) == target:
                    hits.append(("money_norm", m.start(), m.end(), 0.97))
    elif vtype == "date":
        target = norm_date(value)
        if target:
            pat = re.compile(r"\b(\d{4}-\d{2}-\d{2}|[A-Z][a-z]+ \d{1,2}, \d{4})\b")
            for m in pat.finditer(text):
                if norm_date(m.group(0)) == target:
                    hits.append(("date_norm", m.start(), m.end(), 0.97))
    elif vtype == "percent":
        target = norm_percent(value)
        if target is not None:
            for m in re.finditer(r"\b\d+\.\d+\s*%", text):
                if norm_percent(m.group(0)) == target:
                    hits.append(("percent_norm", m.start(), m.end(), 0.96))

    if not hits and vtype == "string" and len(value) > 8:
        window = len(value)
        best, bi = 0.0, -1
        for i in range(0, max(1, len(text) - window), 8):
            r = SequenceMatcher(None, value.lower(), text[i:i + window].lower()).ratio()
            if r > best:
                best, bi = r, i
        if best >= 0.90:
            hits.append(("fuzzy", bi, bi + window, best))

    # de-duplicate overlapping hits, keeping the strongest
    hits.sort(key=lambda h: (-h[3], h[1]))
    kept: list[tuple[str, int, int, float]] = []
    for h in hits:
        if not any(not (h[2] <= k[1] or h[1] >= k[2]) for k in kept):
            kept.append(h)
    return kept
