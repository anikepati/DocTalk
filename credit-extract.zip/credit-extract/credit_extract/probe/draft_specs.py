"""
C.1 — auto-draft an entity spec from probe output.

The probe already knows the section anchors, the value type, the surface forms, and
the confusable siblings. You edit drafts; you do not author 200 specs from scratch.
The one thing that cannot be generated is the `discriminator` sentence — that stays a
human sentence, and it is the highest-value text in the whole prompt.
"""
from __future__ import annotations

import pathlib

import yaml

from ..store import Store

NORMALIZATION_FOR = {"money": "money_usd_scale", "date": "iso_date",
                     "percent": "percent_decimal", "boolean": "boolean",
                     "string": "entity_name_verbatim"}


def draft(store: Store, field_id: str, cls: dict, confusables: list[str],
          headings: list[str]) -> dict:
    tier, arch, vt = cls["tier"], cls["archetype"], cls["value_type"]
    spec = {
        "field_id": field_id,
        "version": 1,
        "display_name": field_id.replace("_", " ").title(),
        "tier": tier,
        "archetype": arch,
        "value_type": vt if vt != "enum" else "string",
        "cardinality": "many" if vt == "list" else "one",
        "status": "active",
        "definition": f"TODO human review. Auto-drafted from grounding probe: "
                      f"hit_rate={cls['hit_rate']}, ambiguity={cls['ambiguity']}.",
        "retrieval": {
            "section_anchors": headings or ["whole document"],
            "strategy": "section_anchor",
            "window_tokens": 6000,
        },
        "few_shot_source": "grounding_probe",
        "few_shot_k": 3,
        "evidence": "required",
        "confidence_policy": {"auto_accept": 0.92, "validate": 0.75, "escalate_rlm": 0.60},
        "business_weight": "medium",
    }
    if vt in NORMALIZATION_FOR and arch != "span_extract":
        spec["normalization"] = NORMALIZATION_FOR[vt]
    if confusables:
        spec["disambiguation"] = {
            "confusable_with": confusables[:5],
            "discriminator": "TODO human sentence — what distinguishes this field from "
                             "the above. This cannot be auto-generated and is the single "
                             "highest-value line in the prompt.",
        }
    if arch == "derive_deterministic":
        spec["depends_on"] = [{"field_id": f, "value_type": "money",
                               "role": "component", "optional": False}
                              for f in cls.get("rule_inputs", [])]
        spec["derivation"] = {
            "statement": "TODO human review of the induced rule.",
            "expr": cls["rule_expr"],
            "preconditions": "all components share the facility currency",
        }
        spec["evidence"] = "not_applicable"
        spec["few_shot_source"] = "none"
        spec["confidence_policy"] = {"auto_accept": 0.99, "validate": 0.99, "escalate_rlm": 0.0}
    if arch == "enum_classify":
        vals = [r["value_norm"] for r in store.q(
            "SELECT DISTINCT value_norm FROM ground_truth WHERE field_id=? LIMIT 12", (field_id,))]
        spec["domain"] = [{"value": v, "criterion": f"the agreement designates {v}"} for v in vals]
    if arch == "table_extract":
        spec["row_schema"] = [
            {"name": "lender_name", "type": "string", "description": "legal name as printed"},
            {"name": "commitment_amount", "type": "number", "description": "normalized amount"},
        ]
    if arch == "rule_apply":
        spec["decision_procedure"] = [
            {"condition": "TODO condition 1", "outcome": "TODO outcome",
             "evidence_required": "TODO quote requirement"}]
        spec["decision_default"] = "TODO default outcome"
        spec["retrieval"]["absence_is_evidence"] = True
    if arch == "crossref_resolve":
        spec["retrieval"]["strategy"] = "family_walk"
    return spec


def write_drafts(store: Store, classes: dict, confusables: dict, out_dir: str) -> list[str]:
    out = pathlib.Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    headings = {}
    for fid, cls in classes.items():
        hs = []
        for sid in cls["top_sections"]:
            r = store.one("SELECT heading FROM document_section WHERE section_id=? LIMIT 1", (sid,))
            if r:
                hs.append(r["heading"])
        headings[fid] = hs
    written = []
    for fid, cls in classes.items():
        p = out / f"{fid}.yaml"
        if p.exists():          # never clobber a human-edited spec
            continue
        p.write_text(yaml.safe_dump(draft(store, fid, cls, confusables.get(fid, []),
                                          headings[fid]), sort_keys=False, width=100))
        written.append(str(p))
    return written
