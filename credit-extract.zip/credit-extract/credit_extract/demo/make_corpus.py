"""
Synthetic credit-agreement corpus.

Exists so the full pipeline runs end to end without the real 20K documents. The
generator emits documents AND the ground truth that produced them, including the
derived fields — which lets the grounding probe and rule induction be exercised for
real rather than mocked.
"""
from __future__ import annotations

import random
from dataclasses import dataclass, field as dc_field

SUFFIX = ["INC.", "LLC", "CORP.", "HOLDINGS, INC.", "GROUP LLC"]
STEM = ["MERIDIAN PACKAGING", "CALDER INDUSTRIAL", "PARKHILL AEROSPACE", "NORTHWIND LOGISTICS",
        "STILLWATER FOODS", "GRANITE PEAK MEDIA", "BLUEFIELD CHEMICALS", "ARDENT MOBILITY",
        "COPPERLINE RETAIL", "VANTAGE MARINE", "HALLOWAY TEXTILES", "REDBRIDGE ENERGY"]
BANKS = ["NORTHSHORE BANK, N.A.", "FIRST COMMERCE BANK", "ATLANTIC UNION TRUST",
         "PIONEER CAPITAL BANK", "HARBORLIGHT BANK, N.A.", "CENTRAL PLAINS BANK"]
CCY = ["USD", "USD", "USD", "EUR", "GBP"]


@dataclass
class Doc:
    doc_id: str
    family_id: str
    doc_type: str
    effective_date: str
    seq: int
    text: str
    gt: dict = dc_field(default_factory=dict)


def _money(n: int) -> str:
    return f"${n:,}"


def _mm(n: int) -> str:
    return f"${n // 1_000_000} million"


def build_family(i: int, rng: random.Random) -> list[Doc]:
    fam = f"FAM{i:05d}"
    borrower = f"{rng.choice(STEM)} {rng.choice(SUFFIX)}"
    agent = rng.choice(BANKS)
    ccy = rng.choice(CCY)
    year = rng.randint(2018, 2024)
    close = f"{year}-{rng.randint(1,12):02d}-{rng.randint(1,28):02d}"
    maturity_year = year + rng.choice([3, 5, 5, 7])
    maturity = f"{maturity_year}-{close[5:]}"

    n_lenders = rng.randint(3, 7)
    lenders = rng.sample(BANKS, min(n_lenders, len(BANKS)))
    if agent not in lenders:
        lenders[0] = agent
    unit = rng.choice([5, 10, 25]) * 1_000_000
    amounts = [unit * rng.randint(1, 6) for _ in lenders]
    revolver = sum(amounts)

    has_tla = rng.random() < 0.55
    tla = rng.choice([50, 75, 100, 150, 200]) * 1_000_000 if has_tla else None
    total = revolver + (tla or 0)

    margin = rng.choice([0.0175, 0.0200, 0.0225, 0.0250, 0.0275, 0.0300])
    covenant_lite = has_tla and rng.random() < 0.4

    lender_rows = "\n".join(
        f"    {n:<28} {_money(a):>16}   {a / revolver * 100:5.2f}%"
        for n, a in zip(lenders, amounts))

    fin_cov = ("""
ARTICLE VI
FINANCIAL COVENANTS

Section 6.01. Total Net Leverage Ratio. The Borrower shall not permit the Total Net
Leverage Ratio as of the last day of any fiscal quarter to exceed 4.50 to 1.00. This
covenant shall be tested as of the last day of each fiscal quarter commencing with the
first full fiscal quarter after the Closing Date, and shall be for the benefit of all
Lenders, including the Term Lenders.

Section 6.02. Interest Coverage Ratio. The Borrower shall not permit the Interest
Coverage Ratio for any Test Period to be less than 2.00 to 1.00.
""" if not covenant_lite else """
ARTICLE VI
FINANCIAL COVENANT

Section 6.01. Springing Financial Covenant. Solely for the benefit of the Revolving
Lenders, if on the last day of any fiscal quarter the aggregate Revolving Exposure
exceeds 35% of the Aggregate Revolving Commitments, the Borrower shall not permit the
First Lien Net Leverage Ratio to exceed 5.00 to 1.00. The Term Lenders shall have no
right to accelerate, and no Event of Default shall arise under the Term Facility, by
reason of a breach of this Section 6.01.
""")

    tla_txt = (f"""
Section 2.02. Term Loans. Subject to the terms hereof, each Term Lender severally
agrees to make a term loan to the Borrower on the Closing Date in an aggregate
principal amount of {_money(tla)} (the "Term Loan A Facility").
""" if has_tla else "")

    text = f"""CREDIT AGREEMENT

CREDIT AGREEMENT dated as of {close}, among {borrower}, a Delaware corporation
(the "Borrower"), the Lenders party hereto, and {agent}, as Administrative Agent.

RECITALS

WHEREAS, the Borrower has requested that the Lenders extend credit as set forth herein;

ARTICLE I
DEFINITIONS

Section 1.01. Defined Terms.

"Administrative Agent" means {agent}, in its capacity as administrative agent.

"Aggregate Revolving Commitments" means the aggregate of the Revolving Commitments of
all Lenders, being {_money(revolver)} on the Closing Date.

"Applicable Margin" means, with respect to any SOFR Loan, {margin * 100:.2f}% per annum.

"Borrower" means {borrower}.

"Closing Date" means {close}.

"Maturity Date" means {maturity}.

"Facility Currency" means {ccy}.

ARTICLE II
THE CREDITS

Section 2.01. Revolving Commitments. Each Lender severally agrees to make revolving
loans to the Borrower from time to time in an aggregate principal amount not to exceed
its Revolving Commitment, provided that the Aggregate Revolving Commitments shall not
exceed {_mm(revolver)} at any time.
{tla_txt}
Section 2.03. Letters of Credit. The LC Sublimit shall be {_money(min(revolver // 10, 25_000_000))},
which sublimit forms part of, and is not in addition to, the Aggregate Revolving Commitments.
{fin_cov}
ARTICLE VII
NEGATIVE COVENANTS

Section 7.01. Indebtedness. The Borrower shall not incur Indebtedness except as permitted.

Section 7.02. Restricted Payments. The Borrower shall not make any Restricted Payment
unless, after giving pro forma effect thereto, the Total Net Leverage Ratio is less
than 3.50 to 1.00.

ARTICLE VIII
EVENTS OF DEFAULT

Section 8.01. Events of Default. Each of the following shall constitute an Event of
Default: (a) failure to pay principal when due; (b) failure to pay interest within
three Business Days;{' (c) breach of any covenant in Article VI;' if not covenant_lite else ''}
(d) any representation proves materially incorrect.

SCHEDULE 1.01(a)
COMMITMENTS

    Lender                             Commitment       Pro Rata Share
{lender_rows}
    ----------------------------------------------------------------
    Total                        {_money(revolver):>16}         100.00%
"""

    gt = {
        "borrower_legal_name": borrower,
        "administrative_agent_name": agent,
        "facility_currency": ccy,
        "closing_date": close,
        "maturity_date_revolving": maturity,
        "revolving_commitment_total": str(revolver),
        "term_loan_a_principal": str(tla) if has_tla else None,
        "has_term_loan_tranche": str(has_tla).lower(),
        "total_facility_size": str(total),
        "applicable_margin_current": f"{margin:.4f}",
        "is_covenant_lite": str(covenant_lite).lower(),
        "lc_sublimit": str(min(revolver // 10, 25_000_000)),
        "lender_commitments": "|".join(f"{n}={a}" for n, a in zip(lenders, amounts)),
    }

    docs = [Doc(f"{fam}-000", fam, "base", close, 0, text, gt)]

    # ~35% of families carry an amendment that repriced the margin
    if rng.random() < 0.35:
        new_margin = round(margin + rng.choice([-0.0050, -0.0025, 0.0025, 0.0050]), 4)
        adate = f"{year + rng.randint(1, 3)}-{rng.randint(1,12):02d}-15"
        atext = f"""FIRST AMENDMENT TO CREDIT AGREEMENT

FIRST AMENDMENT dated as of {adate} to the Credit Agreement dated as of {close}
among {borrower}, the Lenders party thereto and {agent}, as Administrative Agent.

Section 1. Amendment. The definition of "Applicable Margin" in Section 1.01 of the
Credit Agreement is hereby amended and restated in its entirety to read as follows:

"Applicable Margin" means, with respect to any SOFR Loan, {new_margin * 100:.2f}% per annum.

Section 2. Effect. Except as expressly amended hereby, the Credit Agreement remains in
full force and effect.
"""
        # the amendment carries no labels of its own; the family's post-amendment
        # value attaches to the base agreement, which is what "as amended" means
        docs.append(Doc(f"{fam}-001", fam, "amendment", adate, 1, atext, {}))
        docs[0].gt = dict(gt, applicable_margin_current=f"{new_margin:.4f}")

    return docs


def generate(n_families: int = 120, seed: int = 7) -> list[Doc]:
    rng = random.Random(seed)
    out: list[Doc] = []
    for i in range(n_families):
        out.extend(build_family(i, rng))
    return out
