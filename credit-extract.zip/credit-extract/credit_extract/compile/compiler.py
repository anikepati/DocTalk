"""
Entity Spec -> Prompt Compiler.

One prompt per entity. Prompts are build artifacts: never hand-edited.
Edit the YAML spec, recompile, re-evaluate.

    python compiler.py --specs specs/ --out prompts/
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import sys

import yaml
from jinja2 import Environment, FileSystemLoader, StrictUndefined

ARCHETYPE_TEMPLATE = {
    "span_extract":         "A1_span_extract.j2",
    "enum_classify":        "A2_enum_classify.j2",
    "table_extract":        "A3_table_extract.j2",
    "normalize_extract":    "A4_normalize_extract.j2",
    "derive_deterministic": "A5_derive_deterministic.j2",
    "rule_apply":           "A6_rule_apply.j2",
    "crossref_resolve":     "A7_crossref_resolve.j2",
}

TIER_ARCHETYPES = {
    "T0_PRIMITIVE_SPAN":         {"span_extract", "enum_classify"},
    "T1_PRIMITIVE_NORMALIZED":   {"normalize_extract", "enum_classify"},
    "T2_PRIMITIVE_AGGREGATE":    {"table_extract"},
    "T3_DERIVATIVE_DETERMINISTIC": {"derive_deterministic"},
    "T4_DERIVATIVE_JUDGMENT":    {"rule_apply"},
    "T5_CROSS_DOC":              {"crossref_resolve", "rule_apply"},
}

NORMALIZATION_RULES = {
    "money_usd_scale": (
        "- Output a plain integer or decimal number of whole currency units. No symbols,\n"
        "  no thousands separators, no scale words.\n"
        "- Expand scale words: 'million'/'MM' -> x1,000,000; 'billion'/'BN' -> x1,000,000,000.\n"
        "- Parentheses indicate a negative amount.\n"
        "- Report the ISO-4217 currency code separately in `currency`. If the text states\n"
        "  no currency and no governing-currency provision was supplied, abstain."
    ),
    "iso_date": (
        "- Output YYYY-MM-DD.\n"
        "- Two-digit years are ambiguous: abstain rather than assuming a century.\n"
        "- 'the Xth anniversary of <date>' resolves only if <date> is in the supplied text.\n"
        "- Do not apply business-day conventions unless the agreement states one and it\n"
        "  was supplied to you."
    ),
    "percent_decimal": (
        "- Output a decimal fraction: 2.50% -> 0.0250. Four decimal places.\n"
        "- Basis points: 250 bps -> 0.0250.\n"
        "- If the rate is a spread over a benchmark, this field is the SPREAD only."
    ),
    "entity_name_verbatim": (
        "- Copy verbatim, including punctuation, capitalization, and entity suffix.\n"
        "- Do not expand or contract 'Inc.'/'Incorporated', 'LLC'/'L.L.C.'.\n"
        "- Strip only a trailing defined-term parenthetical such as '(the \"Borrower\")'."
    ),
    "boolean": "- Output true or false as a JSON boolean, never as a string.",
}

BASE_CONTRACT_FIELDS = {
    "confidence": '"confidence": <float 0.0-1.0, your calibrated probability this is correct>',
    "abstain":    '"abstain": <true|false>',
    "reasoning":  '"reasoning": "<2-4 sentences, referencing only the supplied text>"',
}


def norm_rules(key: str) -> str:
    if key not in NORMALIZATION_RULES:
        raise KeyError(f"unknown normalization rule: {key}")
    return NORMALIZATION_RULES[key]


def build_contract(spec: dict) -> str:
    a = spec["archetype"]
    lines = ['{', f'  "field_id": "{spec["field_id"]}",']

    if a == "table_extract":
        row = ", ".join(f'"{c["name"]}": <{c["type"]}>' for c in spec["row_schema"])
        lines += [
            f'  "value": [ {{ {row} }}, ... ],',
            '  "row_count": <int>,',
            '  "stated_total": <number|null>,',
            '  "reconciles": <true|false>,',
            '  "evidence_span": {"section": "<heading>", "char_start": <int>, "char_end": <int>},',
        ]
    elif a == "derive_deterministic":
        lines += [
            '  "value": <computed result, normalized>,',
            '  "computation_steps": ["<step> = <intermediate>", ...],',
            '  "inputs_used": {"<field_id>": <value>, ...},',
            '  "stated_in_document": <value|null>,',
            '  "contradicts_document": <true|false>,',
        ]
    elif a == "rule_apply":
        lines += [
            '  "value": <determination>,',
            '  "rule_fired": <int, the numbered condition that decided this>,',
            '  "evidence_quotes": [{"section": "<heading>", "quote": "<verbatim>"}, ...],',
            '  "absence_findings": [{"section": "<heading>", "searched_in_full": true}],',
        ]
    elif a == "crossref_resolve":
        lines += [
            '  "value": <value as currently in effect, normalized>,',
            '  "original_value": <value in the base agreement>,',
            '  "amendment_chain": [{"amendment": "<id>", "effective_date": "<YYYY-MM-DD>", "resulting_value": <v>}],',
            '  "as_of_date": "<YYYY-MM-DD>",',
            '  "unresolved_references": ["<any provision referenced but not supplied>"],',
        ]
    else:
        lines += ['  "value": <normalized value>,']
        if spec.get("normalization"):
            lines += ['  "value_raw": "<verbatim source text>",']
        if spec.get("value_type") == "money":
            lines += ['  "currency": "<ISO-4217>",']
        lines += ['  "evidence_span": {"section": "<heading>", "char_start": <int>, "char_end": <int>, "quote": "<verbatim>"},']

    if a == "normalize_extract":
        lines += ['  "derivation_note": "<how an indirect expression was resolved, or null>",']

    lines += [
        f'  {BASE_CONTRACT_FIELDS["confidence"]},',
        f'  {BASE_CONTRACT_FIELDS["abstain"]},',
        f'  {BASE_CONTRACT_FIELDS["reasoning"]}',
        '}',
    ]
    return "\n".join(lines)


def load_few_shots(spec: dict, shot_dir: pathlib.Path) -> list:
    """
    In production these are auto-harvested from the Stage-1 grounding probe:
    k spans selected for DIVERSITY (different sections, different surface forms,
    one hard case), never the first k matches. Here we read whatever the spec
    author or the harvester has deposited.
    """
    if spec.get("few_shot_source") == "none":
        return []
    p = shot_dir / f"{spec['field_id']}.yaml"
    if not p.exists():
        return []
    shots = yaml.safe_load(p.read_text())["examples"]
    return shots[: spec.get("few_shot_k", 3)]


def lint(spec: dict, prompt: str) -> list[str]:
    errs = []
    tier, arch = spec["tier"], spec["archetype"]
    if arch not in ARCHETYPE_TEMPLATE:
        errs.append(f"unknown archetype {arch}")
    if tier in TIER_ARCHETYPES and arch not in TIER_ARCHETYPES[tier]:
        errs.append(f"archetype {arch} not permitted for tier {tier}")
    if '"abstain"' not in prompt:
        errs.append("no abstain path in output contract")
    if "### OUTPUT CONTRACT" not in prompt:
        errs.append("missing output contract")
    if arch in ("derive_deterministic",) and not spec.get("depends_on"):
        errs.append("derivative field has no depends_on")
    if arch == "rule_apply" and not spec.get("decision_procedure"):
        errs.append("rule_apply field has no decision_procedure")
    if spec.get("normalization") and spec["normalization"] not in NORMALIZATION_RULES:
        errs.append(f"unknown normalization {spec['normalization']}")
    for c in (spec.get("disambiguation") or {}).get("confusable_with", []):
        if c == spec["field_id"]:
            errs.append("field listed as confusable with itself")
    try:
        from ..runtime.validators import REGISTRY, parse_call
        for v in spec.get("validators", []) or []:
            name, _ = parse_call(str(v))
            if name not in REGISTRY:
                errs.append(f"unknown validator {name!r} — a check that never runs "
                            f"is worse than no check")
    except ImportError:
        pass
    if len(prompt) > 24000:
        errs.append(f"prompt {len(prompt)} chars — exceeds budget")
    return errs


SPEC_DEFAULTS = {
    "disambiguation": None,
    "normalization": None,
    "edge_cases": [],
    "depends_on": [],
    "decision_procedure": [],
    "decision_default": None,
    "domain": [],
    "row_schema": [],
    "derivation": None,
    "few_shot_source": "grounding_probe",
    "few_shot_k": 3,
}


def with_defaults(spec: dict) -> dict:
    """StrictUndefined catches typos; optional keys get explicit defaults instead."""
    full = {**SPEC_DEFAULTS, **spec}
    r = full.setdefault("retrieval", {})
    r.setdefault("section_anchors", [])
    r.setdefault("defined_term", None)
    r.setdefault("absence_is_evidence", False)
    if full["derivation"]:
        full["derivation"].setdefault("preconditions", "none stated")
    for d in full["depends_on"]:
        d.setdefault("optional", False)
        d.setdefault("value_type", "unknown")
        d.setdefault("role", "")
    for c in full["decision_procedure"]:
        c.setdefault("evidence_required", None)
    return full


def tidy(prompt: str) -> str:
    """Template inheritance eats newlines; normalize section spacing centrally."""
    lines = [l.rstrip() for l in prompt.splitlines()]
    out = []
    for l in lines:
        if l.startswith("### ") and out and out[-1].strip():
            out.append("")
        out.append(l)
    text = "\n".join(out)
    while "\n\n\n" in text:
        text = text.replace("\n\n\n", "\n\n")
    return text.strip() + "\n"


def compile_spec(raw: dict, env: Environment, shot_dir: pathlib.Path) -> tuple[str, dict]:
    spec = with_defaults(raw)
    tpl = env.get_template(ARCHETYPE_TEMPLATE[spec["archetype"]])
    prompt = tpl.render(
        spec=spec,
        few_shots=load_few_shots(spec, shot_dir),
        output_contract=build_contract(spec),
        norm_rules=norm_rules,
        EVIDENCE="{{evidence_text}}",
        INPUT_VALUES="{{input_values_json}}",
        STATED_VALUE="{{stated_value}}",
        BASE_EXCERPT="{{base_excerpt}}",
        AMENDMENT_EXCERPTS="{{amendment_excerpts}}",
    )
    prompt = tidy(prompt)

    meta = {
        "field_id": spec["field_id"],
        "spec_version": spec["version"],
        "tier": spec["tier"],
        "archetype": spec["archetype"],
        "template_id": ARCHETYPE_TEMPLATE[spec["archetype"]],
        "prompt_hash": hashlib.sha256(prompt.encode()).hexdigest()[:16],
        "chars": len(prompt),
        "depends_on": [d["field_id"] for d in spec.get("depends_on", [])],
        "lint": lint(spec, prompt),
    }
    return prompt, meta


def check_dag(metas: list[dict]) -> list[str]:
    """Cycle detection at compile time, not run time."""
    graph = {m["field_id"]: m["depends_on"] for m in metas}
    known = set(graph)
    errs, state = [], {}

    for m in metas:
        for d in m["depends_on"]:
            if d not in known:
                errs.append(f"{m['field_id']} depends on unknown field {d}")

    def visit(n, stack):
        if state.get(n) == "done":
            return
        if state.get(n) == "open":
            errs.append("dependency cycle: " + " -> ".join(stack + [n]))
            return
        state[n] = "open"
        for d in graph.get(n, []):
            if d in graph:
                visit(d, stack + [n])
        state[n] = "done"

    for n in graph:
        visit(n, [])
    return errs


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--specs", default="specs")
    ap.add_argument("--templates", default="templates")
    ap.add_argument("--few-shots", default="few_shots")
    ap.add_argument("--out", default="prompts")
    args = ap.parse_args()

    env = Environment(
        loader=FileSystemLoader(args.templates),
        undefined=StrictUndefined,
        trim_blocks=True,
        lstrip_blocks=False,
        keep_trailing_newline=True,
    )
    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    metas, failed = [], 0
    for path in sorted(pathlib.Path(args.specs).glob("*.yaml")):
        spec = yaml.safe_load(path.read_text())
        if spec.get("status") != "active":
            continue
        prompt, meta = compile_spec(spec, env, pathlib.Path(args.few_shots))
        fn = f"{spec['field_id']}.v{spec['version']}.txt"
        (out / fn).write_text(prompt)
        meta["file"] = fn
        metas.append(meta)
        flag = "FAIL" if meta["lint"] else "ok  "
        failed += bool(meta["lint"])
        print(f"[{flag}] {meta['field_id']:<34} {meta['tier']:<28} "
              f"{meta['archetype']:<21} {meta['chars']:>6}c  {meta['prompt_hash']}")
        for e in meta["lint"]:
            print(f"         ! {e}")

    dag_errs = check_dag(metas)
    for e in dag_errs:
        print(f"[DAG ] ! {e}")

    (out / "manifest.json").write_text(json.dumps(
        {"prompts": metas, "dag_errors": dag_errs}, indent=2))
    print(f"\n{len(metas)} prompts compiled, {failed} with lint failures, "
          f"{len(dag_errs)} DAG errors -> {out}/manifest.json")
    return 1 if (failed or dag_errs) else 0


if __name__ == "__main__":
    sys.exit(main())


def main_programmatic(specs: str, templates: str, few_shots: str, out: str) -> int:
    """Same as main(), callable from the pipeline driver."""
    import sys as _sys
    argv = _sys.argv
    _sys.argv = ["compiler", "--specs", specs, "--templates", templates,
                 "--few-shots", few_shots, "--out", out]
    try:
        return main()
    finally:
        _sys.argv = argv
