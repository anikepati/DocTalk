"""
Stage F — derivative DAG.

T3 fields never touch the document. The prompt supplies the audit trail and the
explanation; the code supplies the guarantee. Where they disagree, the code wins and
the disagreement is recorded — that is a signal, not an error to be swallowed.
"""
from __future__ import annotations

import json
import re

from ..store import Store


def build_graph(specs: dict) -> dict[str, list[str]]:
    return {fid: [d["field_id"] for d in s.get("depends_on", [])] for fid, s in specs.items()}


def toposort(graph: dict[str, list[str]]) -> tuple[list[str], list[str]]:
    """Cycles are found at COMPILE time. A cycle discovered at run time on document
    14,000 of 20,000 is a very expensive way to learn about a spec error."""
    state, order, errors = {}, [], []

    def visit(n, stack):
        if state.get(n) == "done":
            return
        if state.get(n) == "open":
            errors.append("cycle: " + " -> ".join(stack + [n]))
            return
        state[n] = "open"
        for d in graph.get(n, []):
            if d in graph:
                visit(d, stack + [n])
        state[n] = "done"
        order.append(n)

    for n in graph:
        visit(n, [])
    return order, errors


SAFE = re.compile(r"^[\w\s+\-*/().,]+$")


def eval_expr(expr: str, values: dict) -> float | None:
    """Whitelisted arithmetic only. `coalesce(x, 0)` means 'absent contributes nothing',
    which is deliberately different from a tranche present with value zero."""
    expr = " ".join((expr or "").split())     # folded YAML -> single line
    if not expr or not SAFE.match(expr.replace("coalesce", "")):
        return None
    env = {"coalesce": lambda a, b: b if a is None else a}
    for k, v in values.items():
        try:
            env[k] = float(v) if v is not None else None
        except (TypeError, ValueError):
            env[k] = None
    try:
        return eval(expr, {"__builtins__": {}}, env)   # noqa: S307 - whitelisted grammar
    except Exception:
        return None


def run_dag(store: Store, specs: dict, run_id: str) -> dict:
    graph = build_graph({f: s for f, s in specs.items()
                         if s.get("archetype") == "derive_deterministic"})
    for fid, s in specs.items():
        graph.setdefault(fid, [])
    order, errors = toposort(graph)

    claims = {}
    for r in store.q("SELECT doc_id, field_id, value_norm, abstain FROM extraction_claim "
                     "WHERE run_id=?", (run_id,)):
        if not r["abstain"]:
            claims.setdefault(r["doc_id"], {})[r["field_id"]] = r["value_norm"]

    rows, contradictions = [], 0
    derived_fields = [f for f in order
                      if specs.get(f, {}).get("archetype") == "derive_deterministic"]
    for doc_id, vals in claims.items():
        for fid in derived_fields:
            spec = specs[fid]
            deps = spec.get("depends_on", [])
            inputs = {d["field_id"]: vals.get(d["field_id"]) for d in deps}
            missing = [d["field_id"] for d in deps
                       if not d.get("optional") and inputs.get(d["field_id"]) is None]
            if missing:
                rows.append((run_id, doc_id, fid, None, Store.j([]), Store.j(inputs),
                             None, 0, 1))
                continue
            expr = (spec.get("derivation") or {}).get("expr")
            val = eval_expr(expr, inputs)
            stated = vals.get(fid)
            contra = int(stated is not None and val is not None
                         and abs(float(stated) - val) > 1e-6)
            contradictions += contra
            steps = [f"{k} = {v}" for k, v in inputs.items()] + [f"{expr} = {val}"]
            rows.append((run_id, doc_id, fid, None if val is None else str(int(val)),
                         Store.j(steps), Store.j(inputs), stated, contra, 0))
            vals[fid] = None if val is None else str(int(val))

    store.write("INSERT OR REPLACE INTO derived_value VALUES (?,?,?,?,?,?,?,?,?)", rows)
    return {"derived": len(rows), "cycle_errors": errors, "contradictions": contradictions,
            "order": derived_fields}
