"""
Stage A — corpus foundation.

Parse with offset preservation, build families, segment sections, extract defined
terms, load ground truth, freeze splits at FAMILY level.
"""
from __future__ import annotations

import hashlib
import re

from ..store import Store

SECTION_RE = re.compile(
    r"^(ARTICLE\s+[IVXL]+|SCHEDULE\s+[\w.()]+|EXHIBIT\s+[\w.()]+|RECITALS|"
    r"Section\s+\d+\.\d+\.)", re.MULTILINE)
DEFINED_TERM_RE = re.compile(r'"([A-Z][A-Za-z0-9 \-()]{2,60})"\s+means\s+(.{0,400}?)(?=\n\n|\n")', re.S)


def parse_and_load(store: Store, docs) -> dict:
    """A.1 — text with preserved offsets. Every downstream stage indexes into full_text."""
    rows_d, rows_t = [], []
    for d in docs:
        rows_d.append((d.doc_id, d.family_id, d.doc_type, d.effective_date, d.seq,
                       hashlib.sha256(d.text.encode()).hexdigest(), "demo-1.0"))
        rows_t.append((d.doc_id, d.text, len(d.text)))
    store.write("INSERT OR REPLACE INTO document VALUES (?,?,?,?,?,?,?)", rows_d)
    store.write("INSERT OR REPLACE INTO document_text VALUES (?,?,?)", rows_t)
    return {"documents": len(rows_d)}


def verify_offsets(store: Store, docs) -> int:
    """A.1 checkpoint — a span read back from storage must equal the source span.
    Cheap to run, and it is the guard that keeps every evidence span honest."""
    bad = 0
    for d in docs:
        if len(d.text) < 200:
            continue
        stored = store.one("SELECT full_text FROM document_text WHERE doc_id=?", (d.doc_id,))[0]
        if stored[100:180] != d.text[100:180]:
            bad += 1
    return bad


def segment_sections(store: Store) -> dict:
    """A.3 — heading-anchored section tree with char ranges."""
    rows = []
    for r in store.q("SELECT doc_id, full_text FROM document_text"):
        text, marks = r["full_text"], list(SECTION_RE.finditer(r["full_text"]))
        levels = []
        for m in marks:
            head = text[m.start():text.find("\n", m.start())].strip()
            levels.append(1 if head.startswith(("ARTICLE", "SCHEDULE", "EXHIBIT", "RECITALS")) else 2)
        for i, m in enumerate(marks):
            start, lvl = m.start(), levels[i]
            end = len(text)
            for j in range(i + 1, len(marks)):
                # a level-1 section runs to the next level-1 marker so that an ARTICLE
                # contains its own Sections; a level-2 section runs to the next marker
                if lvl == 1 and levels[j] == 1 or lvl == 2:
                    end = marks[j].start()
                    break
            heading = text[start:text.find("\n", start)].strip()
            rows.append((r["doc_id"], f"S{i:03d}", heading, lvl, start, end))
    store.write("INSERT OR REPLACE INTO document_section VALUES (?,?,?,?,?,?)", rows)
    return {"sections": len(rows)}


def extract_defined_terms(store: Store) -> dict:
    """A.4 — the definitions article is the most reusable asset in the corpus."""
    rows = []
    for r in store.q("SELECT doc_id, full_text FROM document_text"):
        for m in DEFINED_TERM_RE.finditer(r["full_text"]):
            rows.append((r["doc_id"], m.group(1), m.group(2).strip()[:400], m.start(), m.end()))
    store.exec("DELETE FROM defined_term")
    store.write("INSERT INTO defined_term VALUES (?,?,?,?,?)", rows)
    return {"defined_terms": len(rows)}


def load_ground_truth(store: Store, docs, splits: dict) -> dict:
    rows = []
    for d in docs:
        for fid, val in d.gt.items():
            if val is None:
                continue
            rows.append((d.doc_id, fid, str(val), str(val), splits[d.family_id]))
    store.write("INSERT OR REPLACE INTO ground_truth VALUES (?,?,?,?,?)", rows)
    return {"gt_rows": len(rows)}


def make_splits(docs, seed: int = 20260903) -> dict:
    """A.5 — split at FAMILY level. An amendment in dev whose base agreement sits in
    train leaks the answer, and the leak is invisible until test day."""
    import random
    fams = sorted({d.family_id for d in docs})
    random.Random(seed).shuffle(fams)
    n = len(fams)
    out = {}
    for i, f in enumerate(fams):
        out[f] = "train" if i < n * 0.5 else ("dev" if i < n * 0.75 else "test")
    return out


def verify_split_integrity(store: Store) -> int:
    """Zero rows required: no family may straddle two splits."""
    return len(store.q("""
        SELECT g.doc_id FROM ground_truth g JOIN document d ON d.doc_id = g.doc_id
        GROUP BY d.family_id HAVING COUNT(DISTINCT g.split) > 1"""))
