"""
PART G — Recursive Language Model derivation miner. Design time only.

The root model does not receive the document. It receives a REPL over the document
family — grep, section fetch, defined-term lookup, sub-query — and decides what to
read. That is what makes a 300-page family tractable without pushing it all through
one context window.

The inversion is the point: we already know the answer. We ask for the DERIVATION.
The output is spec material, which then compiles into a cheap deterministic path and
never needs the reasoning tier again.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from dataclasses import dataclass, field

from ..runtime.llm import Provider
from ..store import Store

MAX_STEPS = 8


class DocumentREPL:
    """The tool surface the root model drives. Every method is cheap and local; the
    expensive thing is the model deciding which to call."""

    def __init__(self, store: Store, doc_id: str):
        self.store = store
        fam = store.one("SELECT family_id FROM document WHERE doc_id=?", (doc_id,))["family_id"]
        self.docs = store.q("""SELECT d.doc_id, d.doc_type, d.effective_date, t.full_text
                               FROM document d JOIN document_text t ON t.doc_id=d.doc_id
                               WHERE d.family_id=? ORDER BY d.seq""", (fam,))
        self.calls: list[str] = []

    def list_sections(self, doc_id: str | None = None) -> list[str]:
        self.calls.append("list_sections")
        did = doc_id or self.docs[0]["doc_id"]
        return [r["heading"] for r in self.store.q(
            "SELECT heading FROM document_section WHERE doc_id=? ORDER BY char_start", (did,))]

    def get_section(self, heading_substr: str, doc_id: str | None = None) -> str:
        self.calls.append(f"get_section({heading_substr})")
        did = doc_id or self.docs[0]["doc_id"]
        for r in self.store.q("""SELECT heading, char_start, char_end FROM document_section
                                 WHERE doc_id=? ORDER BY char_start""", (did,)):
            if heading_substr.lower() in r["heading"].lower():
                txt = self.store.one("SELECT full_text FROM document_text WHERE doc_id=?",
                                     (did,))["full_text"]
                return txt[r["char_start"]:r["char_end"]]
        return ""

    def grep(self, pattern: str, window: int = 200) -> list[dict]:
        self.calls.append(f"grep({pattern})")
        out = []
        for d in self.docs:
            for m in re.finditer(pattern, d["full_text"], re.I):
                out.append({"doc_id": d["doc_id"], "at": m.start(),
                            "text": d["full_text"][max(0, m.start() - window // 2):
                                                   m.end() + window // 2]})
                if len(out) >= 12:
                    return out
        return out

    def defined_term(self, term: str) -> str:
        self.calls.append(f"defined_term({term})")
        r = self.store.one("SELECT definition FROM defined_term WHERE doc_id=? AND term LIKE ?",
                           (self.docs[0]["doc_id"], f"%{term}%"))
        return r["definition"] if r else ""

    def amendments(self) -> list[dict]:
        self.calls.append("amendments")
        return [{"doc_id": d["doc_id"], "effective_date": d["effective_date"],
                 "text": d["full_text"][:3000]}
                for d in self.docs if d["doc_type"] != "base"]


ROOT_PROMPT = """You are mining a DERIVATION RECIPE, not an answer. The correct answer
is already known and given to you below.

FIELD: {field_id}
KNOWN CORRECT VALUE for document {doc_id}: {gold}

You have a REPL over this document family. Available calls:
  list_sections()                  -> headings in the base agreement
  get_section("<substr>")          -> full text of the matching section
  grep("<regex>")                  -> matches with surrounding context, across the family
  defined_term("<term>")           -> the definition of a defined term
  amendments()                     -> every amendment, in effective-date order

Work out HOW the known value is reachable from the document. Then return JSON only:

{{
  "sections_used": ["<heading>", ...],
  "defined_terms_used": ["<term>", ...],
  "derivation_kind": "literal_span" | "normalization" | "arithmetic" | "rule" | "amendment_walk",
  "recipe": "<imperative steps another system could follow>",
  "conditions": [{{"condition": "...", "outcome": "..."}}],
  "edge_cases": ["..."],
  "confidence": <0..1>
}}

Return the JSON and nothing else.
NEXT_CALL: to use the REPL first, instead return {{"call": "<name>", "args": ["..."]}}.
"""


@dataclass
class Recipe:
    field_id: str
    kind: str
    sections: list = field(default_factory=list)
    terms: list = field(default_factory=list)
    recipe: str = ""
    conditions: list = field(default_factory=list)
    edge_cases: list = field(default_factory=list)
    repl_calls: list = field(default_factory=list)


def mine_field(store: Store, provider: Provider, field_id: str,
               doc_id: str, gold: str, max_steps: int = MAX_STEPS) -> Recipe | None:
    """One field, one document. The loop is the RLM: the model calls the REPL until it
    can state the derivation."""
    repl = DocumentREPL(store, doc_id)
    transcript = ""
    for _ in range(max_steps):
        prompt = ROOT_PROMPT.format(field_id=field_id, doc_id=doc_id, gold=gold) + transcript
        raw = provider.complete(prompt).text
        try:
            obj = json.loads(re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M))
        except json.JSONDecodeError:
            break
        if "call" in obj:
            fn = getattr(repl, obj["call"], None)
            result = fn(*obj.get("args", [])) if fn else f"no such call {obj['call']}"
            transcript += f"\n\nCALL {obj['call']}({obj.get('args')}) ->\n{str(result)[:1500]}"
            continue
        return Recipe(field_id, obj.get("derivation_kind", "rule"),
                      obj.get("sections_used", []), obj.get("defined_terms_used", []),
                      obj.get("recipe", ""), obj.get("conditions", []),
                      obj.get("edge_cases", []), repl.calls)
    return None


def mine(store: Store, provider: Provider, field_ids: list[str],
         samples: int = 20, split: str = "train") -> dict[str, list[Recipe]]:
    """G.2 — sample labeled documents per field. Bounded cost: ~20 documents for ~40
    fields, amortized across the whole corpus."""
    out: dict[str, list[Recipe]] = {}
    for fid in field_ids:
        rows = store.q("""SELECT doc_id, value_norm FROM ground_truth
                          WHERE field_id=? AND split=? LIMIT ?""", (fid, split, samples))
        recs = [r for r in (mine_field(store, provider, fid, x["doc_id"], x["value_norm"])
                            for x in rows) if r]
        if recs:
            out[fid] = recs
    return out


def canonicalize(recipes: list[Recipe]) -> dict:
    """
    G.3 — cluster derivations by shape.

    One dominant shape means the field is specifiable. Five shapes means the field
    should be SPLIT into sub-fields or routed to human_only — do not force a single
    recipe onto a field that does not have one.
    """
    kinds = Counter(r.kind for r in recipes)
    sections = Counter(s for r in recipes for s in r.sections)
    terms = Counter(t for r in recipes for t in r.terms)
    conds = Counter(json.dumps(c, sort_keys=True) for r in recipes for c in r.conditions)
    dominant, n = kinds.most_common(1)[0]
    agreement = n / len(recipes)
    return {
        "n_samples": len(recipes),
        "dominant_kind": dominant,
        "agreement": round(agreement, 3),
        "section_anchors": [s for s, _ in sections.most_common(4)],
        "defined_terms": [t for t, _ in terms.most_common(4)],
        "decision_procedure": [json.loads(c) for c, _ in conds.most_common(6)],
        "edge_cases": sorted({e for r in recipes for e in r.edge_cases})[:8],
        "verdict": ("specifiable" if agreement >= 0.6 else
                    "split_or_human_only"),
    }


def fold_into_spec(spec: dict, canon: dict) -> dict:
    """G.5 — the mined recipe becomes spec fields. Nothing here edits a prompt."""
    s = dict(spec)
    s["version"] = spec.get("version", 1) + 1
    r = s.setdefault("retrieval", {})
    if canon["section_anchors"]:
        r["section_anchors"] = canon["section_anchors"]
    if canon["decision_procedure"]:
        s["decision_procedure"] = [
            {"condition": c.get("condition", ""), "outcome": c.get("outcome", ""),
             "evidence_required": "verbatim quotation of the triggering language"}
            for c in canon["decision_procedure"]]
        s.setdefault("decision_default", "abstain — no condition satisfied")
    if canon["edge_cases"]:
        s["edge_cases"] = canon["edge_cases"]
    if canon["verdict"] != "specifiable":
        s["status"] = "human_only"
    s["mining_provenance"] = {"n_samples": canon["n_samples"],
                              "agreement": canon["agreement"],
                              "dominant_kind": canon["dominant_kind"]}
    return s


def validate_recipes(store: Store, canon_by_field: dict, split: str = "train") -> dict:
    """G.4 — re-execute cheaply and measure coverage. A recipe induced on 20 documents
    and never checked corpus-wide is worse than no recipe: it looks authoritative."""
    out = {}
    for fid, canon in canon_by_field.items():
        rows = store.q("""SELECT g.doc_id, g.value_norm FROM ground_truth g WHERE
                          g.field_id=? AND g.split=?""", (fid, split))
        reachable = 0
        for r in rows:
            txt = store.one("SELECT full_text FROM document_text WHERE doc_id=?",
                            (r["doc_id"],))["full_text"]
            hit = any(a.split(",")[0][:18].lower() in txt.lower()
                      for a in canon["section_anchors"]) if canon["section_anchors"] else False
            reachable += hit
        out[fid] = {"n": len(rows),
                    "anchor_coverage": round(reachable / max(1, len(rows)), 3),
                    "verdict": canon["verdict"]}
    return out
