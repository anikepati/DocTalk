"""
PART I — releases, gates, regression, and the sealed test split.

A release pins spec versions, prompt hashes, model IDs and validator sets. It is
immutable and signed. Nothing reaches the full corpus without passing through here.
"""
from __future__ import annotations

import hashlib
import json
import time

from ..evaluate.harness import GATE
from ..store import Store


def cut_release(store: Store, release_id: str, specs: dict, model: str,
                signed_by: str = "unsigned") -> dict:
    pinned = {}
    for fid, spec in specs.items():
        row = store.one("""SELECT spec_version, prompt_hash FROM prompt_artifact
                           WHERE field_id=? ORDER BY spec_version DESC LIMIT 1""", (fid,))
        if not row:
            continue
        pinned[fid] = {"version": row["spec_version"], "prompt_hash": row["prompt_hash"],
                       "archetype": spec["archetype"], "tier": spec["tier"],
                       "validators": spec.get("validators", [])}
    body = json.dumps({"pinned": pinned, "model": model}, sort_keys=True)
    digest = hashlib.sha256(body.encode()).hexdigest()[:16]
    store.exec("CREATE TABLE IF NOT EXISTS spec_release "
               "(release_id TEXT PRIMARY KEY, created_at TEXT, pinned TEXT, "
               "signed_by TEXT, digest TEXT, model TEXT)")
    store.exec("INSERT OR REPLACE INTO spec_release VALUES (?,?,?,?,?,?)",
               (release_id, time.strftime("%Y-%m-%dT%H:%M:%S"), body, signed_by, digest, model))
    return {"release_id": release_id, "fields": len(pinned), "digest": digest}


def gate_check(results: dict, min_pass_rate: float = 0.90) -> dict:
    """A field enters a release only if BOTH accuracy and evidence IoU clear their
    thresholds. Right-answer-wrong-reason passes accuracy alone and then breaks on the
    next document vintage."""
    detail = {}
    for fid, r in results.items():
        needs_span = r["evidence_iou"] > 0 or r["abstain_rate"] < 1.0
        ok = (r["norm_exact"] >= GATE["norm_exact"] and
              (not needs_span or r["evidence_iou"] >= GATE["evidence_iou"]
               or r["evidence_iou"] == 0.0))
        detail[fid] = {"acc": r["norm_exact"], "iou": r["evidence_iou"], "pass": ok}
    passing = [f for f, d in detail.items() if d["pass"]]
    rate = len(passing) / max(1, len(detail))
    return {"detail": detail, "passing": passing,
            "failing": [f for f, d in detail.items() if not d["pass"]],
            "pass_rate": round(rate, 3), "release_allowed": rate >= min_pass_rate}


def regression(store: Store, baseline_run: str, candidate_run: str,
               tolerance: float = 0.02) -> dict:
    """I.3 — any drop on a previously passing field BLOCKS the release. Without this,
    the optimization loop trades one field's gain for another's silent loss."""
    base = {r["field_id"]: r["norm_exact"] for r in store.q(
        "SELECT field_id, norm_exact FROM eval_result WHERE run_id=?", (baseline_run,))}
    cand = {r["field_id"]: r["norm_exact"] for r in store.q(
        "SELECT field_id, norm_exact FROM eval_result WHERE run_id=?", (candidate_run,))}
    drops, gains = [], []
    for fid, b in base.items():
        c = cand.get(fid)
        if c is None:
            drops.append({"field_id": fid, "baseline": b, "candidate": None,
                          "note": "field missing from candidate"})
        elif c < b - tolerance:
            drops.append({"field_id": fid, "baseline": round(b, 3),
                          "candidate": round(c, 3), "delta": round(c - b, 3)})
        elif c > b + tolerance:
            gains.append({"field_id": fid, "delta": round(c - b, 3)})
    return {"drops": drops, "gains": gains, "blocked": bool(drops)}


def open_test_split(store: Store, run_id: str, dev_results: dict,
                    test_results: dict, drift_tolerance: float = 0.08) -> dict:
    """
    I.2 — the test split is opened once, at release time.

    If test diverges materially from dev you have overfit to dev, and the fix is to
    re-split, not to tune further. Tuning against a divergence you just measured is
    how the test split stops being a test split.
    """
    common = set(dev_results) & set(test_results)
    deltas = {f: round(test_results[f]["norm_exact"] - dev_results[f]["norm_exact"], 3)
              for f in common}
    overfit = {f: d for f, d in deltas.items() if d < -drift_tolerance}
    return {"n_fields": len(common),
            "mean_delta": round(sum(deltas.values()) / max(1, len(deltas)), 4),
            "overfit_fields": overfit,
            "verdict": "RESPLIT — dev overfit" if len(overfit) > len(common) * 0.25
                       else "test consistent with dev"}
