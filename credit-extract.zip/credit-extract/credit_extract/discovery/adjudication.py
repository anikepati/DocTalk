"""
J.4–J.6 — the Cluster Adjudication Board and promotion back into the spec registry.

Reviewers act on leverage-sorted CLUSTERS, not individual items: per-item review does
not scale past a few thousand claims. Each cluster carries a compile target, so an
adjudication retires a pattern permanently instead of fixing one document.
"""
from __future__ import annotations

import pathlib

import yaml

from ..store import Store

COMPILE_TARGETS = ("new_entity_spec", "validator_rule", "decision_branch", "human_only")


def build_board(store: Store, limit: int = 25) -> list[dict]:
    """Leverage-sorted work queue. The top of this list is where a reviewer's hour
    buys the most future automation."""
    rows = store.q("""SELECT candidate_id, kind, signature, frequency, leverage,
                             exemplars, compile_target, status
                      FROM discovery_candidate WHERE status='pending'
                      ORDER BY leverage DESC LIMIT ?""", (limit,))
    n_docs = store.one("SELECT COUNT(*) c FROM document")["c"]
    board = []
    for r in rows:
        board.append({
            "candidate_id": r["candidate_id"], "kind": r["kind"],
            "frequency": r["frequency"],
            "coverage": round(r["frequency"] / max(1, n_docs), 3),
            "leverage": r["leverage"], "proposed_target": r["compile_target"],
            "exemplars": r["exemplars"],
            # what one adjudication buys, in documents
            "retires_items": r["frequency"],
        })
    return board


def adjudicate(store: Store, candidate_id: str, target: str,
               field_id: str | None = None, note: str = "") -> dict:
    if target not in COMPILE_TARGETS:
        raise ValueError(f"target must be one of {COMPILE_TARGETS}")
    store.exec("""UPDATE discovery_candidate SET compile_target=?, status=?
                  WHERE candidate_id=?""", (target, "adjudicated", candidate_id))
    return {"candidate_id": candidate_id, "compile_target": target,
            "field_id": field_id, "note": note}


def promote_to_spec(store: Store, candidate_id: str, field_id: str,
                    spec_dir: str, display_name: str | None = None) -> str:
    """
    J.6 — a promoted candidate becomes a real YAML spec and re-enters PART C.

    It starts life with no labels, so it cannot be gated yet. Labels accumulate from
    adjudication until the field earns an eval gate of its own; until then it runs in
    shadow and its output is advisory.
    """
    r = store.one("SELECT signature, frequency, exemplars FROM discovery_candidate "
                  "WHERE candidate_id=?", (candidate_id,))
    if not r:
        raise KeyError(candidate_id)
    spec = {
        "field_id": field_id,
        "version": 1,
        "display_name": display_name or field_id.replace("_", " ").title(),
        "tier": "T0_PRIMITIVE_SPAN",
        "archetype": "span_extract",
        "value_type": "string",
        "cardinality": "one",
        "status": "shadow",          # runs, but advisory until it has labels and a gate
        "definition": "TODO human definition. Promoted from discovery candidate "
                      f"{candidate_id} (appeared in {r['frequency']} documents).",
        "retrieval": {"section_anchors": ["whole document"], "strategy": "section_anchor",
                      "window_tokens": 6000},
        "few_shot_source": "grounding_probe",
        "evidence": "required",
        "confidence_policy": {"auto_accept": 0.95, "validate": 0.80, "escalate_rlm": 0.60},
        "business_weight": "unknown",
        "discovery_provenance": {"candidate_id": candidate_id, "signature": r["signature"],
                                 "frequency": r["frequency"]},
    }
    p = pathlib.Path(spec_dir) / f"{field_id}.yaml"
    p.write_text(yaml.safe_dump(spec, sort_keys=False, width=100))
    store.exec("UPDATE discovery_candidate SET status='promoted' WHERE candidate_id=?",
               (candidate_id,))
    return str(p)


def deviation_scan(store: Store, min_docs: int = 5) -> list[dict]:
    """
    J.4 — clause-type distribution per section, outliers flagged.

    The rare bespoke carve-out is precisely what nobody wrote a field for and precisely
    what carries risk. Frequency-sorting alone would bury it; this is the complement.
    """
    from collections import Counter, defaultdict
    per_section = defaultdict(Counter)
    for r in store.q("""SELECT s.heading, r.signature FROM residual_span r
                        JOIN document_section s
                          ON s.doc_id=r.doc_id AND s.section_id=r.section_id"""):
        head = r["heading"].split(".")[0].strip().upper()[:40]
        per_section[head][r["signature"]] += 1
    out = []
    for head, sigs in per_section.items():
        total = sum(sigs.values())
        if total < min_docs:
            continue
        for sig, n in sigs.items():
            share = n / total
            if share < 0.15:                 # rare within its own section
                out.append({"section": head, "signature": sig, "count": n,
                            "share_within_section": round(share, 3),
                            "why": "rare clause shape for this section type"})
    return sorted(out, key=lambda d: d["share_within_section"])[:30]
