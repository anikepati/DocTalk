"""
Stage J — discovery of what the 200-field schema does not cover.

These candidates have no ground truth by construction, so they cannot pass through the
eval harness. They go to human adjudication, leverage-sorted, with an explicit compile
target.
"""
from __future__ import annotations

import hashlib
import re
from collections import Counter, defaultdict

from ..store import Store

OBLIGATION = re.compile(r"\b(shall not|shall|may not|provided that|notwithstanding)\b", re.I)
MONEY = re.compile(r"\$\s?[\d,]+")
HIGH_VALUE_SECTIONS = ("NEGATIVE COVENANT", "EVENTS OF DEFAULT", "PREPAYMENT", "FINANCIAL COVENANT")


def compute_residuals(store: Store, run_id: str, min_len: int = 120) -> dict:
    """J.1/J.2 — mask every consumed span, keep what is left and salient."""
    consumed = defaultdict(list)
    for r in store.q("""SELECT doc_id, evidence_start, evidence_end FROM extraction_claim
                        WHERE run_id=? AND abstain=0 AND evidence_start IS NOT NULL""", (run_id,)):
        consumed[r["doc_id"]].append((r["evidence_start"], r["evidence_end"]))

    rows = []
    for r in store.q("SELECT doc_id, full_text FROM document_text"):
        doc_id, text = r["doc_id"], r["full_text"]
        secs = store.q("SELECT section_id, heading, char_start, char_end FROM document_section "
                       "WHERE doc_id=? ORDER BY char_start", (doc_id,))
        spans = sorted(consumed.get(doc_id, []))
        cursor, gaps = 0, []
        for s, e in spans:
            if s - cursor >= min_len:
                gaps.append((cursor, s))
            cursor = max(cursor, e)
        if len(text) - cursor >= min_len:
            gaps.append((cursor, len(text)))

        for gs, ge in gaps:
            chunk = text[gs:ge]
            for sec in secs:
                if sec["char_start"] <= gs < sec["char_end"]:
                    heading = sec["heading"]
                    sid = sec["section_id"]
                    break
            else:
                heading, sid = "", None
            sal = (0.4 * min(1.0, len(OBLIGATION.findall(chunk)) / 3)
                   + 0.3 * min(1.0, len(MONEY.findall(chunk)) / 2)
                   + 0.3 * any(h in heading.upper() for h in HIGH_VALUE_SECTIONS))
            if sal < 0.35:
                continue
            rows.append((doc_id, gs, ge, sid, round(sal, 3), _signature(chunk)))
    store.exec("DELETE FROM residual_span")
    store.write("INSERT INTO residual_span VALUES (?,?,?,?,?,?)", rows)
    return {"residuals": len(rows)}


def _signature(chunk: str) -> str:
    """Cheap structural fingerprint standing in for an embedding: the ordered clause
    skeleton, which is what actually recurs across a corpus of near-boilerplate."""
    toks = re.findall(r"\b(Section \d+\.\d+|[A-Z][a-z]+ [A-Z][a-z]+)\b", chunk)[:6]
    return hashlib.sha1(("|".join(toks) or chunk[:60]).encode()).hexdigest()[:12]


def cluster_candidates(store: Store, min_cluster: int = 5) -> dict:
    """J.3/J.5 — frequency-sort. A residual pattern in 4,000 agreements is a missing
    field; one in 3 is a bespoke term worth flagging but not schematizing."""
    sigs = Counter(r["signature"] for r in store.q("SELECT signature FROM residual_span"))
    n_docs = store.one("SELECT COUNT(*) c FROM document")["c"]
    rows = []
    for sig, freq in sigs.most_common(60):
        if freq < min_cluster:
            continue
        ex = store.q("""SELECT r.doc_id, r.char_start, r.char_end, r.salience,
                               substr(t.full_text, r.char_start+1, 160) AS snippet
                        FROM residual_span r JOIN document_text t ON t.doc_id=r.doc_id
                        WHERE r.signature=? LIMIT 3""", (sig,))
        sal = sum(e["salience"] for e in ex) / len(ex)
        coverage = freq / max(1, n_docs)
        leverage = round(coverage * sal * (1.0 if coverage < 0.9 else 0.3), 4)
        target = ("new_entity_spec" if coverage > 0.5 else
                  "validator_rule" if coverage > 0.1 else "human_only")
        rows.append((f"cand-{sig}", "residual_cluster", sig, freq, leverage,
                     Store.j([dict(e) for e in ex]), target, "pending"))
    store.exec("DELETE FROM discovery_candidate")
    store.write("INSERT INTO discovery_candidate VALUES (?,?,?,?,?,?,?,?)", rows)
    return {"candidates": len(rows)}


def contradiction_candidates(store: Store, run_id: str) -> list[dict]:
    """J — a derived value disagreeing with a directly stated one is either a broken
    rule or a genuine document anomaly. Free, high-precision, and already computed."""
    return [dict(r) for r in store.q("""
        SELECT doc_id, field_id, value_norm, stated_in_document FROM derived_value
        WHERE run_id=? AND contradicts=1""", (run_id,))]
