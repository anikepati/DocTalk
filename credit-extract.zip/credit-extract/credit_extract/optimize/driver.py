"""
PART H — the Ralph loop that drives GEPA.

`gepa.py` proposes spec mutations. This is the outer loop that actually recompiles,
re-evaluates, Pareto-checks against every other field, and writes version+1 on a win.
Fields do not optimize forever: the stop conditions are enforced here.
"""
from __future__ import annotations

import copy
import pathlib
import random

import yaml

from ..compile import compiler as C
from ..derive.dag import run_dag
from ..evaluate.harness import evaluate
from ..runtime.agents import AgentFactory, run_extraction
from ..store import Store
from .gepa import propose


def _recompile_one(spec: dict, spec_dir: pathlib.Path, templates: pathlib.Path,
                   shots: pathlib.Path, out: pathlib.Path, store: Store) -> dict:
    """A candidate is only real once it has compiled and passed lint. A mutation that
    produces an unlintable prompt is discarded, not patched."""
    prompt, meta = C.compile_spec(spec, C.Environment(
        loader=C.FileSystemLoader(str(templates)), undefined=C.StrictUndefined,
        trim_blocks=True, keep_trailing_newline=True), shots)
    if meta["lint"]:
        return {"ok": False, "lint": meta["lint"]}
    store.exec("INSERT OR REPLACE INTO prompt_artifact VALUES (?,?,?,?,?)",
               (spec["field_id"], spec["version"], meta["prompt_hash"],
                meta["template_id"], prompt))
    (out / f"{spec['field_id']}.v{spec['version']}.txt").write_text(prompt)
    return {"ok": True, "meta": meta}


def optimize_field(store: Store, specs: dict, field_id: str, dominant_error: str,
                   provider, types: dict, paths: dict, split: str = "dev",
                   k: int = 4, rounds: int = 4, seed: int = 7) -> dict:
    """
    One field, N rounds. Each round: propose K spec mutations, compile, run, evaluate,
    accept only a candidate that improves the target WITHOUT regressing any other field.
    """
    rng = random.Random(seed)
    spec_dir = pathlib.Path(paths["specs"])
    templates, shots, out = (pathlib.Path(paths["templates"]),
                             pathlib.Path(paths["few_shots"]), pathlib.Path(paths["prompts"]))

    baseline_run = _run_once(store, specs, provider, split)
    baseline = evaluate(store, baseline_run, split, types)
    target0 = baseline.get(field_id, {}).get("norm_exact", 0.0)
    prior = {f: r["norm_exact"] for f, r in baseline.items() if f != field_id}

    best_spec, best_score, history = specs[field_id], target0, []
    stagnant = 0

    for rnd in range(rounds):
        cands = propose(best_spec, dominant_error, rng, k=k)
        round_best = None
        for c in cands:
            comp = _recompile_one(c.spec, spec_dir, templates, shots, out, store)
            if not comp["ok"]:
                history.append({"round": rnd, "mutation": c.mutation,
                                "result": "lint_failed", "detail": comp["lint"]})
                continue
            trial_specs = dict(specs, **{field_id: c.spec})
            rid = _run_once(store, trial_specs, provider, split)
            res = evaluate(store, rid, split, types)
            c.score = res.get(field_id, {}).get("norm_exact", 0.0)
            collateral = {f: r["norm_exact"] for f, r in res.items() if f != field_id}
            regressed = [f for f, v in prior.items()
                         if collateral.get(f, v) < v - 1e-9]
            history.append({"round": rnd, "mutation": c.mutation, "score": round(c.score, 3),
                            "regressed": regressed[:3]})
            if regressed:
                continue                      # Pareto: no gain at another field's expense
            if round_best is None or c.score > round_best.score:
                round_best = c

        if round_best and round_best.score > best_score + 1e-9:
            best_spec, best_score = round_best.spec, round_best.score
            stagnant = 0
            (spec_dir / f"{field_id}.yaml").write_text(
                yaml.safe_dump(_strip_defaults(best_spec), sort_keys=False, width=100))
        else:
            stagnant += 1
            if stagnant >= 2:                 # H.4 — fields do not optimize forever
                break

    return {"field_id": field_id, "baseline": round(target0, 3),
            "final": round(best_score, 3), "gain": round(best_score - target0, 3),
            "version": best_spec.get("version"), "history": history,
            "disposition": ("at_gate" if best_score >= 0.90 else
                            "escalate_rlm" if best_score > target0 else "human_only")}


def _run_once(store: Store, specs: dict, provider, split: str) -> str:
    agents = AgentFactory(store, specs).build()
    res = run_extraction(store, agents, provider, split, "rel-opt")
    run_dag(store, specs, res["run_id"])
    return res["run_id"]


DEFAULT_KEYS = {"disambiguation": None, "normalization": None, "edge_cases": [],
                "depends_on": [], "decision_procedure": [], "decision_default": None,
                "domain": [], "row_schema": [], "derivation": None}


def _strip_defaults(spec: dict) -> dict:
    """Do not persist the compiler's injected defaults back into the YAML — the spec
    file should show what a human wrote, not what the compiler filled in."""
    s = copy.deepcopy(spec)
    for k, v in DEFAULT_KEYS.items():
        if k in s and s[k] == v:
            del s[k]
    return s
