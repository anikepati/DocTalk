"""
Stage H.3 — spec-level optimization.

GEPA mutates the SPEC, never the prompt text. The prompt recompiles from the mutated
spec, so an improvement is reproducible and versioned rather than a lucky string
someone pasted in. K candidates evaluated in parallel, Pareto-tracked so a gain on one
field cannot silently regress another.
"""
from __future__ import annotations

import copy
import random
from dataclasses import dataclass

MUTATIONS = ["widen_anchors", "narrow_anchors", "swap_archetype",
             "reselect_few_shots", "strengthen_discriminator", "tighten_normalization"]


@dataclass
class Candidate:
    spec: dict
    mutation: str
    score: float = 0.0


def propose(spec: dict, dominant_error: str, rng: random.Random, k: int = 4) -> list[Candidate]:
    """The dominant error class chooses the mutation family. This is the whole point of
    running the error taxonomy first — a retrieval failure gets an anchor mutation, not
    a reworded instruction."""
    family = {
        "retrieval": ["widen_anchors", "narrow_anchors"],
        "prompt": ["reselect_few_shots", "strengthen_discriminator", "swap_archetype"],
        "normalization": ["tighten_normalization"],
        "abstained": ["widen_anchors", "reselect_few_shots"],
    }.get(dominant_error, MUTATIONS)

    out = []
    for i in range(k):
        m = family[i % len(family)]
        s = copy.deepcopy(spec)
        r = s.setdefault("retrieval", {})
        if m == "widen_anchors":
            r["section_anchors"] = list(r.get("section_anchors", [])) + ["whole document"]
            r["window_tokens"] = int(r.get("window_tokens", 6000) * 1.5)
        elif m == "narrow_anchors":
            r["section_anchors"] = list(r.get("section_anchors", []))[:1]
            r["window_tokens"] = max(1500, int(r.get("window_tokens", 6000) * 0.6))
        elif m == "swap_archetype":
            s["archetype"] = {"span_extract": "normalize_extract",
                              "normalize_extract": "span_extract"}.get(s["archetype"], s["archetype"])
        elif m == "reselect_few_shots":
            s["few_shot_k"] = min(5, s.get("few_shot_k", 3) + 1)
        elif m == "strengthen_discriminator":
            d = s.setdefault("disambiguation", {"confusable_with": [], "discriminator": ""})
            d["discriminator"] = (d.get("discriminator", "") +
                                  " Prefer the operative provision over any recital or cross-reference.")
        elif m == "tighten_normalization":
            s["normalization"] = s.get("normalization") or "money_usd_scale"
        s["version"] = spec.get("version", 1) + 1
        out.append(Candidate(s, m))
    return out


def pareto_select(cands: list[Candidate], baseline: float,
                  collateral: dict[str, float], prior: dict[str, float]) -> Candidate | None:
    """Accept only a candidate that improves the target WITHOUT regressing any other
    field. Fields do not optimize forever — H.4 stop conditions live in the driver."""
    best = None
    for c in cands:
        if c.score <= baseline:
            continue
        if any(collateral.get(f, v) < v - 1e-9 for f, v in prior.items()):
            continue
        if best is None or c.score > best.score:
            best = c
    return best
