"""
E.1 — retrieval planning, bundling, and cost estimation.

Bundling is a runtime packing decision only: the per-entity prompt remains the
canonical unit for versioning, eval, and optimization. A bundle is the concatenation
of per-entity blocks that share an evidence window.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field

MAX_BUNDLE = 12


@dataclass
class Bundle:
    key: str
    anchors: list
    field_ids: list = field(default_factory=list)


def plan_bundles(specs: dict, max_bundle: int = MAX_BUNDLE) -> list[Bundle]:
    """
    Group by primary section anchor. Two guardrails:
      - never co-bundle fields declared confusable with one another; cross-contamination
        inside a single call is the dominant bundling failure mode
      - never bundle derivative tiers, which do not read the document at all
    """
    groups: dict[str, list[str]] = defaultdict(list)
    for fid, s in specs.items():
        if s.get("archetype") in ("derive_deterministic", "crossref_resolve"):
            continue
        anchors = s.get("retrieval", {}).get("section_anchors") or ["whole document"]
        groups[str(anchors[0])].append(fid)

    confus = {fid: set((s.get("disambiguation") or {}).get("confusable_with", []))
              for fid, s in specs.items()}

    bundles: list[Bundle] = []
    for key, fids in groups.items():
        cur: list[str] = []
        for fid in sorted(fids):
            clash = any(fid in confus.get(o, set()) or o in confus.get(fid, set()) for o in cur)
            if clash or len(cur) >= max_bundle:
                bundles.append(Bundle(key, specs[cur[0]]["retrieval"]["section_anchors"], cur))
                cur = []
            cur.append(fid)
        if cur:
            bundles.append(Bundle(key, specs[cur[0]].get("retrieval", {}).get(
                "section_anchors", [key]), cur))
    return bundles


def project_to_scale(specs: dict, bundles: list[Bundle], target_fields: int = 200,
                     n_docs: int = 20_000) -> dict:
    """Scale the observed fields-per-bundle ratio up to the real field count. Reporting
    a reduction figure computed from 13 demo fields against a 20K corpus is a number
    that means nothing."""
    live = [s for s in specs.values() if s.get("archetype") != "derive_deterministic"]
    per_bundle = max(1.0, len(live) / max(1, len(bundles)))
    proj_bundles = max(1, round(target_fields / per_bundle))
    return {"target_fields": target_fields, "docs": n_docs,
            "fields_per_bundle": round(per_bundle, 1),
            "naive_calls": target_fields * n_docs,
            "bundled_calls": proj_bundles * n_docs,
            "call_reduction": round(1 - proj_bundles / target_fields, 3)}


def estimate_cost(specs: dict, n_docs: int, bundles: list[Bundle],
                  avg_prompt_chars: int = 4500, avg_evidence_chars: int = 18000,
                  escalation_pct: float = 0.05,
                  price_in: float = 0.30 / 1e6, price_out: float = 2.50 / 1e6,
                  price_in_pro: float = 1.25 / 1e6, price_out_pro: float = 10.0 / 1e6) -> dict:
    """I.4 — confirm the envelope BEFORE launching 20K. Runtime RLM cost creep is the
    most common way this blows up."""
    per_doc_unbundled = len([s for s in specs.values()
                             if s.get("archetype") != "derive_deterministic"])
    tin = (avg_prompt_chars + avg_evidence_chars) / 4
    tout = 220 / 4

    naive_calls = per_doc_unbundled * n_docs
    bundled_calls = len(bundles) * n_docs
    flash = bundled_calls * (tin * price_in + tout * price_out)
    # escalations replay the whole document family through the reasoning tier
    rlm_calls = int(bundled_calls * escalation_pct)
    rlm = rlm_calls * ((tin * 4) * price_in_pro + (tout * 3) * price_out_pro)

    return {
        "docs": n_docs,
        "fields_per_doc": per_doc_unbundled,
        "naive_calls": naive_calls,
        "bundled_calls": bundled_calls,
        "call_reduction": round(1 - bundled_calls / max(1, naive_calls), 3),
        "flash_usd": round(flash, 2),
        "rlm_calls": rlm_calls,
        "rlm_usd": round(rlm, 2),
        "total_usd": round(flash + rlm, 2),
        "rlm_share": round(rlm / max(1e-9, flash + rlm), 3),
    }
