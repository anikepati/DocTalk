"""
Stage E — retrieval planning, agent factory, extraction runtime, confidence routing.

One agent per entity, instantiated from a spec release. In production these are ADK
LlmAgents fanned out by a ParallelAgent; the loop below is the same contract without
the framework, so the logic is testable in isolation.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import dataclass

from ..store import Store
from .llm import Provider

ROUTE_ACCEPT, ROUTE_VALIDATE, ROUTE_RLM, ROUTE_HITL = "accept", "validate", "rlm", "hitl"


@dataclass
class Agent:
    field_id: str
    spec_version: int
    tier: str
    archetype: str
    prompt: str
    anchors: list
    policy: dict
    window: int = 6000


class AgentFactory:
    """Agents are DATA, not 200 hand-written classes. Adding a field is a YAML file
    and a release — no code change, no deploy."""

    def __init__(self, store: Store, specs: dict):
        self.store, self.specs = store, specs

    def build(self) -> list[Agent]:
        agents = []
        for fid, spec in self.specs.items():
            row = self.store.one(
                "SELECT spec_version, prompt_text FROM prompt_artifact WHERE field_id=? "
                "ORDER BY spec_version DESC LIMIT 1", (fid,))
            if not row:
                continue
            agents.append(Agent(
                field_id=fid, spec_version=row["spec_version"], tier=spec["tier"],
                archetype=spec["archetype"], prompt=row["prompt_text"],
                anchors=spec.get("retrieval", {}).get("section_anchors", []),
                policy=spec.get("confidence_policy", {}),
                window=spec.get("retrieval", {}).get("window_tokens", 6000) * 4))
        return agents


def resolve_evidence(store: Store, doc_id: str, anchors: list,
                     window: int) -> tuple[str, str | None, int]:
    """
    E.1 — anchors to a concrete char window.

    Fallback ladder: anchor heading match -> defined-term trace -> whole document.
    Which rung fired is itself a diagnostic: a field that keeps falling through to
    whole-document has stale anchors, and that is a retrieval fix, not a prompt fix.
    """
    secs = store.q("SELECT section_id, heading, char_start, char_end FROM document_section "
                   "WHERE doc_id=? ORDER BY char_start", (doc_id,))
    text = store.one("SELECT full_text FROM document_text WHERE doc_id=?", (doc_id,))["full_text"]
    for a in anchors:
        key = re.sub(r"[^A-Za-z0-9 ]", " ", str(a)).lower().split()
        for s in secs:
            h = s["heading"].lower()
            if key and all(k in h for k in key[:2]):
                return (text[s["char_start"]:min(s["char_end"], s["char_start"] + window)],
                        s["section_id"], s["char_start"])
    for a in anchors:
        m = re.search(re.escape(str(a)[:28]), text, re.I)
        if m:
            st = max(0, m.start() - 400)
            return text[st:st + window], None, st
    return text[:window], None, 0


def resolve_family(store: Store, doc_id: str, window: int) -> tuple[str, str]:
    """T5 evidence: base agreement plus every amendment, in effective-date order.
    Section routing structurally cannot answer 'the value as amended'."""
    fam = store.one("SELECT family_id FROM document WHERE doc_id=?", (doc_id,))["family_id"]
    rows = store.q("""SELECT d.doc_id, d.doc_type, d.effective_date, t.full_text
                      FROM document d JOIN document_text t ON t.doc_id=d.doc_id
                      WHERE d.family_id=? ORDER BY d.seq""", (fam,))
    base = next((r["full_text"][:window] for r in rows if r["doc_type"] == "base"), "")
    amends = "\n\n".join(
        f"--- {r['doc_id']} effective {r['effective_date']} ---\n{r['full_text'][:window // 2]}"
        for r in rows if r["doc_type"] != "base")
    return base, amends


def parse_claim(raw: str) -> dict:
    t = raw.strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", t, re.S)
        return json.loads(m.group(0)) if m else {"abstain": True, "value": None,
                                                 "confidence": 0.0, "_parse_error": True}


def route(claim: dict, policy: dict) -> str:
    """E — confidence routing. Abstention is a first-class outcome, not a failure."""
    if claim.get("abstain"):
        return ROUTE_HITL
    c = float(claim.get("confidence") or 0.0)
    if c >= policy.get("auto_accept", 0.92):
        return ROUTE_ACCEPT
    if c >= policy.get("validate", 0.75):
        return ROUTE_VALIDATE
    if c >= policy.get("escalate_rlm", 0.60):
        return ROUTE_RLM
    return ROUTE_HITL


def run_extraction(store: Store, agents: list[Agent], provider: Provider,
                   split: str, release_id: str) -> dict:
    run_id = f"run-{uuid.uuid4().hex[:8]}"
    docs = [r["doc_id"] for r in store.q(
        "SELECT DISTINCT doc_id FROM ground_truth WHERE split=?", (split,))]
    rows, calls, cost = [], 0, 0.0

    for doc_id in docs:
        for ag in agents:
            if ag.archetype == "derive_deterministic":
                continue                     # handled by the DAG, never by extraction
            if ag.archetype == "crossref_resolve":
                b, am = resolve_family(store, doc_id, ag.window)
                ev, sec, base = b + am, None, 0
                prompt = (ag.prompt.replace("{{base_excerpt}}", b)
                                   .replace("{{amendment_excerpts}}", am or "(none)"))
            else:
                ev, sec, base = resolve_evidence(store, doc_id, ag.anchors, ag.window)
                prompt = ag.prompt.replace("{{evidence_text}}", ev)
            resp = provider.complete(prompt)
            calls += 1
            cost += resp.cost_usd
            c = parse_claim(resp.text)
            span = c.get("evidence_span") or {}
            # window-relative -> document-absolute, or every IoU score is meaningless
            for k in ("char_start", "char_end"):
                if isinstance(span.get(k), int):
                    span[k] = span[k] + base
            rows.append((
                f"c-{uuid.uuid4().hex[:12]}", run_id, doc_id, ag.field_id,
                c.get("value_raw"), None if c.get("value") is None else str(c.get("value")),
                float(c.get("confidence") or 0.0), int(bool(c.get("abstain"))),
                span.get("char_start"), span.get("char_end"), sec,
                route(c, ag.policy), c.get("rule_fired"), resp.text[:2000]))

    store.write("INSERT INTO extraction_claim VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
    store.exec("INSERT OR REPLACE INTO extraction_run VALUES (?,?,?,?,datetime('now'),?,?)",
               (run_id, release_id, split, provider.name, calls, cost))
    return {"run_id": run_id, "claims": len(rows), "calls": calls, "cost_usd": round(cost, 4)}
