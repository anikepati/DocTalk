"""
Deterministic validators.

Specs name validators as strings (`nonneg`, `equals_sum(lender_commitments)`).
This module parses those, runs them against a claim plus the rest of the document's
claims, and writes results. A validator failure is what turns a mid-confidence claim
into an escalation instead of an acceptance.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..probe.matchers import norm_money
from ..store import Store

CALL = re.compile(r"^(\w+)(?:\((.*)\))?$")


@dataclass
class VResult:
    validator_id: str
    passed: bool
    detail: str = ""


def _f(v):
    if v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return float(norm_money(str(v))) if norm_money(str(v)) is not None else None


# ---------------------------------------------------------------- validators

def v_nonempty(val, args, ctx):
    return bool(val and str(val).strip()), f"value={val!r}"


def v_nonneg(val, args, ctx):
    f = _f(val)
    return (f is not None and f >= 0), f"value={f}"


def v_in_range(val, args, ctx):
    f = _f(val)
    lo, hi = float(args[0]), float(args[1])
    return (f is not None and lo <= f <= hi), f"{f} vs [{lo},{hi}]"


def v_gte(val, args, ctx):
    f, o = _f(val), _f(ctx["claims"].get(args[0]))
    if f is None or o is None:
        return True, "input missing — not a failure of this field"
    return f >= o, f"{f} >= {o}"


def v_equals_sum(val, args, ctx):
    """The classic reconciliation: a stated total against the rows that compose it.
    Catches both a bad total and a truncated table, which is why it is worth running
    even when both fields already look confident."""
    f = _f(val)
    raw = ctx["claims"].get(args[0])
    if f is None or not raw:
        return True, "counterpart missing"
    parts = [_f(p.split("=")[-1]) for p in str(raw).split("|") if "=" in p]
    parts = [p for p in parts if p is not None]
    if not parts:
        return True, "counterpart unparsed"
    total = sum(parts)
    return abs(total - f) < 1.0, f"rows sum {total} vs stated {f}"


def v_currency_matches(val, args, ctx):
    c = ctx["claims"].get(args[0])
    return (c is None or bool(c)), f"currency={c}"


def v_entity_suffix_present(val, args, ctx):
    ok = bool(re.search(r"\b(INC\.?|LLC|L\.L\.C\.|CORP\.?|N\.A\.|LTD\.?|PLC|COMPANY|GROUP|HOLDINGS)\b",
                        str(val or ""), re.I))
    return ok, f"value={val!r}"


def v_matches_signature_block(val, args, ctx):
    txt = ctx.get("full_text") or ""
    return (str(val or "") in txt), "present in document text"


def v_row_count_gte_1(val, args, ctx):
    return bool(val and str(val).strip()), "list non-empty"


def v_all_amounts_positive(val, args, ctx):
    parts = [_f(p.split("=")[-1]) for p in str(val or "").split("|") if "=" in p]
    bad = [p for p in parts if p is not None and p <= 0]
    return not bad, f"{len(bad)} non-positive rows"


def v_deterministic_recompute_match(val, args, ctx):
    """T3 guarantee. The prompt supplies the explanation; the code supplies the
    number. Where they disagree, the code wins and the disagreement is recorded."""
    d = ctx.get("derived")
    if d is None or val is None:
        return True, "no derived counterpart"
    return abs((_f(val) or 0) - (_f(d) or 0)) < 1.0, f"llm={val} code={d}"


def v_rule_fired_in_range(val, args, ctx):
    rf, n = ctx.get("rule_fired"), int(args[0]) if args else 99
    return (rf is None or 1 <= int(rf) <= n), f"rule_fired={rf}"


def v_consistent_with(val, args, ctx):
    return True, "advisory"


def v_as_of_date_lte_latest_amendment(val, args, ctx):
    return True, "advisory"


REGISTRY = {n[2:]: f for n, f in list(globals().items()) if n.startswith("v_")}


def parse_call(spec_str: str) -> tuple[str, list[str]]:
    m = CALL.match(spec_str.strip())
    if not m:
        return spec_str.strip(), []
    name, arg = m.group(1), m.group(2)
    return name, [a.strip() for a in arg.split(",")] if arg else []


def run_validators(store: Store, run_id: str, specs: dict) -> dict:
    """Run every spec's validators over every claim in a run."""
    claims_by_doc: dict[str, dict] = {}
    rows = store.q("""SELECT claim_id, doc_id, field_id, value_norm, abstain, rule_fired
                      FROM extraction_claim WHERE run_id=?""", (run_id,))
    for r in rows:
        claims_by_doc.setdefault(r["doc_id"], {})[r["field_id"]] = r["value_norm"]
    derived = {}
    for r in store.q("SELECT doc_id, field_id, value_norm FROM derived_value WHERE run_id=?",
                     (run_id,)):
        derived.setdefault(r["doc_id"], {})[r["field_id"]] = r["value_norm"]

    out, failed, unknown = [], 0, set()
    for r in rows:
        spec = specs.get(r["field_id"])
        if not spec or r["abstain"]:
            continue
        ctx = {"claims": claims_by_doc.get(r["doc_id"], {}),
               "derived": derived.get(r["doc_id"], {}).get(r["field_id"]),
               "rule_fired": r["rule_fired"], "full_text": None}
        for vs in spec.get("validators", []) or []:
            name, args = parse_call(vs)
            fn = REGISTRY.get(name)
            if fn is None:
                unknown.add(name)
                continue
            try:
                ok, detail = fn(r["value_norm"], args, ctx)
            except Exception as e:                    # a broken validator is not a
                ok, detail = True, f"validator error: {e}"   # claim failure
            failed += not ok
            out.append((r["claim_id"], vs, int(ok), detail[:200]))

    store.write("INSERT INTO validator_result VALUES (?,?,?,?)", out)
    return {"checks": len(out), "failures": failed, "unknown_validators": sorted(unknown)}


def demote_failures(store: Store, run_id: str) -> int:
    """A validator failure on an accepted claim reroutes it to escalation. Accepting a
    claim that fails its own reconciliation is how bad numbers reach a regulator."""
    ids = [r["claim_id"] for r in store.q("""
        SELECT DISTINCT claim_id FROM validator_result WHERE passed=0""")]
    n = 0
    for cid in ids:
        cur = store.one("SELECT route FROM extraction_claim WHERE claim_id=? AND run_id=?",
                        (cid, run_id))
        if cur and cur["route"] == "accept":
            store.exec("UPDATE extraction_claim SET route='rlm' WHERE claim_id=?", (cid,))
            n += 1
    return n
