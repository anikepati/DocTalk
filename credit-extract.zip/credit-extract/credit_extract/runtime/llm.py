"""
Model providers.

`GeminiProvider` is the production path (Google ADK / LiteLLM naming). `SimulatedProvider`
answers from the document text with configurable noise so the whole pipeline can be run,
evaluated, and regression-tested without a model in the loop. It is a harness component,
not a model: it never appears in a release.
"""
from __future__ import annotations

import json
import os
import random
import re
from dataclasses import dataclass
from typing import Protocol

from ..probe.matchers import norm_date, norm_money, norm_percent


@dataclass
class LLMResponse:
    text: str
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0


class Provider(Protocol):
    name: str
    def complete(self, prompt: str, **kw) -> LLMResponse: ...


class GeminiProvider:
    """Production provider. Kept thin on purpose — the interesting logic is in the
    prompt artifact and the routing, not here."""

    def __init__(self, model: str = "gemini-2.5-flash", temperature: float = 0.0):
        self.name = model
        self.model = model
        self.temperature = temperature
        self._client = None

    def _lazy(self):
        if self._client is None:
            from google import genai                       # pragma: no cover
            self._client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
        return self._client

    def complete(self, prompt: str, **kw) -> LLMResponse:   # pragma: no cover
        c = self._lazy()
        r = c.models.generate_content(
            model=self.model, contents=prompt,
            config={"temperature": self.temperature,
                    "response_mime_type": "application/json"})
        u = getattr(r, "usage_metadata", None)
        return LLMResponse(
            text=r.text,
            input_tokens=getattr(u, "prompt_token_count", 0) or 0,
            output_tokens=getattr(u, "candidates_token_count", 0) or 0,
            cost_usd=_price(self.model, getattr(u, "prompt_token_count", 0) or 0,
                            getattr(u, "candidates_token_count", 0) or 0),
        )


PRICE = {"gemini-2.5-flash": (0.30 / 1e6, 2.50 / 1e6),
         "gemini-2.5-pro": (1.25 / 1e6, 10.0 / 1e6)}


def _price(model: str, tin: int, tout: int) -> float:
    pi, po = PRICE.get(model, (0.0, 0.0))
    return tin * pi + tout * po


class SimulatedProvider:
    """
    Deterministic stand-in. Reads the field contract out of the prompt, finds a
    plausible answer in the supplied evidence, and injects controlled error so the
    eval harness exercises every branch: wrong-span, normalization slips, and
    over-confident non-abstention.
    """

    name = "simulated"

    def __init__(self, seed: int = 11, error_rate: float = 0.12,
                 abstain_bias: float = 0.5):
        self.rng = random.Random(seed)
        self.error_rate = error_rate
        self.abstain_bias = abstain_bias

    def complete(self, prompt: str, **kw) -> LLMResponse:
        fid = _grab(prompt, r"field_id:\s+(\S+)")
        vtype = _grab(prompt, r"value_type:\s+(\S+)") or "string"
        ev = _between(prompt, "<document_evidence>", "</document_evidence>") or ""
        base_x = _between(prompt, "<base_agreement>", "</base_agreement>")
        amend_x = _between(prompt, '<amendments ordered_by="effective_date">', "</amendments>")
        if base_x is not None:
            cands = _candidates(amend_x or "", vtype) or _candidates(base_x, vtype)
            if not cands:
                return self._json({"field_id": fid, "value": None, "abstain": True,
                                   "confidence": 0.9,
                                   "reasoning": "No value located in the family."}, prompt, "")
            v, s0, e0 = cands[-1]        # last amendment in effect wins
            return self._json({"field_id": fid, "value": v,
                               "amendment_chain": [], "as_of_date": None,
                               "evidence_span": {"char_start": s0, "char_end": e0},
                               "confidence": round(self.rng.uniform(0.78, 0.97), 2),
                               "abstain": False,
                               "reasoning": "Walked the amendment chain in effective-date order."},
                              prompt, "")
        iv = _between(prompt, "<input_values>", "</input_values>")

        if iv:
            return self._derive(fid, iv, prompt)

        cands = _candidates(ev, vtype, prompt)
        if not cands:
            return self._json({"field_id": fid, "value": None, "abstain": True,
                               "confidence": round(self.rng.uniform(0.75, 0.95), 2),
                               "reasoning": "Required evidence absent from supplied text."},
                              prompt, ev)

        pick = cands[0]
        if self.rng.random() < self.error_rate and len(cands) > 1:
            pick = self.rng.choice(cands[1:])          # confusable-field style error

        val, start, end = pick
        if self.rng.random() < self.error_rate / 3 and vtype == "money":
            val = str(int(float(val) * 10))            # scale-word normalization slip

        return self._json({
            "field_id": fid, "value": val, "value_raw": ev[start:end],
            "evidence_span": {"char_start": start, "char_end": end,
                              "quote": ev[start:end][:80]},
            "confidence": round(self.rng.uniform(0.72, 0.99), 2), "abstain": False,
            "reasoning": "Located in the anchored section.",
        }, prompt, ev)

    def _derive(self, fid, iv, prompt):
        try:
            inputs = json.loads(iv)
        except json.JSONDecodeError:
            inputs = {}
        vals = [v for v in inputs.values() if isinstance(v, (int, float))]
        if not vals or any(v is None for v in inputs.values() if v == "__REQUIRED__"):
            return self._json({"field_id": fid, "value": None, "abstain": True,
                               "confidence": 0.99, "computation_steps": [],
                               "reasoning": "A non-optional input was null."}, prompt, "")
        total = sum(vals)
        steps = [f"{k} = {v}" for k, v in inputs.items() if isinstance(v, (int, float))]
        steps.append(f"sum = {total}")
        return self._json({"field_id": fid, "value": str(total), "computation_steps": steps,
                           "inputs_used": inputs, "contradicts_document": False,
                           "confidence": 0.99, "abstain": False,
                           "reasoning": "Applied the stated rule to the supplied inputs."},
                          prompt, "")

    def _json(self, obj, prompt, ev) -> LLMResponse:
        t = json.dumps(obj)
        tin, tout = len(prompt) // 4, len(t) // 4
        return LLMResponse(t, tin, tout, _price("gemini-2.5-flash", tin, tout))


def _grab(text: str, pat: str):
    m = re.search(pat, text)
    return m.group(1) if m else None


def _between(text: str, a: str, b: str):
    i, j = text.find(a), text.find(b)
    return text[i + len(a):j].strip() if i >= 0 and j > i else None


def _candidates(ev: str, vtype: str, prompt: str = "") -> list[tuple[str, int, int]]:
    out = []
    permitted = _between(prompt, "You must return one of the following, exactly as written, or abstain:",
                         "### PROCEDURE")
    if permitted:
        for line in permitted.splitlines():
            m = re.match(r"-\s+(\S+)\s+—", line.strip())
            if m and (loc := ev.find(m.group(1))) >= 0:
                out.append((m.group(1), loc, loc + len(m.group(1))))
        if out:
            return out
    if "row_count" in prompt or vtype == "list":
        rows = re.findall(r"^\s{4}([A-Z][A-Za-z&.,' \-]{4,40}?)\s{2,}\$([\d,]+)", ev, re.M)
        pairs = [f"{n.strip()}={norm_money('$' + a)}" for n, a in rows
                 if n.strip().lower() != "total"]
        if pairs:
            i = ev.find("Lender")
            return [("|".join(pairs), max(0, i), len(ev))]
        return []
    if vtype == "money":
        for m in re.finditer(r"\$\s?[\d,]+(?:\.\d+)?(?:\s*(?:million|billion))?", ev):
            v = norm_money(m.group(0))
            if v:
                out.append((str(v), m.start(), m.end()))
    elif vtype == "date":
        for m in re.finditer(r"\b\d{4}-\d{2}-\d{2}\b", ev):
            out.append((norm_date(m.group(0)), m.start(), m.end()))
    elif vtype == "percent":
        for m in re.finditer(r"\b\d+\.\d+\s*%", ev):
            out.append((f"{norm_percent(m.group(0)):.4f}", m.start(), m.end()))
    elif vtype == "boolean":
        cl = "Springing Financial Covenant" in ev or "no right to accelerate" in ev
        out.append((str(cl).lower(), 0, min(40, len(ev))))
    else:
        for m in re.finditer(r"\b([A-Z][A-Z&.,' \-]{6,60}(?:INC\.|LLC|CORP\.|N\.A\.|BANK|MEDIA|"
                             r"HOLDINGS, INC\.|GROUP LLC))", ev):
            out.append((m.group(1).strip(), m.start(), m.end()))
    return out
