"""
G.6 — runtime RLM escalation tier.

An exception path, not a default. Gated behind confidence and validator failure, and
budgeted: recursive decomposition can actively hurt when the evidence already fits a
window, so a field only stays on this tier if it demonstrably wins there.
"""
from __future__ import annotations

import json
import re

from ..mine.rlm import DocumentREPL
from ..runtime.llm import Provider
from ..store import Store

ESCALATION_PROMPT = """You are resolving one field from a credit agreement family that
the fast extraction path could not resolve confidently.

FIELD: {field_id}
DEFINITION: {definition}

REPL calls available: list_sections(), get_section("<substr>"), grep("<regex>"),
defined_term("<term>"), amendments().

Read only what you need. Then return JSON only:
{{"value": <value|null>, "abstain": <bool>, "confidence": <0..1>,
  "evidence_span": {{"char_start": <int>, "char_end": <int>}}, "reasoning": "<text>"}}
To call the REPL first, return {{"call": "<name>", "args": ["..."]}}.
"""


def escalate_claim(store: Store, provider: Provider, doc_id: str, field_id: str,
                   definition: str, max_steps: int = 6) -> dict | None:
    repl = DocumentREPL(store, doc_id)
    transcript = ""
    for _ in range(max_steps):
        raw = provider.complete(
            ESCALATION_PROMPT.format(field_id=field_id, definition=definition) + transcript).text
        try:
            obj = json.loads(re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M))
        except json.JSONDecodeError:
            return None
        if "call" in obj:
            fn = getattr(repl, obj["call"], None)
            res = fn(*obj.get("args", [])) if fn else ""
            transcript += f"\n\nCALL {obj['call']} ->\n{str(res)[:1200]}"
            continue
        obj["_repl_calls"] = repl.calls
        return obj
    return None


def run_escalation(store: Store, provider: Provider, run_id: str, specs: dict,
                   budget_pct: float = 0.05) -> dict:
    """
    Budget is enforced as a hard cap on the number of escalations per run, taken in
    confidence order so the worst claims are resolved first. Blowing the envelope on
    document 12,000 is not recoverable.
    """
    total = store.one("SELECT COUNT(*) c FROM extraction_claim WHERE run_id=?", (run_id,))["c"]
    cap = max(1, int(total * budget_pct))
    rows = store.q("""SELECT claim_id, doc_id, field_id, confidence FROM extraction_claim
                      WHERE run_id=? AND route='rlm' ORDER BY confidence ASC LIMIT ?""",
                   (run_id, cap))
    resolved = skipped = 0
    for r in rows:
        spec = specs.get(r["field_id"], {})
        obj = escalate_claim(store, provider, r["doc_id"], r["field_id"],
                             spec.get("definition", ""))
        if not obj:
            skipped += 1
            continue
        store.exec("""UPDATE extraction_claim
                      SET value_norm=?, confidence=?, abstain=?, route=?
                      WHERE claim_id=?""",
                   (None if obj.get("value") is None else str(obj["value"]),
                    float(obj.get("confidence") or 0.0), int(bool(obj.get("abstain"))),
                    "hitl" if obj.get("abstain") else "accept", r["claim_id"]))
        resolved += 1
    over = store.one("SELECT COUNT(*) c FROM extraction_claim WHERE run_id=? AND route='rlm'",
                     (run_id,))["c"]
    return {"eligible": total, "budget_cap": cap, "resolved": resolved,
            "skipped": skipped, "still_queued_over_budget": over,
            "budget_breached": over > 0}
