"""
Storage layer.

Runs on SQLite so the reference pipeline executes anywhere. Production target is
PostgreSQL — see migrations/001_postgres.sql. The only Postgres-specific machinery
not reproduced here is work-claiming (SELECT FOR UPDATE SKIP LOCKED) and LISTEN/NOTIFY;
everything else is portable SQL.
"""
from __future__ import annotations

import json
import pathlib
import sqlite3
from typing import Any, Iterable

DDL = """
CREATE TABLE IF NOT EXISTS document (
  doc_id TEXT PRIMARY KEY, family_id TEXT, doc_type TEXT,
  effective_date TEXT, seq INTEGER, sha256 TEXT, parser_version TEXT
);
CREATE TABLE IF NOT EXISTS document_text (
  doc_id TEXT PRIMARY KEY, full_text TEXT, char_len INTEGER
);
CREATE TABLE IF NOT EXISTS document_section (
  doc_id TEXT, section_id TEXT, heading TEXT, level INTEGER,
  char_start INTEGER, char_end INTEGER, PRIMARY KEY (doc_id, section_id)
);
CREATE INDEX IF NOT EXISTS ix_section_pos ON document_section(doc_id, char_start);
CREATE TABLE IF NOT EXISTS defined_term (
  doc_id TEXT, term TEXT, definition TEXT, char_start INTEGER, char_end INTEGER
);
CREATE TABLE IF NOT EXISTS ground_truth (
  doc_id TEXT, field_id TEXT, value_raw TEXT, value_norm TEXT,
  split TEXT, PRIMARY KEY (doc_id, field_id)
);
CREATE TABLE IF NOT EXISTS probe_hit (
  field_id TEXT, doc_id TEXT, match_type TEXT, section_id TEXT,
  char_start INTEGER, char_end INTEGER, score REAL
);
CREATE INDEX IF NOT EXISTS ix_probe_field ON probe_hit(field_id);
CREATE TABLE IF NOT EXISTS tier_assignment (
  field_id TEXT PRIMARY KEY, tier TEXT, archetype TEXT, value_type TEXT,
  hit_rate REAL, ambiguity REAL, section_entropy REAL,
  top_sections TEXT, rule_expr TEXT, rule_coverage REAL, notes TEXT
);
CREATE TABLE IF NOT EXISTS prompt_artifact (
  field_id TEXT, spec_version INTEGER, prompt_hash TEXT, template_id TEXT,
  prompt_text TEXT, PRIMARY KEY (field_id, spec_version)
);
CREATE TABLE IF NOT EXISTS extraction_run (
  run_id TEXT PRIMARY KEY, release_id TEXT, split TEXT, model TEXT,
  started_at TEXT, calls INTEGER, cost_usd REAL
);
CREATE TABLE IF NOT EXISTS extraction_claim (
  claim_id TEXT PRIMARY KEY, run_id TEXT, doc_id TEXT, field_id TEXT,
  value_raw TEXT, value_norm TEXT, confidence REAL, abstain INTEGER,
  evidence_start INTEGER, evidence_end INTEGER, section_id TEXT,
  route TEXT, rule_fired INTEGER, raw_response TEXT
);
CREATE INDEX IF NOT EXISTS ix_claim_run ON extraction_claim(run_id, field_id);
CREATE TABLE IF NOT EXISTS validator_result (
  claim_id TEXT, validator_id TEXT, passed INTEGER, detail TEXT
);
CREATE TABLE IF NOT EXISTS derived_value (
  run_id TEXT, doc_id TEXT, field_id TEXT, value_norm TEXT, steps TEXT,
  inputs TEXT, stated_in_document TEXT, contradicts INTEGER, abstain INTEGER,
  PRIMARY KEY (run_id, doc_id, field_id)
);
CREATE TABLE IF NOT EXISTS eval_result (
  run_id TEXT, field_id TEXT, split TEXT, n INTEGER, norm_exact REAL,
  list_f1 REAL, evidence_iou REAL, abstain_rate REAL, abstain_precision REAL,
  error_profile TEXT, PRIMARY KEY (run_id, field_id)
);
CREATE TABLE IF NOT EXISTS residual_span (
  doc_id TEXT, char_start INTEGER, char_end INTEGER, section_id TEXT,
  salience REAL, signature TEXT
);
CREATE TABLE IF NOT EXISTS discovery_candidate (
  candidate_id TEXT PRIMARY KEY, kind TEXT, signature TEXT, frequency INTEGER,
  leverage REAL, exemplars TEXT, compile_target TEXT, status TEXT
);
"""


class Store:
    def __init__(self, path: str = "corpus.db"):
        pathlib.Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(DDL)

    def q(self, sql: str, args: Iterable = ()) -> list[sqlite3.Row]:
        return self.db.execute(sql, tuple(args)).fetchall()

    def one(self, sql: str, args: Iterable = ()):
        r = self.db.execute(sql, tuple(args)).fetchone()
        return r

    def write(self, sql: str, rows: list[tuple]):
        self.db.executemany(sql, rows)
        self.db.commit()

    def exec(self, sql: str, args: Iterable = ()):
        self.db.execute(sql, tuple(args))
        self.db.commit()

    @staticmethod
    def j(v: Any) -> str:
        return json.dumps(v, default=str)
