"""
Stage E.3 / H.1 — per-field evaluation and error taxonomy.

Never report an aggregate as the headline: the aggregate hides the tail, and the tail
is the entire job.
"""
from __future__ import annotations

from collections import Counter, defaultdict

from ..probe.matchers import norm_date, norm_money, norm_percent
from ..store import Store

GATE = {"norm_exact": 0.90, "evidence_iou": 0.50}


def canon(v, vtype: str):
    if v is None:
        return None
    s = str(v).strip()
    if vtype == "money":
        return norm_money(s)
    if vtype == "date":
        return norm_date(s)
    if vtype == "percent":
        return norm_percent(s)
    if vtype == "boolean":
        return s.lower() in ("true", "1", "yes")
    if vtype == "list":
        return tuple(sorted(p.strip() for p in s.split("|") if p.strip()))
    return s.casefold()


def _iou1(a, b) -> float:
    if not a or not b or a[0] is None or b[0] is None:
        return 0.0
    inter = max(0, min(a[1], b[1]) - max(a[0], b[0]))
    union = max(a[1], b[1]) - min(a[0], b[0])
    return inter / union if union else 0.0


def iou(a, golds) -> float:
    """Best overlap across all gold spans. A field can legitimately appear in several
    places; citing any of them is correct."""
    if golds and isinstance(golds[0], (list, tuple)):
        return max((_iou1(a, g) for g in golds), default=0.0)
    return _iou1(a, golds)


def classify_error(pred, gold, pred_span, gold_span, vtype: str) -> str:
    """
    H.1 — four error classes, four different fixes. Running GEPA on a retrieval
    failure burns budget and improves nothing, which is why this runs first.
    """
    if pred is None:
        return "abstained"
    if canon(pred, vtype) == canon(gold, vtype):
        return "correct"
    ov = iou(pred_span, gold_span)
    if ov == 0.0:
        return "retrieval"          # wrong section entirely -> fix anchors
    if ov > 0.5:
        return "normalization"      # right span, wrong value -> fix the rule
    return "prompt"                 # right section, wrong span -> GEPA territory


def evaluate(store: Store, run_id: str, split: str, types: dict) -> dict:
    gold = defaultdict(dict)
    for r in store.q("SELECT doc_id, field_id, value_norm FROM ground_truth WHERE split=?", (split,)):
        gold[r["field_id"]][r["doc_id"]] = r["value_norm"]

    gold_spans = defaultdict(dict)
    for r in store.q("SELECT field_id, doc_id, char_start, char_end FROM probe_hit"):
        gold_spans[r["field_id"]].setdefault(r["doc_id"], []).append(
            (r["char_start"], r["char_end"]))

    pred = defaultdict(dict)
    for r in store.q("""SELECT doc_id, field_id, value_norm, abstain, evidence_start, evidence_end
                        FROM extraction_claim WHERE run_id=?""", (run_id,)):
        pred[r["field_id"]][r["doc_id"]] = (
            None if r["abstain"] else r["value_norm"],
            (r["evidence_start"], r["evidence_end"]))
    for r in store.q("SELECT doc_id, field_id, value_norm, abstain FROM derived_value WHERE run_id=?",
                     (run_id,)):
        pred[r["field_id"]][r["doc_id"]] = (None if r["abstain"] else r["value_norm"], (None, None))

    out, rows = {}, []
    for fid, gmap in gold.items():
        if fid not in pred:
            continue
        vtype = types.get(fid, "string")
        n = correct = abstained = abstain_ok = 0
        ious, profile = [], Counter()
        for doc_id, gval in gmap.items():
            if doc_id not in pred[fid]:
                continue
            n += 1
            pval, pspan = pred[fid][doc_id]
            gspan = gold_spans.get(fid, {}).get(doc_id)
            cls = classify_error(pval, gval, pspan, gspan, vtype)
            profile[cls] += 1
            if cls == "correct":
                correct += 1
            if pval is None:
                abstained += 1
                abstain_ok += int(gspan is None)
            elif gspan:
                ious.append(iou(pspan, gspan))
        if not n:
            continue
        out[fid] = {
            "n": n,
            "norm_exact": round(correct / n, 4),
            "evidence_iou": round(sum(ious) / len(ious), 4) if ious else 0.0,
            "abstain_rate": round(abstained / n, 4),
            "abstain_precision": round(abstain_ok / abstained, 4) if abstained else 1.0,
            "errors": dict(profile),
            "gate": correct / n >= GATE["norm_exact"],
        }
        rows.append((run_id, fid, split, n, out[fid]["norm_exact"], None,
                     out[fid]["evidence_iou"], out[fid]["abstain_rate"],
                     out[fid]["abstain_precision"], Store.j(dict(profile))))
    store.write("INSERT OR REPLACE INTO eval_result VALUES (?,?,?,?,?,?,?,?,?,?)", rows)
    return out


def gate_report(results: dict) -> dict:
    passing = [f for f, r in results.items() if r["gate"]]
    failing = sorted(((f, r) for f, r in results.items() if not r["gate"]),
                     key=lambda kv: kv[1]["norm_exact"])
    dominant = {f: max(r["errors"], key=lambda k: r["errors"][k] if k != "correct" else -1)
                for f, r in failing}
    return {"passing": passing, "failing": [f for f, _ in failing],
            "dominant_error": dominant}
