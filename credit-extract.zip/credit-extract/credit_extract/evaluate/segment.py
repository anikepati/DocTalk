"""
E.4 / H.2 — segmented evaluation and label auditing.

A field at 92% overall is routinely at 40% on amended families. The aggregate hides
exactly the population you most need to know about.
"""
from __future__ import annotations

from collections import defaultdict

from .harness import canon
from ..store import Store

SEGMENTS = {
    "amendment_depth": lambda d: "amended" if d["amend_count"] > 0 else "clean",
    "vintage": lambda d: (d["effective_date"] or "")[:4] or "unknown",
    "doc_type": lambda d: d["doc_type"],
}


def _doc_meta(store: Store) -> dict:
    counts = {r["family_id"]: r["n"] - 1 for r in store.q(
        "SELECT family_id, COUNT(*) n FROM document GROUP BY family_id")}
    out = {}
    for r in store.q("SELECT doc_id, family_id, doc_type, effective_date FROM document"):
        out[r["doc_id"]] = {"doc_type": r["doc_type"], "effective_date": r["effective_date"],
                            "amend_count": counts.get(r["family_id"], 0)}
    return out


def segment_eval(store: Store, run_id: str, split: str, types: dict,
                 by: str = "amendment_depth") -> dict:
    meta = _doc_meta(store)
    keyfn = SEGMENTS[by]
    gold = defaultdict(dict)
    for r in store.q("SELECT doc_id, field_id, value_norm FROM ground_truth WHERE split=?",
                     (split,)):
        gold[r["field_id"]][r["doc_id"]] = r["value_norm"]

    pred = defaultdict(dict)
    for r in store.q("""SELECT doc_id, field_id, value_norm, abstain FROM extraction_claim
                        WHERE run_id=?""", (run_id,)):
        pred[r["field_id"]][r["doc_id"]] = None if r["abstain"] else r["value_norm"]
    for r in store.q("SELECT doc_id, field_id, value_norm, abstain FROM derived_value "
                     "WHERE run_id=?", (run_id,)):
        pred[r["field_id"]][r["doc_id"]] = None if r["abstain"] else r["value_norm"]

    agg = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    for fid, gmap in gold.items():
        vt = types.get(fid, "string")
        for doc_id, gval in gmap.items():
            if doc_id not in pred.get(fid, {}) or doc_id not in meta:
                continue
            seg = keyfn(meta[doc_id])
            agg[fid][seg][1] += 1
            agg[fid][seg][0] += int(canon(pred[fid][doc_id], vt) == canon(gval, vt))

    out = {}
    for fid, segs in agg.items():
        row = {s: {"n": n, "acc": round(c / n, 3)} for s, (c, n) in segs.items() if n}
        if len(row) > 1:
            accs = [v["acc"] for v in row.values()]
            row["_spread"] = round(max(accs) - min(accs), 3)
        out[fid] = row
    return out


def label_audit_sample(store: Store, run_id: str, field_id: str, split: str,
                       types: dict, n: int = 20) -> list[dict]:
    """
    H.2 — with 200 fields some ground truth is wrong. A field stuck at 80% frequently
    has 10% bad labels. Sample disagreements and adjudicate BEFORE spending a single
    optimization cycle on the field.
    """
    vt = types.get(field_id, "string")
    gold = {r["doc_id"]: r["value_norm"] for r in store.q(
        "SELECT doc_id, value_norm FROM ground_truth WHERE field_id=? AND split=?",
        (field_id, split))}
    rows = store.q("""SELECT doc_id, value_norm, abstain, confidence, evidence_start, evidence_end
                      FROM extraction_claim WHERE run_id=? AND field_id=?""", (run_id, field_id))
    out = []
    for r in rows:
        g = gold.get(r["doc_id"])
        p = None if r["abstain"] else r["value_norm"]
        if g is None or canon(p, vt) == canon(g, vt):
            continue
        snippet = ""
        if r["evidence_start"] is not None:
            t = store.one("SELECT full_text FROM document_text WHERE doc_id=?",
                          (r["doc_id"],))["full_text"]
            snippet = t[max(0, r["evidence_start"] - 80):(r["evidence_end"] or 0) + 80]
        out.append({"doc_id": r["doc_id"], "gold": g, "predicted": p,
                    "confidence": r["confidence"], "evidence": snippet.replace("\n", " ")[:220]})
        if len(out) >= n:
            break
    return out
