-- Production DDL. The reference pipeline runs on SQLite (credit_extract/store.py);
-- this is the deployment target. Differences that matter: JSONB, real work-claiming,
-- and LISTEN/NOTIFY wake-up.

CREATE TABLE document (
  doc_id TEXT PRIMARY KEY, family_id TEXT, doc_type TEXT,
  effective_date DATE, seq INT, sha256 TEXT, parser_version TEXT,
  parsed_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX ix_doc_family ON document(family_id, seq);

CREATE TABLE document_text (doc_id TEXT PRIMARY KEY REFERENCES document, full_text TEXT, char_len INT);

CREATE TABLE document_section (
  doc_id TEXT REFERENCES document, section_id TEXT, heading TEXT, level INT,
  char_start INT, char_end INT, page_from INT, page_to INT,
  PRIMARY KEY (doc_id, section_id)
);
CREATE INDEX ix_section_pos ON document_section(doc_id, char_start);

CREATE TABLE defined_term (
  doc_id TEXT REFERENCES document, term TEXT, definition TEXT,
  char_start INT, char_end INT
);
CREATE INDEX ix_term ON defined_term(doc_id, term);

CREATE TABLE ground_truth (
  doc_id TEXT REFERENCES document, field_id TEXT, value_raw TEXT, value_norm TEXT,
  provenance_span INT4RANGE, split TEXT CHECK (split IN ('train','dev','test')),
  PRIMARY KEY (doc_id, field_id)
);

CREATE TABLE entity_spec (
  field_id TEXT, version INT, tier TEXT, archetype TEXT, yaml_body TEXT,
  status TEXT, created_at TIMESTAMPTZ DEFAULT now(), PRIMARY KEY (field_id, version)
);
CREATE TABLE spec_release (
  release_id TEXT PRIMARY KEY, created_at TIMESTAMPTZ DEFAULT now(),
  pinned JSONB NOT NULL, signed_by TEXT
);
CREATE TABLE prompt_artifact (
  field_id TEXT, spec_version INT, prompt_hash TEXT, template_id TEXT, prompt_text TEXT,
  PRIMARY KEY (field_id, spec_version),
  FOREIGN KEY (field_id, spec_version) REFERENCES entity_spec(field_id, version)
);

CREATE TABLE extraction_run (
  run_id TEXT PRIMARY KEY, release_id TEXT REFERENCES spec_release, split TEXT,
  model TEXT, started_at TIMESTAMPTZ, calls INT, cost_usd NUMERIC(12,4)
);

CREATE TABLE extraction_claim (
  claim_id TEXT PRIMARY KEY, run_id TEXT REFERENCES extraction_run,
  doc_id TEXT REFERENCES document, field_id TEXT,
  value_raw TEXT, value_norm TEXT, confidence REAL, abstain BOOLEAN,
  evidence_start INT, evidence_end INT, section_id TEXT,
  route TEXT CHECK (route IN ('accept','validate','rlm','hitl')),
  rule_fired INT, raw_response JSONB
);
CREATE INDEX ix_claim_run_field ON extraction_claim(run_id, field_id);
CREATE INDEX ix_claim_route ON extraction_claim(run_id, route) WHERE route <> 'accept';

CREATE TABLE derived_value (
  run_id TEXT, doc_id TEXT, field_id TEXT, value_norm TEXT,
  steps JSONB, inputs JSONB, stated_in_document TEXT,
  contradicts BOOLEAN, abstain BOOLEAN, PRIMARY KEY (run_id, doc_id, field_id)
);
CREATE INDEX ix_contradiction ON derived_value(run_id) WHERE contradicts;

CREATE TABLE eval_result (
  run_id TEXT, field_id TEXT, split TEXT, n INT, norm_exact REAL, list_f1 REAL,
  evidence_iou REAL, abstain_rate REAL, abstain_precision REAL,
  error_profile JSONB, PRIMARY KEY (run_id, field_id)
);

CREATE TABLE residual_span (
  doc_id TEXT, char_start INT, char_end INT, section_id TEXT,
  salience REAL, signature TEXT
);
CREATE INDEX ix_residual_sig ON residual_span(signature);

CREATE TABLE discovery_candidate (
  candidate_id TEXT PRIMARY KEY, kind TEXT, signature TEXT, frequency INT,
  leverage REAL, exemplars JSONB,
  compile_target TEXT CHECK (compile_target IN
    ('new_entity_spec','validator_rule','decision_branch','human_only')),
  status TEXT DEFAULT 'pending'
);

-- Work queue. Idempotent on (doc_id, release_id): a re-run of a crashed worker
-- must not duplicate claims.
CREATE TABLE work_item (
  doc_id TEXT, release_id TEXT, state TEXT DEFAULT 'pending',
  attempts INT DEFAULT 0, claimed_at TIMESTAMPTZ, PRIMARY KEY (doc_id, release_id)
);

-- Claim a batch without two workers colliding.
-- SELECT * FROM work_item WHERE state='pending'
--   ORDER BY doc_id FOR UPDATE SKIP LOCKED LIMIT 32;

CREATE OR REPLACE FUNCTION notify_work() RETURNS trigger AS $$
BEGIN PERFORM pg_notify('work_ready', NEW.release_id); RETURN NEW; END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_work AFTER INSERT ON work_item
  FOR EACH ROW EXECUTE FUNCTION notify_work();
