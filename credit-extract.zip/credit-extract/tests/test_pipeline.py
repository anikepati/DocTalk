"""Regression tests. Every one of these encodes a bug that actually occurred."""
from __future__ import annotations

import pathlib
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

from credit_extract.demo.make_corpus import generate
from credit_extract.derive.dag import eval_expr, toposort
from credit_extract.evaluate.harness import canon, classify_error, iou
from credit_extract.ingest.pipeline import (extract_defined_terms, load_ground_truth,
                                            make_splits, parse_and_load, segment_sections,
                                            verify_offsets, verify_split_integrity)
from credit_extract.probe.matchers import find_spans, infer_type, norm_date, norm_money, norm_percent
from credit_extract.probe.probe import induce_rules, run_probe
from credit_extract.runtime.planner import estimate_cost, plan_bundles
from credit_extract.runtime.validators import REGISTRY, parse_call, v_equals_sum
from credit_extract.store import Store


@pytest.fixture(scope="module")
def db(tmp_path_factory):
    store = Store(str(tmp_path_factory.mktemp("db") / "t.db"))
    docs = generate(30, seed=3)
    parse_and_load(store, docs)
    segment_sections(store)
    extract_defined_terms(store)
    load_ground_truth(store, docs, make_splits(docs, seed=3))
    return store, docs


# ---------------------------------------------------------------- normalization

def test_money_scale_words():
    assert norm_money("$75 million") == 75_000_000
    assert norm_money("$1,250,000") == 1_250_000
    assert norm_money("($500,000)") == -500_000


def test_percent_and_bps():
    assert norm_percent("2.50%") == 0.025
    assert norm_percent("250 bps") == 0.025


def test_date_formats():
    assert norm_date("2023-03-14") == norm_date("March 14, 2023") == "2023-03-14"


def test_type_inference_separates_percent_from_money():
    assert infer_type(["0.0225", "0.0250"]) == "percent"
    assert infer_type(["75000000", "125000000"]) == "money"


# ---------------------------------------------------------------- corpus foundation

def test_offsets_round_trip(db):
    """BUG: a parser that loses offsets makes every evidence span and IoU meaningless."""
    store, docs = db
    assert verify_offsets(store, docs) == 0


def test_split_integrity_no_family_straddles(db):
    """BUG: an amendment in dev with its base in train leaks the answer."""
    store, _ = db
    assert verify_split_integrity(store) == 0


def test_article_section_contains_its_subsections(db):
    """BUG: ARTICLE II ended at Section 2.01, so every article anchor resolved to a
    24-character window."""
    store, _ = db
    doc_id = store.q("SELECT doc_id FROM document LIMIT 1")[0]["doc_id"]
    art = store.one("""SELECT char_start, char_end FROM document_section
                       WHERE doc_id=? AND heading='ARTICLE II'""", (doc_id,))
    assert art["char_end"] - art["char_start"] > 400


def test_defined_terms_extracted(db):
    store, _ = db
    n = store.one("SELECT COUNT(*) c FROM defined_term")["c"]
    assert n > 100


# ---------------------------------------------------------------- probe

def test_probe_finds_all_hits_not_just_first():
    text = "commitment of $75,000,000 ... aggregate of $75,000,000 in total"
    hits = find_spans(text, "75000000", "money")
    assert len(hits) == 2


def test_rule_induction_recovers_the_sum(db):
    """The whole T3 argument depends on this working."""
    store, _ = db
    run_probe(store, split=None)
    rules = induce_rules(store, "train", min_coverage=0.98)
    assert "total_facility_size" in rules
    r = rules["total_facility_size"]
    assert r["coverage"] >= 0.98
    assert set(r["inputs"]) == {"revolving_commitment_total", "term_loan_a_principal"}


# ---------------------------------------------------------------- derivative DAG

def test_folded_yaml_expression_evaluates():
    """BUG: a YAML `>` scalar yields `a + b\\n + c`; a top-level newline outside parens
    is a SyntaxError, so every derived value silently came back null."""
    expr = "revolving + coalesce(tla, 0)\n                    + coalesce(tlb, 0)\n"
    assert eval_expr(expr, {"revolving": 100, "tla": 50, "tlb": None}) == 150


def test_coalesce_absent_is_not_zero_valued():
    assert eval_expr("coalesce(a, 0) + coalesce(b, 0)", {"a": 10, "b": None}) == 10


def test_expression_grammar_is_whitelisted():
    assert eval_expr("__import__('os').system('id')", {}) is None


def test_toposort_detects_cycles():
    _, errs = toposort({"a": ["b"], "b": ["a"]})
    assert errs and "cycle" in errs[0]


def test_toposort_orders_dependencies_first():
    order, errs = toposort({"total": ["rev", "tla"], "rev": [], "tla": []})
    assert not errs
    assert order.index("rev") < order.index("total")


# ---------------------------------------------------------------- eval harness

def test_iou_scores_against_all_gold_spans():
    """BUG: scoring against only the first gold span marked a correct extraction of the
    second occurrence as a retrieval miss, sending good fields to the wrong optimizer."""
    assert iou((100, 110), [(0, 10), (100, 110)]) == 1.0


def test_error_taxonomy_separates_retrieval_from_normalization():
    assert classify_error("5", "10", (500, 510), [(0, 10)], "money") == "retrieval"
    assert classify_error("5", "10", (0, 10), [(0, 10)], "money") == "normalization"
    assert classify_error("10", "10", (0, 10), [(0, 10)], "money") == "correct"
    assert classify_error(None, "10", None, [(0, 10)], "money") == "abstained"


def test_canon_compares_across_surface_forms():
    assert canon("$75 million", "money") == canon("75000000", "money")


# ---------------------------------------------------------------- validators

def test_validator_registry_parses_arguments():
    assert parse_call("equals_sum(lender_commitments)") == ("equals_sum", ["lender_commitments"])
    assert parse_call("nonneg") == ("nonneg", [])
    assert "deterministic_recompute_match" in REGISTRY


def test_equals_sum_reconciles_a_schedule():
    ctx = {"claims": {"rows": "A=100|B=200|C=300"}}
    ok, _ = v_equals_sum("600", ["rows"], ctx)
    assert ok
    bad, _ = v_equals_sum("650", ["rows"], ctx)
    assert not bad


# ---------------------------------------------------------------- planner

def test_bundling_never_groups_confusable_fields():
    """BUG class: cross-contamination inside one call is the dominant bundling failure."""
    specs = {
        "a": {"archetype": "span_extract", "retrieval": {"section_anchors": ["Article II"]},
              "disambiguation": {"confusable_with": ["b"]}},
        "b": {"archetype": "span_extract", "retrieval": {"section_anchors": ["Article II"]}},
    }
    bundles = plan_bundles(specs)
    for bd in bundles:
        assert not ("a" in bd.field_ids and "b" in bd.field_ids)


def test_bundling_excludes_derivative_tiers():
    specs = {"d": {"archetype": "derive_deterministic", "retrieval": {"section_anchors": ["x"]}}}
    assert plan_bundles(specs) == []


def test_cost_estimate_shows_bundling_reduction():
    specs = {f"f{i}": {"archetype": "span_extract",
                       "retrieval": {"section_anchors": [f"Article {i % 8}"]}}
             for i in range(200)}
    est = estimate_cost(specs, 20_000, plan_bundles(specs))
    assert est["bundled_calls"] < est["naive_calls"]
    assert est["call_reduction"] > 0.5
