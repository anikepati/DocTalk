# File Index

91 files. Everything below is in the zip.

## Read these first

| File | What it is |
|---|---|
| `docs/GUIDE.md` | **Start here.** How to run every part + the logic behind each stage, with real run output |
| `docs/PROCESS_FLOW.md` | 10 mermaid diagrams: system flow, tier decision, extraction sequence, DAG, spec lifecycle, GEPA loop, discovery, ER model, OCP topology, cost shape |
| `RUNBOOK.md` | Operational step-by-step, Parts A–K, with checkpoints and verification queries |
| `entity-prompt-compiler-implementation.md` | Architecture and rationale |
| `README.md` | Orientation and quick start |

## Code — 34 modules, ~3,700 lines

| Module | Part | Responsibility |
|---|---|---|
| `credit_extract/store.py` | — | SQLite reference store, 15 tables |
| `credit_extract/cli.py` | all | Driver; one subcommand per RUNBOOK part |
| `credit_extract/demo/make_corpus.py` | — | Synthetic corpus + ground truth so the pipeline runs with no API key |
| `credit_extract/ingest/pipeline.py` | A | Parse with offsets, families, section tree, defined terms, family-level splits |
| `credit_extract/probe/matchers.py` | B | Matcher cascade, type inference, money/date/percent normalization |
| `credit_extract/probe/probe.py` | B | Probe, diagnostics, rule induction, tier classification, confusables, few-shot harvest |
| `credit_extract/probe/draft_specs.py` | C | Auto-draft specs from probe output |
| `credit_extract/compile/compiler.py` | D | spec → prompt, 7 archetypes, lint, DAG check |
| `credit_extract/runtime/llm.py` | E | GeminiProvider + deterministic simulator |
| `credit_extract/runtime/agents.py` | E | Retrieval ladder, agent factory, routing, extraction |
| `credit_extract/runtime/planner.py` | E.1 | Bundling with confusable guardrail, cost estimation, scale projection |
| `credit_extract/runtime/validators.py` | E.5 | 14 validators, argument parsing, failure demotion |
| `credit_extract/runtime/escalation.py` | G.6 | Budgeted RLM tier with hard cap and breach reporting |
| `credit_extract/derive/dag.py` | F | Toposort, cycle detection, whitelisted expression eval, contradictions |
| `credit_extract/evaluate/harness.py` | E.3/H.1 | Per-field metrics, IoU, 4-class error taxonomy |
| `credit_extract/evaluate/segment.py` | E.4/H.2 | Segmented eval, label-noise audit |
| `credit_extract/mine/rlm.py` | G | DocumentREPL, derivation mining, canonicalization, recipe validation |
| `credit_extract/optimize/gepa.py` | H | Spec mutation proposals, Pareto selection |
| `credit_extract/optimize/driver.py` | H | Ralph loop: recompile, re-eval, accept or stop |
| `credit_extract/release/manager.py` | I | Cut, sign, gate, regression, open test split once |
| `credit_extract/discovery/residuals.py` | J | Residual masking, salience, clustering, leverage |
| `credit_extract/discovery/adjudication.py` | J.4–J.6 | Board, deviation scan, promote to spec |

## Prompt templates — 8

`templates/_base.j2` plus seven archetypes: `A1_span_extract`, `A2_enum_classify`,
`A3_table_extract`, `A4_normalize_extract`, `A5_derive_deterministic`,
`A6_rule_apply`, `A7_crossref_resolve`.

## Entity specs — 13 (one per field, one per tier represented)

`administrative_agent_name`, `applicable_margin_current` (T5), `borrower_legal_name`
(T0), `closing_date`, `facility_currency` (enum), `has_term_loan_tranche` (T4),
`is_covenant_lite` (T4), `lc_sublimit`, `lender_commitments` (T2),
`maturity_date_revolving`, `revolving_commitment_total` (T1),
`term_loan_a_principal`, `total_facility_size` (T3).

## Generated output — 15 compiled prompts + manifest

`prompts/<field_id>.v<N>.txt` and `prompts/manifest.json` (hashes, lint, DAG errors).
Two fields carry a second version written by the GEPA driver — that is the optimizer
loop's real output, not a stray file.

**These are build artifacts.** `make compile` regenerates them; CI regenerates them.
Never hand-edit one.

## Supporting

- `few_shots/*.yaml` — 13 harvested few-shot sets, diversity-selected, abstention cases included
- `migrations/001_postgres.sql` — production DDL, incl. `SELECT FOR UPDATE SKIP LOCKED` and `LISTEN/NOTIFY`
- `tests/test_pipeline.py` — 23 regression tests, each encoding a bug that actually occurred
- `Makefile`, `requirements.txt`

## Verify after unzipping

```bash
pip install -r requirements.txt && pip install pytest
make test     # 23 passed
make run      # full pipeline, ~20s, no API key
```
