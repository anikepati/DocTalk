# RUNBOOK — Entity Prompt Compiler for Credit Agreement Extraction

Operational, step-by-step. Every step states what you run, what it produces, how you
verify it, and when you are allowed to move on. Do not skip a checkpoint — each one
exists because failing it silently corrupts everything downstream.

Companion documents:
- `entity-prompt-compiler-implementation.md` — architecture and rationale
- `prompt_compiler/` — working compiler, 7 archetypes, example specs

**Scope:** 20,000 credit agreements, 200 ground-truth fields.

---

## PART 0 — Setup

### 0.1 Repository layout

```
credit-extract/
├── ingest/            parser, section segmenter, defined-term extractor
├── probe/             grounding probe + rule induction
├── specs/             200 entity spec YAMLs (the only hand-edited surface)
├── few_shots/         auto-harvested, one file per field
├── templates/         7 archetype templates
├── prompts/           GENERATED — never edit, never commit manually
├── agents/            ADK agent factory + runtime
├── derive/            deterministic DAG executor + rule implementations
├── eval/              harness, metrics, gates
├── optimize/          Ralph+GEPA driver
├── discovery/         residual, deviation, contradiction miners
├── migrations/        Postgres DDL
└── compiler.py
```

Add to CI:
```
python compiler.py --specs specs/ --out prompts/   # must exit 0
pytest eval/tests
```
A non-zero compiler exit blocks the merge. `prompts/` is build output — regenerate it
in CI, never trust a committed copy.

### 0.2 Database

```bash
psql -f migrations/001_corpus.sql
psql -f migrations/002_specs.sql
psql -f migrations/003_runtime.sql
psql -f migrations/004_discovery.sql
```

**Checkpoint 0:** all tables exist, `document_text.full_text` is `TEXT` not `VARCHAR`,
and `document_section` has a composite index on `(doc_id, char_start)`.

---

## PART A — Corpus Foundation (Week 1)

### A.1 Parse with offset preservation

```bash
python ingest/parse.py --input s3://corpus/raw/ --workers 32
```

For each document write `document`, `document_text`, and a `char → (page, bbox)` map.

**Verification — run this before anything else:**
```sql
-- offset round-trip: a random span must re-extract identically
SELECT doc_id FROM document_text
WHERE substr(full_text, 1000, 50) IS DISTINCT FROM
      (SELECT reparse_span(doc_id, 1000, 50));
```
Expect zero rows. Add this as a CI test on every parser change.

**Checkpoint A.1:** 100% of 20,000 documents parsed; offset round-trip passes;
`parser_version` recorded on every row. Character offsets are load-bearing for the
probe, evidence spans, IoU scoring, and adjudication provenance. If they drift, every
later stage produces confident nonsense.

### A.2 Build document families

```bash
python ingest/families.py
```

Link base agreements to amendments and amended-and-restated versions. Match on
borrower name + facility identifiers + agent, then order by `effective_date`.

**Verification:**
```sql
SELECT count(*) FROM document
WHERE doc_type IN ('amendment','restatement') AND family_id IS NULL;
```

**Checkpoint A.2:** fewer than 2% unlinked amendments, and **manually audit 50
families end to end**. Wrong family linkage makes every T5 field silently wrong with
high confidence — the worst failure mode in the system, because nothing downstream
detects it.

### A.3 Segment sections

```bash
python ingest/sections.py --workers 32
```

Credit agreements are highly regular. Article/Section numbering plus heading detection
plus the table of contents gets you most of the way. Store a tree with char ranges.

**Verification:**
```sql
SELECT doc_id, count(*) AS n FROM document_section
GROUP BY doc_id HAVING count(*) < 20 OR count(*) > 800;
```
Outliers are usually parse failures, not unusual agreements.

**Checkpoint A.3:** ≥95% of documents have a recognizable "Definitions" article and at
least one Schedule. Sample 20 documents and eyeball the section tree.

### A.4 Extract defined terms

```bash
python ingest/defined_terms.py
```

Section 1.01 gives you term → definition → span per document. This is the single most
reusable asset in the corpus and is required for T5 cross-reference resolution.

**Checkpoint A.4:** median defined-term count per document is between 150 and 600.
Below 50 means the definitions article is not being segmented correctly.

### A.5 Load ground truth and freeze splits

```bash
python ingest/load_gt.py --file gt.csv
python ingest/make_splits.py --train 0.5 --dev 0.25 --test 0.25 --seed 20260903
```

**Split at family level, never document level.** An amendment in dev with its base
agreement in train leaks the answer.

```sql
-- must return zero rows
SELECT family_id FROM ground_truth g JOIN document d USING (doc_id)
GROUP BY family_id HAVING count(DISTINCT g.split) > 1;
```

**Checkpoint A.5:** splits frozen, hashed, and committed. Test split is sealed — no
one looks at it until release gates in Part I.

---

## PART B — Grounding Probe & Tier Classification (Week 2)

This is the highest-leverage step in the project and it uses no LLM at all.

### B.1 Run the probe

```bash
python probe/run.py --sample 500 --split train --workers 16
```

For each of the 200 fields, run the matcher cascade over labeled documents: exact,
normalized, numeric-with-scale, multi-format date, fuzzy (token-set ≥ 0.90), enum
synonym. Record **every** match with `section_id` and char span, not just the first.

### B.2 Produce the diagnostic report

```bash
python probe/report.py --out probe_report.html
```

Per field:
- `literal_hit_rate` — fraction of labeled docs where the value appears in text
- `ambiguity` — mean candidate spans per document
- `section_entropy` — how concentrated the true span is
- page-position distribution

### B.3 Induce rules for the misses

```bash
python probe/induce.py --min-coverage 0.98
```

For low-hit-rate fields, search a bounded operator set to reproduce the value from
other GT fields: identity/aliasing, sum/difference/ratio/min/max, date offsets, enum
mapping, threshold bucketing, simple conditionals.

**Validate any candidate expression across all labeled documents, not the sample it
was induced from.** An expression that fits 20 documents and fails at 60% corpus-wide
is worse than no rule, because it looks authoritative.

### B.4 Assign tiers

```bash
python probe/classify.py --out tier_assignment.csv
```

| Tier | Test | Archetype |
|---|---|---|
| T0 | hit ≥ 0.85, low ambiguity | `span_extract` / `enum_classify` |
| T1 | high hit only after normalization | `normalize_extract` |
| T2 | list or table, multi-span | `table_extract` |
| T3 | induced rule coverage ≥ 0.98 | `derive_deterministic` |
| T4 | needs reasoning over text | `rule_apply` |
| T5 | needs family/amendment walk | `crossref_resolve` |

### B.5 Human review of the classification

Sit down with a credit analyst and review all 200 rows. Budget half a day.

**Checkpoint B:** every field has a tier and an archetype; 20 fields spot-checked
across tiers; expected distribution roughly 60% T0–T2, 25% T3, 15% T4–T5. A
misclassified field wastes an entire optimization cycle later — this review is cheap
insurance.

**Also produced here, for free:** section anchors for T0–T2, and the few-shot span
library. Do not re-derive these by hand.

---

## PART C — Authoring 200 Specs (Weeks 3–4)

### C.1 Auto-draft specs from the probe

```bash
python probe/draft_specs.py --out specs/ --tier-file tier_assignment.csv
```

The probe already knows the section anchors, the value type, the surface forms, and
the confusable siblings. Generate a first-draft YAML for all 200 fields. You are
editing drafts, not writing from scratch.

### C.2 Generate the disambiguation blocks

```bash
python probe/confusables.py --overlap-threshold 0.3
```

Two fields whose true spans co-occur in the same section are the pair the model will
confuse. This computes those pairs from probe data and fills `confusable_with`. **You
still write the `discriminator` sentence by hand** — that one sentence is the highest-
value text in the entire prompt and it cannot be generated.

### C.3 Harvest few-shots

```bash
python probe/harvest_shots.py --k 3 --out few_shots/
```

Select for **diversity**, never the first k matches: different sections, different
surface forms, and one hard case.

**Mandatory:** at least one abstention example per field. Without one, models
essentially never abstain, and across 20K documents a non-abstaining extractor
produces confident wrong values instead of routable gaps. Enforce it as a lint rule.

### C.4 Human pass over T3/T4 specs

T3 `derivation.statement` and T4 `decision_procedure` cannot be auto-drafted reliably.
Sit with a credit analyst and write them. For T4, decompose the judgment into
**numbered conditions evaluated in order** — the model reports which one fired, which
is what makes the determination adjudicable at the rule level rather than one instance
at a time.

**Checkpoint C:** 200 specs exist, all `status: active` fields have a discriminator
sentence, every field has ≥1 abstention shot.

---

## PART D — Compile (Day 1 of Week 4)

```bash
python compiler.py --specs specs/ --templates templates/ \
                   --few-shots few_shots/ --out prompts/
```

Fix every lint failure and every DAG error before proceeding:
- archetype permitted for the declared tier
- abstain path present in the contract
- derivative fields declare `depends_on`; `rule_apply` declares a procedure
- known normalization rule
- no field confusable with itself
- prompt within token budget
- **dependency DAG acyclic, no unknown fields**

```bash
python eval/load_manifest.py --manifest prompts/manifest.json
```

**Checkpoint D:** compiler exits 0; 200 prompts in `prompt_artifact` with hashes bound
to spec versions. From this point on, nobody edits a prompt. Ever. The moment someone
hand-edits a compiled prompt, the registry stops being the source of truth and you are
back to 200 unmaintainable strings.

---

## PART E — Dev-Set Extraction & First Eval (Week 4–5)

### E.1 Build the retrieval plan

```bash
python agents/plan.py --release dev-001
```

Resolve each field's section anchors to concrete char windows per document. For fields
whose anchors miss, fall back to defined-term trace, then to whole-document.

### E.2 Run extraction on dev only

```bash
python agents/run.py --release dev-001 --split dev --model gemini-2.5-flash
```

One `LlmAgent` per prompt, instantiated by the agent factory from the release.
`ParallelAgent` fan-out. Every output is a **claim**: value, evidence span, confidence,
section, route.

Do **not** run on all 20K yet.

### E.3 Run the eval harness

```bash
python eval/run.py --release dev-001 --split dev --out eval_dev_001.html
```

Per field: exact, normalized-exact, list P/R/F1, **evidence-span IoU**, abstain rate,
abstain precision.

**Never report an aggregate as the headline.** The aggregate hides the tail, and the
tail is the entire job.

### E.4 Segment the results

```bash
python eval/segment.py --by vintage,lender,facility_type,amendment_depth
```

A field at 92% overall is routinely at 40% on amended families. Find that before you
spend optimization budget.

**Checkpoint E:** per-field dev numbers exist for all T0–T2 fields. Expect a wide
spread — that is normal and is the point.

---

## PART F — Derivative DAG (Week 5–6)

### F.1 Implement T3 rules in code

```bash
python derive/build_dag.py --specs specs/   # cycle check at compile time
python derive/run.py --release dev-001 --split dev
```

Each T3 rule gets a deterministic Python/SQL implementation matching its `expr`.

### F.2 Run T3 prompts alongside

The T3 prompt receives `input_values_json` and is told explicitly not to read the
document. It produces `computation_steps` and `reasoning` — the audit trail. The code
path produces the guarantee. The `deterministic_recompute_match` validator asserts they
agree.

### F.3 Wire contradiction events

When a derived value disagrees with a value the document states directly, emit a
contradiction event. This is a free, high-precision signal — route it to Part J.

**Checkpoint F:** T3 fields at ≥99% on dev (they are arithmetic; anything less means a
broken input field, not a broken rule). Zero DAG cycles. Contradiction events flowing.

---

## PART G — RLM Derivation Mining (Weeks 7–9)

Design-time only. This is where the T4/T5 specs get authored properly.

### G.1 Stand up the RLM harness

```bash
python mine/rlm_harness.py --root-model gemini-2.5-pro --sub-model gemini-2.5-flash
```

The document family, section tree, and defined-terms dict load as REPL variables. The
root model slices, searches, and recursively sub-queries rather than trying to attend
over the whole family at once.

### G.2 Invert the task

```bash
python mine/derive.py --fields T4,T5 --samples 20
```

Supply the **known correct GT value** and ask for the derivation, not the answer:
which sections, which defined terms, which amendment supersedes which, what rule
converts evidence to value.

### G.3 Cluster and canonicalize

```bash
python mine/cluster.py --out derivation_recipes/
```

A field with one dominant derivation shape is specifiable. A field with five shapes
should be **split into sub-fields** or routed to `human_only`. Do not force a single
recipe onto a field that does not have one.

### G.4 Validate recipes cheaply

```bash
python mine/validate_recipes.py --split train
```

Re-execute each recipe as a cheap plan against the remaining labeled documents and
measure coverage.

### G.5 Fold recipes into specs, recompile

Update `decision_procedure`, `edge_cases`, `section_anchors`. Recompile.

**Checkpoint G:** every T4/T5 field has a written recipe with a measured coverage
number, or an explicit `human_only` marking. Cost here is bounded — ~20 documents per
field for ~40 fields, amortized across 20,000 documents.

### G.6 Configure the runtime RLM escalation tier

```bash
python agents/escalation.py --enable --budget-pct 5
```

Runtime RLM is an **exception path**, not a default. Gate it behind confidence and
validator failure. Measure it per field against plain section routing and keep it only
where it demonstrably wins — recursive decomposition can hurt when the evidence
already fits comfortably in a window.

---

## PART H — Optimization (Weeks 10–11)

### H.1 Classify errors BEFORE optimizing

```bash
python eval/error_taxonomy.py --release dev-001 --out errors.csv
```

| Error class | Symptom | Fix |
|---|---|---|
| Retrieval | wrong section entirely | fix `section_anchors` |
| Prompt | right section, wrong span | GEPA territory |
| Normalization | right span, wrong value | fix the normalization rule |
| Label | genuinely ambiguous | adjudicate the ground truth |

Running GEPA on a retrieval failure burns budget and improves nothing. This step is
not optional.

### H.2 Audit label noise on stuck fields

```bash
python eval/label_audit.py --field <id> --n 20
```

With 200 fields, some ground truth is wrong. A field stuck at 80% frequently has 10%
bad labels. Adjudicate 20 disagreements per stuck field before spending a single
optimization cycle.

### H.3 Run Ralph+GEPA on the failing tail

```bash
python optimize/run.py --fields "$(cat below_gate.txt)" --k 4 --rounds 8
```

**Mutate the spec, not the prompt.** GEPA operates on section anchors, few-shot
selection, disambiguation set, normalization rule, and archetype choice. The prompt
recompiles from the mutated spec. K=4 candidates in parallel, dev minibatch
evaluation, Pareto-tracked across fields so a gain on one cannot silently regress
another.

### H.4 Stop conditions

Gate met, or N rounds with no improvement → escalate the field to the RLM tier or mark
`human_only`. **Fields do not optimize forever.**

**Checkpoint H:** ≥90% of fields at gate on dev. Remaining fields have an explicit
disposition: RLM tier, human-only, or deferred with a reason.

---

## PART I — Release & Full-Corpus Run (Week 12)

### I.1 Cut the release

```bash
python release/cut.py --id rel-2026-001 --sign
```

Pins spec versions, prompt hashes, model IDs, validator versions, bundle plan.
Immutable.

### I.2 Open the test split — once

```bash
python eval/run.py --release rel-2026-001 --split test
```

This is the first and only time you look at test. If the numbers diverge materially
from dev, you have overfit to dev and must re-split rather than tune further.

### I.3 Regression suite

```bash
python eval/regression.py --baseline rel-2026-000 --candidate rel-2026-001
```

Any drop on a previously-passing field blocks the release.

### I.4 Full-corpus run

```bash
python agents/run.py --release rel-2026-001 --split all --workers 64 --checkpoint
```

Checkpointed, idempotent on `(doc_id, release_id)`, work claimed via
`SELECT FOR UPDATE SKIP LOCKED`, wake-up via `LISTEN/NOTIFY`.

**Do not reach this step until dev gates pass.** A full run at 60% accuracy generates
20,000 × 200 items of rework and destroys reviewer trust in the system permanently.

**Cost check before launching:**
```bash
python agents/estimate_cost.py --release rel-2026-001 --docs 20000
```
Confirm the escalation-rate budget holds at scale. Runtime RLM cost creep is the most
common way this blows its envelope.

**Checkpoint I:** full corpus extracted; per-field accuracy, cost, escalation rate,
and abstain rate recorded per field.

---

## PART J — Discovery Loop (Week 13+)

These candidates have no ground truth by construction, so they cannot go through the
eval harness. They go to human adjudication.

### J.1 Residual coverage

```bash
python discovery/residuals.py --release rel-2026-001
```

Mark every span consumed by an accepted claim. Everything unmarked is residual.

### J.2 Salience filter

Keep residuals with high defined-term density, monetary amounts, obligation language
("shall", "may not", "provided that"), or located in high-value sections (Negative
Covenants, Events of Default, Mandatory Prepayments).

### J.3 Cluster corpus-wide

```bash
python discovery/cluster.py --min-cluster-size 25
```

A residual pattern in 4,000 agreements is a missing field. One in 3 agreements is a
bespoke term worth flagging but not schematizing.

### J.4 Deviation detection

```bash
python discovery/deviation.py --by section_type
```

Build the clause-type distribution per section type; flag outliers. The rare bespoke
carve-out is precisely what nobody wrote a field for and precisely what carries risk.

### J.5 Score and route

```bash
python discovery/score.py   # leverage = frequency × business proximity × novelty
python discovery/route.py --to adjudication_board
```

Compile targets:
- `new_entity_spec` → becomes a YAML spec, re-enters Part C
- `validator_rule` → hardens an existing field
- `decision_branch` → deterministic rule promotion
- `human_only` → permanently manual

### J.6 Close the loop

Adjudication produces labels. Labels accumulate. Once a discovered field has enough,
it earns an eval gate of its own and rejoins the normal cycle.

---

## PART K — Steady State

### K.1 Monitor per field

| Signal | Reads as |
|---|---|
| accuracy trend | model or corpus drift |
| abstain rate rising | incoming document mix changed |
| escalation rate rising | anchors going stale |
| validator failure rate | upstream field degrading |
| cost per field | RLM tier creeping |

Alarm on rate-of-change, not absolute level. A stable field whose abstain rate doubles
is telling you the corpus changed, not that the model got worse.

### K.2 Adding a field (the whole point)

1. Write `specs/new_field.yaml`
2. `python compiler.py` — lint and DAG must pass
3. Label ~200 documents for it
4. Eval on dev; iterate the spec if below gate
5. Cut a release

Zero code change. Zero deploy.

### K.3 Changing a field

Never edit a spec version in place. Create `version + 1`, recompile, eval, and let the
regression suite confirm nothing else moved.

---

## Failure Modes Worth Memorizing

| Failure | Where it bites | Guard |
|---|---|---|
| Offsets lost in parsing | Everything downstream | Round-trip test in CI (A.1) |
| Amendment linkage wrong | T5 wrong with high confidence, undetected | Manual audit of 50 families (A.2) |
| Split leakage across families | Dev numbers lie; test confirms too late | Family-level split assertion (A.5) |
| Rule induced on the sample only | Authoritative-looking wrong rule | Validate corpus-wide (B.3) |
| No abstention few-shot | Confident wrong values instead of gaps | Lint rule (C.3) |
| Hand-edited prompt | Registry stops being source of truth | `prompts/` regenerated in CI (D) |
| Optimizing wording when retrieval is broken | Budget burned, no gain | Error taxonomy first (H.1) |
| Label noise read as model error | Unfixable fields optimized forever | Label audit on stuck fields (H.2) |
| Full run before gates pass | 4M items of rework, trust destroyed | Hard sequencing (I.4) |
| Runtime RLM cost creep | Envelope blown at 20K scale | Escalation budget + alarm (G.6) |
