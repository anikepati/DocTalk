# GUIDE — Running the System and How It Works

Everything here is verified against the code in this repository. Every command below
was executed; every output block is real.

---

# PART 1 — RUNNING IT

## 1.1 Install

```bash
cd credit-extract
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt        # jinja2, pyyaml
pip install pytest                     # tests only
```

Python 3.10+. No API key and no database server are needed for the default path: the
reference store is SQLite and the default model provider is a deterministic simulator.

## 1.2 Verify before you run

```bash
make test
```

```
23 passed in 1.85s
```

Each test encodes a bug that actually occurred during development. If any fail, do not
trust a pipeline run.

## 1.3 Run everything

```bash
make run                                    # = cli all --families 80
python -m credit_extract.cli all --families 60 --seed 7
```

Takes about 20 seconds for 60 families. Produces `build/corpus.db` and
`prompts/*.txt`.

## 1.4 Run one part at a time

State lives in SQLite, so parts compose. Run them in order the first time.

| Command | RUNBOOK part | Needs |
|---|---|---|
| `make ingest` | A — parse, sections, terms, splits | nothing |
| `make probe` | B — probe, induction, tiering | A |
| `make specs` | C — draft specs, harvest few-shots | B |
| `make compile` | D — compile prompts, lint, DAG | C |
| `make extract` | E/F — extract, validate, escalate, derive | D |
| `make eval` | E.3/H.1 — metrics, segments, taxonomy | E |
| `make mine` | G — RLM derivation mining | B |
| `make optimize` | H — Ralph+GEPA | E.3 |
| `make release` | I — gates, regression, test split | E.3 |
| `make discover` | J — residuals, board, promotion | E |

Common flags on every subcommand:

```
--db build/corpus.db      SQLite path
--families 80             synthetic families to generate (ingest only)
--provider simulated      or: gemini
--model gemini-2.5-flash
--error-rate 0.12         simulator error injection
--rlm-budget 0.05         escalation cap as a fraction of claims
--k 4 --rounds 2          GEPA candidates and rounds
--optimize-n 2            how many failing fields to optimize
--seed 7
```

## 1.5 Against real documents and real models

Three swaps, in this order:

**Documents.** Replace `credit_extract/demo/make_corpus.py` with a loader that yields
objects carrying `doc_id, family_id, doc_type, effective_date, seq, text, gt`. The only
hard requirement is that `text` preserves character offsets from your parser — write a
`char → (page, bbox)` map alongside it. Everything downstream indexes into `full_text`.

**Model.**

```bash
export GOOGLE_API_KEY=...
python -m credit_extract.cli all --provider gemini --model gemini-2.5-flash
```

`GeminiProvider` in `runtime/llm.py` is the only place that talks to a model.

**Database.**

```bash
psql -f migrations/001_postgres.sql
```

Then swap `store.Store` for a psycopg-backed class with the same four methods
(`q`, `one`, `write`, `exec`). The Postgres DDL adds what SQLite cannot do: work
claiming via `SELECT FOR UPDATE SKIP LOCKED`, and `LISTEN/NOTIFY` wake-up.

## 1.6 Inspecting results

```bash
sqlite3 build/corpus.db
```

```sql
-- per-field accuracy, worst first
SELECT field_id, n, norm_exact, evidence_iou, abstain_rate
FROM eval_result ORDER BY norm_exact;

-- where claims went
SELECT route, COUNT(*) FROM extraction_claim GROUP BY route;

-- validator failures with detail
SELECT v.validator_id, COUNT(*), MIN(v.detail)
FROM validator_result v WHERE v.passed = 0 GROUP BY v.validator_id;

-- derived values that disagree with the document
SELECT doc_id, field_id, value_norm, stated_in_document
FROM derived_value WHERE contradicts = 1;

-- discovery queue
SELECT candidate_id, frequency, leverage, compile_target
FROM discovery_candidate ORDER BY leverage DESC;
```

## 1.7 CI

```bash
make ci      # compile + test
```

`compile` exits non-zero on any lint failure or DAG error, which blocks the merge.
`prompts/` is build output and is regenerated in CI — never trust a committed copy.

---

# PART 2 — WHAT EACH STAGE ACTUALLY DOES

## 2.1 PART A — corpus foundation (`ingest/pipeline.py`)

Four operations, one non-negotiable invariant.

**Sections.** `SECTION_RE` finds `ARTICLE n`, `SCHEDULE x`, `EXHIBIT x`, `RECITALS`,
and `Section n.nn.` Two levels: a level-1 heading runs to the **next level-1 marker**,
so `ARTICLE II` contains Sections 2.01–2.03; a level-2 heading runs to the next marker
of any kind.

> This was a bug. Originally every section ended at the next marker regardless of
> level, so `ARTICLE II` was 24 characters long and every article anchor resolved to an
> empty window. `test_article_section_contains_its_subsections` guards it.

**Defined terms.** `"([A-Z][\w ...]{2,60})"\s+means\s+(...)` over the definitions
article. 360 terms across 79 documents in the sample run. Required for cross-reference
resolution in T5.

**Families.** Base agreement plus amendments, ordered by `effective_date`. Wrong
linkage makes every T5 field wrong *with high confidence* and nothing downstream
detects it.

**Splits at family level.** `verify_split_integrity` returns the count of families
whose documents landed in more than one split; the pipeline asserts zero. An amendment
in dev whose base agreement is in train leaks the answer, and the leak is invisible
until test day.

**The invariant.** `verify_offsets` re-reads a stored span and compares it to source.
Probe hits, evidence spans, IoU scoring, residual masking and adjudication provenance
are all character offsets into `full_text`. If they drift, the pipeline produces
confident nonsense rather than errors.

## 2.2 PART B — grounding probe (`probe/matchers.py`, `probe/probe.py`)

The highest-leverage stage, and there is no model in it.

**Matcher cascade.** For each field and each labeled document: exact match, then
type-specific normalized matching (money with scale words and parenthesis-negatives;
dates across five formats; percent including basis points), then fuzzy at ≥0.90 for
long strings. **Every** hit is recorded, overlaps de-duplicated keeping the strongest.

Recording all hits is the point: the *count* is what tells you a field is ambiguous
rather than merely hard. `revolving_commitment_total` shows ambiguity 3.0 — three
plausible money spans per document — which is why it needs a discriminator, not a
better instruction.

**Diagnostics.** Per field: `hit_rate` (fraction of documents where the value appears
at all), `ambiguity` (mean candidates per document), `section_entropy` (Shannon entropy
over the sections containing true spans — low entropy means a strong anchor).

**Rule induction.** For fields the probe cannot locate, search a bounded operator set
to reproduce the value from *other* ground-truth fields: identity/aliasing, then sums
over 2- and 3-field subsets. `coalesce(x, 0)` treats an absent optional component as
contributing nothing — deliberately different from a component present with value zero.

Presence threshold for candidate inputs is 25%, not 50%. An optional component present
in a minority of documents — a term tranche half the deals do not have — is exactly the
interesting case, and a 50% threshold excludes it.

Every candidate expression is validated on **all** labeled documents, never only the
sample it was induced from. A rule that fits 20 documents and fails corpus-wide is
worse than no rule because it looks authoritative.

Real output:

```
B.3 induced deterministic rules: 1
      total_facility_size = coalesce(revolving_commitment_total, 0)
                          + coalesce(term_loan_a_principal, 0)   coverage=1.0
```

**Tier assignment.** Deterministic, from the diagnostics:

```
administrative_agent_name   T0_PRIMITIVE_SPAN               hit 1.00  amb 3.0
revolving_commitment_total  T1_PRIMITIVE_NORMALIZED         hit 1.00  amb 3.0
lender_commitments          T2_PRIMITIVE_AGGREGATE          hit 0.00  amb 0.0
total_facility_size         T3_DERIVATIVE_DETERMINISTIC     hit 0.50  amb 3.0
is_covenant_lite            T4_DERIVATIVE_JUDGMENT          hit 0.00  amb 0.0
applicable_margin_current   T5_CROSS_DOC                    hit 0.73  amb 1.0
```

Read the zeros. `lender_commitments` and `is_covenant_lite` have hit rate 0.00 — the
value is *never* in the text as written — which is precisely the signal that routes
them away from span extraction. `total_facility_size` at 0.50 is arithmetic, caught by
induction, and gets no extraction prompt at all.

**Also produced for free:** section anchors (from `top_sections`), confusable pairs
(Jaccard overlap of the section sets two fields' true spans land in), and the few-shot
span library.

## 2.3 PART C — spec authoring (`probe/draft_specs.py`)

Auto-drafts a YAML spec per field from probe output: tier, archetype, value type,
section anchors, normalization rule, enum domain from observed GT values, and the
confusable list. You edit drafts; you do not write 200 specs from scratch.

Two things are deliberately left as `TODO` for a human:

- the **discriminator sentence** — one sentence saying what distinguishes this field
  from the fields it co-occurs with. It cannot be generated and it is the
  highest-value text in the whole prompt.
- T3 `derivation.statement` and T4 `decision_procedure`.

`write_drafts` never overwrites an existing file. Human edits survive re-runs.

**Few-shot harvesting** selects for *diversity* — different sections, different match
types — never the first k matches, plus at least one **abstention** example pulled from
a document where the probe found nothing. Without an abstention example models
effectively never abstain, and across 20K documents that means confident wrong values
instead of routable gaps.

## 2.4 PART D — the compiler (`compile/compiler.py`)

`spec + archetype template → prompt`. Seven archetypes:

| ID | Archetype | Built around |
|---|---|---|
| A1 | `span_extract` | verbatim span, candidate-preference ordering |
| A2 | `enum_classify` | closed domain, ordered criteria, no invented categories |
| A3 | `table_extract` | row schema, completeness, reconcile without forcing |
| A4 | `normalize_extract` | verbatim + explicit normalization, no guessed units |
| A5 | `derive_deterministic` | inputs injected; document explicitly not read |
| A6 | `rule_apply` | numbered conditions in order; reports `rule_fired` |
| A7 | `crossref_resolve` | amendment walk, running value, as-of dating |

Every prompt: role → definition → where to look → procedure → **what this field is
NOT** → normalization → edge cases → few-shots → abstention rule → strict JSON
contract → input slot.

**Compile-time lint** blocks the merge on: archetype not permitted for the tier;
missing abstain path; derivative field without `depends_on`; `rule_apply` without a
decision procedure; unknown normalization rule; **unknown validator name**; field
confusable with itself; prompt over budget; and a cycle or unknown field in the
dependency DAG.

> The unknown-validator check exists because a real spec said `sum_equals(...)` while
> the registry defines `equals_sum(...)`. It parsed fine, ran nothing, and reported
> nothing. A check that silently never runs is worse than no check.

> A second real bug: `validators: [in_range(0, 0.15), ...]` in flow-style YAML splits
> on the comma into `in_range(0` and `0.15)`. Any validator call with arguments must be
> written in block style and quoted.

## 2.5 PART E/F — runtime (`runtime/`, `derive/`)

**Retrieval** (`agents.resolve_evidence`) resolves anchors to a char window via a
fallback ladder: anchor heading match → defined-term trace → whole document. Which rung
fired is itself a diagnostic — a field that keeps falling through to whole-document has
stale anchors, and that is a *retrieval* fix, not a prompt fix.

Returns the window's base offset, and claim spans are converted to document-absolute
before storage.

> This was a bug. Models return offsets into the evidence you handed them; probe spans
> are absolute. Every IoU scored 0.00, and the error taxonomy then blamed *retrieval*
> for everything, sending correct fields to the wrong optimizer. The pipeline looked
> like it was working. `test_iou_scores_against_all_gold_spans` and the base-offset
> conversion guard it.

**Bundling** (`planner.plan_bundles`) groups fields sharing a primary anchor, with two
guardrails: never co-bundle fields declared confusable, and never bundle derivative
tiers. Bundling is a runtime packing decision only — the per-entity prompt stays the
canonical unit for versioning, eval and optimization.

Be honest about the payoff. The reduction depends entirely on how many fields share
anchors:

```
E.1 11 bundles, 1.2 fields/bundle
    projected 200 fields x 20K docs: 4,000,000 naive -> 3,380,000 bundled (16%)
```

13 demo fields spread across 11 distinct anchors cannot bundle. With 200 real fields
concentrated in ~25 sections you would see 8 fields per bundle and roughly 88%. Measure
it on your own specs rather than assuming either number.

**Routing** by confidence against the spec's policy: `accept` / `validate` / `rlm` /
`hitl`. Abstention is a first-class outcome routed to HITL, not a failure.

**Validators** (`runtime/validators.py`) — 14 checks with argument parsing.
`equals_sum` reconciles a stated total against the rows composing it, catching both a
bad total and a truncated table. `deterministic_recompute_match` asserts the T3 prompt
and the T3 code agree. `demote_failures` reroutes any *accepted* claim that failed a
validator to escalation — accepting a claim that fails its own reconciliation is how
bad numbers reach a regulator.

```
E.5 validators: 180 checks, 39 failures, 10 accepted claims demoted to escalation
```

**Derivative DAG** (`derive/dag.py`) — toposort with cycle detection at compile time,
whitelisted arithmetic grammar, and contradiction events when a derived value disagrees
with a directly stated one.

> Third bug: a YAML `>` folded scalar yields `a + coalesce(b,0)\n + coalesce(c,0)`. A
> top-level newline outside parentheses is a `SyntaxError`, so every derived value
> silently came back null. `eval_expr` now collapses whitespace first;
> `test_folded_yaml_expression_evaluates` guards it.

**Escalation** (`runtime/escalation.py`) — budgeted RLM tier. Hard cap of
`budget_pct × claims` per run, taken in ascending confidence order so the worst claims
resolve first, and a `budget_breached` flag when the queue exceeds the cap. Blowing the
envelope on document 12,000 of 20,000 is not recoverable.

## 2.6 PART E.3/H.1 — evaluation (`evaluate/`)

Per field: normalized-exact accuracy, evidence-span IoU, abstain rate, abstain
precision, and a four-class error profile. Never an aggregate headline — the aggregate
hides the tail, and the tail is the job.

**The error taxonomy is the load-bearing part.** Four classes, four different fixes:

| Class | Symptom | Fix |
|---|---|---|
| `retrieval` | IoU 0 — wrong section entirely | anchors |
| `prompt` | IoU 0–0.5 — right section, wrong span | GEPA |
| `normalization` | IoU > 0.5 — right span, wrong value | normalization rule |
| `abstained` | no value returned | anchors or few-shots |

Running GEPA on a retrieval failure burns budget and improves nothing.

IoU scores against **every** known gold span, not the first. A field can legitimately
appear in several places; citing any of them is correct.

**Segmentation** (`evaluate/segment.py`) splits accuracy by amendment depth, vintage,
or document type. From the run:

```
E.4 fields with >15pt spread across amended vs clean families: 5
      facility_currency   {'amended': 1.0, 'clean': 0.7}
      total_facility_size {'amended': 0.0, 'clean': 0.2}
```

**Label audit** samples disagreements for a stuck field. With 200 fields some ground
truth is wrong; a field stuck at 80% frequently has 10% bad labels. Adjudicate before
spending an optimization cycle:

```
H.2 label audit sample for lc_sublimit
      gold='25000000'  pred=None        conf=0.91
      gold='12000000'  pred='120000000' conf=0.74
```

The second row is a scale error at high confidence — a normalization bug, not a
retrieval one.

## 2.7 PART G — RLM mining (`mine/rlm.py`)

Design time only. The root model does not receive the document; it receives a
`DocumentREPL` over the family — `list_sections`, `get_section`, `grep`,
`defined_term`, `amendments` — and decides what to read.

**The inversion is the point.** We already know the answer; we ask for the
**derivation**. The loop runs up to `MAX_STEPS`, and the model either returns a REPL
call (executed, appended to the transcript) or a recipe.

`canonicalize` clusters recipes by shape. Agreement below 0.6 means the field should be
**split into sub-fields or routed to `human_only`** — do not force one recipe onto a
field that does not have one. `fold_into_spec` writes the result into spec fields;
nothing here ever edits a prompt.

`validate_recipes` measures anchor coverage corpus-wide, and it earns its keep:

```
G.2 applicable_margin_current  kind=rule  agreement=1.0 -> specifiable
G.4 applicable_margin_current  anchor_coverage=0.0
```

Agreement 1.0 with coverage 0.0 is the check catching a recipe that looks unanimous on
its sample and does not generalize. Under the simulated provider that unanimity is an
artifact; against a real model the same guard applies.

Cost is bounded: ~20 documents per field for ~40 fields, amortized across 20,000.

## 2.8 PART H — optimization (`optimize/`)

`gepa.propose` maps the dominant error class to a mutation family — retrieval errors
get anchor mutations, prompt errors get few-shot and discriminator mutations,
normalization errors get rule mutations. **It mutates the spec, never the prompt text.**

`driver.optimize_field` is the Ralph loop around it. Per round: propose K candidates,
compile each (a candidate that fails lint is discarded, not patched), run extraction,
evaluate, and accept only a candidate that improves the target **without regressing any
other field**. A win writes `version + 1` to the YAML with compiler defaults stripped,
so the file shows what a human wrote. Two stagnant rounds and the field is dispositioned
to `escalate_rlm` or `human_only`. Fields do not optimize forever.

## 2.9 PART I — release (`release/manager.py`)

`cut_release` pins spec versions, prompt hashes, archetypes, validator sets and model
ID into an immutable signed digest. `gate_check` requires accuracy **and** IoU —
right-answer-wrong-reason passes accuracy alone and breaks on the next vintage.
`regression` blocks on any drop beyond tolerance against the baseline run.

`open_test_split` runs once. If test diverges from dev beyond tolerance the verdict is
`RESPLIT — dev overfit`, because tuning against a divergence you just measured is how
the test split stops being a test split.

```
I   pass rate 15% — release BLOCKED
I.2 test split NOT opened — gates must pass first
```

The block is the system working. Auto-drafted specs still carry `TODO` definitions, so
they should not reach 20,000 documents.

## 2.10 PART J — discovery (`discovery/`)

`compute_residuals` masks every span consumed by an accepted claim and keeps the gaps.
Salience weights obligation language (`shall`, `may not`, `provided that`), monetary
amounts, and high-value section types (Negative Covenants, Events of Default,
Mandatory Prepayments).

`cluster_candidates` fingerprints residuals structurally and frequency-sorts.
Leverage = coverage × salience, damped above 90% coverage because something in every
document is usually boilerplate. Compile target follows coverage: >0.5 →
`new_entity_spec`, >0.1 → `validator_rule`, else `human_only`.

`deviation_scan` is the complement: clause shapes that are **rare within their own
section type**. The bespoke carve-out is what nobody wrote a field for and what carries
risk; frequency-sorting alone would bury it.

`build_board` presents leverage-sorted clusters with `retires_items` — how many
documents one adjudication decision settles. `promote_to_spec` writes a real YAML with
`status: shadow`: it runs and is advisory, but has no gate until labels accumulate.

```
J.5 cand-4316c48edd17  freq=45  coverage=0.57  leverage=0.399  -> new_entity_spec (retires 45 items)
J.6 promoted -> discovered_field_001.yaml (status: shadow, no gate until labeled)
```

---

# PART 3 — SPEC REFERENCE

```yaml
field_id: revolving_commitment_total     # unique, snake_case
version: 3                               # immutable; a change is version+1
display_name: Total Revolving Commitment
tier: T1_PRIMITIVE_NORMALIZED            # T0..T5
archetype: normalize_extract             # must be permitted for the tier
value_type: money                        # string|money|date|percent|boolean|list
cardinality: one                         # one|many
status: active                           # active|shadow|human_only

definition: |                            # goes verbatim into the prompt
  The aggregate revolving credit commitment of all lenders as of the closing date.

retrieval:
  section_anchors: ["Article II, Section 2.01", "Schedule 1.01(a), total row"]
  strategy: section_anchor               # section_anchor|family_walk|multi_section
  window_tokens: 6000
  defined_term: null                     # resolve through this term if anchors miss
  absence_is_evidence: false             # rule_apply only

normalization: money_usd_scale           # money_usd_scale|iso_date|percent_decimal|
                                         # boolean|entity_name_verbatim

disambiguation:
  confusable_with: [total_facility_size, term_loan_a_principal, lc_sublimit]
  discriminator: >                       # HUMAN-WRITTEN. Highest-value line here.
    Revolving commitment only. Sublimits sit INSIDE this number, not in addition.

depends_on:                              # T3/T4 only
  - {field_id: revolving_commitment_total, value_type: money, role: component, optional: false}
derivation:                              # T3 only
  statement: |
    Sum the revolving commitment and every term tranche. A null optional tranche is
    absent, not zero.
  expr: revolving_commitment_total + coalesce(term_loan_a_principal, 0)
  preconditions: all components share the facility currency

decision_procedure:                      # T4 only; evaluated IN ORDER
  - condition: "no financial covenant article exists"
    outcome: "value = true"
    evidence_required: "cite the article numbering gap"
decision_default: "value = false"

row_schema:                              # T2 only
  - {name: lender_name, type: string, description: legal name as printed}

domain:                                  # enum_classify only
  - {value: USD, criterion: the agreement designates USD}

validators:                              # BLOCK STYLE. Quote any call with arguments.
  - nonneg
  - "currency_matches(facility_currency)"

edge_cases: ["If stated only as a schedule sum with no total row, abstain."]
few_shot_source: grounding_probe         # or: none
few_shot_k: 3
evidence: required                       # required|not_applicable
confidence_policy: {auto_accept: 0.92, validate: 0.75, escalate_rlm: 0.60}
business_weight: high
```

---

# PART 4 — ADDING AND CHANGING FIELDS

**Add a field.** Write `specs/new_field.yaml` → `make compile` (lint and DAG must pass)
→ label ~200 documents → `make eval` → iterate the spec if below gate → cut a release.
Zero code change, zero deploy.

**Change a field.** Never edit a version in place. Create `version + 1`, recompile,
evaluate, and let the regression suite confirm nothing else moved.

**Add a validator.** Define `v_<name>(val, args, ctx)` in `runtime/validators.py`; it
auto-registers. `ctx` carries `claims` (the document's other claims), `derived`,
`rule_fired`, and `full_text`.

**Add an archetype.** Write `templates/A8_<name>.j2` extending `_base.j2`, register it
in `ARCHETYPE_TEMPLATE` and `TIER_ARCHETYPES`, and add its output shape to
`build_contract`.

---

# PART 5 — WHAT THE SAMPLE RUN ACTUALLY SHOWS

```
gate: 2 passing / 11 failing
```

Low, and correctly so. The specs are auto-drafted with `TODO` definitions and no
human discriminators, and the default provider is a deterministic simulator, not a
model. What the run demonstrates is that every mechanism fires and every guard holds:

- rule induction recovers the sum at coverage 1.0 and routes that field to code
- hit-rate 0.00 fields are routed away from span extraction
- 10 accepted claims are demoted by validators
- the escalation budget is enforced and reports its own breach
- recipe validation catches unanimous-but-non-generalizing derivations
- the release gate blocks and refuses to open the test split
- the discovery loop finds a residual pattern in 57% of documents and promotes it

To see real accuracy, supply real specs with human discriminators and run
`--provider gemini`.
