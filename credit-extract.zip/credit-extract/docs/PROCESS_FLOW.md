# End-to-End Process Flow

20,000 credit agreements · 200 ground-truth fields · one prompt per entity.

---

## 1. System overview

```mermaid
flowchart TB
    subgraph A["PART A — Corpus foundation"]
        A1[Parse<br/>offsets preserved] --> A2[Link families<br/>base + amendments]
        A2 --> A3[Segment sections<br/>Article / Schedule tree]
        A3 --> A4[Extract defined terms]
        A4 --> A5[Load GT<br/>split at FAMILY level]
    end

    subgraph B["PART B — Grounding probe (no LLM)"]
        B1[Matcher cascade<br/>exact / norm / fuzzy] --> B2[Diagnostics<br/>hit rate · ambiguity · entropy]
        B2 --> B3[Rule induction<br/>reproduce from other fields]
        B3 --> B4[Tier assignment<br/>T0 – T5]
    end

    subgraph C["PART C — Spec authoring"]
        C1[Auto-draft 200 specs] --> C2[Confusable pairs<br/>from span overlap]
        C2 --> C3[Harvest few-shots<br/>incl. abstention case]
        C3 --> C4[Human pass<br/>discriminators · T3/T4 rules]
    end

    D["PART D — Prompt compiler<br/>7 archetypes · lint · DAG check"]

    subgraph E["PART E/F — Runtime"]
        E1[Retrieval planner] --> E2[Agent per entity]
        E2 --> E3[Claims<br/>value + evidence + confidence]
        E3 --> E4[Confidence routing]
        E4 --> F1[Derivative DAG<br/>deterministic]
    end

    subgraph G["PART G — RLM mining"]
        G1[Invert the task:<br/>given the answer, find the derivation]
    end

    subgraph H["PART H — Optimization"]
        H1[Error taxonomy] --> H2[Label audit]
        H2 --> H3[Ralph + GEPA<br/>mutate the SPEC]
    end

    subgraph J["PART J — Discovery"]
        J1[Residual spans] --> J2[Cluster corpus-wide]
        J2 --> J3[Deviation + contradictions]
        J3 --> J4[Adjudication board]
    end

    A5 --> B1
    B4 --> C1
    C4 --> D
    D --> E1
    F1 --> EV[PART E.3<br/>per-field eval + gates]
    EV -->|below gate| H1
    H3 -->|new spec version| D
    B4 -->|T4 / T5 unresolved| G1
    G1 -->|derivation recipe| C4
    F1 --> J1
    J4 -->|new_entity_spec| C1
    EV -->|at gate| I[PART I — Release<br/>pin · test once · full 20K run]

    classDef noLLM fill:#e8f4e8,stroke:#4a7c4a
    classDef llm fill:#e8eef8,stroke:#4a5c8c
    class B1,B2,B3,B4,F1 noLLM
    class E2,G1,H3 llm
```

Green = no model in the loop. Roughly a third of the pipeline, including the single
highest-leverage stage, is deterministic.

---

## 2. Tier decision — how a field gets its archetype

```mermaid
flowchart TD
    S[Field with N labeled values] --> P{Value appears<br/>literally in text?}
    P -->|hit ≥ 0.85| Q{Value type}
    P -->|hit < 0.85| R{Reproducible from<br/>other GT fields ≥ 0.98?}

    Q -->|string| T0A["T0 · span_extract"]
    Q -->|closed set| T0B["T0 · enum_classify"]
    Q -->|money / date / pct| T1["T1 · normalize_extract"]
    Q -->|list / table| T2["T2 · table_extract"]

    R -->|yes| T3["T3 · derive_deterministic<br/>NO extraction prompt<br/>code owns the value"]
    R -->|no| U{Needs the<br/>amendment chain?}
    U -->|yes| T5["T5 · crossref_resolve"]
    U -->|no| T4["T4 · rule_apply<br/>→ RLM derivation mining"]

    classDef code fill:#e8f4e8,stroke:#4a7c4a,stroke-width:2px
    class T3 code
```

Expected distribution across 200 fields: ~60% T0–T2, ~25% T3, ~15% T4–T5. Only the
last slice needs real prompt engineering.

---

## 3. One field, one document — extraction sequence

```mermaid
sequenceDiagram
    participant R as Retrieval planner
    participant DB as PostgreSQL
    participant A as LlmAgent (per entity)
    participant M as Gemini 2.5 Flash
    participant V as Validators
    participant X as RLM tier
    participant H as HITL queue

    R->>DB: section anchors → char window
    alt anchor hits
        DB-->>R: section span
    else anchor stale
        DB-->>R: defined-term trace / whole doc
        Note over R: fallback rung is itself a<br/>diagnostic — stale anchors are a<br/>RETRIEVAL fix, not a prompt fix
    end
    R->>A: evidence window + prompt artifact
    A->>M: compiled prompt
    M-->>A: JSON claim (value, span, confidence, abstain)
    A->>DB: write extraction_claim<br/>(span made document-absolute)

    alt confidence ≥ auto_accept
        A->>DB: route = accept
    else ≥ validate
        A->>V: run validators
        V-->>A: pass → accept / fail → escalate
    else ≥ escalate_rlm
        A->>X: recursive walk over document family
        X-->>A: claim or abstain
    else abstain or very low
        A->>H: leverage-sorted queue
    end
```

---

## 4. Derivative DAG

```mermaid
flowchart LR
    subgraph EX["Extracted (T0–T2)"]
        RC[revolving_commitment_total]
        TLA[term_loan_a_principal<br/>optional]
        TLB[term_loan_b_principal<br/>optional]
        FC[facility_currency]
    end

    subgraph DV["Derived (T3) — code, not prompts"]
        TFS[total_facility_size]
    end

    subgraph JD["Judgment (T4)"]
        HTL[has_term_loan_tranche]
        CL[is_covenant_lite]
    end

    RC --> TFS
    TLA --> TFS
    TLB --> TFS
    FC -.currency precondition.-> TFS
    TLA --> HTL
    HTL --> CL

    TFS --> CON{derived ≠<br/>stated in doc?}
    CON -->|yes| DISC[contradiction event<br/>→ discovery loop]

    classDef code fill:#e8f4e8,stroke:#4a7c4a
    class TFS code
```

`coalesce(x, 0)` means an absent optional tranche contributes nothing — deliberately
different from a tranche present with value zero. Cycles are detected at compile time;
a cycle found on document 14,000 of 20,000 is an expensive way to learn about a spec
error.

---

## 5. Spec lifecycle

```mermaid
stateDiagram-v2
    [*] --> Drafted: probe auto-draft
    Drafted --> Authored: human writes discriminator<br/>+ T3/T4 rules
    Authored --> Compiled: compiler.py (lint + DAG)
    Compiled --> Evaluated: dev split
    Evaluated --> AtGate: acc ≥ 0.90 and IoU ≥ 0.50
    Evaluated --> BelowGate: otherwise

    BelowGate --> ErrorClassified: retrieval / prompt /<br/>normalization / label
    ErrorClassified --> Authored: anchor or normalization fix
    ErrorClassified --> Optimizing: prompt-class error
    ErrorClassified --> LabelAudit: ambiguous
    LabelAudit --> Evaluated

    Optimizing --> Compiled: GEPA writes version+1
    Optimizing --> HumanOnly: N rounds, no gain

    AtGate --> Released: pinned in spec_release
    Released --> Frozen: regression-suite protected
    Frozen --> Authored: version+1 on any change
    HumanOnly --> [*]
```

Versions are immutable. A change is always `version + 1`, never an in-place edit.

---

## 6. Optimization loop (Ralph + GEPA)

```mermaid
flowchart TD
    F[Field below gate] --> T{Dominant<br/>error class}
    T -->|retrieval| M1[widen / narrow anchors]
    T -->|prompt| M2[reselect few-shots<br/>strengthen discriminator<br/>swap archetype]
    T -->|normalization| M3[tighten normalization rule]
    T -->|label| LA[adjudicate GT<br/>NOT an optimization problem]

    M1 & M2 & M3 --> K[K=4 spec candidates<br/>ParallelAgent fan-out]
    K --> RC[Recompile prompts]
    RC --> EV[Dev minibatch eval]
    EV --> PA{Improves target<br/>AND regresses nothing?}
    PA -->|yes| W[Write spec version+1]
    PA -->|no| N{rounds < N?}
    N -->|yes| K
    N -->|no| ESC[RLM tier or human_only]
    W --> EV2[Full dev eval] --> DONE[At gate]

    classDef warn fill:#f8e8e8,stroke:#8c4a4a
    class LA warn
```

Running GEPA on a retrieval failure burns budget and improves nothing. The taxonomy
step is what makes the loop targeted rather than superstitious.

---

## 7. Discovery loop

```mermaid
flowchart LR
    CL[Accepted claims] --> MASK[Mask consumed spans]
    MASK --> RES[Residual spans]
    RES --> SAL{Salient?<br/>obligations · money ·<br/>high-value sections}
    SAL -->|no| DROP[discard]
    SAL -->|yes| CLU[Cluster corpus-wide]

    DAG[Derivative DAG] --> CONT[Contradiction events]
    DIST[Clause distribution<br/>per section type] --> DEV[Deviation outliers]

    CLU --> LEV[leverage =<br/>frequency × proximity × novelty]
    CONT --> LEV
    DEV --> LEV
    LEV --> BOARD[Cluster Adjudication Board]

    BOARD --> N1[new_entity_spec]
    BOARD --> N2[validator_rule]
    BOARD --> N3[decision_branch]
    BOARD --> N4[human_only]
    N1 --> SPEC[back to PART C]
```

A residual pattern in 4,000 agreements is a missing field. One in 3 agreements is a
bespoke term — flag it, don't schematize it.

---

## 8. Data model

```mermaid
erDiagram
    document ||--|| document_text : has
    document ||--o{ document_section : segmented_into
    document ||--o{ defined_term : defines
    document ||--o{ ground_truth : labeled_by
    document }o--|| document_family : belongs_to

    entity_spec ||--o{ prompt_artifact : compiles_to
    entity_spec ||--o{ tier_assignment : classified_by
    spec_release ||--o{ prompt_artifact : pins

    extraction_run ||--o{ extraction_claim : produces
    extraction_claim ||--o{ validator_result : checked_by
    extraction_claim ||--o{ derived_value : feeds
    extraction_claim ||--o{ residual_span : leaves

    ground_truth ||--o{ probe_hit : located_by
    probe_hit ||--o{ eval_result : scores
    residual_span ||--o{ discovery_candidate : clusters_into
```

---

## 9. Deployment topology

```mermaid
flowchart TB
    subgraph OCP["OpenShift — multi-cluster"]
        subgraph CTRL["Control plane"]
            REG[Spec registry<br/>hot-reload on release]
            SCHED[Work scheduler<br/>SELECT FOR UPDATE SKIP LOCKED]
        end
        subgraph WRK["Extraction workers (scale-out)"]
            SEQ[SequentialAgent] --> PAR[ParallelAgent fan-out]
            PAR --> AG1[LlmAgent · field 1]
            PAR --> AG2[LlmAgent · field N]
        end
        subgraph ESC["Escalation"]
            RLM[RLM tier<br/>budgeted, alarmed]
        end
        DET[Derivative DAG executor<br/>no model calls]
    end

    PG[(PostgreSQL<br/>sole state store)]
    GEM[Gemini 2.5<br/>Flash / Pro]

    REG --> WRK
    SCHED <--> PG
    WRK <--> PG
    AG1 & AG2 --> GEM
    WRK -->|low confidence| RLM --> GEM
    WRK --> DET --> PG
    PG -.LISTEN/NOTIFY.-> SCHED
```

Adding a field is a YAML file plus a release. No code change, no deploy.

---

## 10. Cost shape

```mermaid
flowchart LR
    N["200 fields × 20,000 docs"] --> A["Naive: one call per field<br/>4,000,000 calls"]
    N --> B["Bundled by section anchor<br/>~25 bundles/doc<br/>500,000 calls"]
    B --> C["Per-entity prompts remain<br/>the canonical unit —<br/>bundles concatenate blocks"]
    B --> D["+ RLM escalation<br/>budgeted at ≤5% of sessions"]

    classDef bad fill:#f8e8e8,stroke:#8c4a4a
    class A bad
```

Bundling is a runtime packing decision. Versioning, evaluation, and GEPA optimization
all continue to operate on the per-entity prompt.
